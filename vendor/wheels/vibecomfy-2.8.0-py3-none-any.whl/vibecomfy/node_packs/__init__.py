from __future__ import annotations

# Lazy-load submodules via __getattr__ to avoid circular imports during
# startup. Eagerly importing _install / _git here would pull in
# vibecomfy.registry (and transitively vibecomfy.ingest) before they are ready.

__all__ = [
    # _defs
    "CustomNodePack",
    "clear_known_node_packs_cache",
    "get_known_node_packs",
    "resolve_node_packs",
    "unresolved_class_types",
    # registry.pack_resolver
    "PackNotFoundError",
    "PackRef",
    "resolve_pack",
    # _git
    "InstalledPackGitRef",
    "find_installed_pack_ref",
    # _install
    "CORE_COMFY_CLASSES",
    "DEFAULT_INSTALL_ROOT",
    "INSTALL_STATE_DIR",
    "InstallBatchResult",
    "PackInstallState",
    "InstallResult",
    "InstallStatus",
    "PipPreflightResult",
    "Runner",
    "default_install_root",
    "build_install_refs_by_name",
    "install_pack",
    "install_required_packs",
    "inspect_pack_install_state",
    "missing_class_types_for_workflow",
    "missing_packs_for_workflow",
    "preflight_pip_requirements",
    "restore_pack",
    "validate_install_refs",
    # _lockfile
    "LockEntry",
    "canonical_class_schema_projection",
    "canonical_pack_schema_projection",
    "compute_schema_hash",
    "read_lockfile",
    "resolve_lockfile_path",
    "upsert_lockfile_entry",
    "write_lockfile",
]

_MODULE_BY_ATTR: dict[str, str] = {}


def _init_module_map() -> dict[str, str]:
    """Build the attr→submodule mapping once."""
    global _MODULE_BY_ATTR
    if _MODULE_BY_ATTR:
        return _MODULE_BY_ATTR

    _defs_names = {
        "CustomNodePack",
        "clear_known_node_packs_cache",
        "get_known_node_packs",
        "resolve_node_packs",
        "unresolved_class_types",
    }
    _git_names = {"InstalledPackGitRef", "find_installed_pack_ref"}
    _install_names = {
        "CORE_COMFY_CLASSES",
        "DEFAULT_INSTALL_ROOT",
        "INSTALL_STATE_DIR",
        "InstallBatchResult",
        "PackInstallState",
        "InstallResult",
        "InstallStatus",
        "PipPreflightResult",
        "Runner",
        "default_install_root",
        "build_install_refs_by_name",
        "install_pack",
        "install_required_packs",
        "inspect_pack_install_state",
        "missing_class_types_for_workflow",
        "missing_packs_for_workflow",
        "preflight_pip_requirements",
        "restore_pack",
        "validate_install_refs",
    }
    _lockfile_names = {
        "LockEntry",
        "canonical_class_schema_projection",
        "canonical_pack_schema_projection",
        "compute_schema_hash",
        "read_lockfile",
        "resolve_lockfile_path",
        "upsert_lockfile_entry",
        "write_lockfile",
    }
    for n in _defs_names:
        _MODULE_BY_ATTR[n] = "._defs"
    for n in {"PackNotFoundError", "PackRef", "resolve_pack"}:
        _MODULE_BY_ATTR[n] = "..registry.pack_resolver"
    for n in _git_names:
        _MODULE_BY_ATTR[n] = "._git"
    for n in _install_names:
        _MODULE_BY_ATTR[n] = "._install"
    for n in _lockfile_names:
        _MODULE_BY_ATTR[n] = "._lockfile"
    return _MODULE_BY_ATTR


def __getattr__(name: str):
    import importlib

    _init_module_map()
    modname = _MODULE_BY_ATTR.get(name)
    if modname is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    mod = importlib.import_module(modname, __package__)
    attr = getattr(mod, name)
    # Cache in the module's globals so __getattr__ is not called again.
    globals()[name] = attr
    return attr
