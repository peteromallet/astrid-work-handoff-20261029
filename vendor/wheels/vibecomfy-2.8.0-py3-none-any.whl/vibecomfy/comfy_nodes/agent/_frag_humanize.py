"""
Humanize/narrative rendering helpers (T-038 extraction of the edit_humanize fragment).

Extracted from the edit.py exec-assembled fragments (T-038, ORACLE-6).
The fragment SOURCE string stays in edit.py until T-041 removes the machinery;
this module is the live implementation. Imports of sibling _frag modules follow
the foundation dependency order; names that would form an import cycle are
resolved lazily at call time (marked with a T-038 late import comment).
"""
from vibecomfy.ingest.normalize import door_get_links, door_get_widgets_values
import json
import os
import re
from pathlib import Path
from typing import Any, Mapping
from vibecomfy.comfy_nodes.agent.audit import write_json_artifact
from vibecomfy.comfy_nodes.agent.contracts import ApplyEligibility, FailureEnvelope, FailureKind, StageResult, TurnContext, TurnOutcome, _ABSENT_FIELD_OLD, _MISSING_FIELD_CHANGE_OLD, _iter_ui_graph_nodes, _ui_node_uid, _ui_node_uid_aliases, _ui_widget_value_for_field
from vibecomfy.comfy_nodes.agent.provider import MalformedModelJSON, MissingRequiredField, ProviderError, ensure_sentence_message
from vibecomfy.executor.revision_evidence import semantic_graph_hash
from vibecomfy.porting.edit.types import FieldChange
from ._frag_chat import _json_safe
from ._frag_state import (
    AgentEditState,
    _accepted_batch_field_changes,
    _accepted_batch_statements,
    _total_landed_edit_count,
)

def _field_change_is_noop(
    change: FieldChange,
    *,
    lint_dropped_op_ids: frozenset[tuple[str, str]] | None = None,
) -> bool:
    """Return True when *change* is a no-op.

    By default a change is a no-op when the old value is present and
    matches the new value.  When ``lint_dropped_op_ids`` is provided,
    any field change whose ``(uid, field_path)`` appears in that set is
    ALSO classified as a no-op — lint-owned classification wins.
    """
    if lint_dropped_op_ids is not None:
        key = (change.uid, change.field_path)
        if key in lint_dropped_op_ids:
            return True
    return change.old is not _ABSENT_FIELD_OLD and change.old == change.new


def _real_field_changes(
    changes: tuple[FieldChange, ...],
    *,
    lint_dropped_op_ids: frozenset[tuple[str, str]] | None = None,
) -> tuple[FieldChange, ...]:
    return tuple(
        change
        for change in changes
        if not _field_change_is_noop(change, lint_dropped_op_ids=lint_dropped_op_ids)
    )


def _net_field_changes(changes: tuple[FieldChange, ...]) -> tuple[FieldChange, ...]:
    """Collapse an edit history into the original-to-final public diff.

    Batch turns are an audit log and may write the same field repeatedly while
    the agent revises its approach.  Public outcome/change surfaces must not
    expose those abandoned intermediate values as separate final edits.
    """
    by_field: dict[tuple[str, str], FieldChange] = {}
    field_order: list[tuple[str, str]] = []
    for change in changes:
        key = (change.uid, change.field_path)
        previous = by_field.get(key)
        if previous is None:
            field_order.append(key)
            by_field[key] = change
            continue
        by_field[key] = FieldChange(
            uid=change.uid,
            field_path=change.field_path,
            old=previous.old,
            new=change.new,
        )
    return _real_field_changes(tuple(by_field[key] for key in field_order))


def _noop_field_changes(
    changes: tuple[FieldChange, ...],
    *,
    lint_dropped_op_ids: frozenset[tuple[str, str]] | None = None,
) -> tuple[FieldChange, ...]:
    return tuple(
        change
        for change in changes
        if _field_change_is_noop(change, lint_dropped_op_ids=lint_dropped_op_ids)
    )


def _batch_candidate_graph_changed(state: AgentEditState) -> bool:
    if not isinstance(state.ui_payload, Mapping) or not isinstance(state.graph, Mapping):
        return False
    return semantic_graph_hash(state.ui_payload) != semantic_graph_hash(state.graph)

def _landed_edit_lead(state: AgentEditState) -> str:
    count = _total_landed_edit_count(state)
    if count <= 0:
        return ""
    noun = "edit" if count == 1 else "edits"
    return f"Applied {count} {noun}."


def _display_value(value: Any, *, limit: int = 48) -> str:
    if isinstance(value, str):
        text = value
    elif value is None:
        text = "null"
    elif isinstance(value, (int, float, bool)):
        text = str(value)
    else:
        try:
            text = json.dumps(_json_safe(value), sort_keys=True)
        except (TypeError, ValueError):
            text = str(value)
    text = " ".join(text.split())
    if len(text) > limit:
        return text[: max(0, limit - 1)] + "…"
    return text


def _node_label_by_uid(*graphs: Mapping[str, Any] | None) -> dict[str, str]:
    labels: dict[str, str] = {}
    for graph in graphs:
        if not isinstance(graph, Mapping):
            continue
        for node in _iter_ui_graph_nodes(graph):
            class_type = node.get("type") or node.get("class_type")
            title = node.get("title")
            label = title if isinstance(title, str) and title.strip() else class_type
            if isinstance(label, str) and label.strip():
                for uid in _ui_node_uid_aliases(node):
                    labels[str(uid)] = label.strip()
    return labels


def _change_subject(change: FieldChange, labels: Mapping[str, str] | None = None) -> str:
    uid = str(change.uid or "node").strip() or "node"
    field = str(change.field_path or "field").strip() or "field"
    label = labels.get(uid) if labels else None
    if isinstance(label, str) and label.strip():
        return f"{label.strip()} {field}"
    if labels is not None and _looks_internal_uid(uid):
        return f"node {field}"
    return f"{uid}.{field}"


def _looks_internal_uid(uid: str) -> bool:
    return bool(re.fullmatch(r"n\d+|.*_\d+|\d+", uid.strip()))


def _link_endpoint_parts(value: Any) -> tuple[str, int | str] | None:
    """Return ``(uid, output_slot)`` for supported FieldChange link endpoint shapes.

    Accepts both ``list`` / ``tuple`` and the batch editor's mapping form because
    ``FieldChange.__post_init__`` freezes JSON-ish mappings into ``MappingProxyType``.
    """
    if (
        isinstance(value, (list, tuple))
        and len(value) == 2
        and isinstance(value[0], (int, str))
        and isinstance(value[1], int)
    ):
        return str(value[0]), value[1]
    if isinstance(value, Mapping):
        uid = value.get("uid")
        output_slot = value.get("output_slot")
        if isinstance(uid, (int, str)) and isinstance(output_slot, (int, str)):
            return str(uid), output_slot
    return None


def _is_link_endpoint(value: Any) -> bool:
    return _link_endpoint_parts(value) is not None


def _resolve_output_slot_name(graph: Mapping[str, Any], uid: str, slot_index: int | str) -> str | None:
    """Return the human-readable output-slot name for *uid* / *slot_index*, or None."""
    if isinstance(slot_index, str):
        return slot_index
    for node in _iter_ui_graph_nodes(graph):
        if uid not in _ui_node_uid_aliases(node):
            continue
        outputs = node.get("outputs")
        if isinstance(outputs, list) and 0 <= slot_index < len(outputs):
            entry = outputs[slot_index]
            if isinstance(entry, Mapping):
                name = entry.get("name")
                if isinstance(name, str) and name.strip():
                    return name.strip()
        break
    return None


def _resolve_endpoint_label(
    endpoint: Any,
    node_labels: Mapping[str, str],
    graph: Mapping[str, Any],
    *fallback_graphs: Mapping[str, Any] | None,
) -> str:
    """Resolve a link endpoint ``[uid, slot]`` to a label like ``'VAE Decode IMAGE'``."""
    parts = _link_endpoint_parts(endpoint)
    if parts is None:
        return "unknown source"
    uid, slot = parts
    node_label = node_labels.get(uid)
    slot_name = _resolve_output_slot_name(graph, uid, slot)
    if slot_name is None:
        for fallback_graph in fallback_graphs:
            if isinstance(fallback_graph, Mapping):
                slot_name = _resolve_output_slot_name(fallback_graph, uid, slot)
                if slot_name is not None:
                    break
    if node_label and slot_name:
        return f"{node_label} {slot_name}"
    if node_label:
        return node_label
    if slot_name:
        return slot_name
    return "unknown source"


def _ui_node_by_uid(graph: Mapping[str, Any] | None) -> dict[str, Mapping[str, Any]]:
    if not isinstance(graph, Mapping):
        return {}
    result: dict[str, Mapping[str, Any]] = {}
    for node in _iter_ui_graph_nodes(graph):
        uid = _ui_node_uid(node)
        if uid:
            result[str(uid)] = node
    return result


def _node_class_label(node: Mapping[str, Any]) -> str:
    class_type = node.get("type") or node.get("class_type")
    if isinstance(class_type, str) and class_type.strip():
        return class_type.strip()
    title = node.get("title")
    if isinstance(title, str) and title.strip():
        return title.strip()
    return "node"


def _ui_display_widget_value_for_field(node: Mapping[str, Any], field: str) -> Any:
    widgets = node.get("widgets")
    widgets_values = door_get_widgets_values(node)
    if isinstance(widgets, list) and isinstance(widgets_values, list):
        for index, widget in enumerate(widgets):
            if (
                isinstance(widget, Mapping)
                and widget.get("name") == field
                and index < len(widgets_values)
            ):
                return widgets_values[index]
    return _ui_widget_value_for_field(node, field)


def _node_key_values(node: Mapping[str, Any]) -> list[str]:
    values: list[str] = []
    for field in ("scale_by", "scale", "upscale_method", "filename_prefix", "seed", "steps", "denoise"):
        value = _ui_display_widget_value_for_field(node, field)
        if value is _MISSING_FIELD_CHANGE_OLD:
            continue
        if field in {"scale_by", "scale"} and isinstance(value, (int, float)) and 0 < float(value) <= 1:
            values.append(f"{round(float(value) * 100):g}%")
        elif field == "filename_prefix":
            values.append(str(value))
        else:
            values.append(_display_value(value, limit=28))
    return values[:3]


def _node_phrase(node: Mapping[str, Any]) -> str:
    label = _node_class_label(node)
    values = _node_key_values(node)
    if values:
        return f"{label} ({', '.join(values)})"
    return label


def _article_for(text: str) -> str:
    first = text[:1].lower()
    return "an" if first in {"a", "e", "i", "o", "u"} else "a"


def _first_link_source_label(
    node: Mapping[str, Any],
    graph: Mapping[str, Any] | None,
    labels: Mapping[str, str],
) -> str | None:
    if not isinstance(graph, Mapping):
        return None
    inputs = node.get("inputs")
    links = door_get_links(graph)
    if not isinstance(inputs, list) or not isinstance(links, list):
        return None
    link_id = None
    for input_slot in inputs:
        if isinstance(input_slot, Mapping) and isinstance(input_slot.get("link"), (int, float)):
            link_id = int(input_slot["link"])
            break
    if link_id is None:
        return None
    by_id: dict[int, Any] = {}
    for link in links:
        if isinstance(link, Mapping) and isinstance(link.get("id"), (int, float)):
            by_id[int(link["id"])] = link
        elif isinstance(link, (list, tuple)) and link and isinstance(link[0], (int, float)):
            by_id[int(link[0])] = link
    link = by_id.get(link_id)
    if isinstance(link, Mapping):
        source_id = link.get("origin_id")
        source_slot = link.get("origin_slot", 0)
    elif isinstance(link, (list, tuple)) and len(link) >= 3:
        source_id = link[1]
        source_slot = link[2]
    else:
        return None
    source_uid = None
    for candidate in _iter_ui_graph_nodes(graph):
        if candidate.get("id") == source_id:
            source_uid = _ui_node_uid(candidate)
            break
    if not source_uid:
        return None
    return _resolve_endpoint_label({"uid": source_uid, "output_slot": source_slot}, labels, graph)


def _delta_structural_uids(state: AgentEditState) -> tuple[set[str], set[str]]:
    """Return ``(added_uids, removed_uids)`` from the accepted Δ statements.

    add_node (``node_call``) / ``remove_node`` statements of the accepted
    batch are the Δ's structural claims; the summary phrases are derived from
    them so prose can never claim a structural change the accepted batch did
    not land.  Only the accepted Δ (the batch) is consumed — no parallel
    delta-op envelope.
    """
    added: set[str] = set()
    removed: set[str] = set()
    for statement in _accepted_batch_statements(state):
        kind = statement.get("op_kind")
        uids = statement.get("touched_uids") or ()
        if kind == "node_call":
            for uid in uids:
                if uid is not None:
                    added.add(str(uid))
        elif kind == "remove_node":
            for uid in uids:
                if uid is not None:
                    removed.add(str(uid))
    return added, removed


def _structural_change_phrases(state: AgentEditState, labels: Mapping[str, str]) -> list[str]:
    added_uids, removed_uids = _delta_structural_uids(state)
    if not added_uids and not removed_uids:
        # No Δ structural ops: fall back to the graph boundary diff so
        # synthetic/pre-batch states (no batch evidence) still render.  In
        # the live loop the Δ ops are always present and are the source of
        # truth.
        before_by_uid = _ui_node_by_uid(state.graph)
        after_by_uid = _ui_node_by_uid(state.ui_payload)
        if not after_by_uid:
            return []
        added_uids = set(after_by_uid) - set(before_by_uid)
        removed_uids = set(before_by_uid) - set(after_by_uid)
    else:
        after_by_uid = _ui_node_by_uid(state.ui_payload)
        before_by_uid = _ui_node_by_uid(state.graph)
        # Keep only uids we can resolve; unknown uids never become prose.
        added_uids = {uid for uid in added_uids if uid in after_by_uid}
        removed_uids = {uid for uid in removed_uids if uid in before_by_uid}
    if not after_by_uid and not before_by_uid:
        return []
    added = [after_by_uid[uid] for uid in sorted(added_uids)]
    removed = [before_by_uid[uid] for uid in sorted(removed_uids)]
    phrases: list[str] = []
    if added:
        parts: list[str] = []
        for node in added[:8]:
            node_text = _node_phrase(node)
            source = _first_link_source_label(node, state.ui_payload, labels)
            if source:
                node_text = f"{node_text} fed by {source}"
            parts.append(node_text)
        text = _join_human_list(parts)
        remaining = len(added) - len(parts)
        if remaining > 0:
            noun = "other node" if remaining == 1 else "other nodes"
            text = f"{text}, plus {remaining} {noun}"
        article = _article_for(parts[0]) if len(parts) == 1 else ""
        phrases.append(f"added {article + ' ' if article else ''}{text}")
    if removed:
        parts = [_node_phrase(node) for node in removed[:3]]
        phrases.append(f"removed {_join_human_list(parts)}")
    return phrases


def _join_human_list(parts: list[str]) -> str:
    if not parts:
        return ""
    if len(parts) == 1:
        return parts[0]
    if len(parts) == 2:
        return f"{parts[0]} and {parts[1]}"
    return f"{', '.join(parts[:-1])}, and {parts[-1]}"


def _human_change_phrase(
    change: FieldChange,
    labels: Mapping[str, str] | None = None,
    *,
    graph: Mapping[str, Any] | None = None,
    old_graph: Mapping[str, Any] | None = None,
    new_graph: Mapping[str, Any] | None = None,
) -> str:
    subject = _change_subject(change, labels)
    if graph is not None and labels is not None:
        old_endpoint_graph = old_graph if isinstance(old_graph, Mapping) else graph
        new_endpoint_graph = new_graph if isinstance(new_graph, Mapping) else graph
        old_link = _is_link_endpoint(change.old)
        new_link = _is_link_endpoint(change.new)
        if old_link and new_link:
            old_label = _resolve_endpoint_label(change.old, labels, old_endpoint_graph, graph, new_graph)
            new_label = _resolve_endpoint_label(change.new, labels, new_endpoint_graph, graph, old_graph)
            return f"rewired {subject} to come from {new_label} instead of {old_label}"
        if new_link and not old_link:
            new_label = _resolve_endpoint_label(change.new, labels, new_endpoint_graph, graph, old_graph)
            return f"connected {subject} to {new_label}"
        if old_link and not new_link:
            old_label = _resolve_endpoint_label(change.old, labels, old_endpoint_graph, graph, new_graph)
            return f"disconnected {subject} from {old_label}"
    if change.old is None or change.old is _ABSENT_FIELD_OLD:
        return f"set {subject} to {_display_value(change.new)}"
    return (
        f"updated {subject} from "
        f"{_display_value(change.old)} to {_display_value(change.new)}"
    )


def _sentence_case(text: str) -> str:
    stripped = text.strip()
    if not stripped:
        return ""
    return stripped[0].upper() + stripped[1:]


def _humanized_edit_message(state: AgentEditState) -> str:
    changes = _net_field_changes(_accepted_batch_field_changes(state))
    labels = _node_label_by_uid(state.graph, state.ui_payload)
    structural_phrases = _structural_change_phrases(state, labels)
    if structural_phrases:
        return _sentence_case(
            ensure_sentence_message(
                _join_human_list(structural_phrases),
                fallback="Updated the workflow structure.",
            )
        )
    if not changes:
        return ensure_sentence_message(
            "",
            fallback="The candidate is ready to review.",
        )
    if len(changes) == 1:
        return _sentence_case(
            ensure_sentence_message(
                _human_change_phrase(
                    changes[0],
                    labels,
                    graph=state.graph,
                    old_graph=state.graph,
                    new_graph=state.ui_payload,
                ),
                fallback="Updated the workflow.",
            )
        )
    phrases = [
        _human_change_phrase(
            change,
            labels,
            graph=state.graph,
            old_graph=state.graph,
            new_graph=state.ui_payload,
        )
        for change in changes[:3]
    ]
    if len(changes) == 2:
        text = f"{phrases[0]} and {phrases[1]}"
    else:
        text = f"{phrases[0]}, {phrases[1]}, and {phrases[2]}"
        remaining = len(changes) - 3
        if remaining > 0:
            noun = "other field" if remaining == 1 else "other fields"
            text = f"{text}, plus {remaining} {noun}"
    return _sentence_case(ensure_sentence_message(text, fallback=f"Updated {len(changes)} workflow fields."))


def _terminal_answer_message(state: AgentEditState) -> str | None:
    from ._frag_batch_reports import _BATCH_EXIT_NOOP  # T-038 late import: sibling cycle broken; resolved at call time
    if state.lint_noop_messages or state.batch_noop_field_changes or state.batch_field_changes:
        return None
    if state.batch_exit_mode != _BATCH_EXIT_NOOP:
        return None

    for turn in reversed(state.batch_turns or []):
        if not isinstance(turn, Mapping):
            continue
        statements = turn.get("statements")
        has_terminal_done = False
        if isinstance(statements, list):
            has_terminal_done = any(
                isinstance(stmt, Mapping) and stmt.get("op_kind") == "done"
                for stmt in statements
            )
        batch = turn.get("batch")
        if not has_terminal_done and isinstance(batch, str):
            has_terminal_done = batch.strip().startswith("done(")
        if not has_terminal_done:
            continue
        message = turn.get("message")
        if isinstance(message, str) and message.strip():
            return ensure_sentence_message(message.strip(), fallback="No graph changes were needed.")
    return None


def _humanized_noop_message(state: AgentEditState) -> str:
    revision_message = _revision_rejected_candidate_message(state)
    if revision_message:
        return revision_message

    # Prefer lint normalization messages when available (they carry
    # class/title/field/slot context and avoid raw gate text or uids).
    if state.lint_noop_messages:
        msgs = state.lint_noop_messages
        if len(msgs) == 1:
            return _sentence_case(ensure_sentence_message(msgs[0], fallback="No change needed."))
        return "The requested changes are already in place; no updates needed."

    changes = tuple(state.batch_noop_field_changes or ())
    labels = _node_label_by_uid(state.graph, state.ui_payload)
    if len(changes) == 1:
        change = changes[0]
        return _sentence_case(
            ensure_sentence_message(
                f"{_change_subject(change, labels)} is already {_display_value(change.new)}; no change needed",
                fallback="No change needed.",
            )
        )
    if len(changes) > 1:
        return "The requested fields already match the current graph; no change needed."
    answer = _terminal_answer_message(state)
    if answer:
        return answer
    summary = (state.batch_done_summary or "").strip()
    gate_jargon = bool(re.search(r"\bGate\s+[AB]\b|identity verified|No operations were applied", summary, re.I))
    if summary and not gate_jargon:
        return ensure_sentence_message(summary, fallback="No graph changes were needed.")
    if gate_jargon:
        return "Nothing needed changing; the workflow already matches that."
    return "No graph changes were needed."


def _revision_rejected_candidate_message(state: AgentEditState) -> str:
    evidence = state.revision_evidence
    scoped = evidence.scoped_diff if evidence is not None else None
    if evidence is None or scoped is None or evidence.candidate_eligible is True:
        return ""
    blockers = list(scoped.eligibility_blockers or ())
    mismatch_reasons = [
        str(item.get("reason") or "").strip()
        for item in evidence.topology.socket_type_mismatches
        if isinstance(item, Mapping) and str(item.get("reason") or "").strip()
    ]
    if "candidate_topology_blockers" in blockers and mismatch_reasons:
        return ensure_sentence_message(
            "I left the graph unchanged because the candidate did not repair existing socket type mismatches first: "
            + "; ".join(mismatch_reasons[:3]),
            fallback="I left the graph unchanged because the candidate would not produce a valid workflow.",
        )
    if blockers:
        return ensure_sentence_message(
            "I left the graph unchanged because the candidate was not safe to apply: "
            + ", ".join(blockers),
            fallback="I left the graph unchanged because the candidate was not safe to apply.",
        )
    return "I left the graph unchanged because the candidate was not safe to apply."


def _revision_candidate_retry_hint(state: AgentEditState) -> str:
    message = _revision_rejected_candidate_message(state)
    evidence = state.revision_evidence
    mismatch_reasons = []
    if evidence is not None:
        mismatch_reasons = [
            str(item.get("reason") or "").strip()
            for item in evidence.topology.socket_type_mismatches
            if isinstance(item, Mapping) and str(item.get("reason") or "").strip()
        ]
    details = "; ".join(mismatch_reasons[:3])
    if details:
        return (
            "the candidate still leaves invalid graph wiring. Repair these existing "
            f"socket mismatches first: {details}. Then add the save/export path. "
            "Prefer installed local nodes from search results such as CreateVideo -> SaveVideo "
            "or SaveAnimatedWEBP when their signatures are available; use vibecomfy.exec only "
            "for explicit code/Python requests or when no installed node path exists."
        )
    return (
        (message or "the candidate was not safe to apply")
        + " Fix the reported eligibility blockers, then call done() again."
    )


def _operation_detail_payload(changes: tuple[FieldChange, ...]) -> list[dict[str, Any]]:
    return [
        {
            **change.to_dict(),
            "summary": (
                f"Set {_change_subject(change)} to {_display_value(change.new)}."
                if change.old is None or change.old is _ABSENT_FIELD_OLD
                else (
                    f"Changed {_change_subject(change)} from "
                    f"{_display_value(change.old)} to {_display_value(change.new)}."
                )
            ),
        }
        for change in _real_field_changes(changes)
    ]


def _change_details_payload(state: AgentEditState, context: TurnContext) -> dict[str, Any]:
    gate_snapshot = context.gate_snapshot()
    gate_a = gate_snapshot.get("edit_scope_ok") or gate_snapshot.get("python_load_ok")
    gate_b = gate_snapshot.get("isomorphic_ok") or gate_snapshot.get("ui_fidelity_ok")
    operations = _operation_detail_payload(_net_field_changes(_accepted_batch_field_changes(state)))
    payload = {
        "landed_operation_count": _total_landed_edit_count(state),
        "done_summary": state.batch_done_summary or "",
        "final_summary": state.batch_final_summary or "",
        "gate_a": _json_safe(gate_a),
        "gate_b": _json_safe(gate_b),
        "operations": operations,
        "batch_turns": _json_safe(state.batch_turns),
    }
    advisory = getattr(state, "post_edit_reorganisation_advisory", None)
    if isinstance(advisory, Mapping):
        payload["layout_reorganisation"] = _json_safe(dict(advisory))
    return payload


_NARRATOR_RESPONSE_REQUIRED_FIELD = "message"


def _narrator_system_message() -> str:
    return (
        "You write the final user-facing status line for a completed agent-edit turn. "
        "Use only the provided structured facts. Do not invent edits, validation status, "
        "or apply readiness. Do not mention internal gate labels. Return JSON with a "
        'single string field named "message".\n'
        "You MUST state what happened per these structured fields: whether the graph "
        "changed (change.graph_changed / change.graph_unchanged), the outcome kind "
        "(outcome.kind), and how many operations landed (change.landed_operation_count). "
        "Never claim an edit you did not land: when graph_unchanged is true or "
        "landed_operation_count is 0, you MUST NOT say the graph was edited, applied, "
        "updated, connected, or changed. Never claim validation passed when "
        "validation.passed is false. Describe exactly those facts."
    )


def _narrator_user_message(
    *,
    narrative_context: Mapping[str, Any],
    raw_executor_message: str,
    fallback_message: str,
) -> str:
    request_payload = {
        "instructions": {
            "style": "One or two concise sentences.",
            "must_include": [
                "Describe what actually happened after validation.",
                "Ask a direct question when the outcome requires clarification.",
                "State exactly what the structured facts report: whether the graph changed "
                "(change.graph_unchanged), the outcome kind (outcome.kind), and the landed "
                "operation count (change.landed_operation_count).",
            ],
            "must_avoid": [
                "Internal gate jargon",
                "Contradicting the landed edit count or validation outcome",
                "Claiming an edit you did not land — never say the graph changed, an edit "
                "applied, or a connection was made when graph_unchanged is true or "
                "landed_operation_count is 0",
                "Claiming validation passed when validation.passed is false",
            ],
        },
        "raw_executor_message": raw_executor_message[:240],
        "fallback_message": fallback_message,
        "narrative_context": narrative_context,
    }
    return (
        "Return a JSON object with the final public message for this agent-edit turn.\n"
        + json.dumps(_json_safe(request_payload), indent=2, sort_keys=True)
    )


def _narrator_message_from_response(response: Mapping[str, Any]) -> str:
    response_json = response.get("json")
    if not isinstance(response_json, Mapping):
        raise MalformedModelJSON("Narrator response must include a JSON object.")
    message = response_json.get(_NARRATOR_RESPONSE_REQUIRED_FIELD)
    if not isinstance(message, str) or not message.strip():
        raise MissingRequiredField(
            'Narrator JSON must include non-empty string key "message".'
        )
    return message.strip()


def _narrative_issue_summary(issue: Any) -> str:
    if isinstance(issue, Mapping):
        for key in ("summary", "message", "diagnostic", "reason", "code"):
            value = issue.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()
    text = " ".join(str(issue).split())
    return text[:160] if text else ""


def _narrative_issue_payloads(issues: Any, *, limit: int = 3) -> list[dict[str, Any]]:
    if not isinstance(issues, (list, tuple)):
        return []
    payloads: list[dict[str, Any]] = []
    for issue in issues:
        summary = _narrative_issue_summary(issue)
        if not summary:
            continue
        code = ""
        if isinstance(issue, Mapping):
            raw_code = issue.get("code") or issue.get("kind") or issue.get("severity")
            if isinstance(raw_code, str):
                code = raw_code.strip()
        payload = {"summary": summary}
        if code:
            payload["code"] = code
        payloads.append(payload)
        if len(payloads) >= limit:
            break
    return payloads


def _narrative_stage_payload(result: StageResult | None) -> dict[str, Any] | None:
    if not isinstance(result, StageResult):
        return None
    payload = {
        "ok": result.ok,
        "blocking": result.blocking,
        "issues": _narrative_issue_payloads(result.issues),
    }
    if result.duration_ms is not None:
        payload["duration_ms"] = result.duration_ms
    return payload


def _validation_summary_payload(context: TurnContext) -> dict[str, Any]:
    gate_snapshot = context.gate_snapshot()
    plan_gate = gate_snapshot.get("plan_validate_ok")
    return {
        "passed": bool(
            gate_snapshot.get("ir_validate_ok")
            and gate_snapshot.get("queue_validate_ok")
            and gate_snapshot.get("ui_load_safe_ok")
            and (plan_gate is not False)
        ),
        "canvas_apply_allowed": context.canvas_apply_allowed,
        "queue_allowed": context.queue_allowed,
        "gates": {
            "python_load_ok": gate_snapshot.get("python_load_ok"),
            "ir_validate_ok": gate_snapshot.get("ir_validate_ok"),
            "ui_load_safe_ok": gate_snapshot.get("ui_load_safe_ok"),
            "queue_validate_ok": gate_snapshot.get("queue_validate_ok"),
            "plan_validate_ok": plan_gate,
            "state_match_ok": gate_snapshot.get("state_match_ok"),
        },
        "stages": {
            "lower": _narrative_stage_payload(context.stage_results.get("lower")),
            "validate": _narrative_stage_payload(context.stage_results.get("validate")),
            "queue": _narrative_stage_payload(context.stage_results.get("queue")),
        },
    }


def _narrative_research_payload(state: AgentEditState) -> dict[str, Any]:
    payload: dict[str, Any] = {}
    summary = " ".join((state.collected_research_summary or "").split())
    if summary:
        payload["summary"] = summary[:240]
    warnings: list[str] = []
    for source in getattr(state, "collected_research_sources", ()) or ():
        if isinstance(source, Mapping) and str(source.get("tier", "")).strip():
            warnings.append(str(source.get("tier")).strip())
        elif isinstance(source, str) and source.strip():
            warnings.append(source.strip())
    if warnings:
        payload["warnings"] = warnings[:3]
    plan = state.execution_plan
    if plan is not None:
        plan_id = getattr(plan, "plan_id", None)
        if isinstance(plan_id, str) and plan_id.strip():
            payload["plan_id"] = plan_id.strip()
    return payload


def _narrative_revision_payload(state: AgentEditState) -> dict[str, Any]:
    evidence = state.revision_evidence
    scoped = evidence.scoped_diff if evidence is not None else None
    if evidence is None and scoped is None:
        return {}
    payload: dict[str, Any] = {}
    candidate_eligible = getattr(evidence, "candidate_eligible", None)
    if candidate_eligible is None and scoped is not None:
        candidate_eligible = getattr(scoped, "candidate_eligible", None)
    if candidate_eligible is not None:
        payload["candidate_eligible"] = bool(candidate_eligible)
    blockers = ()
    if scoped is not None:
        blockers = getattr(scoped, "eligibility_blockers", ()) or ()
    elif evidence is not None:
        blockers = getattr(evidence, "eligibility_blockers", ()) or ()
    blocker_list = [str(item).strip() for item in blockers if str(item).strip()]
    if blocker_list:
        payload["eligibility_blockers"] = blocker_list[:4]
    readiness = getattr(evidence, "readiness", None) if evidence is not None else None
    readiness_blockers = getattr(readiness, "readiness_blockers", ()) if readiness is not None else ()
    readiness_list = [str(item).strip() for item in readiness_blockers if str(item).strip()]
    if readiness_list:
        payload["readiness_blockers"] = readiness_list[:3]
    topology = getattr(evidence, "topology", None) if evidence is not None else None
    mismatches = getattr(topology, "socket_type_mismatches", ()) if topology is not None else ()
    mismatch_payloads = _narrative_issue_payloads(mismatches, limit=3)
    if mismatch_payloads:
        payload["socket_type_mismatches"] = mismatch_payloads
    return payload


def _compact_change_details_payload(change_details: Mapping[str, Any]) -> dict[str, Any]:
    operations = change_details.get("operations")
    compact_operations: list[dict[str, Any]] = []
    if isinstance(operations, list):
        for item in operations[:5]:
            if not isinstance(item, Mapping):
                continue
            compact_item = {
                "uid": item.get("uid"),
                "field_path": item.get("field_path"),
                "summary": item.get("summary"),
            }
            compact_operations.append(_json_safe(compact_item))
    payload = {
        "landed_operation_count": int(change_details.get("landed_operation_count") or 0),
        "done_summary": str(change_details.get("done_summary") or "").strip(),
        "final_summary": str(change_details.get("final_summary") or "").strip(),
        "operations": compact_operations,
    }
    if "gate_a" in change_details:
        payload["gate_a"] = _json_safe(change_details.get("gate_a"))
    if "gate_b" in change_details:
        payload["gate_b"] = _json_safe(change_details.get("gate_b"))
    advisory = change_details.get("layout_reorganisation")
    if isinstance(advisory, Mapping):
        payload["layout_reorganisation"] = _json_safe(dict(advisory))
    return payload


def _post_edit_reorganisation_advice_sentence(state: AgentEditState) -> str:
    advisory = getattr(state, "post_edit_reorganisation_advisory", None)
    if not isinstance(advisory, Mapping):
        return ""
    if advisory.get("result") != "offer_reorganisation":
        return ""
    command = advisory.get("suggested_command")
    command_text = (
        command
        if isinstance(command, str) and command.strip()
        else "/reorganise_comfy_workflow"
    )
    return (
        "The edit is ready to review, and the canvas may benefit from "
        f"{command_text}."
    )


def _append_post_edit_reorganisation_advice(message: str, state: AgentEditState) -> str:
    advice = _post_edit_reorganisation_advice_sentence(state)
    if not advice:
        return message
    base = ensure_sentence_message(message, fallback="The candidate is ready to review.")
    return f"{base} {advice}"


def _narrative_context_payload(
    state: AgentEditState,
    context: TurnContext,
    *,
    outcome: TurnOutcome | None = None,
    failure: FailureEnvelope | None = None,
    public_outcome: str | None = None,
    apply_eligibility: ApplyEligibility | None = None,
    change_details: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    if change_details is None:
        change_details = _change_details_payload(state, context)
    compact_change_details = _compact_change_details_payload(change_details)
    landed_operation_count = int(compact_change_details.get("landed_operation_count") or 0)
    graph_changed = bool(_batch_candidate_graph_changed(state) or landed_operation_count > 0)
    internal_kind = outcome.kind if outcome is not None else ("failure" if failure is not None else "unknown")
    if apply_eligibility is None:
        apply_eligibility = context.apply_eligibility
    validation = _validation_summary_payload(context)
    payload: dict[str, Any] = {
        "task": " ".join((state.task or "").split())[:240],
        "route": state.route or "",
        "outcome": {
            "kind": public_outcome or "",
            "internal_kind": internal_kind,
            "public_kind": public_outcome or "",
            "batch_exit_mode": state.batch_exit_mode or "",
            "clarification_question": (
                outcome.question.strip()
                if outcome is not None and isinstance(outcome.question, str) and outcome.question.strip()
                else ""
            ),
        },
        "change": {
            "graph_changed": graph_changed,
            "graph_unchanged": not graph_changed,
            "landed_operation_count": landed_operation_count,
            "operations": compact_change_details.get("operations", []),
        },
        "validation": validation,
        "apply_eligibility": apply_eligibility.to_dict(),
        "change_details": compact_change_details,
        "diagnostics": {
            "delta": _narrative_issue_payloads(state.delta_diagnostics),
            "lowering": _narrative_issue_payloads(state.lowering_evidence),
        },
        "research": _narrative_research_payload(state),
        "revision": _narrative_revision_payload(state),
    }
    if failure is not None:
        payload["failure"] = {
            "kind": failure.kind.value,
            "stage": failure.stage,
            "retryable": failure.retryable,
            "graph_unchanged": failure.graph_unchanged,
            "next_action": failure.next_action,
            "message": " ".join((failure.user_facing_message or "").split())[:240],
        }
    return _json_safe(payload)


def _fallback_narrative_message(
    state: AgentEditState,
    *,
    outcome: TurnOutcome | None = None,
    failure: FailureEnvelope | None = None,
    narrative_context: Mapping[str, Any] | None = None,
    fallback_reason: str | None = None,
) -> str:
    from ._frag_batch_reports import _BATCH_EXIT_BUDGET, _BATCH_EXIT_STUCK  # T-038 late import: sibling cycle broken; resolved at call time
    if failure is not None:
        if state.batch_exit_mode == _BATCH_EXIT_STUCK:
            warning = ensure_sentence_message(
                "I stopped because the edit remained incomplete after a rejected clarification",
                fallback=state.batch_final_summary or failure.user_facing_message,
            )
        elif state.batch_exit_mode == _BATCH_EXIT_BUDGET or failure.kind is FailureKind.BATCH_BUDGET_EXHAUSTED:
            warning = ensure_sentence_message(
                "I ran out of turn budget before completing the remaining changes",
                fallback=state.batch_final_summary or failure.user_facing_message,
            )
        else:
            warning = ensure_sentence_message(
                failure.user_facing_message,
                fallback=failure.message or "The graph is unchanged.",
            )
        lead = _landed_edit_lead(state)
        if lead:
            return f"{lead} {warning}".strip()
        return warning

    if outcome is None:
        return ensure_sentence_message(state.user_message, fallback="The agent edit turn completed.")

    if outcome.kind == "edit":
        message = _humanized_edit_message(state)
        if fallback_reason in {"provider_failure", "malformed_response", "timeout"}:
            message = ensure_sentence_message(message, fallback="The candidate is ready to review.")
        return _append_post_edit_reorganisation_advice(message, state)
    if outcome.kind == "edit+clarify":
        question = (
            outcome.question.strip()
            if isinstance(outcome.question, str) and outcome.question.strip()
            else "What detail should I use before continuing?"
        )
        lead = _landed_edit_lead(state)
        if lead:
            return f"{lead} {ensure_sentence_message(question, fallback=question)}".strip()
        return ensure_sentence_message(question, fallback="What detail should I use before continuing?")
    if outcome.kind == "clarify":
        question = (
            outcome.question.strip()
            if isinstance(outcome.question, str) and outcome.question.strip()
            else "What detail should I use before continuing?"
        )
        return ensure_sentence_message(question, fallback="What detail should I use before continuing?")
    if outcome.kind == "noop":
        return _humanized_noop_message(state)
    if outcome.kind == "budget":
        return ensure_sentence_message(
            "I ran out of turn budget before completing the remaining changes",
            fallback=state.batch_final_summary or state.user_message,
        )

    if narrative_context is not None:
        change = narrative_context.get("change")
        if isinstance(change, Mapping) and int(change.get("landed_operation_count") or 0) > 0:
            return _humanized_edit_message(state)
    return ensure_sentence_message(state.user_message, fallback="The agent edit turn completed.")


def _narrative_artifact_path(state: AgentEditState, path: Path) -> Path:
    if path.is_absolute():
        return path
    return state.turn_dir / path


def _synthesize_post_validation_narrative(
    state: AgentEditState,
    context: TurnContext,
    *,
    outcome: TurnOutcome | None = None,
    failure: FailureEnvelope | None = None,
    public_outcome: str | None = None,
    apply_eligibility: ApplyEligibility | None = None,
    change_details: Mapping[str, Any] | None = None,
) -> str:
    # T-039 late import: the provider seam is patched on the assembled edit
    # module (edit.run_model_turn) by tests and runtime code; resolve at call
    # time so the patch stays visible (matches the exec shared-namespace
    # semantics).
    from vibecomfy.comfy_nodes.agent.edit import run_model_turn
    if change_details is None:
        change_details = _change_details_payload(state, context)
    context_path = _narrative_artifact_path(state, state.narrative_context_path)
    request_path = _narrative_artifact_path(state, state.narrative_request_path)
    response_path = _narrative_artifact_path(state, state.narrative_response_path)
    validation_path = _narrative_artifact_path(state, state.narrative_validation_path)
    state.narrative_context_path = context_path
    state.narrative_request_path = request_path
    state.narrative_response_path = response_path
    state.narrative_validation_path = validation_path
    narrative_context = _narrative_context_payload(
        state,
        context,
        outcome=outcome,
        failure=failure,
        public_outcome=public_outcome,
        apply_eligibility=apply_eligibility,
        change_details=change_details,
    )
    write_json_artifact(context_path, narrative_context)

    request_payload = getattr(state, "request_payload", None)
    request_payload = request_payload if isinstance(request_payload, Mapping) else {}
    # A request-scoped profile selector is authoritative for this isolated
    # turn; environment overrides remain useful for tests and harness probes.
    # Do not invent a default here: this legacy synthesis helper only calls an
    # LLM when a route/model was explicitly selected.
    route = os.getenv("VIBECOMFY_NARRATOR_ROUTE") or (
        request_payload.get("narrator_route")
        if isinstance(request_payload.get("narrator_route"), str)
        else None
    )
    model = os.getenv("VIBECOMFY_NARRATOR_MODEL") or (
        request_payload.get("narrator_model")
        if isinstance(request_payload.get("narrator_model"), str)
        else None
    )
    fallback_message = _fallback_narrative_message(
        state,
        outcome=outcome,
        failure=failure,
        narrative_context=narrative_context,
    )
    final_message = fallback_message
    fallback_reason = "deterministic_only"
    attempted = bool(route or model)
    raw_executor_message = " ".join((state.raw_executor_message or "").split())
    request_payload: dict[str, Any] = {
        "attempted": attempted,
        "route": route,
        "model": model,
        "response_contract": "json",
        "raw_executor_message": raw_executor_message[:240],
    }
    response_payload: dict[str, Any] = {
        "attempted": attempted,
        "selected_source": "fallback",
        "selected_message": fallback_message,
    }
    validation_payload: dict[str, Any]

    if attempted:
        messages = [
            {"role": "system", "content": _narrator_system_message()},
            {
                "role": "user",
                "content": _narrator_user_message(
                    narrative_context=narrative_context,
                    raw_executor_message=raw_executor_message,
                    fallback_message=fallback_message,
                ),
            },
        ]
        request_payload["messages"] = messages
        write_json_artifact(request_path, request_payload)
        try:
            narrator_response = run_model_turn(
                task="Write the final post-validation narrative message.",
                messages=messages,
                route=route,
                model=model,
                response_contract="json",
                profiling_context={
                    "surface": "agent_edit_narrator",
                    "session_dir": str(state.session_dir),
                    "turn_dir": str(state.turn_dir),
                },
            )
            response_payload["provider_response"] = _json_safe(dict(narrator_response))
            candidate_message = _narrator_message_from_response(narrator_response)
            response_payload["candidate_message"] = candidate_message
            # The agent's own message ALWAYS ships: never discard the LLM
            # narrative for a deterministic substitute, regardless of its
            # prose. Fact-grounding is enforced at the prompt, not by a gate.
            final_message = candidate_message
            fallback_reason = ""
            response_payload["selected_source"] = "narrator"
            response_payload["selected_message"] = final_message
            validation_payload = {
                "attempted": True,
                "selected_source": "narrator",
                "selected_message": final_message,
                "fallback_reason": fallback_reason,
            }
        except TimeoutError as exc:
            fallback_reason = "timeout"
            response_payload["error"] = {
                "type": type(exc).__name__,
                "message": str(exc),
            }
            response_payload["fallback_reason"] = fallback_reason
            validation_payload = {
                "attempted": True,
                "selected_source": "fallback",
                "selected_message": fallback_message,
                "fallback_reason": fallback_reason,
                "error": response_payload["error"],
            }
        except (MalformedModelJSON, MissingRequiredField) as exc:
            fallback_reason = "malformed_response"
            response_payload["error"] = {
                "type": type(exc).__name__,
                "message": str(exc),
            }
            response_payload["fallback_reason"] = fallback_reason
            validation_payload = {
                "attempted": True,
                "selected_source": "fallback",
                "selected_message": fallback_message,
                "fallback_reason": fallback_reason,
                "error": response_payload["error"],
            }
        except ProviderError as exc:
            fallback_reason = "provider_failure"
            response_payload["error"] = {
                "type": type(exc).__name__,
                "message": str(exc),
            }
            response_payload["fallback_reason"] = fallback_reason
            validation_payload = {
                "attempted": True,
                "selected_source": "fallback",
                "selected_message": fallback_message,
                "fallback_reason": fallback_reason,
                "error": response_payload["error"],
            }
    else:
        request_payload["skip_reason"] = "narrator_env_unset"
        write_json_artifact(request_path, request_payload)
        response_payload["skip_reason"] = "narrator_env_unset"
        validation_payload = {
            "attempted": False,
            "selected_source": "fallback",
            "selected_message": fallback_message,
            "fallback_reason": fallback_reason,
        }

    validation_payload["final_validation"] = {
        "ok": True,
        "message": final_message,
        "issues": [],
    }
    response_payload["selected_message"] = final_message
    write_json_artifact(response_path, response_payload)
    write_json_artifact(validation_path, validation_payload)
    state.artifacts = {
        **(state.artifacts or {}),
        "narrative_context": str(context_path),
        "narrative_request": str(request_path),
        "narrative_response": str(response_path),
        "narrative_validation": str(validation_path),
    }
    return final_message


def _batch_warning_sentence(
    state: AgentEditState,
    *,
    failure: FailureEnvelope | None = None,
    outcome: TurnOutcome | None = None,
) -> str:
    from ._frag_batch_reports import _BATCH_EXIT_BUDGET, _BATCH_EXIT_STUCK  # T-038 late import: sibling cycle broken; resolved at call time
    if failure is not None:
        if failure.kind is FailureKind.STALE_STATE_MISMATCH:
            return ensure_sentence_message(
                failure.user_facing_message,
                fallback="The canvas changed since the current baseline. Rebaseline and resubmit from the current canvas.",
            )
        if state.batch_exit_mode == _BATCH_EXIT_STUCK:
            return ensure_sentence_message(
                "I stopped because the edit remained incomplete after a rejected clarification",
                fallback=state.batch_final_summary or failure.message,
            )
        if state.batch_exit_mode == _BATCH_EXIT_BUDGET:
            return ensure_sentence_message(
                "I ran out of turn budget before completing the remaining changes",
                fallback=state.batch_final_summary or failure.message,
            )
        return ensure_sentence_message(
            failure.user_facing_message,
            fallback=failure.message or "The graph is unchanged.",
        )
    if outcome is not None and outcome.kind == "edit+clarify":
        return ensure_sentence_message(
            outcome.question,
            fallback=state.user_message or "I still need clarification before continuing.",
        )
    return ""


def _synthesize_batch_repl_message(
    state: AgentEditState,
    *,
    outcome: TurnOutcome | None = None,
    failure: FailureEnvelope | None = None,
) -> str:
    from vibecomfy.comfy_nodes.agent.edit import _resolver_candidates_from_batch_turns  # T-038 late import: exec'd-host fragment; resolved at call time
    lead = _landed_edit_lead(state)
    if failure is not None:
        warning = _batch_warning_sentence(state, failure=failure)
        if lead:
            return f"{lead} {warning}".strip()
        return warning
    if outcome is None:
        return ensure_sentence_message(state.user_message, fallback="The agent edit turn completed.")
    if outcome.kind == "edit":
        return _humanized_edit_message(state)
    if outcome.kind == "edit+clarify":
        warning = _batch_warning_sentence(state, outcome=outcome)
        if lead:
            return f"{lead} {warning}".strip()
        return warning
    if outcome.kind == "clarify":
        return ensure_sentence_message(
            outcome.question,
            fallback=state.user_message or "I need clarification before continuing.",
        )
    if outcome.kind == "budget":
        return ensure_sentence_message(
            "I ran out of turn budget before completing the requested changes",
            fallback=state.batch_final_summary or state.user_message,
        )
    if outcome.kind == "noop" and _resolver_candidates_from_batch_turns(state):
        return ensure_sentence_message(
            state.user_message,
            fallback=(
                "I found external node evidence, but could not apply a grounded "
                "workflow pattern to the current graph."
            ),
        )
    if outcome.kind == "noop":
        return _humanized_noop_message(state)
    return ensure_sentence_message(state.user_message, fallback="The agent edit turn completed.")


__all__ = (
     "_NARRATOR_RESPONSE_REQUIRED_FIELD",
     "_append_post_edit_reorganisation_advice", "_article_for",
     "_batch_candidate_graph_changed", "_batch_warning_sentence",
     "_change_details_payload", "_change_subject", "_compact_change_details_payload",
     "_delta_structural_uids", "_display_value", "_fallback_narrative_message", "_field_change_is_noop",
     "_first_link_source_label", "_human_change_phrase", "_humanized_edit_message",
     "_humanized_noop_message", "_is_link_endpoint", "_join_human_list",
     "_landed_edit_lead", "_link_endpoint_parts", "_looks_internal_uid",
     "_narrative_artifact_path", "_narrative_context_payload",
     "_narrative_issue_payloads", "_narrative_issue_summary",
     "_narrative_research_payload", "_narrative_revision_payload",
     "_narrative_stage_payload", "_narrator_message_from_response",
     "_narrator_system_message", "_narrator_user_message", "_net_field_changes",
     "_node_class_label", "_node_key_values", "_node_label_by_uid", "_node_phrase",
     "_noop_field_changes", "_operation_detail_payload",
     "_post_edit_reorganisation_advice_sentence", "_real_field_changes",
     "_resolve_endpoint_label", "_resolve_output_slot_name",
     "_revision_candidate_retry_hint", "_revision_rejected_candidate_message",
     "_sentence_case", "_structural_change_phrases", "_synthesize_batch_repl_message",
     "_synthesize_post_validation_narrative", "_terminal_answer_message",
     "_ui_display_widget_value_for_field", "_ui_node_by_uid",
     "_validation_summary_payload",
)
