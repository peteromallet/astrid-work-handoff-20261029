"""Lazy consumer for the structured object_info cache.

Reads per-pack JSON files and ``index.json`` on first access.
All public functions are deterministic and do not require ComfyUI or network.
"""

from __future__ import annotations

import copy
import json
import threading
import warnings
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Any, Iterable, Mapping

from vibecomfy.errors import ObjectInfoIdentityAmbiguityError
from vibecomfy.errors import ObjectInfoCacheCorruptError
from vibecomfy.porting.object_info.generation import active_cache_root, cache_file_witness, read_json, safe_cache_filename

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

CACHE_DIR: Path = Path(__file__).resolve().parent.parent / "cache" / "object_info"
INDEX_PATH: Path = CACHE_DIR / "index.json"

# ``comfy_metadata.json`` lives at the package root (vibecomfy/) and pins the
# ComfyUI snapshot the object_info cache was captured against. Used only to make
# fail-closed schema errors actionable ("refresh the snapshot").
METADATA_PATH: Path = Path(__file__).resolve().parent.parent.parent / "comfy_metadata.json"

# ComfyUI types that are link-only sockets, not literal widget controls.
# These are filtered from object_info_widget_value_order.
_WIDGET_LIKE_TYPES: frozenset[str] = frozenset({
    "MODEL", "CLIP", "VAE", "IMAGE", "LATENT", "CONDITIONING", "MASK",
    "AUDIO", "VIDEO", "CONTROL_NET", "HIDDEN",
})
_LITERAL_WIDGET_TYPES: frozenset[str] = frozenset({
    "BOOLEAN", "COMBO", "ENUM", "FLOAT", "INT", "STRING",
})

_CURATED_OUTPUTS: dict[str, list[dict[str, str]]] = {
    # Core classes used by checked-in tests and v2.3 generated templates. These
    # labels are stable ComfyUI socket names and keep named handles available
    # when the large generated object_info cache is not committed.
    "CLIPTextEncode": [{"name": "CONDITIONING", "type": "CONDITIONING"}],
    "CLIPLoader": [{"name": "CLIP", "type": "CLIP"}],
    "CLIPVisionEncode": [{"name": "CLIP_VISION_OUTPUT", "type": "CLIP_VISION_OUTPUT"}],
    "CLIPVisionLoader": [{"name": "CLIP_VISION", "type": "CLIP_VISION"}],
    "CFGGuider": [{"name": "GUIDER", "type": "GUIDER"}],
    "CFGNorm": [{"name": "patched_model", "type": "MODEL"}],
    "ComfySwitchNode": [{"name": "output", "type": "*"}],
    "ConditioningZeroOut": [{"name": "CONDITIONING", "type": "CONDITIONING"}],
    "CreateVideo": [{"name": "VIDEO", "type": "VIDEO"}],
    "DepthAnything_V2": [{"name": "image", "type": "IMAGE"}],
    "DownloadAndLoadDepthAnythingV2Model": [{"name": "da_v2_model", "type": "MODEL"}],
    "DualCLIPLoader": [{"name": "CLIP", "type": "CLIP"}],
    "DualCLIPLoaderGGUF": [{"name": "CLIP", "type": "CLIP"}],
    "EmptyAceStep1.5LatentAudio": [{"name": "LATENT", "type": "LATENT"}],
    "EmptyLTXVLatentVideo": [{"name": "LATENT", "type": "LATENT"}],
    "EmptySD3LatentImage": [{"name": "LATENT", "type": "LATENT"}],
    "GetVideoComponents": [{"name": "images", "type": "IMAGE"}],
    "ImageResizeKJv2": [{"name": "IMAGE", "type": "IMAGE"}],
    "ImageScaleToTotalPixels": [{"name": "IMAGE", "type": "IMAGE"}],
    "INTConstant": [{"name": "value", "type": "INT"}],
    "KSampler": [{"name": "LATENT", "type": "LATENT"}],
    "KSamplerSelect": [{"name": "SAMPLER", "type": "SAMPLER"}],
    "LoadImage": [{"name": "IMAGE", "type": "IMAGE"}],
    "LoadVideo": [{"name": "VIDEO", "type": "VIDEO"}],
    "LoraLoaderModelOnly": [{"name": "MODEL", "type": "MODEL"}],
    "ManualSigmas": [{"name": "SIGMAS", "type": "SIGMAS"}],
    "ModelSamplingAuraFlow": [{"name": "MODEL", "type": "MODEL"}],
    "ModelSamplingSD3": [{"name": "MODEL", "type": "MODEL"}],
    "PathchSageAttentionKJ": [{"name": "MODEL", "type": "MODEL"}],
    "Boolean": [{"name": "BOOLEAN", "type": "BOOLEAN"}],
    "Float": [{"name": "FLOAT", "type": "FLOAT"}],
    "Integer": [{"name": "INT", "type": "INT"}],
    "String": [{"name": "STRING", "type": "STRING"}],
    "PrimitiveBoolean": [{"name": "BOOLEAN", "type": "BOOLEAN"}],
    "PrimitiveFloat": [{"name": "FLOAT", "type": "FLOAT"}],
    "PrimitiveInt": [{"name": "INT", "type": "INT"}],
    "RandomNoise": [{"name": "NOISE", "type": "NOISE"}],
    "SamplerCustomAdvanced": [{"name": "output", "type": "LATENT"}],
    "TextEncodeAceStepAudio1.5": [{"name": "CONDITIONING", "type": "CONDITIONING"}],
    "TextEncodeQwenImageEdit": [{"name": "CONDITIONING", "type": "CONDITIONING"}],
    "UNETLoader": [{"name": "MODEL", "type": "MODEL"}],
    "VAEDecode": [{"name": "IMAGE", "type": "IMAGE"}],
    "VAEDecodeAudio": [{"name": "AUDIO", "type": "AUDIO"}],
    "VAEDecodeTiled": [{"name": "IMAGE", "type": "IMAGE"}],
    "VAEEncode": [{"name": "LATENT", "type": "LATENT"}],
    "VAELoader": [{"name": "VAE", "type": "VAE"}],
    "WanImageToVideo": [
        {"name": "positive", "type": "CONDITIONING"},
        {"name": "negative", "type": "CONDITIONING"},
        {"name": "latent", "type": "LATENT"},
    ],
    "LTX2AttentionTunerPatch": [{"name": "model", "type": "MODEL"}],
    "LTX2_NAG": [{"name": "model", "type": "MODEL"}],
    "LTXAddVideoICLoRAGuide": [
        {"name": "positive", "type": "CONDITIONING"},
        {"name": "negative", "type": "CONDITIONING"},
        {"name": "latent", "type": "LATENT"},
    ],
    "LTXFloatToInt": [{"name": "INT", "type": "INT"}],
    "LTXICLoRALoaderModelOnly": [
        {"name": "model", "type": "MODEL"},
        {"name": "latent_downscale_factor", "type": "FLOAT"},
    ],
    "LTXVAudioVAELoader": [{"name": "Audio VAE", "type": "VAE"}],
    "LTXVChunkFeedForward": [{"name": "model", "type": "MODEL"}],
    "LTXVConcatAVLatent": [{"name": "latent", "type": "LATENT"}],
    "LTXVConditioning": [
        {"name": "positive", "type": "CONDITIONING"},
        {"name": "negative", "type": "CONDITIONING"},
    ],
    "LTXVAddGuideMulti": [
        {"name": "positive", "type": "CONDITIONING"},
        {"name": "negative", "type": "CONDITIONING"},
        {"name": "latent", "type": "LATENT"},
    ],
    "LTXVCropGuides": [
        {"name": "positive", "type": "CONDITIONING"},
        {"name": "negative", "type": "CONDITIONING"},
        {"name": "latent", "type": "LATENT"},
    ],
    "LTXVEmptyLatentAudio": [{"name": "Latent", "type": "LATENT"}],
    "LTXVImgToVideoInplaceKJ": [{"name": "latent", "type": "LATENT"}],
    "LTXVPreprocess": [{"name": "output_image", "type": "IMAGE"}],
    "LTXVSeparateAVLatent": [
        {"name": "video_latent", "type": "LATENT"},
        {"name": "audio_latent", "type": "LATENT"},
    ],
    # controlnet_aux classes used by the v2.3 pilot. These packs were absent
    # from the local object_info cache during the audit, but their single image
    # output is stable and needed by both codemod readability and Handle.out().
    "CannyEdgePreprocessor": [{"name": "IMAGE", "type": "IMAGE"}],
    "DWPreprocessor": [{"name": "IMAGE", "type": "IMAGE"}],
}

# ---------------------------------------------------------------------------
# Internal lazy state
# ---------------------------------------------------------------------------

_index: dict[str, str] | None = None
_pack_cache: dict[str, dict[str, dict[str, Any]]] = {}
_reader_lock = threading.RLock()
_reader_state: dict[str, Any] | None = None


@dataclass(frozen=True)
class _ClassEntrySnapshot:
    entries: Mapping[str, dict[str, Any]]
    misses: frozenset[str]


_CLASS_ENTRY_SNAPSHOT: ContextVar[_ClassEntrySnapshot | None] = ContextVar(
    "_CLASS_ENTRY_SNAPSHOT", default=None
)


@dataclass(frozen=True)
class ObjectInfoIdentity:
    pack_slug: str
    git_commit: str | None = None
    evidence_identity: str | None = None


@dataclass(frozen=True)
class ObjectInfoLookupWarning:
    code: str
    message: str


@dataclass(frozen=True)
class ObjectInfoLookupResult:
    entry: dict[str, Any] | None
    source: str
    low_confidence: bool = False
    warning: ObjectInfoLookupWarning | None = None


def _normalize_output_name(name: str) -> str:
    cleaned = name.strip().replace(" ", "_")
    return cleaned.upper()


def _sync_reader() -> bool:
    global _reader_state, _index
    configured = Path(CACHE_DIR).expanduser().resolve(strict=False)
    marker = configured / "CURRENT"
    marker_sig = cache_file_witness(marker)
    prior = _reader_state
    if prior and prior["root"] == configured and prior["committed"] and marker_sig is None:
        raise ObjectInfoCacheCorruptError(f"object_info cache marker disappeared: {marker}")
    marker_changed = not prior or prior["root"] != configured or marker_sig != prior["marker_sig"]
    committed = bool(marker_sig)
    marker_text = prior["marker_text"] if prior and not marker_changed else None
    if marker_sig is not None and marker_changed:
        active = active_cache_root(configured)
        try:
            marker_text = marker.read_text(encoding="utf-8").strip()
        except OSError as exc:
            raise ObjectInfoCacheCorruptError(f"cannot read object_info cache marker {marker}: {exc}") from exc
    elif marker_sig is None:
        active = configured
        committed = False
    else:
        active = prior["active"]
    index_sig = cache_file_witness(active / "index.json")
    pack_changed = bool(prior and prior["root"] == configured and prior["pack_sigs"] and any(cache_file_witness(active / name) != sig for name, sig in prior["pack_sigs"].items()))
    changed = marker_changed or not prior or index_sig != (prior["index_sig"] if prior else None) or pack_changed
    if changed and committed and not (marker_sig is not None and marker_changed):
        active = active_cache_root(configured)
        index_sig = cache_file_witness(active / "index.json")
    if changed:
        _index = None
        _pack_cache.clear()
    pack_sigs = {} if changed else (prior["pack_sigs"] if prior else {})
    _reader_state = {"root": configured, "active": active, "committed": committed,
                     "marker_sig": marker_sig, "marker_text": marker_text,
                     "index_sig": index_sig, "pack_sigs": pack_sigs}
    return changed


def _load_index() -> dict[str, str]:
    global _index
    with _reader_lock:
        for attempt in range(2):
            _sync_reader()
            if _index is None:
                root = _reader_state["active"]
                _index = _read_index_at_root(root)
            if not _sync_reader():
                return _index
            if attempt:
                raise ObjectInfoCacheCorruptError("object_info cache changed during index load")
        return _index


def _read_index_at_root(root: Path) -> dict[str, str]:
    """Read one index without allowing publication to change its root."""
    path = root / "index.json"
    if not path.exists() and not path.is_symlink():
        return {}
    data = read_json(root, "index.json")
    if not isinstance(data, dict):
        raise ObjectInfoCacheCorruptError(f"object_info index must be an object: {path}")
    normalized = {
        class_type: filename for class_type, filename in data.items()
        if isinstance(class_type, str) and isinstance(filename, str) and safe_cache_filename(filename)
    }
    if len(normalized) != len(data):
        raise ObjectInfoCacheCorruptError(f"unsafe object_info index row in {path}")
    return normalized


def _load_pack(filename: str) -> dict[str, dict[str, Any]]:
    with _reader_lock:
        for attempt in range(2):
            _sync_reader()
            if filename not in _pack_cache:
                root = _reader_state["active"]
                data = _read_pack_at_root(root, filename)
                _pack_cache[filename] = data
                _reader_state["pack_sigs"][filename] = cache_file_witness(root / filename)
            if not _sync_reader():
                return _pack_cache[filename]
            if attempt:
                raise ObjectInfoCacheCorruptError("object_info cache changed during pack load")
        return _pack_cache[filename]


def _read_pack_at_root(root: Path, filename: str) -> dict[str, dict[str, Any]]:
    """Read one provider file from a caller-pinned active root."""
    if not safe_cache_filename(filename):
        raise ObjectInfoCacheCorruptError(f"unsafe object_info provider filename: {filename!r}")
    data = read_json(root, filename)
    if not isinstance(data, dict):
        raise ObjectInfoCacheCorruptError(f"object_info provider file must be an object: {root / filename}")
    return data


def _pack_filenames_at_root(root: Path) -> list[str]:
    filenames = {
        str(path.name)
        for path in root.glob("*.json")
        if path.name not in {"index.json", "provenance.json", "manifest.json"}
    }
    filenames.update(str(filename) for filename in _read_index_at_root(root).values())
    return sorted(filenames)


def _all_pack_filenames() -> list[str]:
    with _reader_lock:
        _sync_reader()
        root = _reader_state["active"]
        # Read the index from the captured immutable generation. Calling
        # _load_index() here could observe a newly published CURRENT and pair
        # that index with this old generation's glob result.
        return _pack_filenames_at_root(root)


def _resolve_class_type(class_type: str) -> dict[str, Any] | None:
    with _reader_lock:
        idx = _load_index()
        filename = idx.get(class_type)
        if filename is None:
            return None
        return _load_pack(filename).get(class_type)


def _identity_matches(
    entry: dict[str, Any],
    *,
    pack_slug: str,
    git_commit: str | None,
    evidence_identity: str | None,
) -> bool:
    if entry.get("pack_slug") != pack_slug:
        return False
    if git_commit is not None:
        return entry.get("git_commit") == git_commit
    return entry.get("evidence_identity") == evidence_identity


def _identity_key(pack_slug: str, git_commit: str | None, evidence_identity: str | None) -> tuple[str, str]:
    if git_commit is not None and evidence_identity is not None:
        raise ValueError("identity lookup accepts git_commit or evidence_identity, not both")
    if git_commit is None and evidence_identity is None:
        raise ValueError("identity lookup requires git_commit or evidence_identity")
    return (
        pack_slug,
        f"git_commit:{git_commit}" if git_commit is not None else f"evidence_identity:{evidence_identity}",
    )


def _identity_lookup_matches(
    class_type: str,
    *,
    pack_slug: str,
    git_commit: str | None,
    evidence_identity: str | None,
) -> list[tuple[str, dict[str, Any]]]:
    _identity_key(pack_slug, git_commit, evidence_identity)
    matches: list[tuple[str, dict[str, Any]]] = []
    with _reader_lock:
        _sync_reader()
        root = _reader_state["active"]
        for filename in _pack_filenames_at_root(root):
            entry = _read_pack_at_root(root, filename).get(class_type)
            if isinstance(entry, dict) and _identity_matches(
                entry,
                pack_slug=pack_slug,
                git_commit=git_commit,
                evidence_identity=evidence_identity,
            ):
                matches.append((filename, entry))
    return matches


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def get_class(class_type: str) -> dict[str, Any] | None:
    """Return the normalized cache entry for *class_type*, or ``None``.

    The returned dict has keys:
    ``pack``, ``pack_version``, ``python_module``, ``category``, ``name``,
    ``display_name``, ``description``, ``inputs``, ``input_order``,
    ``input_order_all``, ``object_info_widget_order``, ``outputs``, ``function``.
    """
    class_type = str(class_type)
    snapshot = _CLASS_ENTRY_SNAPSHOT.get()
    if snapshot is not None:
        if class_type in snapshot.entries:
            # Preserve get_class()'s historical caller-owned mutable result
            # without allowing one consumer (or inherited async context) to
            # mutate the operation snapshot seen by another.
            return copy.deepcopy(snapshot.entries[class_type])
        if class_type in snapshot.misses:
            return None
        raise ObjectInfoCacheCorruptError(
            f"object_info class {class_type!r} was not captured for this operation"
        )

    entry = _resolve_class_type(class_type)
    if entry is not None:
        return entry
    curated_outputs = _CURATED_OUTPUTS.get(class_type)
    if curated_outputs is None:
        return None
    return {"outputs": curated_outputs}


@contextmanager
def class_entry_snapshot(class_types: Iterable[str]):
    """Bind one content-witnessed object-info view for a bounded operation.

    Scalar lookups intentionally recheck loaded pack bytes on every call. A
    conversion performs many related lookups against one logical input, so it
    first captures all known classes with :func:`get_classes` and reuses that
    coherent view. An unrequested late lookup fails closed rather than mixing
    entries from two cache generations. Outside this context scalar freshness
    is unchanged.
    """
    requested = tuple(sorted({str(item) for item in class_types if str(item)}))
    current = _CLASS_ENTRY_SNAPSHOT.get()
    if current is not None and all(
        item in current.entries or item in current.misses
        for item in requested
    ):
        # A nested operation over a subset inherits the outer operation's
        # coherent view. ContextVar isolation still gives concurrent callers
        # independent snapshots, and an unrelated nested class set captures a
        # fresh view which is reset back to this one on exit.
        yield
        return
    # An unrelated nested operation gets its own coherent capture and then
    # restores the outer snapshot. It must not ask the outer scope to resolve
    # classes which were absent from that operation's declared set.
    outer_token = _CLASS_ENTRY_SNAPSHOT.set(None) if current is not None else None
    try:
        resolved = get_classes(requested)
    finally:
        if outer_token is not None:
            _CLASS_ENTRY_SNAPSHOT.reset(outer_token)
    state = _ClassEntrySnapshot(
        entries=MappingProxyType(copy.deepcopy(resolved)),
        misses=frozenset(set(requested) - set(resolved)),
    )
    token = _CLASS_ENTRY_SNAPSHOT.set(state)
    try:
        yield
    finally:
        _CLASS_ENTRY_SNAPSHOT.reset(token)


def get_classes(class_types: Iterable[str]) -> dict[str, dict[str, Any]]:
    """Resolve a class set against one content-witnessed reader snapshot.

    Bulk static consumers must not call :func:`get_class` once per AST node:
    every scalar lookup intentionally rechecks the content witness for every
    pack already read.  This variant performs the same before/after reader
    checks once for the requested set, reads each required pack at most once,
    and retries if publication or any retained pack changes during the batch.
    """
    global _index

    requested = tuple(sorted({str(item) for item in class_types if str(item)}))
    if not requested:
        return {}
    snapshot = _CLASS_ENTRY_SNAPSHOT.get()
    if snapshot is not None:
        late = [
            item for item in requested
            if item not in snapshot.entries and item not in snapshot.misses
        ]
        if late:
            raise ObjectInfoCacheCorruptError(
                f"object_info classes {late!r} were not captured for this operation"
            )
        return {
            item: copy.deepcopy(snapshot.entries[item])
            for item in requested
            if item in snapshot.entries
        }
    with _reader_lock:
        for attempt in range(2):
            _sync_reader()
            assert _reader_state is not None
            root = _reader_state["active"]
            if _index is None:
                _index = _read_index_at_root(root)
            by_filename: dict[str, list[str]] = {}
            for class_type in requested:
                filename = _index.get(class_type)
                if filename is not None:
                    by_filename.setdefault(filename, []).append(class_type)
            resolved: dict[str, dict[str, Any]] = {}
            changed_during_read = False
            for filename, names in sorted(by_filename.items()):
                if filename not in _pack_cache:
                    path = root / filename
                    witness_before = cache_file_witness(path)
                    _reader_state["pack_sigs"][filename] = witness_before
                    pack = _read_pack_at_root(root, filename)
                    witness_after = cache_file_witness(path)
                    if witness_before != witness_after:
                        changed_during_read = True
                        break
                    _pack_cache[filename] = pack
                    _reader_state["pack_sigs"][filename] = witness_after
                pack = _pack_cache[filename]
                for class_type in names:
                    entry = pack.get(class_type)
                    if isinstance(entry, dict):
                        resolved[class_type] = entry
            if changed_during_read:
                _index = None
                _pack_cache.clear()
                # Reconcile the before-read witness through the normal reader
                # boundary.  A mutable legacy root retries; a modified
                # committed generation fails its manifest check instead of
                # admitting bytes from a tampered generation.
                _sync_reader()
                if attempt:
                    raise ObjectInfoCacheCorruptError(
                        "object_info cache changed during batch class load"
                    )
                continue
            if not _sync_reader():
                for class_type in requested:
                    if class_type in resolved:
                        continue
                    curated_outputs = _CURATED_OUTPUTS.get(class_type)
                    if curated_outputs is not None:
                        resolved[class_type] = {"outputs": curated_outputs}
                return resolved
            if attempt:
                raise ObjectInfoCacheCorruptError(
                    "object_info cache changed during batch class load"
                )
    raise AssertionError("unreachable")


def resolve_class_entry(
    class_type: str,
    identity: ObjectInfoIdentity | dict[str, Any] | None = None,
    *,
    allow_class_fallback: bool = True,
) -> ObjectInfoLookupResult:
    """Resolve an object_info entry, preferring an explicit pack identity.

    Class-only callers can pass no identity and get the historical cache/curated
    lookup semantics. Identity-aware callers get a provenance-sensitive result
    with source and warning metadata when a fallback is used or blocked.
    """
    normalized_identity = _coerce_identity(identity)
    if normalized_identity is None:
        entry = get_class(class_type)
        return ObjectInfoLookupResult(
            entry=entry,
            source="class" if entry is not None else "miss",
            low_confidence=False,
        )

    if _CLASS_ENTRY_SNAPSHOT.get() is not None:
        raise ObjectInfoCacheCorruptError(
            "identity-specific object_info lookup is not part of the captured "
            "class-only operation snapshot"
        )

    try:
        entry = get_class_by_identity(
            class_type,
            pack_slug=normalized_identity.pack_slug,
            git_commit=normalized_identity.git_commit,
            evidence_identity=normalized_identity.evidence_identity,
        )
    except ObjectInfoIdentityAmbiguityError:
        raise
    if entry is not None:
        return ObjectInfoLookupResult(entry=entry, source="identity", low_confidence=False)

    if not allow_class_fallback:
        return ObjectInfoLookupResult(
            entry=None,
            source="identity_miss",
            low_confidence=True,
            warning=ObjectInfoLookupWarning(
                code="identity_cache_miss",
                message=(
                    f"No object_info cache entry for {class_type} matched identity "
                    f"{_identity_label(normalized_identity)}."
                ),
            ),
        )

    fallback = get_class(class_type)
    if fallback is None:
        return ObjectInfoLookupResult(
            entry=None,
            source="miss",
            low_confidence=True,
            warning=ObjectInfoLookupWarning(
                code="identity_cache_miss",
                message=(
                    f"No object_info cache entry for {class_type} matched identity "
                    f"{_identity_label(normalized_identity)}, and class fallback was unavailable."
                ),
            ),
        )

    if _entry_has_authoritative_identity(fallback):
        code = "provenanced_cache_miss_fallback"
        message = (
            f"No object_info cache entry for {class_type} matched identity "
            f"{_identity_label(normalized_identity)}; using a different provenanced class cache entry."
        )
    else:
        code = "unprovenanced_cache_fallback"
        message = (
            f"No object_info cache entry for {class_type} matched identity "
            f"{_identity_label(normalized_identity)}; using non-authoritative class fallback."
        )
    return ObjectInfoLookupResult(
        entry=fallback,
        source="class_fallback",
        low_confidence=True,
        warning=ObjectInfoLookupWarning(code=code, message=message),
    )


def get_class_by_identity(
    class_type: str,
    *,
    pack_slug: str,
    git_commit: str | None = None,
    evidence_identity: str | None = None,
) -> dict[str, Any] | None:
    """Return the cache entry for *class_type* keyed by explicit pack identity."""
    if _CLASS_ENTRY_SNAPSHOT.get() is not None:
        raise ObjectInfoCacheCorruptError(
            "identity-specific object_info lookup is not part of the captured "
            "class-only operation snapshot"
        )
    matches = _identity_lookup_matches(
        class_type,
        pack_slug=pack_slug,
        git_commit=git_commit,
        evidence_identity=evidence_identity,
    )
    if not matches:
        return None
    if len(matches) > 1:
        raise ObjectInfoIdentityAmbiguityError(
            (
                f"multiple object_info cache entries matched {class_type} for pack {pack_slug}; "
                "provide a more specific identity or refresh duplicate cache files."
            ),
            class_type=class_type,
            pack_slug=pack_slug,
            git_commit=git_commit,
            evidence_identity=evidence_identity,
            matches=[
                {
                    "filename": filename,
                    "pack_version": entry.get("pack_version"),
                    "git_commit": entry.get("git_commit"),
                    "evidence_identity": entry.get("evidence_identity"),
                    "source_kind": entry.get("source_kind"),
                }
                for filename, entry in matches
            ],
        )
    return matches[0][1]


def has_class_identity(
    class_type: str,
    *,
    pack_slug: str,
    git_commit: str | None = None,
    evidence_identity: str | None = None,
) -> bool:
    """Return True when an explicit object_info identity resolves for *class_type*."""
    return get_class_by_identity(
        class_type,
        pack_slug=pack_slug,
        git_commit=git_commit,
        evidence_identity=evidence_identity,
    ) is not None


def _coerce_identity(identity: ObjectInfoIdentity | dict[str, Any] | None) -> ObjectInfoIdentity | None:
    if identity is None:
        return None
    if isinstance(identity, ObjectInfoIdentity):
        return identity
    pack_slug = identity.get("pack_slug") or identity.get("pack") or identity.get("slug")
    git_commit = identity.get("git_commit") or identity.get("commit")
    evidence_identity = identity.get("evidence_identity")
    if not pack_slug:
        raise ValueError("object_info identity requires pack_slug")
    if git_commit and evidence_identity:
        raise ValueError("object_info identity accepts git_commit or evidence_identity, not both")
    if not git_commit and not evidence_identity:
        raise ValueError("object_info identity requires git_commit or evidence_identity")
    return ObjectInfoIdentity(
        pack_slug=str(pack_slug),
        git_commit=str(git_commit) if git_commit else None,
        evidence_identity=str(evidence_identity) if evidence_identity else None,
    )


def _identity_label(identity: ObjectInfoIdentity) -> str:
    key = f"git_commit={identity.git_commit}" if identity.git_commit else f"evidence_identity={identity.evidence_identity}"
    return f"pack_slug={identity.pack_slug}, {key}"


def _entry_has_authoritative_identity(entry: dict[str, Any]) -> bool:
    if entry.get("git_commit"):
        return True
    source_kind = str(entry.get("source_kind") or "")
    return bool(entry.get("evidence_identity")) and source_kind not in {
        "",
        "legacy_object_info_import",
        "structured_cache_copy",
    }


def object_info_widget_order(class_type: str) -> list[str | None]:
    """Return the ordered widget names (excluding link-only sockets) for *class_type*.

    Returns an empty list when the class is not found in the cache.
    This is a raw object_info fallback — callers should prefer the curated
    ``WIDGET_SCHEMA`` table and only use this when no curated entry exists.
    """
    entry = (
        get_class(class_type)
        if _CLASS_ENTRY_SNAPSHOT.get() is not None
        else _resolve_class_type(class_type)
    )
    if entry is None:
        return []
    return reconciled_object_info_widget_order(entry)


def reconciled_object_info_widget_order(entry: dict[str, Any]) -> list[str | None]:
    """Return object_info widget order with metadata-backed UI slots included.

    Comfy object_info stores controls such as ``control_after_generate`` as
    metadata on an input spec, while LiteGraph serializes that control as an
    extra positional ``widgets_values`` slot.  Reconcile that here so emitters
    reason about actual UI serialization, not just formal API inputs.
    """
    raw_order = entry.get("object_info_widget_order")
    if not isinstance(raw_order, list):
        return []
    raw: list[str | None] = [name if isinstance(name, str) else None for name in raw_order]
    input_specs = {name: spec for name, spec in _iter_input_specs(entry)}
    out: list[str | None] = []
    skip_next_hole = False
    for index, name in enumerate(raw):
        if skip_next_hole:
            skip_next_hole = False
            continue
        out.append(name)
        if not isinstance(name, str) or not name:
            continue
        if not _input_spec_has_control_after_generate(input_specs.get(name)):
            continue
        next_item = raw[index + 1] if index + 1 < len(raw) else None
        if next_item == "control_after_generate":
            continue
        if next_item is None and index + 1 < len(raw):
            skip_next_hole = True
        # LiteGraph serializes this UI-only control as its own widgets_values
        # slot. Name it in the frozen domain so live emit and replay share
        # one roster (KSampler family / canary 03fced).
        out.append("control_after_generate")
    return out


def _input_spec_has_control_after_generate(spec: list[Any] | None) -> bool:
    if not spec:
        return False
    if len(spec) > 1 and isinstance(spec[1], dict):
        return "control_after_generate" in spec[1]
    return False


def object_info_widget_value_order(class_type: str) -> list[str]:
    """Return object_info widget names aligned to UI ``widgets_values``.

    Older cache entries may preserve the full INPUT_TYPES order with ``None``
    placeholders, and some also retain named link sockets such as
    ``control_net``. LiteGraph ``widgets_values`` only stores literal widgets,
    so callers that write by field name need the compact literal-only order.
    """

    entry = _resolve_class_type(class_type)
    if entry is None:
        return [
            str(name)
            for name in object_info_widget_order(class_type)
            if isinstance(name, str) and name
        ]
    return compact_literal_widget_order(entry)


def compact_literal_widget_order(entry: dict[str, Any]) -> list[str]:
    """Compact ``widgets_values`` order: named literals including UI-only controls.

    Socket placeholders (``None``) are dropped. ``control_after_generate`` is
    kept even though it is not a formal API input — LiteGraph serializes it
    as its own slot, and the frozen replay name table must match live emit.
    """
    input_specs = {name: spec for name, spec in _iter_input_specs(entry)}
    names: list[str] = []
    for name in reconciled_object_info_widget_order(entry):
        if not isinstance(name, str) or not name:
            continue
        if name == "control_after_generate":
            names.append(name)
            continue
        spec = input_specs.get(name)
        if spec is not None and not _input_spec_is_widget_value(spec):
            continue
        names.append(name)
    return names


def _input_spec_is_widget_value(spec: list[Any]) -> bool:
    if not spec:
        return False
    head = spec[0]
    if isinstance(head, list):
        return True
    input_type = _normalize_input_type(head).upper()
    if input_type in _LITERAL_WIDGET_TYPES:
        return True
    if input_type in _WIDGET_LIKE_TYPES:
        return False
    return not input_type.isupper()


def effective_widget_names_for_class(class_type: str, *, allow_object_info_fallback: bool = False) -> list[str | None]:
    """Return curated widget names, optionally falling back to cached object_info."""
    from vibecomfy.porting.widgets.schema import WIDGET_SCHEMA

    curated = WIDGET_SCHEMA.get(class_type)
    if curated is not None:
        return list(curated)
    if allow_object_info_fallback:
        return object_info_widget_order(class_type)
    return []


def output_names(class_type: str) -> list[str]:
    """Return ordered output names for *class_type* (e.g. ``["MODEL"]``).

    Returns an empty list when the class is not found in the cache.
    """
    entry = _resolve_class_type(class_type)
    if entry is None:
        return [o["name"] for o in _CURATED_OUTPUTS.get(class_type, [])]
    names = [o.get("name", "") for o in entry.get("outputs", [])]
    return names or [o["name"] for o in _CURATED_OUTPUTS.get(class_type, [])]


def output_types(class_type: str) -> list[str]:
    """Return ordered output types for *class_type* (e.g. ``["MODEL"]``).

    Returns an empty list when the class is not found in the cache.
    """
    entry = _resolve_class_type(class_type)
    if entry is None:
        return [o["type"] for o in _CURATED_OUTPUTS.get(class_type, [])]
    types = [o.get("type", "") for o in entry.get("outputs", [])]
    return types or [o["type"] for o in _CURATED_OUTPUTS.get(class_type, [])]


def class_defaults(class_type: str) -> dict[str, Any]:
    """Return schema default values by input name for *class_type*.

    Only inputs with an explicit object_info ``default`` are returned. The
    lookup is offline and deterministic; unknown classes return ``{}``.
    """
    entry = get_class(class_type)
    if entry is None:
        return {}
    defaults: dict[str, Any] = {}
    for name, spec in _iter_input_specs(entry):
        metadata = spec[1] if len(spec) > 1 and isinstance(spec[1], dict) else {}
        if "default" in metadata:
            defaults[name] = metadata["default"]
    return defaults


def class_input_types(class_type: str) -> dict[str, str]:
    """Return best-effort input type names by input name for *class_type*."""
    entry = get_class(class_type)
    if entry is None:
        return {}
    return {
        name: _normalize_input_type(spec[0] if spec else None)
        for name, spec in _iter_input_specs(entry)
    }


def class_output_count(class_type: str) -> int:
    """Return the number of declared outputs for *class_type*.

    Fails OPEN: an unknown class (absent from both the object_info snapshot and
    the curated fallback) reports ``0``. Codegen sites that rely on the count to
    determine output arity must use :func:`require_class_output_count` instead so
    a genuinely-unknown node fails CLOSED with a named, actionable error.
    """
    return len(output_names(class_type))


def class_is_known(class_type: str) -> bool:
    """Return True when *class_type* has a usable output schema.

    A class is "known" when it resolves through the shared authoring schema
    provider chain (shipped object_info corpus + source parser + on-demand
    resolver), OR has a curated ``_CURATED_OUTPUTS`` fallback. Unknown classes
    are exactly the ones for which :func:`output_names` /
    :func:`class_output_count` fail open with an empty list / zero.

    Routing through the provider unifies the previously-duplicate class-existence
    check with the schema-resolution chokepoint, so uninstalled custom-node
    classes the source parser can resolve are now also "known". The local
    snapshot/curated fallbacks are kept as a defensive backstop (and remain the
    source of truth under tests that patch ``CACHE_DIR`` in isolation).
    """
    # Lazy import: ``schema.provider`` imports from this module at call time
    # (see ``AuthoringSchemaProvider``), so a module-level import would cycle.
    try:
        from vibecomfy.schema.provider import (  # noqa: PLC0415
            get_authoring_schema_provider,
            schema_for,
        )
        provider = get_authoring_schema_provider()
        if schema_for(provider, class_type) is not None:
            return True
    except Exception as exc:
        # Fall through to the local snapshot/curated fallback below on any
        # local cache miss, but preserve provider failures as failures rather
        # than misclassifying an unreadable authority as a missing class.
        from vibecomfy.schema.provider import SchemaProviderError

        if isinstance(exc, SchemaProviderError):
            raise
        pass
    if _resolve_class_type(class_type) is not None:
        return True
    return class_type in _CURATED_OUTPUTS


def snapshot_version() -> str:
    """Return the ComfyUI version string the object_info snapshot was captured

    against, read from ``comfy_metadata.json``. Best-effort: returns
    ``"unknown"`` if the metadata file is absent or unreadable.
    """
    try:
        with open(METADATA_PATH, "r", encoding="utf-8") as fh:
            meta = json.load(fh)
    except (OSError, ValueError):
        return "unknown"
    version = meta.get("version") if isinstance(meta, dict) else None
    return str(version) if version else "unknown"


def check_output_arity_consensus(class_type: str, ui_output_count: int | None) -> int:
    """Return the effective output count after checking cache vs UI arity evidence.

    Unknown classes preserve historical defaults: the cached count is returned
    without raising or warning because there is no reliable snapshot evidence to
    compare against.
    """
    cached_count = class_output_count(class_type)
    if ui_output_count is None or not class_is_known(class_type):
        return cached_count
    if cached_count < ui_output_count:
        warnings.warn(
            (
                f"output arity disagreement for {class_type}: cached snapshot "
                f"declares {cached_count} outputs but UI declares {ui_output_count}. "
                "continuing with the UI output count because live/UI object_info "
                "takes precedence over stale embedded metadata."
            ),
            stacklevel=2,
        )
        return ui_output_count
    if cached_count > ui_output_count:
        warnings.warn(
            (
                f"output arity disagreement for {class_type}: cached snapshot "
                f"declares {cached_count} outputs but UI declares {ui_output_count}; "
                "continuing with the UI output count because live/UI object_info "
                "takes precedence over stale embedded metadata."
            ),
            stacklevel=2,
        )
        return ui_output_count
    return cached_count


def require_class_output_count(class_type: str, ui_output_count: int | None = None) -> int:
    """Return class output count while enforcing typed cache-vs-UI arity checks."""
    return check_output_arity_consensus(class_type, ui_output_count)


def class_has_list_output(class_type: str) -> bool:
    """Return True when any declared output is marked OUTPUT_IS_LIST."""
    entry = get_class(class_type)
    if entry is None:
        return any(bool(o.get("is_list")) for o in _CURATED_OUTPUTS.get(class_type, []))
    return any(bool(o.get("is_list")) for o in entry.get("outputs", []))


def list_classes() -> list[str]:
    """Return all class types in the cache, sorted deterministically."""
    idx = _load_index()
    if idx:
        return sorted(idx.keys())
    return sorted(_CURATED_OUTPUTS)


def _iter_input_specs(entry: dict[str, Any]) -> list[tuple[str, list[Any]]]:
    inputs = entry.get("inputs")
    if not isinstance(inputs, dict):
        return []
    ordered = entry.get("input_order_all")
    names: list[str] = [str(name) for name in ordered] if isinstance(ordered, list) else []
    by_name: dict[str, list[Any]] = {}
    for section in ("required", "optional"):
        values = inputs.get(section)
        if not isinstance(values, dict):
            continue
        for name, spec in values.items():
            if isinstance(spec, list):
                by_name[str(name)] = spec
            elif isinstance(spec, str):
                by_name[str(name)] = [spec]
    if not names:
        names = sorted(by_name)
    return [(name, by_name[name]) for name in names if name in by_name]


def _normalize_input_type(value: Any) -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        return "ENUM"
    if value is None:
        return ""
    return str(value)


def reset_cache() -> None:
    """Clear the module-level object-info index and pack cache.

    Callers should invoke this after writing new object_info cache files
    (e.g. after an ``ensure_env`` run) so that subsequent ``consume`` reads
    pick up the latest on-disk state.
    """
    global _index, _pack_cache, _reader_state
    with _reader_lock:
        _index = None
        _pack_cache.clear()
        _reader_state = None


def cache_stats() -> dict[str, Any]:
    """Return summary stats about the loaded cache (for debugging)."""
    idx = _load_index()
    return {
        "total_classes": len(idx),
        "packs_cached": len(_pack_cache),
        "cache_dir": str(CACHE_DIR),
    }
