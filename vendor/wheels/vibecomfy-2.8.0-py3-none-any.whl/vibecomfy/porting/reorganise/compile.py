from __future__ import annotations

from vibecomfy.ingest.normalize import door_get_nodes
import hashlib
import json
from dataclasses import dataclass, field
from math import ceil, hypot, sqrt
from types import MappingProxyType
from typing import Any, Literal, Mapping, Sequence

from vibecomfy.identity.uid import make_uid
from vibecomfy.porting.canonical_coords import snap_pos, snap_size
from vibecomfy.porting.layout_store import STORE_VERSION

from ._placement import (
    CompiledSectionTopology,
    _CompileSection,
    _SectionPlacement,
    _Spacing,
    _huge_wall_band as _huge_wall_band,
    _reflow_overtall_lane_trails as _reflow_overtall_lane_trails,
    _topology_for,
    _wall_bucket_id_from_section_id,
    _wall_section_rank as _wall_section_rank,
    plan_section_placements as _plan_section_placements,
)
from .classify import ClassificationReport, classify_layout_facts
from .diagnostics import DIAGNOSTIC_SEVERITY_ERROR, ReorganiseDiagnostic, ReorganiseDiagnosticReport
from .graph_facts import GraphInventoryFacts, GroupFact, NodeFurnitureFact, extract_graph_facts
from .plan_types import (
    HELPER_PLACEMENT_EDGE_PATH,
    HELPER_PLACEMENT_INSIDE_SECTION,
    HELPER_PLACEMENT_NEAR_CONSUMER,
    HELPER_PLACEMENT_NEAR_PRODUCER,
    LAYOUT_BEHAVIOR_NOTE,
    LAYOUT_BEHAVIOR_PRIMARY,
    LAYOUT_BEHAVIOR_SIDECAR,
    LAYOUT_BEHAVIOR_WALL,
    ROLE_HINT_CONDITIONING,
    ROLE_HINT_CONTROL,
    ROLE_HINT_DECODE,
    ROLE_HINT_HELPER,
    ROLE_HINT_LATENT,
    ROLE_HINT_LOADER,
    ROLE_HINT_OUTPUT,
    ROLE_HINT_POSTPROCESS,
    ROLE_HINT_SAMPLER,
    ROLE_HINT_SHARED,
    ROLE_HINT_SUBGRAPH_CONTAINER,
    ROLE_HINT_UI,
    ROLE_HINT_UNKNOWN,
    ROLE_HINT_UTILITY,
    SECTION_KIND_BRANCH,
    SECTION_KIND_CONDITIONING,
    SECTION_KIND_CONTAINER,
    SECTION_KIND_CONTROL,
    SECTION_KIND_CUSTOM,
    SECTION_KIND_DECODE,
    SECTION_KIND_LATENT,
    SECTION_KIND_LOADERS,
    SECTION_KIND_OUTPUT,
    SECTION_KIND_POSTPROCESS,
    SECTION_KIND_SAMPLING,
    SECTION_KIND_UTILITY,
    UNASSIGNED_CLASSIFY_DETERMINISTICALLY,
    UNASSIGNED_PRESERVE_EXISTING,
    UNASSIGNED_REJECT,
    AssessmentIssue,
    AssessmentMetric,
    CanonicalNodeRef,
    LayoutPlanV1,
    LayoutSection,
    LayoutTraceEntry,
    RoleHint,
    SamplerRelationClaim,
    SectionKind,
)
from .report import build_assessment_report
from .validate import validate_layout_plan

SpacingPreset = Literal["compact", "balanced", "wide"]
ExistingGroupPolicy = Literal[
    "preserve",
    "rename_only",
    "resize_only",
    "rename_and_resize",
    "semantic_preserve",
    "dissolve_with_warning",
    "force_regroup",
]
GroupingPolicy = Literal["auto", "none", "preserve_existing", "stage", "wall"]
SectionTemplate = Literal[
    "single",
    "pair",
    "row",
    "pipeline",
    "fan_in",
    "fan_out",
    "parallel_branches",
    "alternatives",
    "grid",
    "hub_and_spokes",
    "notes_sidebar",
]

DEFAULT_NODE_WIDTH = 260
DEFAULT_NODE_HEIGHT = 100
DEFAULT_GROUP_HEADER_HEIGHT = 36
MIN_NODE_GUTTER = 32
MIN_GROUP_GUTTER = 32
EXISTING_GROUP_SCORE_THRESHOLD = 0.65
EXISTING_GROUP_MIN_NODE_COVERAGE = 0.66
EXISTING_GROUP_MIN_ROLE_OR_TOPOLOGY = 0.65
EXISTING_GROUP_CONTAINMENT_WEIGHT = 0.35
EXISTING_GROUP_TOPOLOGY_WEIGHT = 0.25
EXISTING_GROUP_TITLE_ROLE_WEIGHT = 0.25
EXISTING_GROUP_NODE_COVERAGE_WEIGHT = 0.15

# Compile-local huge workflow defaults. These deliberately stay outside
# LayoutPlan v1 so the plan remains semantic-only.
COMPILE_HUGE_WORKFLOW_NODE_THRESHOLD = 20
COMPILE_HUGE_WORKFLOW_EDGE_THRESHOLD = 48
COMPILE_HUGE_WORKFLOW_PROJECTION_TOKEN_THRESHOLD = 4000
COMPILE_LARGE_SECTION_CLUSTER_SIZE = 10
COMPILE_MAX_ROW_COLUMNS = 3

COMPILE_METRIC_NODE_LAYOUT_COUNT = "compiled_node_layout_count"
COMPILE_METRIC_GROUP_LAYOUT_COUNT = "compiled_group_layout_count"
COMPILE_METRIC_HELPER_LAYOUT_COUNT = "compiled_helper_layout_count"
COMPILE_METRIC_NODE_OVERLAP_COUNT = "compiled_node_overlap_count"
COMPILE_METRIC_GROUP_OVERLAP_COUNT = "compiled_group_overlap_count"
COMPILE_METRIC_INTERNAL_WHITESPACE_RATIO_MAX = "compiled_internal_whitespace_ratio_max"
COMPILE_METRIC_BASELINE_VARIANCE_MAX = "compiled_baseline_variance_max"
COMPILE_METRIC_DETACHED_GROUP_DISTANCE_MAX = "compiled_detached_group_distance_max"
COMPILE_METRIC_HELPER_SIDECAR_OVERLAP_COUNT = "compiled_helper_sidecar_overlap_count"
COMPILE_METRIC_NOTE_SECTION_MISMATCH_COUNT = "compiled_note_section_mismatch_count"
COMPILE_METRIC_MAX_PRIMARY_NODES_PER_ROW = "compiled_max_primary_nodes_per_row"
COMPILE_METRIC_LONG_EDGE_DISTANCE_MAX = "compiled_long_edge_distance_max"
COMPILE_METRIC_BACKWARD_EDGE_RATIO = "compiled_backward_edge_ratio"
COMPILE_METRIC_CROSSING_PROXY_COUNT = "compiled_crossing_proxy_count"
COMPILE_METRIC_MINIMUM_GUTTER = "compiled_minimum_gutter"
COMPILE_METRIC_HELPER_DISTANCE_MAX = "compiled_helper_distance_max"
COMPILE_METRIC_IDEMPOTENCE_DELTA = "compiled_idempotence_delta"
COMPILE_METRIC_STRUCTURAL_HASH_UNCHANGED = "structural_hash_unchanged"

# A layered column is reflowed into wrapped sub-columns when it is at least this
# many times taller than the section's next-tallest column. See
# ``_rebalance_layer_columns``.
_REBALANCE_IMBALANCE_FACTOR = 1.6
_REBALANCE_MIN_DOMINANT_NODES = 3
COMPILE_ISSUE_NODE_OVERLAP = "compiler_node_overlap"
COMPILE_ISSUE_GROUP_OVERLAP = "compiler_group_overlap"
COMPILE_ISSUE_INTERNAL_WHITESPACE_HIGH = "compiler_internal_whitespace_high"
COMPILE_ISSUE_BASELINE_VARIANCE_HIGH = "compiler_baseline_variance_high"
COMPILE_ISSUE_DETACHED_GROUP_DISTANCE_HIGH = "compiler_detached_group_distance_high"
COMPILE_ISSUE_HELPER_SIDECAR_OVERLAP = "compiler_helper_sidecar_overlap"
COMPILE_ISSUE_NOTE_SECTION_MISMATCH = "compiler_note_section_mismatch"
COMPILE_ISSUE_MAX_PRIMARY_ROW_COUNT_HIGH = "compiler_max_primary_row_count_high"
COMPILE_ISSUE_LONG_EDGE_DISTANCE_HIGH = "compiler_long_edge_distance_high"
COMPILE_ISSUE_BACKWARD_EDGE_RATIO_HIGH = "compiler_backward_edge_ratio_high"
COMPILE_ISSUE_CROSSING_PROXY_HIGH = "compiler_crossing_proxy_high"
COMPILE_ISSUE_MINIMUM_GUTTER = "compiler_minimum_gutter_violation"
COMPILE_ISSUE_HELPER_DISTANCE_HIGH = "compiler_helper_distance_high"
COMPILE_ISSUE_IDEMPOTENCE_DELTA = "compiler_idempotence_delta"
COMPILE_ISSUE_STRUCTURAL_HASH_CHANGED = "compiler_structural_hash_changed"
COMPILE_ISSUE_EXISTING_GROUP_DISSOLVED = "existing_group_dissolved"
COMPILE_ISSUE_EXISTING_GROUP_REBUILT = "existing_group_rebuilt"
COMPILE_ISSUE_MIXED_CORE_ROLE = "compiler_mixed_core_role"
COMPILE_ISSUE_PINNED_PRESERVATION_FAILED = "compiler_pinned_preservation_failed"
COMPILE_BACKWARD_EDGE_RATIO_THRESHOLD = 0.15
COMPILE_BACKWARD_EDGE_X_TOLERANCE = 8.0
COMPILE_CROSSING_PROXY_THRESHOLD = 0
COMPILE_INTERNAL_WHITESPACE_RATIO_THRESHOLD = 0.9
COMPILE_BASELINE_VARIANCE_THRESHOLD = 16.0
COMPILE_DETACHED_GROUP_DISTANCE_THRESHOLD = 1600.0
COMPILE_MAX_PRIMARY_ROW_COUNT_THRESHOLD = 3
COMPILE_LONG_EDGE_DISTANCE_THRESHOLD = 2200.0
COMPILE_HELPER_DISTANCE_THRESHOLD = 420.0
COMPILE_IDEMPOTENCE_DELTA_THRESHOLD = 0
# Fixed-point drift penalty applied when a scalar attribute (color, bgcolor,
# mode, flags) changes between the compiler-owned sidecar and a recompilation.
# It intentionally exceeds COMPILE_IDEMPOTENCE_DELTA_THRESHOLD so any value
# change is treated as drift, not as a sub-threshold geometric wobble.
_IDEMPOTENCE_DRIFT_PENALTY = float(COMPILE_IDEMPOTENCE_DELTA_THRESHOLD + 1)
_ENTRY_DRIFT_SCALAR_KEYS = ("color", "bgcolor", "mode")
_ENTRY_DRIFT_MAPPING_KEYS = ("flags",)
_GROUP_DRIFT_SCALAR_KEYS = ("color",)
COMPILE_METRIC_ORDER = (
    COMPILE_METRIC_NODE_LAYOUT_COUNT,
    COMPILE_METRIC_GROUP_LAYOUT_COUNT,
    COMPILE_METRIC_HELPER_LAYOUT_COUNT,
    COMPILE_METRIC_NODE_OVERLAP_COUNT,
    COMPILE_METRIC_GROUP_OVERLAP_COUNT,
    COMPILE_METRIC_INTERNAL_WHITESPACE_RATIO_MAX,
    COMPILE_METRIC_BASELINE_VARIANCE_MAX,
    COMPILE_METRIC_DETACHED_GROUP_DISTANCE_MAX,
    COMPILE_METRIC_HELPER_SIDECAR_OVERLAP_COUNT,
    COMPILE_METRIC_NOTE_SECTION_MISMATCH_COUNT,
    COMPILE_METRIC_MAX_PRIMARY_NODES_PER_ROW,
    COMPILE_METRIC_LONG_EDGE_DISTANCE_MAX,
    COMPILE_METRIC_BACKWARD_EDGE_RATIO,
    COMPILE_METRIC_CROSSING_PROXY_COUNT,
    COMPILE_METRIC_MINIMUM_GUTTER,
    COMPILE_METRIC_HELPER_DISTANCE_MAX,
    COMPILE_METRIC_IDEMPOTENCE_DELTA,
    COMPILE_METRIC_STRUCTURAL_HASH_UNCHANGED,
)
COMPILE_ISSUE_ORDER = (
    COMPILE_ISSUE_NODE_OVERLAP,
    COMPILE_ISSUE_GROUP_OVERLAP,
    COMPILE_ISSUE_INTERNAL_WHITESPACE_HIGH,
    COMPILE_ISSUE_BASELINE_VARIANCE_HIGH,
    COMPILE_ISSUE_DETACHED_GROUP_DISTANCE_HIGH,
    COMPILE_ISSUE_HELPER_SIDECAR_OVERLAP,
    COMPILE_ISSUE_NOTE_SECTION_MISMATCH,
    COMPILE_ISSUE_MAX_PRIMARY_ROW_COUNT_HIGH,
    COMPILE_ISSUE_LONG_EDGE_DISTANCE_HIGH,
    COMPILE_ISSUE_BACKWARD_EDGE_RATIO_HIGH,
    COMPILE_ISSUE_CROSSING_PROXY_HIGH,
    COMPILE_ISSUE_MINIMUM_GUTTER,
    COMPILE_ISSUE_HELPER_DISTANCE_HIGH,
    COMPILE_ISSUE_IDEMPOTENCE_DELTA,
    COMPILE_ISSUE_STRUCTURAL_HASH_CHANGED,
    COMPILE_ISSUE_EXISTING_GROUP_DISSOLVED,
    COMPILE_ISSUE_EXISTING_GROUP_REBUILT,
    COMPILE_ISSUE_MIXED_CORE_ROLE,
    COMPILE_ISSUE_PINNED_PRESERVATION_FAILED,
)

_ENTRY_KEYS = ("pos", "size", "flags", "color", "bgcolor", "mode", "properties")
_SECTION_KEYS = (
    "entries",
    "groups",
    "extra",
    "lastRerouteId",
    "definitions",
    "virtual_wires",
)

_ROLE_COLORS: Mapping[str, str] = MappingProxyType(
    {
        SECTION_KIND_LOADERS: "#3f6f8f",
        SECTION_KIND_CONDITIONING: "#7b5ea7",
        SECTION_KIND_LATENT: "#6b8f5a",
        SECTION_KIND_SAMPLING: "#9a6a3a",
        SECTION_KIND_DECODE: "#4f7f72",
        SECTION_KIND_OUTPUT: "#8a5f68",
        SECTION_KIND_CONTROL: "#5f6f9a",
        SECTION_KIND_POSTPROCESS: "#7a7560",
        SECTION_KIND_UTILITY: "#686f78",
        SECTION_KIND_BRANCH: "#6f6a9a",
        SECTION_KIND_CONTAINER: "#5f7470",
        SECTION_KIND_CUSTOM: "#646464",
    }
)

_SECTION_MIN_RANKS: Mapping[SectionKind, int] = MappingProxyType(
    {
        SECTION_KIND_LOADERS: 0,
        SECTION_KIND_CONDITIONING: 1,
        SECTION_KIND_LATENT: 1,
        SECTION_KIND_CONTROL: 2,
        SECTION_KIND_SAMPLING: 3,
        SECTION_KIND_BRANCH: 3,
        SECTION_KIND_DECODE: 4,
        SECTION_KIND_POSTPROCESS: 5,
        SECTION_KIND_OUTPUT: 6,
        SECTION_KIND_UTILITY: 2,
        SECTION_KIND_CONTAINER: 0,
        SECTION_KIND_CUSTOM: 2,
    }
)

_ROLE_TO_SECTION_KIND: Mapping[RoleHint, SectionKind] = MappingProxyType(
    {
        ROLE_HINT_LOADER: SECTION_KIND_LOADERS,
        ROLE_HINT_CONDITIONING: SECTION_KIND_CONDITIONING,
        ROLE_HINT_LATENT: SECTION_KIND_LATENT,
        ROLE_HINT_SAMPLER: SECTION_KIND_SAMPLING,
        ROLE_HINT_DECODE: SECTION_KIND_DECODE,
        ROLE_HINT_OUTPUT: SECTION_KIND_OUTPUT,
        ROLE_HINT_CONTROL: SECTION_KIND_CONTROL,
        ROLE_HINT_POSTPROCESS: SECTION_KIND_POSTPROCESS,
        ROLE_HINT_HELPER: SECTION_KIND_UTILITY,
        ROLE_HINT_UI: SECTION_KIND_UTILITY,
        ROLE_HINT_SHARED: SECTION_KIND_CUSTOM,
        ROLE_HINT_SUBGRAPH_CONTAINER: SECTION_KIND_CONTAINER,
        ROLE_HINT_UNKNOWN: SECTION_KIND_CUSTOM,
    }
)

_SECTION_TITLE_TOKENS: Mapping[SectionKind, frozenset[str]] = MappingProxyType(
    {
        SECTION_KIND_LOADERS: frozenset({"loader", "load", "model", "checkpoint", "clip", "lora", "vae"}),
        SECTION_KIND_CONDITIONING: frozenset({"conditioning", "condition", "prompt", "text", "negative", "positive", "clip"}),
        SECTION_KIND_LATENT: frozenset({"latent", "empty", "noise"}),
        SECTION_KIND_SAMPLING: frozenset({"sampling", "sample", "sampler", "diffusion", "denoise"}),
        SECTION_KIND_DECODE: frozenset({"decode", "decoder", "vae", "image"}),
        SECTION_KIND_OUTPUT: frozenset({"output", "save", "preview", "result", "image"}),
        SECTION_KIND_CONTROL: frozenset({"control", "controlnet", "adapter", "reference"}),
        SECTION_KIND_POSTPROCESS: frozenset({"postprocess", "post", "upscale", "resize", "filter"}),
        SECTION_KIND_UTILITY: frozenset({"utility", "helper", "note", "reroute"}),
        SECTION_KIND_BRANCH: frozenset({"branch", "alternative", "parallel"}),
        SECTION_KIND_CONTAINER: frozenset({"container", "scope", "subgraph"}),
        SECTION_KIND_CUSTOM: frozenset({"custom", "group"}),
    }
)


def _freeze_jsonish(value: Any) -> Any:
    if isinstance(value, Mapping):
        return MappingProxyType({str(key): _freeze_jsonish(item) for key, item in value.items()})
    if isinstance(value, list | tuple):
        return tuple(_freeze_jsonish(item) for item in value)
    return value


def _thaw_jsonish(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _thaw_jsonish(item) for key, item in value.items()}
    if isinstance(value, tuple):
        return [_thaw_jsonish(item) for item in value]
    return value


def _candidate_schema_hash() -> str:
    payload = json.dumps(
        {"entry_keys": list(_ENTRY_KEYS), "section_keys": list(_SECTION_KEYS)},
        sort_keys=True,
    ).encode("utf-8")
    return hashlib.blake2b(payload, digest_size=8).hexdigest()


@dataclass(frozen=True, slots=True)
class LayoutCompileOptions:
    spacing_preset: SpacingPreset = "balanced"
    existing_group_policy: ExistingGroupPolicy = "semantic_preserve"
    grouping_policy: GroupingPolicy = "auto"
    force_regroup: bool = False
    pinned_refs: tuple[CanonicalNodeRef, ...] = ()
    preserve_node_sizes: bool = True
    minimize_setget_helpers: bool = True

    def __post_init__(self) -> None:
        if self.spacing_preset not in {"compact", "balanced", "wide"}:
            raise ValueError(f"unknown spacing preset: {self.spacing_preset!r}")
        if self.existing_group_policy not in {
            "preserve",
            "rename_only",
            "resize_only",
            "rename_and_resize",
            "semantic_preserve",
            "dissolve_with_warning",
            "force_regroup",
        }:
            raise ValueError(f"unknown existing group policy: {self.existing_group_policy!r}")
        if self.grouping_policy not in {"auto", "none", "preserve_existing", "stage", "wall"}:
            raise ValueError(f"unknown grouping policy: {self.grouping_policy!r}")
        object.__setattr__(self, "pinned_refs", tuple(self.pinned_refs))

    def to_json(self) -> dict[str, Any]:
        return {
            "spacing_preset": self.spacing_preset,
            "existing_group_policy": self.existing_group_policy,
            "grouping_policy": self.grouping_policy,
            "force_regroup": self.force_regroup,
            "pinned_refs": [ref.to_json() for ref in self.pinned_refs],
            "preserve_node_sizes": self.preserve_node_sizes,
            "minimize_setget_helpers": self.minimize_setget_helpers,
        }


@dataclass(frozen=True, slots=True)
class CompiledNodeLayout:
    ref: CanonicalNodeRef
    section_id: str
    role_hint: RoleHint
    x: int
    y: int
    width: int = DEFAULT_NODE_WIDTH
    height: int = DEFAULT_NODE_HEIGHT
    pinned: bool = False
    auto_collapsed: bool = False

    def to_json(self) -> dict[str, Any]:
        return {
            "ref": self.ref.to_json(),
            "section_id": self.section_id,
            "role_hint": self.role_hint,
            "pos": [self.x, self.y],
            "size": [self.width, self.height],
            "pinned": self.pinned,
            "auto_collapsed": self.auto_collapsed,
        }


@dataclass(frozen=True, slots=True)
class CompiledGroupLayout:
    id: str
    scope_path: str
    title: str
    kind: SectionKind
    node_refs: tuple[CanonicalNodeRef, ...]
    x: int
    y: int
    width: int
    height: int
    color: str
    role_hint: RoleHint | None = None
    template: SectionTemplate | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "node_refs", tuple(self.node_refs))

    def to_json(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "id": self.id,
            "scope_path": self.scope_path,
            "title": self.title,
            "kind": self.kind,
            "nodes": [ref.to_json() for ref in self.node_refs],
            "bounding": [self.x, self.y, self.width, self.height],
            "color": self.color,
        }
        if self.role_hint is not None:
            payload["role_hint"] = self.role_hint
        if self.template is not None:
            payload["template"] = self.template
        return payload




@dataclass(frozen=True, slots=True)
class CompiledSamplerRelation:
    kind: Literal["sequential", "parallel", "independent", "mixed"]
    samplers: tuple[CanonicalNodeRef, ...]
    section_ids: tuple[str, ...]
    auto_name: str
    source: CanonicalNodeRef | None = None
    target: CanonicalNodeRef | None = None
    bridge_path: tuple[CanonicalNodeRef, ...] = ()
    reasons: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "samplers", tuple(self.samplers))
        object.__setattr__(self, "section_ids", tuple(self.section_ids))
        object.__setattr__(self, "bridge_path", tuple(self.bridge_path))
        object.__setattr__(self, "reasons", tuple(self.reasons))

    def to_json(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "kind": self.kind,
            "samplers": [ref.to_json() for ref in self.samplers],
            "section_ids": list(self.section_ids),
            "auto_name": self.auto_name,
            "bridge_path": [ref.to_json() for ref in self.bridge_path],
            "reasons": list(self.reasons),
        }
        if self.source is not None:
            payload["source"] = self.source.to_json()
        if self.target is not None:
            payload["target"] = self.target.to_json()
        return payload


@dataclass(frozen=True, slots=True)
class LayoutCandidatePatch:
    entries: Mapping[str, Mapping[str, Any]] = field(default_factory=dict)
    groups: tuple[Mapping[str, Any], ...] = ()
    extra: Mapping[str, Any] = field(default_factory=dict)
    last_reroute_id: Any = None
    definitions: Mapping[str, Any] = field(default_factory=dict)
    virtual_wires: Mapping[str, Any] = field(default_factory=dict)
    store_version: int = STORE_VERSION
    vibecomfy_version: str = "0"
    schema_hash: str = field(default_factory=_candidate_schema_hash)
    unkeyed: tuple[Any, ...] = ()
    structural_hash_before: str = ""
    structural_hash_after: str = ""
    monotonic_generation: int = 0
    lease_nonce: str = ""
    plan_hash: str = ""

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "entries",
            MappingProxyType(
                {str(key): _freeze_jsonish(value) for key, value in self.entries.items()}
            ),
        )
        object.__setattr__(self, "groups", tuple(_freeze_jsonish(group) for group in self.groups))
        object.__setattr__(self, "extra", _freeze_jsonish(self.extra))
        object.__setattr__(self, "definitions", _freeze_jsonish(self.definitions))
        object.__setattr__(self, "virtual_wires", _freeze_jsonish(self.virtual_wires))
        object.__setattr__(self, "unkeyed", tuple(self.unkeyed))
        # Compute plan_hash from the full mutation-plan projection (core fields
        # only, excluding the metadata fields added by this patch itself).
        if not self.plan_hash:
            projection = {
                "store_version": self.store_version,
                "vibecomfy_version": self.vibecomfy_version,
                "schema_hash": self.schema_hash,
                "entries": _thaw_jsonish(self.entries),
                "groups": [_thaw_jsonish(group) for group in self.groups],
                "extra": _thaw_jsonish(self.extra),
                "lastRerouteId": self.last_reroute_id,
                "definitions": _thaw_jsonish(self.definitions),
                "virtual_wires": _thaw_jsonish(self.virtual_wires),
                "unkeyed": list(self.unkeyed),
            }
            raw = json.dumps(
                projection,
                sort_keys=True,
                separators=(",", ":"),
                ensure_ascii=True,
                default=str,
            ).encode("utf-8")
            object.__setattr__(self, "plan_hash", hashlib.sha256(raw).hexdigest())

    def to_json(self) -> dict[str, Any]:
        return {
            "store_version": self.store_version,
            "vibecomfy_version": self.vibecomfy_version,
            "schema_hash": self.schema_hash,
            "entries": _thaw_jsonish(self.entries),
            "groups": [_thaw_jsonish(group) for group in self.groups],
            "extra": _thaw_jsonish(self.extra),
            "lastRerouteId": self.last_reroute_id,
            "definitions": _thaw_jsonish(self.definitions),
            "virtual_wires": _thaw_jsonish(self.virtual_wires),
            "unkeyed": list(self.unkeyed),
            "structural_hash_before": self.structural_hash_before,
            "structural_hash_after": self.structural_hash_after,
            "monotonic_generation": self.monotonic_generation,
            "lease_nonce": self.lease_nonce,
            "plan_hash": self.plan_hash,
        }


@dataclass(frozen=True, slots=True)
class LayoutCompileResult:
    ok: bool
    options: LayoutCompileOptions
    node_layouts: tuple[CompiledNodeLayout, ...]
    group_layouts: tuple[CompiledGroupLayout, ...]
    section_topologies: tuple[CompiledSectionTopology, ...]
    sampler_relations: tuple[CompiledSamplerRelation, ...]
    candidate_patch: LayoutCandidatePatch
    validation_report: ReorganiseDiagnosticReport
    report: Any
    structural_hash_before: str
    structural_hash_after: str
    trace_entries: tuple[LayoutTraceEntry, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "node_layouts", tuple(self.node_layouts))
        object.__setattr__(self, "group_layouts", tuple(self.group_layouts))
        object.__setattr__(self, "section_topologies", tuple(self.section_topologies))
        object.__setattr__(self, "sampler_relations", tuple(self.sampler_relations))
        object.__setattr__(self, "trace_entries", tuple(self.trace_entries))

    @property
    def diagnostics(self) -> tuple[Any, ...]:
        return self.report.diagnostics

    @property
    def metrics(self) -> tuple[AssessmentMetric, ...]:
        return self.report.metrics

    def to_json(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "options": self.options.to_json(),
            "structural_hash_before": self.structural_hash_before,
            "structural_hash_after": self.structural_hash_after,
            "node_layouts": [layout.to_json() for layout in self.node_layouts],
            "group_layouts": [layout.to_json() for layout in self.group_layouts],
            "section_topologies": [topology.to_json() for topology in self.section_topologies],
            "sampler_relations": [relation.to_json() for relation in self.sampler_relations],
            "candidate_patch": self.candidate_patch.to_json(),
            "validation_report": self.validation_report.to_json(),
            "report": self.report.to_json(),
            "trace_entries": [entry.to_json() for entry in self.trace_entries],
        }






@dataclass(frozen=True, slots=True)
class _GeneratedSection:
    kind: SectionKind
    title: str
    role_hint: RoleHint | None = None


@dataclass(frozen=True, slots=True)
class _OwnershipDecision:
    ref: CanonicalNodeRef
    section_id: str
    attachment_target: CanonicalNodeRef | None = None
    reason: str | None = None


@dataclass(frozen=True, slots=True)
class _ExistingGroupScore:
    scope_path: str
    index: int
    title: str | None
    section_kind: SectionKind
    member_refs: tuple[CanonicalNodeRef, ...]
    contained_refs: tuple[CanonicalNodeRef, ...]
    containment: float
    topology: float
    title_role: float
    node_coverage: float
    score: float

    def __post_init__(self) -> None:
        object.__setattr__(self, "member_refs", tuple(self.member_refs))
        object.__setattr__(self, "contained_refs", tuple(self.contained_refs))

    @property
    def coherent(self) -> bool:
        return (
            self.score >= EXISTING_GROUP_SCORE_THRESHOLD
            and self.containment > 0.0
            and self.node_coverage >= EXISTING_GROUP_MIN_NODE_COVERAGE
            and (
                self.title_role >= EXISTING_GROUP_MIN_ROLE_OR_TOPOLOGY
                or self.topology >= EXISTING_GROUP_MIN_ROLE_OR_TOPOLOGY
            )
        )

    def to_json(self) -> dict[str, Any]:
        return {
            "scope_path": self.scope_path,
            "index": self.index,
            "title": self.title,
            "section_kind": self.section_kind,
            "member_refs": [ref.to_json() for ref in self.member_refs],
            "contained_refs": [ref.to_json() for ref in self.contained_refs],
            "containment": round(self.containment, 4),
            "topology": round(self.topology, 4),
            "title_role": round(self.title_role, 4),
            "node_coverage": round(self.node_coverage, 4),
            "score": round(self.score, 4),
            "coherent": self.coherent,
        }


@dataclass(frozen=True, slots=True)
class _ExistingGroupRect:
    x: float
    y: float
    width: float
    height: float

    @property
    def right(self) -> float:
        return self.x + self.width

    @property
    def bottom(self) -> float:
        return self.y + self.height


@dataclass(frozen=True, slots=True)
class _CompileRect:
    key: str
    x: float
    y: float
    width: float
    height: float
    ref: CanonicalNodeRef | None = None
    group: CompiledGroupLayout | None = None

    @property
    def right(self) -> float:
        return self.x + self.width

    @property
    def bottom(self) -> float:
        return self.y + self.height

    @property
    def center(self) -> tuple[float, float]:
        return (self.x + self.width / 2.0, self.y + self.height / 2.0)




@dataclass(frozen=True, slots=True)
class _LocalSectionLayout:
    template: SectionTemplate
    offsets: Mapping[CanonicalNodeRef, tuple[int, int]]
    width: int
    height: int
    placement_choices: Mapping[CanonicalNodeRef, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(self, "offsets", MappingProxyType(dict(self.offsets)))
        object.__setattr__(self, "placement_choices", MappingProxyType(dict(self.placement_choices)))


@dataclass(frozen=True, slots=True)
class _CompiledLayoutPlacement:
    node_layouts: tuple[CompiledNodeLayout, ...]
    group_layouts: tuple[CompiledGroupLayout, ...]


@dataclass(slots=True)
class _TraceNodeState:
    ref: CanonicalNodeRef
    class_type: str
    role_hint: RoleHint = ROLE_HINT_UNKNOWN
    layout_behavior: str = "unknown"
    pipeline_stage: str | None = None
    section_id: str | None = None
    attachment_target: CanonicalNodeRef | None = None
    placement_choice: str | None = None
    x: float | None = None
    y: float | None = None
    reason: str | None = None


class _CompileTraceAccumulator:
    def __init__(self, facts: GraphInventoryFacts) -> None:
        self._states: dict[CanonicalNodeRef, _TraceNodeState] = {}
        for fact in facts.canonical_refs:
            class_type = str(getattr(fact, "class_type", ""))
            layout_behavior = str(getattr(fact, "layout_behavior", "unknown") or "unknown")
            self._states[fact.ref] = _TraceNodeState(
                ref=fact.ref,
                class_type=class_type,
                role_hint=fact.role_hint,
                layout_behavior=layout_behavior,
            )

    def record_classification(self, classification: ClassificationReport) -> None:
        for ref, state in self._states.items():
            hint = classification.hint_for(ref)
            if hint is not None:
                state.role_hint = hint.role_hint
                state.pipeline_stage = hint.pipeline_stage

    def record_section_ownership(
        self,
        ownership: Mapping[CanonicalNodeRef, _OwnershipDecision],
    ) -> None:
        for ref, decision in ownership.items():
            state = self._states.get(ref)
            if state is None:
                continue
            state.section_id = decision.section_id
            state.attachment_target = decision.attachment_target
            state.reason = decision.reason

    def record_local_packing(
        self,
        section: _CompileSection,
        local_layout: _LocalSectionLayout,
    ) -> None:
        # Compute row placement for readable trace entries.
        # Group offsets by y-coordinate: nodes sharing the same y are in the same row.
        row_index_by_ref: dict[CanonicalNodeRef, int] = {}
        if local_layout.offsets:
            y_values = sorted({y for _x, y in local_layout.offsets.values()})
            for ref, (_x, y) in local_layout.offsets.items():
                row_index_by_ref[ref] = y_values.index(y)
        for ref in section.node_refs:
            state = self._states.get(ref)
            if state is not None:
                state.section_id = section.id
                explicit_choice = local_layout.placement_choices.get(ref)
                if explicit_choice is not None:
                    state.placement_choice = explicit_choice
                elif local_layout.template == "row":
                    row_idx = row_index_by_ref.get(ref, 0)
                    state.placement_choice = f"row:{row_idx}"
                else:
                    state.placement_choice = local_layout.template

    def record_global_layout(self, layout: CompiledNodeLayout) -> None:
        state = self._states.get(layout.ref)
        if state is not None:
            state.section_id = layout.section_id
            state.x = layout.x
            state.y = layout.y

    def record_wall_placement(
        self,
        section: _CompileSection,
        placement: _SectionPlacement,
        *,
        order: int,
    ) -> None:
        choice = f"wall:order:{order}:rank:{placement.rank}:band:{placement.band}:row:{placement.row}"
        for ref in section.node_refs:
            state = self._states.get(ref)
            if state is None:
                continue
            state.section_id = section.id
            state.placement_choice = (
                f"{state.placement_choice}|{choice}"
                if state.placement_choice is not None
                else choice
            )

    def to_entries(self) -> tuple[LayoutTraceEntry, ...]:
        return tuple(
            LayoutTraceEntry(
                ref=state.ref,
                class_type=state.class_type,
                role_hint=state.role_hint,
                layout_behavior=state.layout_behavior,
                pipeline_stage=state.pipeline_stage,
                section_id=state.section_id,
                attachment_target=state.attachment_target,
                placement_choice=state.placement_choice,
                x=state.x,
                y=state.y,
                reason=state.reason,
            )
            for state in sorted(self._states.values(), key=lambda item: _ref_sort_key(item.ref))
        )


def _classify_layout_phase(
    facts: GraphInventoryFacts,
    *,
    trace: _CompileTraceAccumulator | None = None,
) -> ClassificationReport:
    classification = classify_layout_facts(facts)
    if trace is not None:
        trace.record_classification(classification)
    return classification


def _compile_section_ownership_phase(
    plan: LayoutPlanV1,
    facts: GraphInventoryFacts,
    classification: ClassificationReport,
    options: LayoutCompileOptions,
    *,
    trace: _CompileTraceAccumulator | None = None,
) -> tuple[_CompileSection, ...]:
    sections, ownership = _compile_sections(plan, facts, classification, options)
    if trace is not None:
        trace.record_section_ownership(ownership)
    return sections


def _patch_emission_phase(
    node_layouts: Sequence[CompiledNodeLayout],
    group_layouts: Sequence[CompiledGroupLayout],
    facts: GraphInventoryFacts,
    options: LayoutCompileOptions,
    *,
    structural_hash: str = "",
) -> LayoutCandidatePatch:
    return _candidate_patch(node_layouts, group_layouts, facts, options, structural_hash=structural_hash)


def _validation_metrics_phase(
    *,
    sections: Sequence[_CompileSection],
    classification: ClassificationReport,
    node_layouts: Sequence[CompiledNodeLayout],
    group_layouts: Sequence[CompiledGroupLayout],
    facts: GraphInventoryFacts,
    candidate_patch: LayoutCandidatePatch,
    structural_hash: str,
    diagnostics: Sequence[Any],
    issues: Sequence[AssessmentIssue] = (),
):
    role_purity_issues = _validate_role_purity(sections, classification)
    return _build_report(
        node_layouts=node_layouts,
        group_layouts=group_layouts,
        facts=facts,
        candidate_patch=candidate_patch,
        structural_hash_before=structural_hash,
        structural_hash_after=structural_hash,
        diagnostics=diagnostics,
        issues=(*issues, *role_purity_issues),
    )


def compile_layout_plan(
    plan: LayoutPlanV1,
    facts: GraphInventoryFacts,
    *,
    options: LayoutCompileOptions | None = None,
) -> LayoutCompileResult:
    opts = options or LayoutCompileOptions()
    validation_report = validate_layout_plan(plan, facts)
    structural_hash = structural_hash_for_layout_facts(facts)
    if not validation_report.ok:
        candidate_patch = LayoutCandidatePatch()
        report = _build_report(
            node_layouts=(),
            group_layouts=(),
            facts=facts,
            candidate_patch=candidate_patch,
            structural_hash_before=structural_hash,
            structural_hash_after=structural_hash,
            diagnostics=validation_report.diagnostics,
        )
        return LayoutCompileResult(
            ok=False,
            options=opts,
            node_layouts=(),
            group_layouts=(),
            section_topologies=(),
            sampler_relations=(),
            candidate_patch=candidate_patch,
            validation_report=validation_report,
            report=report,
            structural_hash_before=structural_hash,
            structural_hash_after=structural_hash,
            trace_entries=(),
        )

    trace = _CompileTraceAccumulator(facts)
    classification = _classify_layout_phase(facts, trace=trace)
    sections = _compile_section_ownership_phase(
        plan,
        facts,
        classification,
        opts,
        trace=trace,
    )
    section_topologies = _compile_section_topologies(sections, facts)
    sampler_relations = _normalize_sampler_relations(plan, facts, sections)
    layout = _layout_sections(
        plan,
        sections,
        section_topologies,
        facts,
        opts,
        classification,
        trace=trace,
    )
    node_layouts = layout.node_layouts
    group_layouts = layout.group_layouts
    # ---- pinned-node preservation gate ----
    pinned_diagnostics = _validate_pinned_preservation(node_layouts, facts, opts)
    if pinned_diagnostics:
        validation_report = ReorganiseDiagnosticReport(
            ok=False,
            diagnostics=(*validation_report.diagnostics, *pinned_diagnostics),
        )
    # ---------------------------------------
    should_apply_existing_policy = (
        not _large_workflow_soft_quality_gate(facts)
        and _effective_grouping_policy(facts, opts) != "none"
    )
    group_layouts, policy_issues = _apply_existing_group_policy(
        group_layouts,
        facts,
        opts,
        classification,
    ) if should_apply_existing_policy else (group_layouts, ())
    candidate_patch = _patch_emission_phase(node_layouts, group_layouts, facts, opts, structural_hash=structural_hash)
    report = _validation_metrics_phase(
        sections=sections,
        classification=classification,
        node_layouts=node_layouts,
        group_layouts=group_layouts,
        facts=facts,
        candidate_patch=candidate_patch,
        structural_hash=structural_hash,
        diagnostics=validation_report.diagnostics,
        issues=policy_issues,
    )
    return LayoutCompileResult(
        ok=validation_report.ok and report.verdict != "blocked",
        options=opts,
        node_layouts=node_layouts,
        group_layouts=group_layouts,
        section_topologies=section_topologies,
        sampler_relations=sampler_relations,
        candidate_patch=candidate_patch,
        validation_report=validation_report,
        report=report,
        structural_hash_before=structural_hash,
        structural_hash_after=structural_hash,
        trace_entries=trace.to_entries(),
    )


def compile_layout_plan_from_ui(
    plan: LayoutPlanV1,
    ui_json: Mapping[str, Any],
    *,
    sidecar_envelope: Mapping[str, Any] | None = None,
    options: LayoutCompileOptions | None = None,
) -> LayoutCompileResult:
    facts = extract_graph_facts(ui_json, sidecar_envelope=sidecar_envelope)
    return compile_layout_plan(plan, facts, options=options)


def structural_hash_for_layout_facts(facts: GraphInventoryFacts) -> str:
    """Return a deterministic runtime-structure hash for compiler invariance.

    Layout-store furniture sections such as entries, groups, extra,
    lastRerouteId, definitions payloads, and virtual_wires payloads are
    intentionally excluded. The hash is over canonical node identities, classes,
    helper status, effective topology facts, group geometry/color/position,
    and node furniture position/size available to the compiler.
    """

    payload = {
        "canonical_refs": [
            {
                "ref": fact.ref.to_json(),
                "class_type": fact.class_type,
                "is_helper": fact.is_helper,
            }
            for fact in sorted(facts.canonical_refs, key=lambda fact: _ref_sort_key(fact.ref))
        ],
        "scope_topologies": [
            topology.to_json()
            for topology in sorted(facts.scope_topologies, key=lambda topology: topology.scope_path)
        ],
        "scope_furniture": [
            {
                "scope_path": scope.scope_path,
                "groups": [
                    {
                        "index": group.index,
                        "title": group.title,
                        "bounding": _thaw_jsonish(group.bounding),
                        "color": group.color,
                    }
                    for group in sorted(scope.groups, key=lambda g: g.index)
                ],
            }
            for scope in sorted(facts.scope_furniture, key=lambda s: s.scope_path)
        ],
        "node_furniture": [
            {
                "ref": fact.ref.to_json(),
                "pos": _thaw_jsonish(fact.pos),
                "size": _thaw_jsonish(fact.size),
                "flags": _thaw_jsonish(fact.flags),
            }
            for fact in sorted(facts.node_furniture, key=lambda f: _ref_sort_key(f.ref))
        ],
    }
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")
    return hashlib.blake2b(raw, digest_size=16).hexdigest()


def topology_hash_for_layout_facts(facts: GraphInventoryFacts) -> str:
    """Return a position-invariant topology-only hash for structural-noop checks.

    This hash covers canonical node identities, classes, helper status,
    and effective topology facts *only*.  Furniture (group geometry, color,
    node position, size, flags) is intentionally excluded so that pure
    layout repositioning does not change the hash.
    """

    payload = {
        "canonical_refs": [
            {
                "ref": fact.ref.to_json(),
                "class_type": fact.class_type,
                "is_helper": fact.is_helper,
            }
            for fact in sorted(facts.canonical_refs, key=lambda fact: _ref_sort_key(fact.ref))
        ],
        "scope_topologies": [
            topology.to_json()
            for topology in sorted(facts.scope_topologies, key=lambda topology: topology.scope_path)
        ],
    }
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")
    return hashlib.blake2b(raw, digest_size=16).hexdigest()


def _compile_sections(
    plan: LayoutPlanV1,
    facts: GraphInventoryFacts,
    classification: ClassificationReport,
    options: LayoutCompileOptions,
) -> tuple[tuple[_CompileSection, ...], Mapping[CanonicalNodeRef, _OwnershipDecision]]:
    section_defs = {section.id: section for section in plan.sections}
    generated_defs: dict[str, _GeneratedSection] = {}
    huge_mode = _large_workflow_soft_quality_gate(facts)
    helper_refs = {fact.ref for fact in facts.canonical_refs if fact.is_helper}
    canonical_by_ref = {fact.ref: fact for fact in facts.canonical_refs}
    furniture_by_ref = {fact.ref: fact for fact in facts.node_furniture}
    placement_by_helper = {placement.helper: placement for placement in plan.helper_placements}

    primary_owned: dict[CanonicalNodeRef, str] = {}
    ownership: dict[CanonicalNodeRef, _OwnershipDecision] = {}
    for section in plan.sections:
        for ref in section.nodes:
            if ref not in helper_refs:
                primary_owned[ref] = section.id
                ownership[ref] = _OwnershipDecision(
                    ref=ref,
                    section_id=section.id,
                    reason="primary_explicit_section",
                )
    for shared in plan.shared_nodes:
        if shared.node not in helper_refs:
            primary_owned[shared.node] = shared.home
            ownership[shared.node] = _OwnershipDecision(
                ref=shared.node,
                section_id=shared.home,
                reason="primary_shared_home",
            )

    anchored_helper_targets: dict[CanonicalNodeRef, CanonicalNodeRef] = {}
    for placement in plan.helper_placements:
        if placement.kind in {HELPER_PLACEMENT_NEAR_PRODUCER, HELPER_PLACEMENT_NEAR_CONSUMER} and placement.target is not None:
            anchored_helper_targets[placement.helper] = placement.target
    if huge_mode:
        prompt_generated = _GeneratedSection(
            kind=SECTION_KIND_CONDITIONING,
            title="Prompt / Conditioning",
            role_hint=ROLE_HINT_CONDITIONING,
        )
        for ref, section_id in tuple(primary_owned.items()):
            section = section_defs.get(section_id)
            title = (section.title if section is not None and section.title is not None else section_id).lower()
            if section is not None and (
                section.kind == SECTION_KIND_CONDITIONING
                or _huge_prompt_prep_title(title)
            ):
                primary_owned[ref] = "__huge_prompt_conditioning__"
                ownership[ref] = _OwnershipDecision(
                    ref=ref,
                    section_id="__huge_prompt_conditioning__",
                    reason="primary_huge_prompt_conditioning",
                )
                generated_defs["__huge_prompt_conditioning__"] = prompt_generated
    if huge_mode and _can_preserve_existing_groups(options):
        for ref, generated in _huge_existing_group_ownership(facts, classification).items():
            # Existing canvas groups are weak, inferred evidence.  They must
            # never replace the semantic ownership stated by the layout plan.
            # In particular, a large catch-all group can span loaders,
            # conditioning, sampling, latent, and decode nodes; preserving it
            # here used to overwrite every one of those explicit sections.
            if ref in helper_refs or ref in primary_owned:
                continue
            primary_owned[ref] = generated[0]
            ownership[ref] = _OwnershipDecision(
                ref=ref,
                section_id=generated[0],
                reason="primary_huge_existing_group",
            )
            generated_defs.setdefault(generated[0], generated[1])
        for ref, generated in _huge_existing_label_ownership(facts, classification).items():
            if ref in helper_refs:
                continue
            primary_owned[ref] = generated[0]
            ownership[ref] = _OwnershipDecision(
                ref=ref,
                section_id=generated[0],
                reason="primary_huge_existing_label",
            )
            generated_defs.setdefault(generated[0], generated[1])

    unassigned = tuple(
        fact.ref
        for fact in sorted(facts.canonical_refs, key=lambda item: _ref_sort_key(item.ref))
        if fact.ref not in primary_owned and fact.ref not in helper_refs
    )
    if plan.unassigned_policy == UNASSIGNED_PRESERVE_EXISTING and _can_preserve_existing_groups(options):
        preserved = _preserved_existing_ownership(
            facts,
            unassigned_refs=unassigned,
            assigned_refs=set(primary_owned),
            classification=classification,
        )
        for ref, generated in preserved.items():
            primary_owned[ref] = generated[0]
            ownership[ref] = _OwnershipDecision(
                ref=ref,
                section_id=generated[0],
                reason="primary_preserve_existing_group",
            )
            generated_defs.setdefault(generated[0], generated[1])

    if plan.unassigned_policy in {
        UNASSIGNED_CLASSIFY_DETERMINISTICALLY,
        UNASSIGNED_PRESERVE_EXISTING,
    }:
        for ref in unassigned:
            if ref in primary_owned:
                continue
            fact = canonical_by_ref.get(ref)
            if huge_mode and _is_prompt_text_ref(ref, canonical_by_ref):
                primary_owned[ref] = "__huge_prompt_conditioning__"
                ownership[ref] = _OwnershipDecision(
                    ref=ref,
                    section_id="__huge_prompt_conditioning__",
                    reason="primary_huge_prompt_text",
                )
                generated_defs["__huge_prompt_conditioning__"] = _GeneratedSection(
                    kind=SECTION_KIND_CONDITIONING,
                    title="Prompt / Conditioning",
                    role_hint=ROLE_HINT_CONDITIONING,
                )
                continue
            hint = classification.hint_for(ref)
            role = hint.role_hint if hint is not None else fact.role_hint if fact is not None else ROLE_HINT_UNKNOWN
            primary_owned[ref] = _section_for_role(role, section_defs)
            ownership[ref] = _OwnershipDecision(
                ref=ref,
                section_id=primary_owned[ref],
                reason="primary_classified_role",
            )
    elif plan.unassigned_policy == UNASSIGNED_REJECT:
        pass

    incident_adjacency = _incident_ref_adjacency(facts)
    helper_targets = {
        placement.helper: _helper_section_id(placement, primary_owned)
        for placement in plan.helper_placements
    }
    helper_targets.update(
        _nearest_note_helper_sections(
            facts,
            primary_owned,
            section_defs,
            generated_defs,
        )
    )
    for helper_ref in sorted(helper_refs, key=_ref_sort_key):
        resolved = _resolve_helper_ownership(
            helper_ref,
            facts=facts,
            primary_owned=primary_owned,
            canonical_by_ref=canonical_by_ref,
            furniture_by_ref=furniture_by_ref,
            placement_by_helper=placement_by_helper,
            incident_adjacency=incident_adjacency,
        )
        section_id = helper_targets.get(helper_ref, resolved.section_id)
        reason = resolved.reason
        if section_id != resolved.section_id and helper_ref in helper_targets and resolved.reason in {
            None,
            "helper_unowned_fallback",
            "note_unowned_fallback",
        }:
            reason = "helper_explicit_or_nearest_section"
        ownership[helper_ref] = _OwnershipDecision(
            ref=helper_ref,
            section_id=section_id,
            attachment_target=resolved.attachment_target,
            reason=reason,
        )

    refs_by_section: dict[str, list[CanonicalNodeRef]] = {}
    for ref, decision in sorted(ownership.items(), key=lambda item: _ref_sort_key(item[0])):
        refs_by_section.setdefault(decision.section_id, []).append(ref)

    section_ids_to_emit = set(refs_by_section)
    parent_ids = {
        section.parent_id
        for section in plan.sections
        if section.parent_id is not None
    }
    for section in plan.sections:
        if section.kind == SECTION_KIND_CONTAINER or section.id in parent_ids:
            section_ids_to_emit.add(section.id)

    sections: list[_CompileSection] = []
    for section_id in sorted(
        section_ids_to_emit,
        key=lambda item: _section_sort_key(item, section_defs.get(item), refs_by_section.get(item, ())),
    ):
        refs = refs_by_section.get(section_id, [])
        section = section_defs.get(section_id)
        generated = generated_defs.get(section_id)
        kind = (
            section.kind
            if section is not None
            else generated.kind
            if generated is not None
            else _generated_section_kind(section_id)
        )
        title = (
            section.title
            if section is not None and section.title is not None
            else generated.title
            if generated is not None
            else _title_for(section_id, kind)
        )
        compiled = _CompileSection(
            id=section_id,
            kind=kind,
            title=title,
            role_hint=section.role_hint if section is not None else generated.role_hint if generated is not None else None,
            node_refs=tuple(sorted(refs, key=_ref_sort_key)),
            parent_id=section.parent_id if section is not None else None,
        )
        sections.extend(
            _split_section_preserving_anchored_helpers(
                compiled,
                facts,
                anchored_helper_targets=anchored_helper_targets,
                enabled=huge_mode,
            )
        )
    return tuple(sections), MappingProxyType(dict(ownership))


def _nearest_note_helper_sections(
    facts: GraphInventoryFacts,
    final_primary_owned: Mapping[CanonicalNodeRef, str],
    section_defs: Mapping[str, LayoutSection],
    generated_defs: Mapping[str, _GeneratedSection],
) -> dict[CanonicalNodeRef, str]:
    rects = _node_rects_by_ref(facts.node_furniture)
    primary_centers = {
        ref: _existing_rect_center(rect)
        for ref, rect in rects.items()
        if ref in final_primary_owned
    }
    if not primary_centers:
        return {}
    canonical_by_ref = {fact.ref: fact for fact in facts.canonical_refs}
    section_title_by_id = _section_title_lookup(section_defs, generated_defs)
    targets: dict[CanonicalNodeRef, str] = {}
    for ref, rect in rects.items():
        fact = canonical_by_ref.get(ref)
        if fact is None or fact.class_type not in {"Note", "MarkdownNote"}:
            continue
        semantic_section = _semantic_note_section_id(fact.title or "", section_title_by_id)
        if semantic_section is not None:
            targets[ref] = semantic_section
            continue
        center = _existing_rect_center(rect)
        candidates = [
            (
                _distance_sq(center, primary_center),
                final_primary_owned[primary_ref],
                _ref_sort_key(primary_ref),
                primary_ref,
            )
            for primary_ref, primary_center in primary_centers.items()
            if primary_ref.scope_path == ref.scope_path
        ]
        if not candidates:
            continue
        distance, section_id, _sort_key, _primary_ref = min(candidates)
        if distance <= 500.0 * 500.0:
            targets[ref] = section_id
    return targets


def _section_title_lookup(
    section_defs: Mapping[str, LayoutSection],
    generated_defs: Mapping[str, _GeneratedSection],
) -> dict[str, str]:
    titles: dict[str, str] = {}
    for section_id, section in section_defs.items():
        title = section.title or _title_for(section_id, section.kind)
        titles[section_id] = title
    for section_id, generated in generated_defs.items():
        titles[section_id] = generated.title or _title_for(section_id, generated.kind)
    return titles


def _semantic_note_section_id(
    note_title: str,
    section_title_by_id: Mapping[str, str],
) -> str | None:
    text = note_title.lower()
    preferences: list[tuple[str, ...]] = []
    if any(token in text for token in ("video setting", "about size", "width", "height", "fps")):
        preferences.append(("video settings", "settings"))
    if any(token in text for token in ("lora", "model")):
        preferences.append(("lora", "model"))
    if any(token in text for token in ("prompt", "enhancer", "prompting")):
        preferences.append(("prompt", "conditioning"))
    if any(token in text for token in ("sampler", "preview", "tiny vae")):
        preferences.append(("sampler", "decode"))
    for tokens in preferences:
        for token in tokens:
            matches = [
                (section_id, title)
                for section_id, title in section_title_by_id.items()
                if token in title.lower()
            ]
            if matches:
                return sorted(matches, key=lambda item: (len(item[1]), item[0]))[0][0]
    return None


def _split_section_preserving_anchored_helpers(
    section: _CompileSection,
    facts: GraphInventoryFacts,
    *,
    anchored_helper_targets: Mapping[CanonicalNodeRef, CanonicalNodeRef],
    enabled: bool,
) -> tuple[_CompileSection, ...]:
    anchored_helpers = tuple(ref for ref in section.node_refs if ref in anchored_helper_targets)
    if not enabled or not anchored_helpers:
        return _split_huge_section_for_wall(section, facts, enabled=enabled)

    primary_section = _CompileSection(
        id=section.id,
        kind=section.kind,
        title=section.title,
        role_hint=section.role_hint,
        node_refs=tuple(ref for ref in section.node_refs if ref not in anchored_helper_targets),
        parent_id=section.parent_id,
    )
    split_sections = list(_split_huge_section_for_wall(primary_section, facts, enabled=enabled))
    if not split_sections:
        split_sections = [primary_section]

    helpers_by_section_index: dict[int, list[CanonicalNodeRef]] = {}
    for helper in anchored_helpers:
        target = anchored_helper_targets[helper]
        target_index = next(
            (index for index, split in enumerate(split_sections) if target in split.node_refs),
            0,
        )
        helpers_by_section_index.setdefault(target_index, []).append(helper)

    result: list[_CompileSection] = []
    for index, split in enumerate(split_sections):
        helpers = tuple(sorted(helpers_by_section_index.get(index, ()), key=_ref_sort_key))
        if not helpers:
            result.append(split)
            continue
        result.append(
            _CompileSection(
                id=split.id,
                kind=split.kind,
                title=split.title,
                role_hint=split.role_hint,
                node_refs=tuple((*split.node_refs, *helpers)),
                parent_id=split.parent_id,
            )
        )
    return tuple(result)


def _huge_existing_group_ownership(
    facts: GraphInventoryFacts,
    classification: ClassificationReport,
) -> dict[CanonicalNodeRef, tuple[str, _GeneratedSection]]:
    helper_refs = {fact.ref for fact in facts.canonical_refs if fact.is_helper}
    ownership: dict[CanonicalNodeRef, tuple[str, _GeneratedSection]] = {}
    for group, score in _scored_existing_groups(facts, classification):
        if score.containment <= 0.0 or score.score < 0.5:
            continue
        primary_refs = tuple(ref for ref in score.member_refs if ref not in helper_refs)
        if not primary_refs:
            continue
        section_id, generated = _huge_existing_group_section(group, score, primary_refs, facts)
        for ref in primary_refs:
            ownership[ref] = (section_id, generated)
    return ownership


def _huge_existing_label_ownership(
    facts: GraphInventoryFacts,
    classification: ClassificationReport,
) -> dict[CanonicalNodeRef, tuple[str, _GeneratedSection]]:
    label_refs = {fact.ref for fact in facts.canonical_refs if _is_label_ref(fact.ref, facts)}
    if not label_refs:
        return {}

    rects = _node_rects_by_ref(facts.node_furniture)
    ownership: dict[CanonicalNodeRef, tuple[str, _GeneratedSection]] = {}
    scored_groups = tuple(_scored_existing_groups(facts, classification))
    existing_sections: list[tuple[GroupFact, _ExistingGroupScore, tuple[CanonicalNodeRef, ...], str, _GeneratedSection]] = []
    for group, score in scored_groups:
        primary_refs = tuple(ref for ref in score.member_refs if ref not in label_refs)
        if not primary_refs:
            continue
        section_id, generated = _huge_existing_group_section(group, score, primary_refs, facts)
        existing_sections.append((group, score, primary_refs, section_id, generated))

    for ref in sorted(label_refs, key=_ref_sort_key):
        semantic = _semantic_label_section(ref, facts, existing_sections)
        if semantic is not None:
            ownership[ref] = semantic

    for group, score, primary_refs, section_id, generated in existing_sections:
        if score.containment <= 0.0 or score.score < 0.5:
            continue
        group_rect = _group_rect(group.bounding)
        contained_refs = _contained_group_refs(group.scope_path, group_rect, rects, set())
        explicit_refs = _group_node_refs(facts, group.scope_path, group.nodes)
        candidate_refs = explicit_refs if explicit_refs is not None and explicit_refs else contained_refs
        group_label_refs = tuple(ref for ref in candidate_refs if ref in label_refs and ref not in ownership)
        if not group_label_refs:
            continue
        for ref in group_label_refs:
            ownership[ref] = (section_id, generated)
    for ref in sorted((ref for ref in label_refs if ref not in ownership), key=_ref_sort_key):
        nearest = _nearest_existing_section_for_label(ref, rects, existing_sections)
        if nearest is not None:
            ownership[ref] = nearest
    return ownership


def _nearest_existing_section_for_label(
    ref: CanonicalNodeRef,
    rects: Mapping[CanonicalNodeRef, _ExistingGroupRect],
    existing_sections: Sequence[tuple[GroupFact, _ExistingGroupScore, tuple[CanonicalNodeRef, ...], str, _GeneratedSection]],
) -> tuple[str, _GeneratedSection] | None:
    label_rect = rects.get(ref)
    if label_rect is None:
        return None
    label_center = _existing_rect_center(label_rect)
    candidates: list[tuple[float, str, _GeneratedSection]] = []
    for group, score, primary_refs, section_id, generated in existing_sections:
        if score.containment <= 0.0 or score.score < 0.5:
            continue
        center = _existing_group_or_refs_center(group, primary_refs, rects)
        if center is None:
            continue
        candidates.append((_distance_sq(label_center, center), section_id, generated))
    if not candidates:
        return None
    _distance, section_id, generated = min(candidates, key=lambda item: (item[0], item[1]))
    return (section_id, generated)


def _existing_group_or_refs_center(
    group: GroupFact,
    refs: Sequence[CanonicalNodeRef],
    rects: Mapping[CanonicalNodeRef, _ExistingGroupRect],
) -> tuple[float, float] | None:
    group_rect = _group_rect(group.bounding)
    if group_rect is not None:
        return _existing_rect_center(group_rect)
    centers = [_existing_rect_center(rects[ref]) for ref in refs if ref in rects]
    if not centers:
        return None
    return (
        sum(center[0] for center in centers) / len(centers),
        sum(center[1] for center in centers) / len(centers),
    )


def _existing_rect_center(rect: _ExistingGroupRect) -> tuple[float, float]:
    return (rect.x + rect.width / 2.0, rect.y + rect.height / 2.0)


def _distance_sq(left: tuple[float, float], right: tuple[float, float]) -> float:
    return (left[0] - right[0]) ** 2 + (left[1] - right[1]) ** 2


def _semantic_label_section(
    ref: CanonicalNodeRef,
    facts: GraphInventoryFacts,
    existing_sections: Sequence[tuple[GroupFact, _ExistingGroupScore, tuple[CanonicalNodeRef, ...], str, _GeneratedSection]],
) -> tuple[str, _GeneratedSection] | None:
    text = _label_text(ref, facts)
    if not text:
        return None
    lowered = text.lower()
    if any(token in lowered for token in ("prompt", "enhance")):
        return (
            "__huge_prompt_conditioning__",
            _GeneratedSection(
                kind=SECTION_KIND_CONDITIONING,
                title="Prompt / Conditioning",
                role_hint=ROLE_HINT_CONDITIONING,
            ),
        )
    preferences: tuple[str, ...] = ()
    if "lora" in lowered:
        preferences = ("lora",)
    elif "model" in lowered:
        preferences = ("model",)
    elif "video" in lowered or "size" in lowered or "setting" in lowered:
        preferences = ("setting", "video")
    elif "sampler" in lowered:
        preferences = ("sampler",)
    if not preferences:
        return None
    for group, _score, _primary_refs, section_id, generated in existing_sections:
        title = str(group.title or generated.title or "").lower()
        if any(token in title for token in preferences):
            return (section_id, generated)
    return None


def _label_text(ref: CanonicalNodeRef, facts: GraphInventoryFacts) -> str:
    canonical_by_ref = {fact.ref: fact for fact in facts.canonical_refs}
    furniture_by_ref = {fact.ref: fact for fact in facts.node_furniture}
    fact = canonical_by_ref.get(ref)
    furniture = furniture_by_ref.get(ref)
    return " ".join(
        part
        for part in (
            str(getattr(fact, "title", "") or ""),
            str(getattr(furniture, "title", "") or ""),
        )
        if part
    )


def _huge_existing_group_section(
    group: GroupFact,
    score: _ExistingGroupScore,
    primary_refs: Sequence[CanonicalNodeRef],
    facts: GraphInventoryFacts,
) -> tuple[str, _GeneratedSection]:
    title = group.title if isinstance(group.title, str) and group.title else ""
    normalized = title.lower()
    if _huge_prompt_prep_title(normalized) or _prompt_text_refs(primary_refs, facts):
        return (
            "__huge_prompt_conditioning__",
            _GeneratedSection(
                kind=SECTION_KIND_CONDITIONING,
                title="Prompt / Conditioning",
                role_hint=ROLE_HINT_CONDITIONING,
            ),
        )
    section_id = _existing_group_section_id(group.scope_path, group.index)
    return (
        section_id,
        _GeneratedSection(
            kind=_huge_existing_group_kind(score, normalized),
            title=title or _title_for(section_id, score.section_kind),
        ),
    )


def _huge_prompt_prep_title(title: str) -> bool:
    return (
        "conditioning" in title
        or "prompt" in title
        or "text to video" in title
        or "text-to-video" in title
        or "enhance" in title
    )


def _prompt_text_refs(
    refs: Sequence[CanonicalNodeRef],
    facts: GraphInventoryFacts,
) -> tuple[CanonicalNodeRef, ...]:
    canonical_by_ref = {fact.ref: fact for fact in facts.canonical_refs}
    return tuple(
        ref
        for ref in refs
        if _is_prompt_text_ref(ref, canonical_by_ref)
    )


def _is_prompt_text_ref(
    ref: CanonicalNodeRef,
    canonical_by_ref: Mapping[CanonicalNodeRef, Any],
) -> bool:
    fact = canonical_by_ref.get(ref)
    if fact is None:
        return False
    class_type = str(getattr(fact, "class_type", "")).lower()
    title = str(getattr(fact, "title", "") or "").lower()
    text = f"{class_type} {title}"
    if any(token in text for token in ("prompt", "textgenerate", "text generate", "enhance")):
        return True
    if "stringconcatenate" in class_type:
        return True
    if "primitivestring" in class_type:
        return True
    return False


def _huge_existing_group_kind(score: _ExistingGroupScore, title: str) -> SectionKind:
    if "input" in title:
        return SECTION_KIND_UTILITY
    if "setting" in title:
        return SECTION_KIND_UTILITY
    if "sampler" in title:
        return SECTION_KIND_SAMPLING
    if "latent" in title or "prepare" in title:
        return SECTION_KIND_LATENT
    if "decode" in title:
        return SECTION_KIND_DECODE
    return score.section_kind


def _split_huge_section_for_wall(
    section: _CompileSection,
    facts: GraphInventoryFacts,
    *,
    enabled: bool,
) -> tuple[_CompileSection, ...]:
    if not enabled or section.kind == SECTION_KIND_CONTAINER or len(section.node_refs) <= 6:
        return (section,)
    if section.id == "__huge_prompt_conditioning__":
        return (section,)
    if section.id.startswith("__existing_"):
        return (section,)

    buckets: dict[tuple[str, str, SectionKind], list[CanonicalNodeRef]] = {}
    for ref in section.node_refs:
        bucket_id, title, kind = _wall_bucket_for_ref(section, ref, facts)
        buckets.setdefault((bucket_id, title, kind), []).append(ref)
    buckets = _merge_label_wall_buckets(buckets, facts)
    if len(buckets) <= 1:
        return (section,)

    split: list[_CompileSection] = []
    for (bucket_id, title, kind), refs in sorted(
        buckets.items(),
        key=lambda item: (_wall_bucket_sort_key(item[0][0]), item[0][0]),
    ):
        chunks = _wall_bucket_chunks(
            bucket_id,
            refs,
            facts=facts,
        )
        for index, chunk in enumerate(chunks):
            suffix = f"_{index + 1}" if len(chunks) > 1 else ""
            split.append(
                _CompileSection(
                    id=f"{section.id}__{bucket_id}{suffix}",
                    kind=kind,
                    title=f"{title} {index + 1}" if len(chunks) > 1 else title,
                    role_hint=section.role_hint,
                    node_refs=chunk,
                    parent_id=section.parent_id,
                )
            )
    return tuple(split)


def _merge_label_wall_buckets(
    buckets: Mapping[tuple[str, str, SectionKind], Sequence[CanonicalNodeRef]],
    facts: GraphInventoryFacts,
) -> dict[tuple[str, str, SectionKind], list[CanonicalNodeRef]]:
    merged = {key: list(refs) for key, refs in buckets.items()}
    label_keys = [key for key in merged if key[0] == "labels"]
    if not label_keys:
        return merged
    target_keys = [key for key in merged if key[0] != "labels" and key[0] != "setget"]
    if not target_keys:
        target_keys = [key for key in merged if key[0] != "labels"]
    if not target_keys:
        return merged

    rects = _node_rects_by_ref(facts.node_furniture)
    for label_key in label_keys:
        label_refs = merged.pop(label_key, [])
        for ref in label_refs:
            target_key = _nearest_wall_bucket_for_ref(ref, target_keys, merged, rects)
            if target_key is None:
                merged.setdefault(label_key, []).append(ref)
            else:
                merged.setdefault(target_key, []).append(ref)
    return merged


def _nearest_wall_bucket_for_ref(
    ref: CanonicalNodeRef,
    target_keys: Sequence[tuple[str, str, SectionKind]],
    buckets: Mapping[tuple[str, str, SectionKind], Sequence[CanonicalNodeRef]],
    rects: Mapping[CanonicalNodeRef, _ExistingGroupRect],
) -> tuple[str, str, SectionKind] | None:
    rect = rects.get(ref)
    if rect is None:
        return target_keys[0] if target_keys else None
    center = _existing_rect_center(rect)
    candidates: list[tuple[float, tuple[str, str, SectionKind]]] = []
    for key in target_keys:
        bucket_center = _refs_center(buckets.get(key, ()), rects)
        if bucket_center is None:
            continue
        candidates.append((_distance_sq(center, bucket_center), key))
    if not candidates:
        return target_keys[0] if target_keys else None
    return min(candidates, key=lambda item: (item[0], item[1][0]))[1]


def _refs_center(
    refs: Sequence[CanonicalNodeRef],
    rects: Mapping[CanonicalNodeRef, _ExistingGroupRect],
) -> tuple[float, float] | None:
    centers = [_existing_rect_center(rects[ref]) for ref in refs if ref in rects]
    if not centers:
        return None
    return (
        sum(center[0] for center in centers) / len(centers),
        sum(center[1] for center in centers) / len(centers),
    )


def _wall_bucket_chunks(
    bucket_id: str,
    refs: Sequence[CanonicalNodeRef],
    *,
    facts: GraphInventoryFacts | None = None,
) -> tuple[tuple[CanonicalNodeRef, ...], ...]:
    max_sizes = {
        "setget": 10_000,
        "labels": 6,
        "settings": 5,
        "custom": 10_000,
    }
    max_size = max_sizes.get(bucket_id, 8)
    if facts is not None and bucket_id in {"custom", "prep", "imageprep", "latent"}:
        refs = _wall_spatially_ordered_refs(refs, facts)
    else:
        refs = tuple(sorted(refs, key=_ref_sort_key))
    return tuple(
        tuple(refs[index : index + max_size])
        for index in range(0, len(refs), max_size)
    )


def _wall_spatially_ordered_refs(
    refs: Sequence[CanonicalNodeRef],
    facts: GraphInventoryFacts,
) -> tuple[CanonicalNodeRef, ...]:
    """Order huge fallback chunks by flow before ids.

    The wall splitter is a last-resort path for nodes with weak semantic
    classification.  Sorting those nodes by uid produces arbitrary "Custom N"
    groups.  The original canvas position is a stronger signal for these
    weakly-classified nodes because it preserves the user's existing local
    neighborhoods; topology is only the tie-breaker.
    """

    rects = _node_rects_by_ref(facts.node_furniture)
    return tuple(sorted(refs, key=lambda item: _wall_spatial_ref_sort_key(item, rects, facts)))


def _wall_spatial_ref_sort_key(
    ref: CanonicalNodeRef,
    rects: Mapping[CanonicalNodeRef, _ExistingGroupRect],
    facts: GraphInventoryFacts,
) -> tuple[Any, ...]:
    rect = rects.get(ref)
    if rect is None:
        return (1, *_local_ref_sort_key(ref, facts))
    return (0, round(rect.x), round(rect.y), *_local_ref_sort_key(ref, facts))


def _wall_bucket_for_ref(
    section: _CompileSection,
    ref: CanonicalNodeRef,
    facts: GraphInventoryFacts,
) -> tuple[str, str, SectionKind]:
    canonical_by_ref = {fact.ref: fact for fact in facts.canonical_refs}
    fact = canonical_by_ref.get(ref)
    class_type = str(getattr(fact, "class_type", "")).lower()
    title = str(getattr(fact, "title", "") or "").lower()
    text = f"{class_type} {title}"

    if any(token in class_type for token in ("setnode", "getnode")):
        return ("setget", "Set / Get Helpers", SECTION_KIND_UTILITY)
    if any(token in class_type for token in ("markdown", "note")):
        return ("labels", "Labels / Notes", SECTION_KIND_UTILITY)
    if any(token in text for token in ("width", "height", "fps", "frame", "setting", "constant", "primitive")):
        return ("settings", "Settings", SECTION_KIND_UTILITY)

    if section.kind == SECTION_KIND_LOADERS:
        if any(token in text for token in ("lora", "patch", "power lora")):
            return ("lora", "LoRA / Model Patching", SECTION_KIND_LOADERS)
        if any(token in text for token in ("clip", "text projection", "embedding")):
            return ("clip", "CLIP / Text Models", SECTION_KIND_LOADERS)
        if "vae" in text:
            return ("vae", "VAE Resources", SECTION_KIND_LOADERS)
        if any(token in text for token in ("image", "resize", "preprocess", "reference")):
            return ("input", "Input / Image Prep", SECTION_KIND_UTILITY)
        return ("models", "Models", SECTION_KIND_LOADERS)

    if section.kind == SECTION_KIND_UTILITY:
        if any(token in text for token in ("note", "markdown", "about")):
            return ("labels", "Labels / Notes", SECTION_KIND_UTILITY)
        if _is_prompt_text_ref(ref, canonical_by_ref):
            return ("prompt", "Prompt / Text", SECTION_KIND_CONDITIONING)
        if any(token in text for token in ("width", "height", "fps", "frame", "setting", "constant", "primitive")):
            return ("settings", "Settings", SECTION_KIND_UTILITY)
        return ("setget", "Set / Get Helpers", SECTION_KIND_UTILITY)

    if section.kind == SECTION_KIND_CUSTOM:
        if any(token in text for token in ("display", "showanything", "label", "preview")):
            return ("displays", "Displays / Labels", SECTION_KIND_UTILITY)
        if any(token in text for token in ("forloop", "loop", "mathexpression", "math expression")):
            return ("loop_control", "Loop / Math Control", SECTION_KIND_CONTROL)
        if any(token in text for token in ("purgevram", "purge vram", "clear cache", "cleanup")):
            return ("cleanup", "Cleanup", SECTION_KIND_UTILITY)
        if any(token in text for token in ("modelsampling", "sageattention", "torchcompile", "compilemodel")):
            return ("model_patching", "Model Patching", SECTION_KIND_LOADERS)
        if any(token in text for token in ("loadvideo", "videoinfo", "video info")):
            return ("video_io", "Video Input / Info", SECTION_KIND_UTILITY)
        if any(token in text for token in ("wanvace", "wanvideo", "video continuation", "videocontinuation", "florence2")):
            return ("video_generation", "Video Generation", SECTION_KIND_SAMPLING)
        if any(token in text for token in ("colormatch", "color match")):
            return ("color_match", "Color Match", SECTION_KIND_POSTPROCESS)
        if any(token in text for token in ("prompt", "text", "string", "enhance")):
            return ("prompt", "Prompt / Text", SECTION_KIND_CONDITIONING)
        if any(token in text for token in ("image", "resize", "preprocess", "latent")):
            return ("prep", "Image / Latent Prep", SECTION_KIND_LATENT)
        if any(token in text for token in ("nag", "guider", "cfg", "condition")):
            return ("conditioning", "Conditioning", SECTION_KIND_CONDITIONING)
        return ("custom", "Custom", SECTION_KIND_CUSTOM)

    if section.kind == SECTION_KIND_LATENT:
        if any(token in text for token in ("image", "resize", "preprocess")):
            return ("imageprep", "Image / Latent Prep", SECTION_KIND_LATENT)
        return ("latent", "Latent", SECTION_KIND_LATENT)

    if section.kind == SECTION_KIND_SAMPLING:
        if "scheduler" in text or "sigma" in text or "noise" in text:
            return ("sampling_settings", "Sampling Settings", SECTION_KIND_SAMPLING)
        return ("samplers", "Samplers", SECTION_KIND_SAMPLING)

    if section.kind == SECTION_KIND_POSTPROCESS:
        if any(token in text for token in ("upscale", "resize")):
            return ("upscale", "Upscale / Resize", SECTION_KIND_POSTPROCESS)
        return ("postprocess", "Postprocess", SECTION_KIND_POSTPROCESS)

    return (_slugify_title(section.title), section.title, section.kind)


def _wall_bucket_sort_key(bucket_id: str) -> int:
    order = {
        "models": 0,
        "clip": 1,
        "vae": 2,
        "lora": 3,
        "input": 4,
        "settings": 5,
        "labels": 6,
        "setget": 7,
        "video_io": 8,
        "prompt": 10,
        "conditioning": 11,
        "prep": 12,
        "imageprep": 13,
        "latent": 14,
        "model_patching": 15,
        "loop_control": 16,
        "video_generation": 17,
        "sampling_settings": 20,
        "samplers": 21,
        "color_match": 29,
        "upscale": 30,
        "postprocess": 31,
        "displays": 32,
        "cleanup": 33,
        "custom": 40,
    }
    return order.get(bucket_id, 999)


def _slugify_title(title: str) -> str:
    slug = "".join(ch.lower() if ch.isalnum() else "_" for ch in title).strip("_")
    return slug or "group"


def _compile_section_topologies(
    sections: Sequence[_CompileSection],
    facts: GraphInventoryFacts,
) -> tuple[CompiledSectionTopology, ...]:
    section_by_id = {section.id: section for section in sections}
    ref_to_section = {
        ref: section.id
        for section in sections
        for ref in section.node_refs
    }
    section_edges: dict[str, set[str]] = {section.id: set() for section in sections}
    for topology in facts.scope_topologies:
        for edge in topology.effective_edges:
            source_section = ref_to_section.get(edge.source)
            target_section = ref_to_section.get(edge.target)
            if source_section is None or target_section is None or source_section == target_section:
                continue
            section_edges.setdefault(source_section, set()).add(target_section)
            section_edges.setdefault(target_section, set())

    scc_by_section, members_by_scc = _section_sccs(section_edges)
    component_edges = _component_edges(section_edges, scc_by_section)
    island_by_component = _component_islands(component_edges, members_by_scc, section_by_id)
    rank_by_component = _component_ranks(component_edges, island_by_component, members_by_scc, section_by_id)
    predecessor_ids = {section.id: set() for section in sections}
    successor_ids = {section.id: set(section_edges.get(section.id, ())) for section in sections}
    for source, targets in section_edges.items():
        for target in targets:
            predecessor_ids.setdefault(target, set()).add(source)

    topologies: list[CompiledSectionTopology] = []
    for section in sections:
        scc_id = scc_by_section[section.id]
        topologies.append(
            CompiledSectionTopology(
                section_id=section.id,
                scope_path=_common_scope(section.node_refs),
                island_index=island_by_component[scc_id],
                rank=rank_by_component[scc_id],
                scc_id=scc_id,
                auto_name=_stable_auto_name(section, scc_id),
                predecessor_ids=tuple(sorted(predecessor_ids.get(section.id, ()), key=_id_sort_key)),
                successor_ids=tuple(sorted(successor_ids.get(section.id, ()), key=_id_sort_key)),
            )
        )
    return tuple(sorted(topologies, key=lambda item: (item.scope_path, item.island_index, item.rank, item.scc_id, item.section_id)))


def _normalize_sampler_relations(
    plan: LayoutPlanV1,
    facts: GraphInventoryFacts,
    sections: Sequence[_CompileSection],
) -> tuple[CompiledSamplerRelation, ...]:
    sampler_refs = tuple(
        sorted(
            (
                fact.ref
                for fact in facts.canonical_refs
                if "sampler" in fact.class_type.lower()
            ),
            key=_ref_sort_key,
        )
    )
    if len(sampler_refs) < 2:
        return ()

    ref_to_section = {
        ref: section.id
        for section in sections
        for ref in section.node_refs
    }
    canonical_by_ref = {fact.ref: fact for fact in facts.canonical_refs}
    adjacency = _effective_ref_adjacency(facts)
    relation_claims = tuple(plan.sampler_relations) + tuple(facts.summary.sampler_relation_candidates)
    claims_by_pair: dict[frozenset[CanonicalNodeRef], list[SamplerRelationClaim]] = {}
    for claim in relation_claims:
        if len(claim.samplers) != 2:
            continue
        claims_by_pair.setdefault(frozenset(claim.samplers), []).append(claim)

    relations: list[CompiledSamplerRelation] = []
    pair_kinds: dict[frozenset[CanonicalNodeRef], str] = {}
    for index, left in enumerate(sampler_refs):
        for right in sampler_refs[index + 1:]:
            pair = (left, right)
            claims = tuple(sorted(claims_by_pair.get(frozenset(pair), ()), key=_sampler_claim_sort_key))
            relation = _normalized_sampler_pair(
                pair,
                claims,
                adjacency,
                ref_to_section,
                canonical_by_ref,
            )
            relations.append(relation)
            pair_kinds[frozenset(pair)] = relation.kind

    aggregate = _mixed_sampler_aggregate(relations, ref_to_section)
    if aggregate is not None:
        relations.append(aggregate)
    return tuple(sorted(relations, key=_compiled_sampler_relation_sort_key))


def _layout_sections(
    plan: LayoutPlanV1,
    sections: Sequence[_CompileSection],
    section_topologies: Sequence[CompiledSectionTopology],
    facts: GraphInventoryFacts,
    options: LayoutCompileOptions,
    classification: ClassificationReport,
    *,
    trace: _CompileTraceAccumulator | None = None,
) -> _CompiledLayoutPlacement:
    return _layout_sections_with_phases(
        plan,
        sections,
        section_topologies,
        facts,
        options,
        classification,
        trace=trace,
    )


def _layout_sections_with_phases(
    plan: LayoutPlanV1,
    sections: Sequence[_CompileSection],
    section_topologies: Sequence[CompiledSectionTopology],
    facts: GraphInventoryFacts,
    options: LayoutCompileOptions,
    classification: ClassificationReport,
    *,
    trace: _CompileTraceAccumulator | None,
) -> _CompiledLayoutPlacement:
    spacing = _spacing(options.spacing_preset)
    furniture_by_ref = {fact.ref: fact for fact in facts.node_furniture}
    canonical_by_ref = {fact.ref: fact for fact in facts.canonical_refs}
    huge_mode = _large_workflow_soft_quality_gate(facts)
    if huge_mode:
        spacing = _huge_wall_spacing(spacing)
    layout_options = _huge_wall_layout_options(options) if huge_mode else options
    pinned_refs = set() if huge_mode else _effective_pinned_refs(facts, layout_options, classification)
    should_repair_huge_overlaps = huge_mode and _existing_primary_overlap_count(facts) > 0
    topology_by_section = {topology.section_id: topology for topology in section_topologies}
    placements = _section_placements(sections, section_topologies, facts, spacing, furniture_by_ref, layout_options, plan)
    node_layouts = _global_placement_shim(
        sections,
        placements,
        topology_by_section,
        facts,
        furniture_by_ref,
        canonical_by_ref,
        layout_options,
        spacing,
        pinned_refs,
        classification,
        plan,
        trace=trace,
    )
    node_layouts = list(_sidecar_layout_shim(plan, node_layouts, spacing, trace=trace))
    should_repair_helper_primary_overlaps = _helper_primary_layout_overlap_count(node_layouts, facts) > 0
    if not huge_mode or should_repair_huge_overlaps or should_repair_helper_primary_overlaps:
        node_layouts = list(_resolve_node_collisions(node_layouts, facts, spacing))
    if trace is not None:
        for layout in node_layouts:
            trace.record_global_layout(layout)
    group_layouts = _compiled_group_layouts(sections, node_layouts, facts, spacing, layout_options)
    # Preserve the proven pre-transaction-spine placement baseline for ordinary
    # workflows.  Whole-section group reflow exists for the compact huge-wall
    # path; applying it to every graph turns small overlaps into cascading
    # vertical translations and destroys the established canvas shape.
    should_repair_generated_group_overlaps = huge_mode and _group_layout_overlap_count(group_layouts) > 0
    if should_repair_huge_overlaps or should_repair_generated_group_overlaps:
        node_layouts, group_layouts = _resolve_group_collisions(
            sections,
            node_layouts,
            group_layouts,
            facts,
            spacing,
            layout_options,
        )
    group_layouts = _filter_group_layouts_for_policy(group_layouts, facts, layout_options)
    return _CompiledLayoutPlacement(
        node_layouts=tuple(sorted(node_layouts, key=lambda layout: _ref_sort_key(layout.ref))),
        group_layouts=group_layouts,
    )


def _global_placement_shim(
    sections: Sequence[_CompileSection],
    placements: Mapping[str, _SectionPlacement],
    topology_by_section: Mapping[str, CompiledSectionTopology],
    facts: GraphInventoryFacts,
    furniture_by_ref: Mapping[CanonicalNodeRef, NodeFurnitureFact],
    canonical_by_ref: Mapping[CanonicalNodeRef, Any],
    layout_options: LayoutCompileOptions,
    spacing: _Spacing,
    pinned_refs: set[CanonicalNodeRef],
    classification: ClassificationReport,
    plan: LayoutPlanV1,
    *,
    trace: _CompileTraceAccumulator | None,
) -> list[CompiledNodeLayout]:
    node_layouts: list[CompiledNodeLayout] = []
    for order, section in enumerate(sorted(
        sections,
        key=lambda section: _section_placement_sort_key(section, placements, topology_by_section),
    )):
        placement = placements[section.id]
        if trace is not None:
            trace.record_wall_placement(section, placement, order=order)
        local_layout = _local_packing_shim(
            section,
            facts,
            furniture_by_ref,
            layout_options,
            spacing,
            plan,
            trace=trace,
        )
        node_layouts.extend(
            _place_section_node_layouts(
                section,
                placement,
                local_layout,
                facts,
                furniture_by_ref,
                canonical_by_ref,
                layout_options,
                spacing,
                pinned_refs,
                classification,
                trace=trace,
            )
        )
    return node_layouts


def _local_packing_shim(
    section: _CompileSection,
    facts: GraphInventoryFacts,
    furniture_by_ref: Mapping[CanonicalNodeRef, NodeFurnitureFact],
    options: LayoutCompileOptions,
    spacing: _Spacing,
    plan: LayoutPlanV1 | None,
    *,
    trace: _CompileTraceAccumulator | None,
) -> _LocalSectionLayout:
    local_layout = _local_section_layout(section, facts, furniture_by_ref, options, spacing, plan)
    if trace is not None:
        trace.record_local_packing(section, local_layout)
    return local_layout


def _place_section_node_layouts(
    section: _CompileSection,
    placement: _SectionPlacement,
    local_layout: _LocalSectionLayout,
    facts: GraphInventoryFacts,
    furniture_by_ref: Mapping[CanonicalNodeRef, NodeFurnitureFact],
    canonical_by_ref: Mapping[CanonicalNodeRef, Any],
    layout_options: LayoutCompileOptions,
    spacing: _Spacing,
    pinned_refs: set[CanonicalNodeRef],
    classification: ClassificationReport,
    *,
    trace: _CompileTraceAccumulator | None,
) -> list[CompiledNodeLayout]:
    node_layouts: list[CompiledNodeLayout] = []
    x = placement.x
    y = placement.y
    for ref in section.node_refs:
        furniture = furniture_by_ref.get(ref)
        width, height = _node_size_for_ref(
            ref,
            facts,
            furniture,
            preserve=layout_options.preserve_node_sizes,
            minimize_setget_helpers=layout_options.minimize_setget_helpers,
        )
        local_x, local_y = local_layout.offsets[ref]
        node_x = x + spacing.group_padding + local_x
        node_y = y + spacing.group_padding + DEFAULT_GROUP_HEADER_HEIGHT + local_y
        if ref in pinned_refs and furniture is not None:
            pinned_pos = _pos(furniture.pos)
            if pinned_pos is not None:
                node_x, node_y = pinned_pos
        hint = classification.hint_for(ref)
        fact = canonical_by_ref.get(ref)
        layout = CompiledNodeLayout(
            ref=ref,
            section_id=section.id,
            role_hint=(
                hint.role_hint
                if hint is not None
                else fact.role_hint
                if fact is not None
                else ROLE_HINT_UNKNOWN
            ),
            x=node_x,
            y=node_y,
            width=width,
            height=height,
            pinned=ref in pinned_refs,
            auto_collapsed=_auto_collapse_setget_ref(
                ref,
                facts,
                furniture,
                minimize_setget_helpers=layout_options.minimize_setget_helpers,
            ),
        )
        node_layouts.append(layout)
        if trace is not None:
            trace.record_global_layout(layout)
    return node_layouts


def _sidecar_layout_shim(
    plan: LayoutPlanV1,
    node_layouts: Sequence[CompiledNodeLayout],
    spacing: _Spacing,
    *,
    trace: _CompileTraceAccumulator | None,
) -> Sequence[CompiledNodeLayout]:
    adjusted = _apply_floating_helper_positions(plan, node_layouts, spacing)
    if trace is not None:
        for layout in adjusted:
            trace.record_global_layout(layout)
    return adjusted


def _helper_primary_layout_overlap_count(
    node_layouts: Sequence[CompiledNodeLayout],
    facts: GraphInventoryFacts,
) -> int:
    helper_refs = {fact.ref for fact in facts.canonical_refs if fact.is_helper}
    helpers = [layout for layout in node_layouts if layout.ref in helper_refs]
    primaries = [layout for layout in node_layouts if layout.ref not in helper_refs]
    count = 0
    for helper in helpers:
        for primary in primaries:
            if _layouts_violate_gutter(helper, primary, 0):
                count += 1
    return count


def _group_layout_overlap_count(group_layouts: Sequence[CompiledGroupLayout]) -> int:
    count = 0
    for index, left in enumerate(group_layouts):
        for right in group_layouts[index + 1:]:
            if _group_layouts_violate_gutter(left, right, 0):
                count += 1
    return count


def _filter_group_layouts_for_policy(
    group_layouts: Sequence[CompiledGroupLayout],
    facts: GraphInventoryFacts,
    options: LayoutCompileOptions,
) -> tuple[CompiledGroupLayout, ...]:
    policy = _effective_grouping_policy(facts, options)
    if policy in {"stage", "wall"}:
        return tuple(group_layouts)
    existing_keys = _existing_group_node_keys(facts)
    if policy == "preserve_existing":
        return tuple(
            group
            for group in group_layouts
            if (
                group.scope_path,
                tuple(sorted(group.node_refs, key=_ref_sort_key)),
            )
            in existing_keys
        )
    return ()


def _effective_grouping_policy(
    facts: GraphInventoryFacts,
    options: LayoutCompileOptions,
) -> GroupingPolicy:
    if options.grouping_policy != "auto":
        return options.grouping_policy
    if _large_workflow_soft_quality_gate(facts):
        return "wall"
    existing_count = sum(len(scope.groups) for scope in facts.scope_furniture)
    node_count = len(facts.canonical_refs)
    root_node_count = next(
        (scope.node_count for scope in facts.summary.scopes if scope.scope_path == ""),
        node_count,
    )
    nested_scope_count = sum(1 for scope in facts.summary.scopes if scope.scope_path)
    branch_count = sum(len(scope.parallel_branch_candidates) for scope in facts.scope_topologies)
    helper_count = len(facts.helper_nodes)
    if existing_count > 0:
        return "stage"
    overlap_count = _existing_primary_overlap_count(facts)
    if nested_scope_count and root_node_count <= 12 and overlap_count == 0:
        return "none"
    if overlap_count > 0:
        return "stage"
    if node_count > 0 and helper_count == node_count:
        return "stage"
    if node_count >= 15 or (node_count >= 12 and branch_count >= 4) or helper_count >= 3:
        return "stage"
    return "none"


def _existing_primary_overlap_count(facts: GraphInventoryFacts) -> int:
    helper_refs = {fact.ref for fact in facts.canonical_refs if fact.is_helper}
    rects = {
        ref: _CompileRect(
            key=json.dumps(ref.to_json(), ensure_ascii=True),
            ref=ref,
            x=rect.x,
            y=rect.y,
            width=rect.width,
            height=rect.height,
        )
        for ref, rect in _node_rects_by_ref(facts.node_furniture).items()
        if ref not in helper_refs
    }
    return len(_rect_overlap_pairs(rects))


def _existing_group_node_keys(
    facts: GraphInventoryFacts,
) -> set[tuple[str, tuple[CanonicalNodeRef, ...]]]:
    keys: set[tuple[str, tuple[CanonicalNodeRef, ...]]] = set()
    helper_refs = {fact.ref for fact in facts.canonical_refs if fact.is_helper}
    rects = _node_rects_by_ref(facts.node_furniture)
    for scope in facts.scope_furniture:
        for group in scope.groups:
            explicit_refs = _group_node_refs(facts, group.scope_path, group.nodes)
            if explicit_refs is None:
                group_rect = _group_rect(group.bounding)
                refs = _contained_group_refs(group.scope_path, group_rect, rects, helper_refs)
            else:
                refs = tuple(ref for ref in explicit_refs if ref not in helper_refs)
            if refs:
                keys.add((group.scope_path, tuple(sorted(refs, key=_ref_sort_key))))
    return keys


def _huge_wall_layout_options(options: LayoutCompileOptions) -> LayoutCompileOptions:
    return LayoutCompileOptions(
        spacing_preset=options.spacing_preset,
        existing_group_policy=options.existing_group_policy,
        grouping_policy="wall",
        force_regroup=options.force_regroup,
        pinned_refs=options.pinned_refs,
        preserve_node_sizes=False,
        minimize_setget_helpers=options.minimize_setget_helpers,
    )


def _huge_wall_spacing(spacing: _Spacing) -> _Spacing:
    # Section groups form one visual wall, so use one gutter in both axes.
    # Keeping the old independently-scaled horizontal gutter made adjacent
    # columns more than three times farther apart than vertically stacked
    # groups (167px versus 53px for the balanced preset).
    section_gap = max(44, round(spacing.section_gap_y * 0.55))
    return _Spacing(
        section_gap_x=section_gap,
        island_gap_x=max(1800, round(spacing.island_gap_x * 0.55)),
        band_gap_y=max(320, round(spacing.band_gap_y * 0.45)),
        section_gap_y=section_gap,
        node_gap_y=max(60, round(spacing.node_gap_y * 0.46)),
        group_padding=max(32, round(spacing.group_padding * 0.7)),
    )


def _section_placements(
    sections: Sequence[_CompileSection],
    section_topologies: Sequence[CompiledSectionTopology],
    facts: GraphInventoryFacts,
    spacing: _Spacing,
    furniture_by_ref: Mapping[CanonicalNodeRef, NodeFurnitureFact],
    options: LayoutCompileOptions,
    plan: LayoutPlanV1 | None,
) -> dict[str, _SectionPlacement]:
    return _plan_section_placements(
        sections,
        section_topologies,
        facts,
        spacing,
        furniture_by_ref,
        options,
        plan,
        estimate_section_size=_estimated_section_size,
        is_large_workflow=_large_workflow_soft_quality_gate,
        reflow_overtall_lane_trails=_reflow_overtall_lane_trails,
    )




def _estimated_section_size(
    section: _CompileSection,
    facts: GraphInventoryFacts,
    furniture_by_ref: Mapping[CanonicalNodeRef, NodeFurnitureFact],
    options: LayoutCompileOptions,
    spacing: _Spacing,
    plan: LayoutPlanV1 | None = None,
) -> tuple[int, int]:
    local_layout = _local_section_layout(section, facts, furniture_by_ref, options, spacing, plan)
    return (
        local_layout.width + spacing.group_padding * 2,
        DEFAULT_GROUP_HEADER_HEIGHT
        + spacing.group_padding * 2
        + local_layout.height,
    )


def _local_section_layout(
    section: _CompileSection,
    facts: GraphInventoryFacts,
    furniture_by_ref: Mapping[CanonicalNodeRef, NodeFurnitureFact],
    options: LayoutCompileOptions,
    spacing: _Spacing,
    plan: LayoutPlanV1 | None,
) -> _LocalSectionLayout:
    refs = tuple(section.node_refs)
    sizes = {
        ref: _node_size_for_ref(
            ref,
            facts,
            furniture_by_ref.get(ref),
            preserve=options.preserve_node_sizes,
            minimize_setget_helpers=options.minimize_setget_helpers,
        )
        for ref in refs
    }
    if not refs:
        return _LocalSectionLayout(template="single", offsets={}, width=0, height=0)
    sidecar_refs = tuple(
        ref
        for ref in refs
        if section.id != "__helpers__" and _is_local_sidecar_ref(ref, facts, plan)
    )
    sidecar_ref_set = set(sidecar_refs)
    layout_refs = tuple(ref for ref in refs if ref not in sidecar_ref_set)
    template_refs = _template_layout_refs(layout_refs if layout_refs else refs, plan)
    if not template_refs:
        template_refs = layout_refs if layout_refs else refs
    helper_reserves = _anchored_helper_reserves(refs, sizes, plan, spacing)
    template_sizes = {
        ref: _reserved_template_size(ref, sizes[ref], helper_reserves)
        for ref in template_refs
    }

    edges = _section_effective_edges(facts, template_refs)
    if _use_large_section_clusters(section, facts, edges):
        template = "grid"
        offsets = _large_section_cluster_offsets(template_refs, edges, facts, template_sizes, spacing)
    else:
        template_section = (
            section
            if template_refs == refs
            else _CompileSection(
                id=section.id,
                kind=section.kind,
                title=section.title,
                role_hint=section.role_hint,
                node_refs=template_refs,
                parent_id=section.parent_id,
            )
        )
        template = _select_section_template(template_section, facts, edges)
        if sidecar_refs and template == "alternatives":
            template = "row"
        offsets = _offsets_for_template(template, template_refs, edges, facts, template_sizes, spacing)
    offsets = _restore_reserved_anchor_offsets(offsets, helper_reserves)
    if plan is not None:
        offsets = _apply_local_helper_offsets(section, plan, offsets, sizes, spacing)
    placement_choices: dict[CanonicalNodeRef, str] = {}
    if sidecar_refs:
        offsets, sidecar_choices = _pack_sidecars(
            section,
            sidecar_refs,
            offsets,
            sizes,
            facts,
            plan,
            spacing,
        )
        placement_choices.update(sidecar_choices)
    for ref in refs:
        if ref not in offsets:
            offsets = {**offsets, ref: (0, len(offsets) * (sizes[ref][1] + spacing.node_gap_y))}
    width, height = _local_bounds(offsets, sizes)
    return _LocalSectionLayout(
        template=template,
        offsets=offsets,
        width=width,
        height=height,
        placement_choices=placement_choices,
    )


def _is_local_sidecar_ref(
    ref: CanonicalNodeRef,
    facts: GraphInventoryFacts,
    plan: LayoutPlanV1 | None,
) -> bool:
    if _layout_behavior_for_ref(ref, facts) == LAYOUT_BEHAVIOR_SIDECAR:
        return True
    placement = _helper_placement_for_ref(ref, plan)
    return placement is not None and placement.kind in {
        HELPER_PLACEMENT_NEAR_PRODUCER,
        HELPER_PLACEMENT_NEAR_CONSUMER,
    }


def _template_layout_refs(
    refs: Sequence[CanonicalNodeRef],
    plan: LayoutPlanV1 | None,
) -> tuple[CanonicalNodeRef, ...]:
    if plan is None:
        return tuple(refs)
    anchored_helpers = {
        placement.helper
        for placement in plan.helper_placements
        if placement.kind
        in {
            HELPER_PLACEMENT_NEAR_PRODUCER,
            HELPER_PLACEMENT_NEAR_CONSUMER,
            HELPER_PLACEMENT_EDGE_PATH,
        }
    }
    return tuple(ref for ref in refs if ref not in anchored_helpers)


def _anchored_helper_reserves(
    refs: Sequence[CanonicalNodeRef],
    sizes: Mapping[CanonicalNodeRef, tuple[int, int]],
    plan: LayoutPlanV1 | None,
    spacing: _Spacing,
) -> dict[CanonicalNodeRef, tuple[int, int, int, int]]:
    if plan is None:
        return {}
    section_refs = set(refs)
    by_anchor: dict[tuple[str, CanonicalNodeRef], list[CanonicalNodeRef]] = {}
    for placement in plan.helper_placements:
        if placement.kind not in {HELPER_PLACEMENT_NEAR_PRODUCER, HELPER_PLACEMENT_NEAR_CONSUMER}:
            continue
        if placement.helper not in section_refs or placement.target not in section_refs:
            continue
        if placement.helper not in sizes or placement.target not in sizes:
            continue
        by_anchor.setdefault((placement.kind, placement.target), []).append(placement.helper)

    anchor_gap = max(24, spacing.node_gap_y // 2)
    stack_gap = max(8, spacing.node_gap_y // 4)
    reserves: dict[CanonicalNodeRef, tuple[int, int, int, int]] = {}
    for (kind, target), helpers in by_anchor.items():
        target_width, target_height = sizes[target]
        max_width = max((sizes[helper][0] for helper in helpers), default=0)
        total_height = sum(sizes[helper][1] for helper in helpers) + stack_gap * max(0, len(helpers) - 1)
        side = max_width + anchor_gap if max_width else 0
        vertical = max(0, round((total_height - target_height) / 2))
        left, right, top, bottom = reserves.get(target, (0, 0, 0, 0))
        if kind == HELPER_PLACEMENT_NEAR_CONSUMER:
            left = max(left, side)
        else:
            right = max(right, side)
        top = max(top, vertical)
        bottom = max(bottom, vertical)
        reserves[target] = (left, right, top, bottom)
    return reserves


def _reserved_template_size(
    ref: CanonicalNodeRef,
    size: tuple[int, int],
    reserves: Mapping[CanonicalNodeRef, tuple[int, int, int, int]],
) -> tuple[int, int]:
    left, right, top, bottom = reserves.get(ref, (0, 0, 0, 0))
    return (size[0] + left + right, size[1] + top + bottom)


def _restore_reserved_anchor_offsets(
    offsets: Mapping[CanonicalNodeRef, tuple[int, int]],
    reserves: Mapping[CanonicalNodeRef, tuple[int, int, int, int]],
) -> dict[CanonicalNodeRef, tuple[int, int]]:
    adjusted = dict(offsets)
    for ref, (left, _right, top, _bottom) in reserves.items():
        if ref not in adjusted:
            continue
        x, y = adjusted[ref]
        adjusted[ref] = (x + left, y + top)
    return adjusted


def _select_section_template(
    section: _CompileSection,
    facts: GraphInventoryFacts,
    edges: Sequence[tuple[CanonicalNodeRef, CanonicalNodeRef]],
) -> SectionTemplate:
    refs = tuple(section.node_refs)
    if len(refs) == 1:
        return "single"
    title = (section.title or "").lower()
    if "setting" in title or _constant_like_refs(refs, facts):
        return "row"
    if _note_refs(refs, facts):
        return "notes_sidebar"
    if section.kind == SECTION_KIND_BRANCH and _parallel_branch_candidate(refs, facts) is not None:
        return "parallel_branches"
    if _is_alternatives_section(section, facts, edges):
        return "alternatives"
    if _hub_ref(refs, edges) is not None:
        return "hub_and_spokes"
    if _fan_in_ref(refs, edges) is not None:
        return "fan_in"
    if _fan_out_ref(refs, edges) is not None:
        return "fan_out"
    if _is_pipeline(refs, edges):
        return "pipeline"
    if len(refs) == 2:
        return "pair"
    if len(refs) <= 4:
        return "row"
    return "grid"


def _constant_like_refs(
    refs: Sequence[CanonicalNodeRef],
    facts: GraphInventoryFacts,
) -> bool:
    if len(refs) < 2:
        return False
    canonical_by_ref = {fact.ref: fact for fact in facts.canonical_refs}
    constant_count = 0
    for ref in refs:
        fact = canonical_by_ref.get(ref)
        class_type = str(getattr(fact, "class_type", "")).lower()
        title = str(getattr(fact, "title", "") or "").lower()
        if (
            "constant" in class_type
            or title in {"fps", "width", "height"}
            or "length" in title
        ):
            constant_count += 1
    return constant_count == len(refs)


def _offsets_for_template(
    template: SectionTemplate,
    refs: Sequence[CanonicalNodeRef],
    edges: Sequence[tuple[CanonicalNodeRef, CanonicalNodeRef]],
    facts: GraphInventoryFacts,
    sizes: Mapping[CanonicalNodeRef, tuple[int, int]],
    spacing: _Spacing,
) -> dict[CanonicalNodeRef, tuple[int, int]]:
    ordered = tuple(sorted(refs, key=lambda ref: _local_ref_sort_key(ref, facts)))
    gap_x = spacing.node_gap_y
    gap_y = spacing.node_gap_y

    if template == "single":
        return {ordered[0]: (0, 0)}
    if template in {"pair", "alternatives"}:
        return _layout_columns((ordered,), sizes, gap_x, gap_y)
    if template == "row":
        primary_refs: list[CanonicalNodeRef] = []
        note_refs: list[CanonicalNodeRef] = []
        for ref in ordered:
            behavior = _layout_behavior_for_ref(ref, facts)
            if behavior == LAYOUT_BEHAVIOR_NOTE:
                note_refs.append(ref)
            else:
                primary_refs.append(ref)
        primary_offsets = _layout_wrapped_row(primary_refs, sizes, gap_x, gap_y, COMPILE_MAX_ROW_COLUMNS)
        primary_width, _primary_height = _local_bounds(primary_offsets, sizes)
        result: dict[CanonicalNodeRef, tuple[int, int]] = dict(primary_offsets)
        if note_refs:
            note_x = primary_width + gap_x if primary_refs else 0
            note_y = 0
            for ref in note_refs:
                result[ref] = (note_x, note_y)
                note_y += sizes[ref][1] + gap_y
        return result
    if template == "grid":
        return _layout_grid(ordered, sizes, gap_x, gap_y)
    if template == "pipeline":
        return _layout_columns_balanced(_local_layers(ordered, edges, facts), sizes, gap_x, gap_y)
    if template == "fan_in":
        sink = _fan_in_ref(ordered, edges)
        if sink is not None:
            predecessors = tuple(sorted({source for source, target in edges if target == sink}, key=lambda ref: _local_ref_sort_key(ref, facts)))
            remainder = tuple(ref for ref in ordered if ref != sink and ref not in predecessors)
            return _layout_columns_balanced(((*predecessors, *remainder), (sink,)), sizes, gap_x, gap_y)
    if template == "fan_out":
        source = _fan_out_ref(ordered, edges)
        if source is not None:
            successors = tuple(sorted({target for item_source, target in edges if item_source == source}, key=lambda ref: _local_ref_sort_key(ref, facts)))
            remainder = tuple(ref for ref in ordered if ref != source and ref not in successors)
            return _layout_columns_balanced(((source,), (*successors, *remainder)), sizes, gap_x, gap_y)
    if template == "hub_and_spokes":
        hub = _hub_ref(ordered, edges)
        if hub is not None:
            inputs = tuple(sorted({source for source, target in edges if target == hub}, key=lambda ref: _local_ref_sort_key(ref, facts)))
            outputs = tuple(sorted({target for source, target in edges if source == hub}, key=lambda ref: _local_ref_sort_key(ref, facts)))
            remainder = tuple(ref for ref in ordered if ref != hub and ref not in inputs and ref not in outputs)
            return _layout_columns_balanced((inputs, (hub, *remainder), outputs), sizes, gap_x, gap_y)
    if template == "parallel_branches":
        candidate = _parallel_branch_candidate(ordered, facts)
        if candidate is not None:
            source, roots, terminals = candidate
            used = {source, *roots, *terminals}
            remainder = tuple(ref for ref in ordered if ref not in used)
            terminal_column = terminals if terminals else remainder
            middle_column = (*roots, *(() if terminals else remainder))
            tail_column = terminal_column if terminals else ()
            columns = tuple(column for column in ((source,), middle_column, tail_column) if column)
            return _layout_columns_balanced(columns, sizes, gap_x, gap_y)
    if template == "notes_sidebar":
        notes = _note_refs(ordered, facts)
        main = tuple(ref for ref in ordered if ref not in notes)
        main_offsets = (
            _layout_columns_balanced(_local_layers(main, edges, facts), sizes, gap_x, gap_y)
            if main
            else {}
        )
        main_width, _main_height = _local_bounds(main_offsets, sizes)
        note_offsets = _layout_columns((notes,), sizes, gap_x, gap_y)
        return {
            **main_offsets,
            **{ref: (main_width + gap_x + x, y) for ref, (x, y) in note_offsets.items()},
        }
    return _layout_grid(ordered, sizes, gap_x, gap_y)


def _use_large_section_clusters(
    section: _CompileSection,
    facts: GraphInventoryFacts,
    edges: Sequence[tuple[CanonicalNodeRef, CanonicalNodeRef]],
) -> bool:
    if section.kind == SECTION_KIND_CONTAINER or len(section.node_refs) < 2:
        return False
    if len(section.node_refs) <= COMPILE_LARGE_SECTION_CLUSTER_SIZE:
        return False
    if len(section.node_refs) >= COMPILE_HUGE_WORKFLOW_NODE_THRESHOLD:
        return True
    if len(edges) >= COMPILE_HUGE_WORKFLOW_EDGE_THRESHOLD:
        return True
    return _facts_projection_token_estimate(facts) >= COMPILE_HUGE_WORKFLOW_PROJECTION_TOKEN_THRESHOLD


def _facts_projection_token_estimate(facts: GraphInventoryFacts) -> int:
    payload = {
        "summary": facts.summary.to_json(),
        "scope_topologies": [
            {
                "scope_path": topology.scope_path,
                "node_count": len(topology.node_topology),
                "edge_count": len(topology.effective_edges),
                "truncated": topology.truncated,
            }
            for topology in facts.scope_topologies
        ],
    }
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return max(1, (len(raw) + 3) // 4)


def _large_section_cluster_offsets(
    refs: Sequence[CanonicalNodeRef],
    edges: Sequence[tuple[CanonicalNodeRef, CanonicalNodeRef]],
    facts: GraphInventoryFacts,
    sizes: Mapping[CanonicalNodeRef, tuple[int, int]],
    spacing: _Spacing,
) -> dict[CanonicalNodeRef, tuple[int, int]]:
    clusters = tuple(cluster for row in _large_section_clusters(refs, edges, facts) for cluster in row)
    offsets: dict[CanonicalNodeRef, tuple[int, int]] = {}
    row_y = 0
    row_x = 0
    cluster_gap_x = max(spacing.section_gap_x, spacing.node_gap_y * 2)
    cluster_gap_y = max(spacing.section_gap_y, spacing.node_gap_y)
    max_cluster_width = max((sizes[ref][0] for ref in refs), default=DEFAULT_NODE_WIDTH)
    row_width_budget = (
        max_cluster_width * COMPILE_MAX_ROW_COLUMNS
        + cluster_gap_x * max(0, COMPILE_MAX_ROW_COLUMNS - 1)
    )
    row_height = 0
    for cluster in clusters:
        cluster_width = max((sizes[ref][0] for ref in cluster), default=0)
        cluster_height = max(
            0,
            sum(sizes[ref][1] for ref in cluster)
            + max(0, len(cluster) - 1) * spacing.node_gap_y,
        )
        if row_x and row_x + cluster_width > row_width_budget:
            row_y += row_height + cluster_gap_y
            row_x = 0
            row_height = 0
        y = 0
        for ref in cluster:
            offsets[ref] = (row_x, row_y + y)
            y += sizes[ref][1] + spacing.node_gap_y
        row_height = max(row_height, cluster_height)
        row_x += cluster_width + cluster_gap_x
    return offsets


def _large_section_clusters(
    refs: Sequence[CanonicalNodeRef],
    edges: Sequence[tuple[CanonicalNodeRef, CanonicalNodeRef]],
    facts: GraphInventoryFacts,
) -> tuple[tuple[tuple[CanonicalNodeRef, ...], ...], ...]:
    ordered_refs = tuple(sorted(refs, key=lambda ref: _local_ref_sort_key(ref, facts)))
    topology_by_ref = {
        node.ref: node
        for topology in facts.scope_topologies
        for node in topology.node_topology
    }
    row_keys = sorted(
        {
            (
                ref.scope_path,
                str(getattr(topology_by_ref.get(ref), "wcc_id", _entry_key(ref))),
            )
            for ref in ordered_refs
        },
        key=lambda item: (0 if item[0] == "" else 1, item[0], _id_sort_key(item[1])),
    )
    rows: list[tuple[tuple[CanonicalNodeRef, ...], ...]] = []
    for row_key in row_keys:
        row_refs = tuple(
            ref
            for ref in ordered_refs
            if (
                ref.scope_path,
                str(getattr(topology_by_ref.get(ref), "wcc_id", _entry_key(ref))),
            )
            == row_key
        )
        if not row_refs:
            continue
        rows.append(_large_section_row_clusters(row_refs, edges, facts))
    return tuple(rows)


def _large_section_row_clusters(
    refs: Sequence[CanonicalNodeRef],
    edges: Sequence[tuple[CanonicalNodeRef, CanonicalNodeRef]],
    facts: GraphInventoryFacts,
) -> tuple[tuple[CanonicalNodeRef, ...], ...]:
    clusters: list[tuple[CanonicalNodeRef, ...]] = []
    current: list[CanonicalNodeRef] = []
    for layer in _local_layers(refs, edges, facts):
        layer_refs = tuple(ref for ref in layer if ref in refs)
        if not layer_refs:
            continue
        if current and len(current) + len(layer_refs) > COMPILE_LARGE_SECTION_CLUSTER_SIZE:
            clusters.append(tuple(current))
            current = []
        for ref in layer_refs:
            current.append(ref)
            if len(current) >= COMPILE_LARGE_SECTION_CLUSTER_SIZE:
                clusters.append(tuple(current))
                current = []
    if current:
        clusters.append(tuple(current))
    return tuple(clusters)


def _pack_sidecars(
    section: _CompileSection,
    sidecar_refs: Sequence[CanonicalNodeRef],
    offsets: Mapping[CanonicalNodeRef, tuple[int, int]],
    sizes: Mapping[CanonicalNodeRef, tuple[int, int]],
    facts: GraphInventoryFacts,
    plan: LayoutPlanV1 | None,
    spacing: _Spacing,
) -> tuple[dict[CanonicalNodeRef, tuple[int, int]], dict[CanonicalNodeRef, str]]:
    adjusted: dict[CanonicalNodeRef, tuple[int, int]] = dict(offsets)
    choices: dict[CanonicalNodeRef, str] = {}
    if not adjusted:
        return adjusted, choices

    gap = max(24, spacing.node_gap_y // 2)
    stack_gap = max(12, spacing.node_gap_y // 3)
    sidecars_by_target: dict[tuple[CanonicalNodeRef, str], list[CanonicalNodeRef]] = {}
    fallback_sidecars: list[CanonicalNodeRef] = []

    for ref in sorted(sidecar_refs, key=lambda item: _local_ref_sort_key(item, facts)):
        target = _sidecar_target_for_ref(ref, section, adjusted, facts, plan)
        if target is None or target not in adjusted or target not in sizes:
            fallback_sidecars.append(ref)
            continue
        side = _sidecar_side_for_ref(ref, target, plan)
        sidecars_by_target.setdefault((target, side), []).append(ref)

    for (target, side), stack_refs in sorted(
        sidecars_by_target.items(),
        key=lambda item: (_local_ref_sort_key(item[0][0], facts), item[0][1]),
    ):
        adjusted = _ensure_sidecar_stack_room(target, side, stack_refs, adjusted, sizes, gap, stack_gap)
        stack_offsets = _sidecar_stack_offsets(target, side, stack_refs, adjusted, sizes, gap, stack_gap)
        for stack_index, ref in enumerate(stack_refs):
            before = offsets.get(ref)
            adjusted[ref] = stack_offsets[ref]
            choices[ref] = _sidecar_trace_choice(ref, target, side, stack_index, before, stack_offsets[ref])

    if fallback_sidecars:
        y = _local_bounds(adjusted, sizes)[1] + spacing.node_gap_y
        x = 0
        for ref in fallback_sidecars:
            adjusted[ref] = (x, y)
            choices[ref] = "sidecar:fallback"
            x += sizes[ref][0] + spacing.node_gap_y

    min_x = min((x for x, _y in adjusted.values()), default=0)
    if min_x < 0:
        shift = -min_x
        adjusted = {ref: (x + shift, y) for ref, (x, y) in adjusted.items()}
        choices = {
            ref: f"{choice};shift_x={shift}"
            for ref, choice in choices.items()
        }
    return adjusted, choices


def _sidecar_target_for_ref(
    ref: CanonicalNodeRef,
    section: _CompileSection,
    offsets: Mapping[CanonicalNodeRef, tuple[int, int]],
    facts: GraphInventoryFacts,
    plan: LayoutPlanV1 | None,
) -> CanonicalNodeRef | None:
    placement = _helper_placement_for_ref(ref, plan)
    if placement is not None:
        for candidate in (placement.target, placement.source, placement.destination):
            if candidate in offsets:
                return candidate
        if placement.section_id == section.id:
            return None
    adjacency = _section_sidecar_adjacency(ref, offsets, facts)
    if len(adjacency) == 1:
        return adjacency[0]
    return None


def _helper_placement_for_ref(ref: CanonicalNodeRef, plan: LayoutPlanV1 | None) -> Any | None:
    if plan is None:
        return None
    for placement in plan.helper_placements:
        if placement.helper == ref:
            return placement
    return None


def _sidecar_side_for_ref(
    ref: CanonicalNodeRef,
    target: CanonicalNodeRef,
    plan: LayoutPlanV1 | None,
) -> str:
    placement = _helper_placement_for_ref(ref, plan)
    if placement is not None:
        if placement.kind == HELPER_PLACEMENT_NEAR_CONSUMER:
            return "left"
        if placement.kind == HELPER_PLACEMENT_NEAR_PRODUCER:
            return "right"
        if placement.kind == HELPER_PLACEMENT_EDGE_PATH and placement.destination == target:
            return "left"
    return "right"


def _section_sidecar_adjacency(
    ref: CanonicalNodeRef,
    offsets: Mapping[CanonicalNodeRef, tuple[int, int]],
    facts: GraphInventoryFacts,
) -> tuple[CanonicalNodeRef, ...]:
    candidates: set[CanonicalNodeRef] = set()
    for topology in facts.scope_topologies:
        for edge in topology.effective_edges:
            if edge.source == ref and edge.target in offsets:
                candidates.add(edge.target)
            elif edge.target == ref and edge.source in offsets:
                candidates.add(edge.source)
    return tuple(sorted(candidates, key=_ref_sort_key))


def _ensure_sidecar_stack_room(
    target: CanonicalNodeRef,
    side: str,
    stack_refs: Sequence[CanonicalNodeRef],
    offsets: Mapping[CanonicalNodeRef, tuple[int, int]],
    sizes: Mapping[CanonicalNodeRef, tuple[int, int]],
    gap: int,
    stack_gap: int,
) -> dict[CanonicalNodeRef, tuple[int, int]]:
    adjusted = dict(offsets)
    for _pass in range(max(1, len(adjusted))):
        stack_rect = _sidecar_stack_rect(target, side, stack_refs, adjusted, sizes, gap, stack_gap)
        if side == "left" and stack_rect[0] < 0:
            shift_refs = {
                ref
                for ref, (x, _y) in adjusted.items()
                if x >= adjusted[target][0] and ref not in stack_refs
            }
            adjusted = _shift_offsets(adjusted, shift_refs, -stack_rect[0])
            continue
        colliding = [
            ref
            for ref in sorted(adjusted, key=lambda item: (adjusted[item][0], _ref_sort_key(item)))
            if ref != target
            and ref not in stack_refs
            and _offset_rects_violate_gutter(stack_rect, _offset_rect(ref, adjusted, sizes), gap)
        ]
        if not colliding:
            return adjusted
        if side == "right":
            threshold = adjusted[target][0] + sizes[target][0]
            push_refs = {
                ref
                for ref, (x, _y) in adjusted.items()
                if ref not in stack_refs and x >= threshold
            }
            push_refs.update(ref for ref in colliding if adjusted[ref][0] >= threshold)
            dx = max(1, round(max(stack_rect[0] + stack_rect[2] + gap - adjusted[ref][0] for ref in colliding)))
        else:
            threshold = adjusted[target][0]
            push_refs = {
                ref
                for ref, (x, _y) in adjusted.items()
                if ref not in stack_refs and x >= threshold
            }
            dx = max(1, round(max(_offset_rect(ref, adjusted, sizes)[0] + _offset_rect(ref, adjusted, sizes)[2] + gap - stack_rect[0] for ref in colliding)))
        if not push_refs:
            return adjusted
        adjusted = _shift_offsets(adjusted, push_refs, dx)
    return adjusted


def _sidecar_stack_offsets(
    target: CanonicalNodeRef,
    side: str,
    stack_refs: Sequence[CanonicalNodeRef],
    offsets: Mapping[CanonicalNodeRef, tuple[int, int]],
    sizes: Mapping[CanonicalNodeRef, tuple[int, int]],
    gap: int,
    stack_gap: int,
) -> dict[CanonicalNodeRef, tuple[int, int]]:
    target_x, target_y = offsets[target]
    target_width, target_height = sizes[target]
    stack_height = sum(sizes[ref][1] for ref in stack_refs) + max(0, len(stack_refs) - 1) * stack_gap
    y = target_y + round((target_height - stack_height) / 2)
    result: dict[CanonicalNodeRef, tuple[int, int]] = {}
    for ref in stack_refs:
        width, height = sizes[ref]
        x = target_x + target_width + gap if side == "right" else target_x - width - gap
        result[ref] = (x, y)
        y += height + stack_gap
    return result


def _sidecar_stack_rect(
    target: CanonicalNodeRef,
    side: str,
    stack_refs: Sequence[CanonicalNodeRef],
    offsets: Mapping[CanonicalNodeRef, tuple[int, int]],
    sizes: Mapping[CanonicalNodeRef, tuple[int, int]],
    gap: int,
    stack_gap: int,
) -> tuple[int, int, int, int]:
    stack_offsets = _sidecar_stack_offsets(target, side, stack_refs, offsets, sizes, gap, stack_gap)
    return _offset_bounds(stack_refs, stack_offsets, sizes)


def _offset_bounds(
    refs: Sequence[CanonicalNodeRef],
    offsets: Mapping[CanonicalNodeRef, tuple[int, int]],
    sizes: Mapping[CanonicalNodeRef, tuple[int, int]],
) -> tuple[int, int, int, int]:
    left = min(offsets[ref][0] for ref in refs)
    top = min(offsets[ref][1] for ref in refs)
    right = max(offsets[ref][0] + sizes[ref][0] for ref in refs)
    bottom = max(offsets[ref][1] + sizes[ref][1] for ref in refs)
    return (left, top, right - left, bottom - top)


def _offset_rect(
    ref: CanonicalNodeRef,
    offsets: Mapping[CanonicalNodeRef, tuple[int, int]],
    sizes: Mapping[CanonicalNodeRef, tuple[int, int]],
) -> tuple[int, int, int, int]:
    x, y = offsets[ref]
    width, height = sizes[ref]
    return (x, y, width, height)


def _offset_rects_violate_gutter(
    left: tuple[int, int, int, int],
    right: tuple[int, int, int, int],
    gutter: int,
) -> bool:
    return not (
        left[0] + left[2] + gutter <= right[0]
        or right[0] + right[2] + gutter <= left[0]
        or left[1] + left[3] + gutter <= right[1]
        or right[1] + right[3] + gutter <= left[1]
    )


def _shift_offsets(
    offsets: Mapping[CanonicalNodeRef, tuple[int, int]],
    refs: set[CanonicalNodeRef],
    dx: int,
) -> dict[CanonicalNodeRef, tuple[int, int]]:
    if dx <= 0:
        return dict(offsets)
    return {
        ref: (x + dx, y) if ref in refs else (x, y)
        for ref, (x, y) in offsets.items()
    }


def _sidecar_trace_choice(
    ref: CanonicalNodeRef,
    target: CanonicalNodeRef,
    side: str,
    stack_index: int,
    before: tuple[int, int] | None,
    after: tuple[int, int],
) -> str:
    before_label = "none" if before is None else f"{before[0]},{before[1]}"
    return (
        f"sidecar:{side}:stack:{stack_index}:target:{_entry_key(target)}"
        f":offset:{before_label}->{after[0]},{after[1]}"
    )


def _apply_local_helper_offsets(
    section: _CompileSection,
    plan: LayoutPlanV1,
    offsets: Mapping[CanonicalNodeRef, tuple[int, int]],
    sizes: Mapping[CanonicalNodeRef, tuple[int, int]],
    spacing: _Spacing,
) -> dict[CanonicalNodeRef, tuple[int, int]]:
    adjusted = dict(offsets)
    section_refs = set(section.node_refs)
    anchor_gap = max(24, spacing.node_gap_y // 2)
    near_placements_by_anchor: dict[tuple[str, CanonicalNodeRef], list[Any]] = {}
    for placement in sorted(plan.helper_placements, key=lambda item: _ref_sort_key(item.helper)):
        helper = placement.helper
        if helper not in section_refs or helper not in sizes:
            continue
        if placement.kind == HELPER_PLACEMENT_INSIDE_SECTION:
            continue
        helper_width, helper_height = sizes[helper]
        if placement.kind == HELPER_PLACEMENT_EDGE_PATH:
            source = placement.source
            destination = placement.destination
            if source in adjusted and destination in adjusted and source in sizes and destination in sizes:
                source_center = _offset_center(adjusted[source], sizes[source])
                target_center = _offset_center(adjusted[destination], sizes[destination])
                adjusted[helper] = (
                    round((source_center[0] + target_center[0] - helper_width) / 2),
                    round((source_center[1] + target_center[1] - helper_height) / 2),
                )
            continue
        target = placement.target
        if target not in adjusted or target not in sizes:
            continue
        if placement.kind in {HELPER_PLACEMENT_NEAR_PRODUCER, HELPER_PLACEMENT_NEAR_CONSUMER}:
            near_placements_by_anchor.setdefault((placement.kind, target), []).append(placement)
    stack_gap = max(8, spacing.node_gap_y // 4)
    for (kind, target), placements in sorted(
        near_placements_by_anchor.items(),
        key=lambda item: (item[0][0], _ref_sort_key(item[0][1])),
    ):
        if target not in adjusted or target not in sizes:
            continue
        target_x, target_y = adjusted[target]
        target_width, target_height = sizes[target]
        helpers = [placement.helper for placement in sorted(placements, key=lambda item: _ref_sort_key(item.helper))]
        total_height = sum(sizes[helper][1] for helper in helpers) + stack_gap * max(0, len(helpers) - 1)
        y = round(target_y + (target_height - total_height) / 2)
        max_width = max(sizes[helper][0] for helper in helpers)
        for helper in helpers:
            helper_width, helper_height = sizes[helper]
            if kind == HELPER_PLACEMENT_NEAR_PRODUCER:
                x = target_x + target_width + anchor_gap
            else:
                x = target_x - max_width - anchor_gap + (max_width - helper_width)
            adjusted[helper] = (x, y)
            y += helper_height + stack_gap
    return adjusted


def _offset_center(
    offset: tuple[int, int],
    size: tuple[int, int],
) -> tuple[float, float]:
    return (offset[0] + size[0] / 2, offset[1] + size[1] / 2)


def _section_effective_edges(
    facts: GraphInventoryFacts,
    refs: Sequence[CanonicalNodeRef],
) -> tuple[tuple[CanonicalNodeRef, CanonicalNodeRef], ...]:
    ref_set = set(refs)
    edges: set[tuple[CanonicalNodeRef, CanonicalNodeRef]] = set()
    for topology in facts.scope_topologies:
        for edge in topology.effective_edges:
            if edge.source in ref_set and edge.target in ref_set and edge.source != edge.target:
                edges.add((edge.source, edge.target))
    return tuple(sorted(edges, key=lambda item: (_ref_sort_key(item[0]), _ref_sort_key(item[1]))))


def _note_refs(
    refs: Sequence[CanonicalNodeRef],
    facts: GraphInventoryFacts,
) -> tuple[CanonicalNodeRef, ...]:
    canonical_by_ref = {fact.ref: fact for fact in facts.canonical_refs}
    notes = []
    for ref in refs:
        fact = canonical_by_ref.get(ref)
        class_type = str(getattr(fact, "class_type", "")).lower()
        if "note" in class_type or "markdown" in class_type or "annotation" in class_type:
            notes.append(ref)
    return tuple(sorted(notes, key=lambda ref: _local_ref_sort_key(ref, facts)))


def _parallel_branch_candidate(
    refs: Sequence[CanonicalNodeRef],
    facts: GraphInventoryFacts,
) -> tuple[CanonicalNodeRef, tuple[CanonicalNodeRef, ...], tuple[CanonicalNodeRef, ...]] | None:
    ref_set = set(refs)
    candidates: list[tuple[CanonicalNodeRef, tuple[CanonicalNodeRef, ...], tuple[CanonicalNodeRef, ...]]] = []
    for topology in facts.scope_topologies:
        for candidate in topology.parallel_branch_candidates:
            roots = tuple(root for root in sorted(candidate.branch_roots, key=lambda ref: _local_ref_sort_key(ref, facts)) if root in ref_set)
            if candidate.source not in ref_set or len(roots) < 2:
                continue
            terminals = tuple(
                terminal
                for terminal in sorted(candidate.terminal_refs, key=lambda ref: _local_ref_sort_key(ref, facts))
                if terminal in ref_set
            )
            candidates.append((candidate.source, roots, terminals))
    if not candidates:
        return None
    return sorted(candidates, key=lambda item: (_ref_sort_key(item[0]), tuple(_ref_sort_key(ref) for ref in item[1])))[0]


def _is_alternatives_section(
    section: _CompileSection,
    facts: GraphInventoryFacts,
    edges: Sequence[tuple[CanonicalNodeRef, CanonicalNodeRef]],
) -> bool:
    if edges or len(section.node_refs) < 2 or len(section.node_refs) > 4:
        return False
    canonical_by_ref = {fact.ref: fact for fact in facts.canonical_refs}
    roles = {
        getattr(canonical_by_ref.get(ref), "role_hint", ROLE_HINT_UNKNOWN)
        for ref in section.node_refs
    }
    classes = {
        str(getattr(canonical_by_ref.get(ref), "class_type", "")).lower()
        for ref in section.node_refs
    }
    return len(roles) == 1 or len(classes) == 1 or section.kind == SECTION_KIND_BRANCH


def _hub_ref(
    refs: Sequence[CanonicalNodeRef],
    edges: Sequence[tuple[CanonicalNodeRef, CanonicalNodeRef]],
) -> CanonicalNodeRef | None:
    incoming, outgoing = _local_degree_maps(refs, edges)
    candidates = [
        ref
        for ref in refs
        if len(incoming.get(ref, ())) > 0 and len(outgoing.get(ref, ())) > 0 and len(incoming.get(ref, ())) + len(outgoing.get(ref, ())) >= 3
    ]
    if not candidates:
        return None
    return sorted(candidates, key=lambda ref: (-(len(incoming.get(ref, ())) + len(outgoing.get(ref, ()))), _ref_sort_key(ref)))[0]


def _fan_in_ref(
    refs: Sequence[CanonicalNodeRef],
    edges: Sequence[tuple[CanonicalNodeRef, CanonicalNodeRef]],
) -> CanonicalNodeRef | None:
    incoming, outgoing = _local_degree_maps(refs, edges)
    candidates = [
        ref
        for ref in refs
        if len(incoming.get(ref, ())) >= 2 and len(outgoing.get(ref, ())) == 0
    ]
    if not candidates:
        return None
    return sorted(candidates, key=lambda ref: (-len(incoming.get(ref, ())), _ref_sort_key(ref)))[0]


def _fan_out_ref(
    refs: Sequence[CanonicalNodeRef],
    edges: Sequence[tuple[CanonicalNodeRef, CanonicalNodeRef]],
) -> CanonicalNodeRef | None:
    incoming, outgoing = _local_degree_maps(refs, edges)
    candidates = [
        ref
        for ref in refs
        if len(outgoing.get(ref, ())) >= 2 and len(incoming.get(ref, ())) == 0
    ]
    if not candidates:
        return None
    return sorted(candidates, key=lambda ref: (-len(outgoing.get(ref, ())), _ref_sort_key(ref)))[0]


def _local_degree_maps(
    refs: Sequence[CanonicalNodeRef],
    edges: Sequence[tuple[CanonicalNodeRef, CanonicalNodeRef]],
) -> tuple[dict[CanonicalNodeRef, set[CanonicalNodeRef]], dict[CanonicalNodeRef, set[CanonicalNodeRef]]]:
    incoming = {ref: set() for ref in refs}
    outgoing = {ref: set() for ref in refs}
    for source, target in edges:
        outgoing.setdefault(source, set()).add(target)
        incoming.setdefault(target, set()).add(source)
    return incoming, outgoing


def _is_pipeline(
    refs: Sequence[CanonicalNodeRef],
    edges: Sequence[tuple[CanonicalNodeRef, CanonicalNodeRef]],
) -> bool:
    if len(refs) < 3 or len(edges) < len(refs) - 1:
        return False
    incoming, outgoing = _local_degree_maps(refs, edges)
    starts = [ref for ref in refs if not incoming.get(ref)]
    ends = [ref for ref in refs if not outgoing.get(ref)]
    return (
        len(starts) == 1
        and len(ends) == 1
        and all(len(incoming.get(ref, ())) <= 1 and len(outgoing.get(ref, ())) <= 1 for ref in refs)
    )


def _local_layers(
    refs: Sequence[CanonicalNodeRef],
    edges: Sequence[tuple[CanonicalNodeRef, CanonicalNodeRef]],
    facts: GraphInventoryFacts,
) -> tuple[tuple[CanonicalNodeRef, ...], ...]:
    if not refs:
        return ()
    ref_set = set(refs)
    incoming = {ref: set() for ref in refs}
    outgoing = {ref: set() for ref in refs}
    for source, target in edges:
        if source in ref_set and target in ref_set:
            outgoing[source].add(target)
            incoming[target].add(source)
    pending = sorted((ref for ref in refs if not incoming[ref]), key=lambda ref: _local_ref_sort_key(ref, facts))
    processed: set[CanonicalNodeRef] = set()
    layer_by_ref: dict[CanonicalNodeRef, int] = {}
    while pending:
        ref = pending.pop(0)
        if ref in processed:
            continue
        processed.add(ref)
        layer_by_ref[ref] = max((layer_by_ref.get(source, 0) + 1 for source in incoming[ref]), default=0)
        for target in sorted(outgoing[ref], key=lambda item: _local_ref_sort_key(item, facts)):
            if target not in processed and all(source in processed for source in incoming[target]):
                pending.append(target)
    for ref in sorted((ref for ref in refs if ref not in processed), key=lambda item: _local_ref_sort_key(item, facts)):
        layer_by_ref[ref] = max(layer_by_ref.values(), default=-1) + 1
    layers: dict[int, list[CanonicalNodeRef]] = {}
    for ref, layer in layer_by_ref.items():
        layers.setdefault(layer, []).append(ref)
    return tuple(
        tuple(sorted(items, key=lambda ref: _local_ref_sort_key(ref, facts)))
        for _layer, items in sorted(layers.items())
    )


def _layout_columns(
    columns: Sequence[Sequence[CanonicalNodeRef]],
    sizes: Mapping[CanonicalNodeRef, tuple[int, int]],
    gap_x: int,
    gap_y: int,
) -> dict[CanonicalNodeRef, tuple[int, int]]:
    offsets: dict[CanonicalNodeRef, tuple[int, int]] = {}
    x = 0
    for column in columns:
        refs = tuple(column)
        if not refs:
            continue
        y = 0
        column_width = max(sizes[ref][0] for ref in refs)
        for ref in refs:
            offsets[ref] = (x, y)
            y += sizes[ref][1] + gap_y
        x += column_width + gap_x
    return offsets


def _column_stack_height(
    refs: Sequence[CanonicalNodeRef],
    sizes: Mapping[CanonicalNodeRef, tuple[int, int]],
    gap_y: int,
) -> int:
    if not refs:
        return 0
    return sum(sizes[ref][1] for ref in refs) + max(0, len(refs) - 1) * gap_y


def _reflow_into_balanced_columns(
    refs: Sequence[CanonicalNodeRef],
    sizes: Mapping[CanonicalNodeRef, tuple[int, int]],
    gap_y: int,
    target_columns: int,
) -> tuple[tuple[CanonicalNodeRef, ...], ...]:
    """Pack nodes into ``target_columns`` contiguous, height-balanced columns.

    Finds the smallest achievable per-column stack height (binary search over
    the greedy "fill each column up to a budget" packing) and reflows the nodes
    into that many contiguous columns.  Contiguity preserves the section's
    vertical reading order; minimising the tallest column keeps the group
    compact instead of letting one column run far past its siblings.
    """
    if target_columns <= 1 or len(refs) <= 1:
        return (tuple(refs),) if refs else ()
    node_heights = [sizes[ref][1] for ref in refs]

    def columns_for_budget(budget: int) -> int:
        columns = 1
        running = 0
        for height in node_heights:
            stepped = height if running == 0 else running + gap_y + height
            if stepped <= budget or running == 0:
                running = stepped
            else:
                columns += 1
                running = height
        return columns

    low = max(node_heights)
    high = _column_stack_height(refs, sizes, gap_y)
    budget = high
    while low <= high:
        midpoint = (low + high) // 2
        if columns_for_budget(midpoint) <= target_columns:
            budget = midpoint
            high = midpoint - 1
        else:
            low = midpoint + 1

    columns: list[tuple[CanonicalNodeRef, ...]] = []
    current: list[CanonicalNodeRef] = []
    running = 0
    for ref, height in zip(refs, node_heights, strict=True):
        stepped = height if not current else running + gap_y + height
        if stepped <= budget or not current:
            current.append(ref)
            running = stepped
        else:
            columns.append(tuple(current))
            current = [ref]
            running = height
    if current:
        columns.append(tuple(current))
    return tuple(columns)


def _rebalance_layer_columns(
    columns: Sequence[Sequence[CanonicalNodeRef]],
    sizes: Mapping[CanonicalNodeRef, tuple[int, int]],
    gap_y: int,
    *,
    max_columns: int = COMPILE_MAX_ROW_COLUMNS,
    imbalance_factor: float = _REBALANCE_IMBALANCE_FACTOR,
    min_dominant_nodes: int = _REBALANCE_MIN_DOMINANT_NODES,
) -> tuple[tuple[CanonicalNodeRef, ...], ...]:
    """Reflow a layered section into a compact, height-balanced column grid.

    Sections whose nodes are weakly connected -- for example prompt pipelines
    wired through rgthree Set/Get broadcast channels rather than direct edges --
    collapse their independent roots into a single topological layer, and
    topological layering can also emit more layers than a group can read as
    columns.  Both cases produce a group that is either far taller than its
    neighbours (one over-tall column with whitespace beside it) or far wider
    than the wall's column budget.

    This reflows the section's nodes into at most ``max_columns`` contiguous
    columns of near-equal height whenever the layered layout is imbalanced or
    exceeds the column budget, preserving reading order.  Already compact,
    balanced layouts are returned unchanged.  The rule is structural: it keys
    off relative column heights, node counts, and the column budget -- never off
    node identity, class, or section title.
    """
    cleaned = tuple(tuple(column) for column in columns if column)
    if not cleaned:
        return ()
    heights = tuple(_column_stack_height(column, sizes, gap_y) for column in cleaned)
    dominant_index = max(range(len(heights)), key=lambda index: heights[index])
    dominant_height = heights[dominant_index]
    dominant_column = cleaned[dominant_index]
    sibling_heights = tuple(height for index, height in enumerate(heights) if index != dominant_index)
    runner_up_height = max(sibling_heights, default=0)

    flat_refs = tuple(ref for column in cleaned for ref in column)
    if len(flat_refs) < min(max(2, min_dominant_nodes), 3):
        return cleaned

    over_capacity = len(cleaned) > max_columns
    imbalanced = (
        runner_up_height > 0
        and dominant_height >= runner_up_height * imbalance_factor
        and len(dominant_column) >= min_dominant_nodes
    )
    # A single column with many nodes (e.g. every root landed in layer 0 because
    # the section's nodes are only wired through broadcasts) is the degenerate
    # imbalance case: there are no siblings to compare against.
    single_tall_column = len(cleaned) < 2 and len(flat_refs) >= min_dominant_nodes
    if not over_capacity and not imbalanced and not single_tall_column:
        return cleaned

    if runner_up_height > 0:
        columns_for_height = ceil(max(1, dominant_height) / max(1, runner_up_height * imbalance_factor))
    else:
        columns_for_height = int(ceil(sqrt(len(flat_refs))))
    target_columns = max(2, min(max_columns, columns_for_height, len(flat_refs)))
    reflowed = _reflow_into_balanced_columns(flat_refs, sizes, gap_y, target_columns)
    return reflowed if reflowed else cleaned


def _layout_columns_balanced(
    columns: Sequence[Sequence[CanonicalNodeRef]],
    sizes: Mapping[CanonicalNodeRef, tuple[int, int]],
    gap_x: int,
    gap_y: int,
) -> dict[CanonicalNodeRef, tuple[int, int]]:
    rebalanced = _rebalance_layer_columns(columns, sizes, gap_y)
    return _layout_columns(rebalanced, sizes, gap_x, gap_y)


def _layout_wrapped_row(
    refs: Sequence[CanonicalNodeRef],
    sizes: Mapping[CanonicalNodeRef, tuple[int, int]],
    gap_x: int,
    gap_y: int,
    max_columns: int,
) -> dict[CanonicalNodeRef, tuple[int, int]]:
    if not refs:
        return {}
    columns = max(1, min(max_columns, len(refs)))
    rows = tuple(
        tuple(refs[index : index + columns])
        for index in range(0, len(refs), columns)
    )
    column_widths = [
        max((sizes[row[column]][0] for row in rows if column < len(row)), default=0)
        for column in range(columns)
    ]
    row_heights = [
        max((sizes[ref][1] for ref in row), default=0)
        for row in rows
    ]
    column_x = [sum(column_widths[:column]) + column * gap_x for column in range(columns)]
    row_y = [sum(row_heights[:row]) + row * gap_y for row in range(len(rows))]
    return {
        ref: (column_x[column], row_y[row])
        for row, row_refs in enumerate(rows)
        for column, ref in enumerate(row_refs)
    }


def _layout_grid(
    refs: Sequence[CanonicalNodeRef],
    sizes: Mapping[CanonicalNodeRef, tuple[int, int]],
    gap_x: int,
    gap_y: int,
) -> dict[CanonicalNodeRef, tuple[int, int]]:
    if not refs:
        return {}
    columns = 1
    while columns * columns < len(refs):
        columns += 1
    columns = min(columns, COMPILE_MAX_ROW_COLUMNS)
    rows = (len(refs) + columns - 1) // columns
    column_widths = [
        max((sizes[refs[row * columns + column]][0] for row in range(rows) if row * columns + column < len(refs)), default=0)
        for column in range(columns)
    ]
    row_heights = [
        max((sizes[refs[row * columns + column]][1] for column in range(columns) if row * columns + column < len(refs)), default=0)
        for row in range(rows)
    ]
    column_x = [sum(column_widths[:column]) + column * gap_x for column in range(columns)]
    row_y = [sum(row_heights[:row]) + row * gap_y for row in range(rows)]
    return {
        ref: (column_x[index % columns], row_y[index // columns])
        for index, ref in enumerate(refs)
    }


def _layout_primary_rows(
    primary_refs: Sequence[CanonicalNodeRef],
    sizes: Mapping[CanonicalNodeRef, tuple[int, int]],
    gap_x: int,
    gap_y: int,
    *,
    columns_per_row: int = 3,
) -> dict[CanonicalNodeRef, tuple[int, int]]:
    """Layout primary nodes in rows of at most *columns_per_row* nodes each.

    Uses actual ``_node_size_for_ref`` dimensions to compute column widths and
    row heights so that spacing/group bounds are driven by real node sizes.
    """
    if not primary_refs:
        return {}
    columns = min(columns_per_row, len(primary_refs))
    rows = (len(primary_refs) + columns - 1) // columns
    column_widths = [
        max(
            (
                sizes[primary_refs[r * columns + c]][0]
                for r in range(rows)
                if r * columns + c < len(primary_refs)
            ),
            default=0,
        )
        for c in range(columns)
    ]
    row_heights = [
        max(
            (
                sizes[primary_refs[r * columns + c]][1]
                for c in range(columns)
                if r * columns + c < len(primary_refs)
            ),
            default=0,
        )
        for r in range(rows)
    ]
    col_x = [sum(column_widths[:c]) + c * gap_x for c in range(columns)]
    row_y = [sum(row_heights[:r]) + r * gap_y for r in range(rows)]
    return {
        ref: (col_x[idx % columns], row_y[idx // columns])
        for idx, ref in enumerate(primary_refs)
    }


def _layout_behavior_for_ref(
    ref: CanonicalNodeRef,
    facts: GraphInventoryFacts,
) -> str:
    """Return the ``layout_behavior`` string for *ref*, defaulting to ``"unknown"``."""
    for fact in facts.canonical_refs:
        if fact.ref == ref:
            return str(getattr(fact, "layout_behavior", "unknown") or "unknown")
    return "unknown"


def _local_bounds(
    offsets: Mapping[CanonicalNodeRef, tuple[int, int]],
    sizes: Mapping[CanonicalNodeRef, tuple[int, int]],
) -> tuple[int, int]:
    if not offsets:
        return (0, 0)
    width = max(x + sizes[ref][0] for ref, (x, _y) in offsets.items())
    height = max(y + sizes[ref][1] for ref, (_x, y) in offsets.items())
    return (width, height)


def _local_ref_sort_key(ref: CanonicalNodeRef, facts: GraphInventoryFacts) -> tuple[Any, ...]:
    topology_by_ref = {
        node.ref: node
        for topology in facts.scope_topologies
        for node in topology.node_topology
    }
    topology = topology_by_ref.get(ref)
    if topology is None:
        return (0, 0, 0, *_ref_sort_key(ref))
    return (
        getattr(topology, "topological_rank", 0),
        getattr(topology, "lane_band", 0),
        getattr(topology, "lane_index", 0),
        *_ref_sort_key(ref),
    )


def _effective_pinned_refs(
    facts: GraphInventoryFacts,
    options: LayoutCompileOptions,
    classification: ClassificationReport,
) -> set[CanonicalNodeRef]:
    if _force_existing_regroup(options):
        return set()
    pinned_refs = set(options.pinned_refs)
    for furniture in facts.node_furniture:
        if _truthy_flag(furniture.flags, "pinned") or _truthy_flag(furniture.sidecar_entry, "pinned"):
            pinned_refs.add(furniture.ref)
    return pinned_refs


def _validate_pinned_preservation(
    node_layouts: Sequence[CompiledNodeLayout],
    facts: GraphInventoryFacts,
    options: LayoutCompileOptions,
) -> tuple[ReorganiseDiagnostic, ...]:
    """Emit deterministic blocking errors when pinned nodes are not at their exact furniture positions.

    Pinned-node preservation is exact: every pinned node must have a known furniture
    position and the compiler-assigned position must match it byte-for-byte.
    """
    if _force_existing_regroup(options):
        return ()
    furniture_by_ref: dict[CanonicalNodeRef, NodeFurnitureFact] = {
        fact.ref: fact for fact in facts.node_furniture
    }
    pinned_refs: set[CanonicalNodeRef] = set(options.pinned_refs)
    for furniture in facts.node_furniture:
        if _truthy_flag(furniture.flags, "pinned") or _truthy_flag(furniture.sidecar_entry, "pinned"):
            pinned_refs.add(furniture.ref)
    diagnostics: list[ReorganiseDiagnostic] = []
    for layout in node_layouts:
        if layout.ref not in pinned_refs:
            continue
        furniture = furniture_by_ref.get(layout.ref)
        if furniture is None:
            diagnostics.append(
                ReorganiseDiagnostic(
                    code=COMPILE_ISSUE_PINNED_PRESERVATION_FAILED,
                    message=(
                        f"Pinned node {layout.ref.to_json()!r} has no furniture entry; "
                        f"pinned positions can only be preserved when furniture is present."
                    ),
                    severity=DIAGNOSTIC_SEVERITY_ERROR,
                    detail={"ref": layout.ref.to_json()},
                )
            )
            continue
        pinned_pos = _pos(furniture.pos)
        if pinned_pos is None:
            diagnostics.append(
                ReorganiseDiagnostic(
                    code=COMPILE_ISSUE_PINNED_PRESERVATION_FAILED,
                    message=(
                        f"Pinned node {layout.ref.to_json()!r} has no position in furniture; "
                        f"pinned nodes require an exact furniture position."
                    ),
                    severity=DIAGNOSTIC_SEVERITY_ERROR,
                    detail={"ref": layout.ref.to_json()},
                )
            )
            continue
        actual_pos = (layout.x, layout.y)
        if actual_pos != pinned_pos:
            diagnostics.append(
                ReorganiseDiagnostic(
                    code=COMPILE_ISSUE_PINNED_PRESERVATION_FAILED,
                    message=(
                        f"Pinned node {layout.ref.to_json()!r} position mismatch: "
                        f"expected {pinned_pos}, got {actual_pos}."
                    ),
                    severity=DIAGNOSTIC_SEVERITY_ERROR,
                    detail={
                        "ref": layout.ref.to_json(),
                        "expected": list(pinned_pos),
                        "actual": list(actual_pos),
                    },
                )
            )
    return tuple(diagnostics)


def _truthy_flag(value: Any, key: str) -> bool:
    if not isinstance(value, Mapping):
        return False
    item = value.get(key)
    return isinstance(item, bool) and item


def _force_existing_regroup(options: LayoutCompileOptions) -> bool:
    return options.force_regroup or options.existing_group_policy == "force_regroup"


def _apply_existing_group_policy(
    group_layouts: Sequence[CompiledGroupLayout],
    facts: GraphInventoryFacts,
    options: LayoutCompileOptions,
    classification: ClassificationReport,
) -> tuple[tuple[CompiledGroupLayout, ...], tuple[AssessmentIssue, ...]]:
    policy: ExistingGroupPolicy = "force_regroup" if _force_existing_regroup(options) else options.existing_group_policy
    baseline = tuple(group_layouts)
    baseline_by_id = {group.id: group for group in baseline}
    baseline_by_nodes: dict[tuple[str, tuple[CanonicalNodeRef, ...]], CompiledGroupLayout] = {}
    for group in baseline:
        if group.node_refs:
            baseline_by_nodes.setdefault(
                (group.scope_path, tuple(sorted(group.node_refs, key=_ref_sort_key))),
                group,
            )

    groups_by_id = dict(baseline_by_id)
    issues: list[AssessmentIssue] = []
    for group, score in _scored_existing_groups(facts, classification):
        match = _matching_compiled_group(group, score, baseline_by_id, baseline_by_nodes)
        if not score.coherent:
            if policy == "semantic_preserve":
                continue
            action = "dissolved" if policy == "dissolve_with_warning" or match is None else "rebuilt"
            issues.append(_existing_group_policy_issue(group, score, policy=policy, action=action))
            continue
        if policy in {"dissolve_with_warning", "force_regroup"}:
            continue
        replacement = _policy_group_layout(group, score, match, policy)
        groups_by_id[replacement.id] = replacement

    return (
        tuple(sorted(groups_by_id.values(), key=lambda layout: (-_scope_depth(layout.scope_path), layout.scope_path, layout.id))),
        tuple(issues),
    )


def _existing_group_scores(
    facts: GraphInventoryFacts,
    classification: ClassificationReport,
) -> tuple[_ExistingGroupScore, ...]:
    return tuple(score for _group, score in _scored_existing_groups(facts, classification))


def _scored_existing_groups(
    facts: GraphInventoryFacts,
    classification: ClassificationReport,
) -> tuple[tuple[GroupFact, _ExistingGroupScore], ...]:
    scored: list[tuple[GroupFact, _ExistingGroupScore]] = []
    for scope in sorted(facts.scope_furniture, key=lambda item: item.scope_path):
        for group in sorted(scope.groups, key=lambda item: item.index):
            score = _score_existing_group(facts, group, classification)
            if score is not None:
                scored.append((group, score))
    return tuple(scored)


def _matching_compiled_group(
    group: GroupFact,
    score: _ExistingGroupScore,
    baseline_by_id: Mapping[str, CompiledGroupLayout],
    baseline_by_nodes: Mapping[tuple[str, tuple[CanonicalNodeRef, ...]], CompiledGroupLayout],
) -> CompiledGroupLayout | None:
    existing_id = _existing_group_section_id(group.scope_path, group.index)
    match = baseline_by_id.get(existing_id)
    if match is not None:
        return match
    return baseline_by_nodes.get((group.scope_path, tuple(sorted(score.member_refs, key=_ref_sort_key))))


def _policy_group_layout(
    group: GroupFact,
    score: _ExistingGroupScore,
    baseline: CompiledGroupLayout | None,
    policy: ExistingGroupPolicy,
) -> CompiledGroupLayout:
    existing_rect = _group_rect(group.bounding)
    if policy in {"resize_only", "rename_and_resize"} and baseline is not None:
        x, y, width, height = baseline.x, baseline.y, baseline.width, baseline.height
    elif existing_rect is not None:
        x, y = snap_pos((existing_rect.x, existing_rect.y))
        width, height = snap_size((existing_rect.width, existing_rect.height))
    elif baseline is not None:
        x, y, width, height = baseline.x, baseline.y, baseline.width, baseline.height
    else:
        x, y, width, height = 0, 0, DEFAULT_NODE_WIDTH, DEFAULT_NODE_HEIGHT + DEFAULT_GROUP_HEADER_HEIGHT

    use_semantic_title = policy in {"rename_only", "rename_and_resize"}
    title = (
        baseline.title
        if use_semantic_title and baseline is not None
        else group.title
        if isinstance(group.title, str) and group.title
        else baseline.title
        if baseline is not None
        else _title_for(_existing_group_section_id(group.scope_path, group.index), score.section_kind)
    )
    kind = baseline.kind if baseline is not None else score.section_kind
    return CompiledGroupLayout(
        id=baseline.id if baseline is not None else _existing_group_section_id(group.scope_path, group.index),
        scope_path=group.scope_path,
        title=title,
        kind=kind,
        role_hint=baseline.role_hint if baseline is not None else None,
        node_refs=score.member_refs,
        x=x,
        y=y,
        width=max(1, width),
        height=max(1, height),
        color=group.color if isinstance(group.color, str) and group.color else baseline.color if baseline is not None else _ROLE_COLORS.get(kind, _ROLE_COLORS[SECTION_KIND_CUSTOM]),
        template=baseline.template if baseline is not None else None,
    )


def _existing_group_policy_issue(
    group: GroupFact,
    score: _ExistingGroupScore,
    *,
    policy: ExistingGroupPolicy,
    action: Literal["dissolved", "rebuilt"],
) -> AssessmentIssue:
    code = (
        COMPILE_ISSUE_EXISTING_GROUP_REBUILT
        if action == "rebuilt"
        else COMPILE_ISSUE_EXISTING_GROUP_DISSOLVED
    )
    title = group.title if isinstance(group.title, str) and group.title else f"group {group.index}"
    return AssessmentIssue(
        code=code,
        message=f"Existing group {title!r} was {action} because it is incoherent.",
        severity="warning",
        refs=score.member_refs,
        detail={
            "scope_path": group.scope_path,
            "group_index": group.index,
            "title": group.title,
            "policy": policy,
            "action": action,
            "score": round(score.score, 4),
            "containment": round(score.containment, 4),
            "topology": round(score.topology, 4),
            "title_role": round(score.title_role, 4),
            "node_coverage": round(score.node_coverage, 4),
        },
    )


def _candidate_patch(
    node_layouts: Sequence[CompiledNodeLayout],
    group_layouts: Sequence[CompiledGroupLayout],
    facts: GraphInventoryFacts,
    options: LayoutCompileOptions,
    *,
    structural_hash: str = "",
) -> LayoutCandidatePatch:
    furniture_by_ref = {fact.ref: fact for fact in facts.node_furniture}
    entries: dict[str, Mapping[str, Any]] = {}
    for layout in sorted(node_layouts, key=lambda item: _entry_key(item.ref)):
        furniture = furniture_by_ref.get(layout.ref)
        entries[_entry_key(layout.ref)] = _entry_for_layout(layout, furniture)

    groups = tuple(_sidecar_group(group) for group in sorted(group_layouts, key=lambda item: (item.scope_path, item.id)))
    sidecar = facts.sidecar_envelope
    root_scope = next((scope for scope in facts.scope_furniture if scope.scope_path == ""), None)
    extra = sidecar.get("extra") if isinstance(sidecar.get("extra"), Mapping) else None
    if extra is None and root_scope is not None:
        extra = root_scope.extra
    last_reroute_id = sidecar.get("lastRerouteId")
    if last_reroute_id is None and root_scope is not None:
        last_reroute_id = root_scope.last_reroute_id
    return LayoutCandidatePatch(
        entries=entries,
        groups=groups,
        extra=extra or {},
        last_reroute_id=last_reroute_id,
        definitions=sidecar.get("definitions") if isinstance(sidecar.get("definitions"), Mapping) else {},
        virtual_wires=_candidate_virtual_wires(facts),
        store_version=STORE_VERSION,
        vibecomfy_version=str(sidecar.get("vibecomfy_version", "0")),
        schema_hash=_candidate_schema_hash(),
        unkeyed=_candidate_unkeyed(sidecar),
        structural_hash_before=structural_hash,
        structural_hash_after=structural_hash,
    )


def _candidate_virtual_wires(facts: GraphInventoryFacts) -> Mapping[str, Any]:
    sidecar = facts.sidecar_envelope
    if isinstance(sidecar.get("virtual_wires"), Mapping):
        return sidecar["virtual_wires"]
    return {
        wire.key: _thaw_jsonish(wire.payload)
        for wire in sorted(facts.virtual_wires, key=lambda item: (item.source, item.key))
    }


def _candidate_unkeyed(sidecar: Mapping[str, Any]) -> tuple[Any, ...]:
    unkeyed = sidecar.get("unkeyed", ())
    if isinstance(unkeyed, Sequence) and not isinstance(unkeyed, (str, bytes)):
        return tuple(unkeyed)
    return ()


# Section kinds excluded from role-purity diagnostics.
_ROLE_PURITY_EXCLUDED_KINDS: frozenset[SectionKind] = frozenset(
    {SECTION_KIND_CUSTOM, SECTION_KIND_UTILITY, SECTION_KIND_CONTAINER, SECTION_KIND_BRANCH}
)

# For each single-role core section kind, the set of classification role hints
# that are acceptable without a mixed-core-role warning.
_SECTION_KIND_ACCEPTABLE_ROLES: Mapping[SectionKind, frozenset[RoleHint]] = MappingProxyType(
    {
        SECTION_KIND_LOADERS: frozenset({ROLE_HINT_LOADER}),
        SECTION_KIND_CONDITIONING: frozenset({ROLE_HINT_CONDITIONING}),
        SECTION_KIND_LATENT: frozenset({ROLE_HINT_LATENT}),
        SECTION_KIND_SAMPLING: frozenset({ROLE_HINT_SAMPLER}),
        SECTION_KIND_DECODE: frozenset({ROLE_HINT_DECODE}),
        SECTION_KIND_OUTPUT: frozenset({ROLE_HINT_OUTPUT, ROLE_HINT_DECODE}),
        SECTION_KIND_CONTROL: frozenset({ROLE_HINT_CONTROL}),
        SECTION_KIND_POSTPROCESS: frozenset({ROLE_HINT_POSTPROCESS}),
    }
)

# Core role hints that, when misplaced, trigger a mixed-core-role warning.
_CORE_ROLE_HINTS: frozenset[RoleHint] = frozenset(
    {
        ROLE_HINT_LOADER,
        ROLE_HINT_CONDITIONING,
        ROLE_HINT_LATENT,
        ROLE_HINT_SAMPLER,
        ROLE_HINT_DECODE,
        ROLE_HINT_OUTPUT,
        ROLE_HINT_CONTROL,
        ROLE_HINT_POSTPROCESS,
    }
)


def _validate_role_purity(
    sections: Sequence[_CompileSection],
    classification: ClassificationReport,
) -> tuple[AssessmentIssue, ...]:
    """Emit warning diagnostics when a core-role node appears in a mismatched
    single-role section.

    Sections of kind ``custom``, ``utility``, ``container``, and ``branch`` are
    excluded from these checks.  Helper nodes (``helper`` / ``ui`` role hints)
    and nodes with an ``unknown`` role hint are also never flagged.
    """
    issues: list[AssessmentIssue] = []
    for section in sections:
        if section.kind in _ROLE_PURITY_EXCLUDED_KINDS:
            continue
        acceptable = _SECTION_KIND_ACCEPTABLE_ROLES.get(section.kind)
        if acceptable is None:
            continue
        mismatched: list[dict[str, Any]] = []
        for ref in section.node_refs:
            hint = classification.hint_for(ref)
            if hint is None:
                continue
            role = hint.role_hint
            if role not in _CORE_ROLE_HINTS:
                # Helpers, UI, unknown, shared, subgraph-container are not
                # considered misplacements here.
                continue
            if role in acceptable:
                continue
            mismatched.append(
                {
                    "ref": ref.to_json(),
                    "class_type": hint.class_type,
                    "actual_role": role,
                    "section_kind": section.kind,
                }
            )
        if mismatched:
            issues.append(
                AssessmentIssue(
                    code=COMPILE_ISSUE_MIXED_CORE_ROLE,
                    message=f"Section \"{section.id}\" ({section.kind}) contains nodes "
                    f"with unexpected core roles.",
                    severity="warning",
                    refs=tuple(
                        CanonicalNodeRef(*item["ref"])
                        for item in mismatched
                    ),
                    detail={
                        "section_id": section.id,
                        "section_kind": section.kind,
                        "mismatched": mismatched,
                    },
                )
            )
    return tuple(issues)


def _build_report(
    *,
    node_layouts: Sequence[CompiledNodeLayout],
    group_layouts: Sequence[CompiledGroupLayout],
    facts: GraphInventoryFacts,
    candidate_patch: LayoutCandidatePatch,
    structural_hash_before: str,
    structural_hash_after: str,
    diagnostics: Sequence[Any],
    issues: Sequence[AssessmentIssue] = (),
) -> Any:
    helper_count = sum(
        1
        for layout in node_layouts
        if layout.role_hint in {ROLE_HINT_HELPER, ROLE_HINT_UI}
    )
    gate_metrics, gate_issues = _compile_gate_metrics_and_issues(
        node_layouts=node_layouts,
        group_layouts=group_layouts,
        facts=facts,
        candidate_patch=candidate_patch,
        structural_hash_before=structural_hash_before,
        structural_hash_after=structural_hash_after,
    )
    metrics = (
        AssessmentMetric(name=COMPILE_METRIC_NODE_LAYOUT_COUNT, value=len(node_layouts)),
        AssessmentMetric(name=COMPILE_METRIC_GROUP_LAYOUT_COUNT, value=len(group_layouts)),
        AssessmentMetric(name=COMPILE_METRIC_HELPER_LAYOUT_COUNT, value=helper_count),
        *gate_metrics,
        AssessmentMetric(
            name=COMPILE_METRIC_STRUCTURAL_HASH_UNCHANGED,
            value=structural_hash_before == structural_hash_after,
        ),
    )
    return build_assessment_report(
        metrics=metrics,
        issues=(*tuple(issues), *gate_issues),
        diagnostics=diagnostics,
        metric_order=COMPILE_METRIC_ORDER,
        issue_order=COMPILE_ISSUE_ORDER,
    )


def _compile_gate_metrics_and_issues(
    *,
    node_layouts: Sequence[CompiledNodeLayout],
    group_layouts: Sequence[CompiledGroupLayout],
    facts: GraphInventoryFacts,
    candidate_patch: LayoutCandidatePatch,
    structural_hash_before: str,
    structural_hash_after: str,
) -> tuple[tuple[AssessmentMetric, ...], tuple[AssessmentIssue, ...]]:
    helper_refs = {fact.ref for fact in facts.canonical_refs if fact.is_helper}
    node_rects = _node_rects(node_layouts)
    primary_rects = {
        ref: rect
        for ref, rect in node_rects.items()
        if ref not in helper_refs
    }
    group_rects = _group_metric_rects(group_layouts, node_rects)
    node_overlaps = _rect_overlap_pairs(primary_rects)
    group_overlaps = _unintended_group_overlap_pairs(group_rects)
    whitespace_ratio_max, whitespace_warnings = _compiled_group_whitespace(group_layouts, node_rects)
    baseline_variance_max, baseline_variance_warnings = _compiled_baseline_variance(node_layouts, facts)
    detached_group_distance_max, detached_group_warnings = _compiled_detached_group_distances(node_layouts, group_layouts, facts)
    helper_sidecar_overlaps = _compiled_helper_sidecar_overlap_pairs(node_rects, facts)
    note_section_mismatches = _compiled_note_section_mismatches(node_layouts, facts)
    max_primary_nodes_per_row, primary_row_warnings = _compiled_primary_row_density(node_layouts, facts)
    long_edge_distance_max, long_edge_warnings = _compiled_long_edge_distances(facts, node_rects)
    backward_count, measured_edges = _compiled_backward_edge_counts(facts, node_rects)
    backward_ratio = _ratio_float(backward_count, measured_edges)
    crossings = _compiled_crossing_proxy_pairs(facts, node_rects)
    minimum_gutter, gutter_violations = _compiled_minimum_gutter(primary_rects, group_rects)
    helper_distance_max, helper_distance_violations = _compiled_helper_distance_violations(facts, node_rects, helper_refs)
    idempotence_delta, idempotence_detail = _compiled_idempotence_delta(facts, candidate_patch)
    large_workflow_soft_quality_gate = _large_workflow_soft_quality_gate(facts)
    root_node_count = next(
        (scope.node_count for scope in facts.summary.scopes if scope.scope_path == ""),
        len(primary_rects),
    )
    nested_scope_count = sum(1 for scope in facts.summary.scopes if scope.scope_path)
    small_visible_wrapper = bool(nested_scope_count and root_node_count <= 12)
    node_only_small_layout = not group_layouts and (len(primary_rects) <= 14 or small_visible_wrapper)

    metrics = (
        AssessmentMetric(
            name=COMPILE_METRIC_NODE_OVERLAP_COUNT,
            value=len(node_overlaps),
            threshold=0,
        ),
        AssessmentMetric(
            name=COMPILE_METRIC_GROUP_OVERLAP_COUNT,
            value=len(group_overlaps),
            threshold=0,
        ),
        AssessmentMetric(
            name=COMPILE_METRIC_INTERNAL_WHITESPACE_RATIO_MAX,
            value=round(whitespace_ratio_max, 4),
            threshold=COMPILE_INTERNAL_WHITESPACE_RATIO_THRESHOLD,
        ),
        AssessmentMetric(
            name=COMPILE_METRIC_BASELINE_VARIANCE_MAX,
            value=round(baseline_variance_max, 2),
            threshold=COMPILE_BASELINE_VARIANCE_THRESHOLD,
        ),
        AssessmentMetric(
            name=COMPILE_METRIC_DETACHED_GROUP_DISTANCE_MAX,
            value=round(detached_group_distance_max, 2),
            threshold=COMPILE_DETACHED_GROUP_DISTANCE_THRESHOLD,
        ),
        AssessmentMetric(
            name=COMPILE_METRIC_HELPER_SIDECAR_OVERLAP_COUNT,
            value=len(helper_sidecar_overlaps),
            threshold=0,
        ),
        AssessmentMetric(
            name=COMPILE_METRIC_NOTE_SECTION_MISMATCH_COUNT,
            value=len(note_section_mismatches),
            threshold=0,
        ),
        AssessmentMetric(
            name=COMPILE_METRIC_MAX_PRIMARY_NODES_PER_ROW,
            value=max_primary_nodes_per_row,
            threshold=COMPILE_MAX_PRIMARY_ROW_COUNT_THRESHOLD,
        ),
        AssessmentMetric(
            name=COMPILE_METRIC_LONG_EDGE_DISTANCE_MAX,
            value=round(long_edge_distance_max, 2),
            threshold=COMPILE_LONG_EDGE_DISTANCE_THRESHOLD,
        ),
        AssessmentMetric(
            name=COMPILE_METRIC_BACKWARD_EDGE_RATIO,
            value=round(backward_ratio, 4),
            threshold=COMPILE_BACKWARD_EDGE_RATIO_THRESHOLD,
        ),
        AssessmentMetric(
            name=COMPILE_METRIC_CROSSING_PROXY_COUNT,
            value=len(crossings),
            threshold=COMPILE_CROSSING_PROXY_THRESHOLD,
        ),
        AssessmentMetric(
            name=COMPILE_METRIC_MINIMUM_GUTTER,
            value=round(minimum_gutter, 2),
            threshold=MIN_NODE_GUTTER,
        ),
        AssessmentMetric(
            name=COMPILE_METRIC_HELPER_DISTANCE_MAX,
            value=round(helper_distance_max, 2),
            threshold=COMPILE_HELPER_DISTANCE_THRESHOLD,
        ),
        AssessmentMetric(
            name=COMPILE_METRIC_IDEMPOTENCE_DELTA,
            value=round(idempotence_delta, 2),
            threshold=COMPILE_IDEMPOTENCE_DELTA_THRESHOLD,
        ),
    )

    issues: list[AssessmentIssue] = []
    if node_overlaps:
        issues.append(
            AssessmentIssue(
                code=COMPILE_ISSUE_NODE_OVERLAP,
                message="Compiled primary node boxes overlap.",
                severity="warning" if large_workflow_soft_quality_gate else "error",
                refs=tuple(ref for left, right in node_overlaps for ref in (left.ref, right.ref) if ref is not None),
                detail={
                    "count": len(node_overlaps),
                    "pairs": [
                        [_rect_ref_json(left), _rect_ref_json(right)]
                        for left, right in node_overlaps
                    ],
                },
            )
        )
    if group_overlaps:
        issues.append(
            AssessmentIssue(
                code=COMPILE_ISSUE_GROUP_OVERLAP,
                message="Compiled group boxes overlap without containment.",
                severity="warning" if large_workflow_soft_quality_gate else "error",
                refs=tuple(
                    ref
                    for left, right in group_overlaps
                    for group in (left.group, right.group)
                    if group is not None
                    for ref in group.node_refs
                ),
                detail={
                    "count": len(group_overlaps),
                    "pairs": [
                        [_rect_group_json(left), _rect_group_json(right)]
                        for left, right in group_overlaps
                    ],
                },
            )
        )
    if whitespace_warnings:
        issues.append(
            AssessmentIssue(
                code=COMPILE_ISSUE_INTERNAL_WHITESPACE_HIGH,
                message="Compiled group bounds contain excessive internal whitespace.",
                severity="warning",
                refs=tuple(
                    ref
                    for warning in whitespace_warnings
                    for ref in warning["group"].node_refs
                ),
                detail={
                    "threshold": COMPILE_INTERNAL_WHITESPACE_RATIO_THRESHOLD,
                    "groups": [_group_whitespace_warning_json(warning) for warning in whitespace_warnings],
                },
            )
        )
    if baseline_variance_warnings:
        issues.append(
            AssessmentIssue(
                code=COMPILE_ISSUE_BASELINE_VARIANCE_HIGH,
                message="Compiled primary rows do not share a stable baseline.",
                severity="warning",
                refs=tuple(
                    ref
                    for warning in baseline_variance_warnings
                    for ref in warning["refs"]
                ),
                detail={
                    "threshold": COMPILE_BASELINE_VARIANCE_THRESHOLD,
                    "rows": [_baseline_variance_warning_json(warning) for warning in baseline_variance_warnings],
                },
            )
        )
    if detached_group_warnings:
        issues.append(
            AssessmentIssue(
                code=COMPILE_ISSUE_DETACHED_GROUP_DISTANCE_HIGH,
                message="Connected compiled sections landed unusually far apart.",
                severity="warning",
                refs=tuple(
                    ref
                    for warning in detached_group_warnings
                    for ref in (warning["source_ref"], warning["target_ref"])
                ),
                detail={
                    "threshold": COMPILE_DETACHED_GROUP_DISTANCE_THRESHOLD,
                    "connections": [_detached_group_warning_json(warning) for warning in detached_group_warnings],
                },
            )
        )
    if helper_sidecar_overlaps:
        issues.append(
            AssessmentIssue(
                code=COMPILE_ISSUE_HELPER_SIDECAR_OVERLAP,
                message="Compiled helper sidecars overlap other rendered nodes.",
                severity="warning",
                refs=tuple(
                    ref
                    for left, right in helper_sidecar_overlaps
                    for ref in (left.ref, right.ref)
                    if ref is not None
                ),
                detail={
                    "count": len(helper_sidecar_overlaps),
                    "pairs": [
                        [_rect_ref_json(left), _rect_ref_json(right)]
                        for left, right in helper_sidecar_overlaps
                    ],
                },
            )
        )
    if note_section_mismatches:
        issues.append(
            AssessmentIssue(
                code=COMPILE_ISSUE_NOTE_SECTION_MISMATCH,
                message="Compiled note nodes do not match their evidenced primary section.",
                severity="warning",
                refs=tuple(mismatch["note_ref"] for mismatch in note_section_mismatches),
                detail={
                    "count": len(note_section_mismatches),
                    "mismatches": [_note_section_mismatch_json(mismatch) for mismatch in note_section_mismatches],
                },
            )
        )
    if primary_row_warnings:
        issues.append(
            AssessmentIssue(
                code=COMPILE_ISSUE_MAX_PRIMARY_ROW_COUNT_HIGH,
                message="Compiled primary rows exceed the preferred per-row node count.",
                severity="warning",
                refs=tuple(
                    ref
                    for warning in primary_row_warnings
                    for ref in warning["refs"]
                ),
                detail={
                    "threshold": COMPILE_MAX_PRIMARY_ROW_COUNT_THRESHOLD,
                    "rows": [_primary_row_warning_json(warning) for warning in primary_row_warnings],
                },
            )
        )
    if long_edge_warnings:
        issues.append(
            AssessmentIssue(
                code=COMPILE_ISSUE_LONG_EDGE_DISTANCE_HIGH,
                message="Compiled edge spans remain unusually long.",
                severity="warning",
                refs=tuple(
                    ref
                    for warning in long_edge_warnings
                    for ref in (warning["source"], warning["target"])
                ),
                detail={
                    "threshold": COMPILE_LONG_EDGE_DISTANCE_THRESHOLD,
                    "edges": [_long_edge_warning_json(warning) for warning in long_edge_warnings],
                },
            )
        )
    if backward_ratio > COMPILE_BACKWARD_EDGE_RATIO_THRESHOLD:
        issues.append(
            AssessmentIssue(
                code=COMPILE_ISSUE_BACKWARD_EDGE_RATIO_HIGH,
                message="Compiled edge direction frequently moves backward on the x axis.",
                severity="warning" if large_workflow_soft_quality_gate or node_only_small_layout else "error",
                detail={
                    "backward_edges": backward_count,
                    "measured_edges": measured_edges,
                    "ratio": round(backward_ratio, 4),
                    "threshold": COMPILE_BACKWARD_EDGE_RATIO_THRESHOLD,
                },
            )
        )
    if len(crossings) > COMPILE_CROSSING_PROXY_THRESHOLD:
        issues.append(
            AssessmentIssue(
                code=COMPILE_ISSUE_CROSSING_PROXY_HIGH,
                message="Compiled edge crossing proxy exceeded the threshold.",
                severity="warning" if large_workflow_soft_quality_gate or node_only_small_layout else "error",
                refs=tuple(ref for pair in crossings for edge in pair for ref in (edge.source, edge.target)),
                detail={
                    "count": len(crossings),
                    "threshold": COMPILE_CROSSING_PROXY_THRESHOLD,
                    "edge_pairs": [
                        [_edge_ref_json(left), _edge_ref_json(right)]
                        for left, right in crossings
                    ],
                },
            )
        )
    if gutter_violations:
        issues.append(
            AssessmentIssue(
                code=COMPILE_ISSUE_MINIMUM_GUTTER,
                message="Compiled layout violates minimum node or group gutters.",
                severity="warning" if node_only_small_layout else "error",
                refs=tuple(
                    ref
                    for violation in gutter_violations
                    for ref in violation.get("refs", ())
                    if isinstance(ref, CanonicalNodeRef)
                ),
                detail={
                    "minimum_gutter": round(minimum_gutter, 2),
                    "threshold": MIN_NODE_GUTTER,
                    "violations": [_gutter_violation_json(violation) for violation in gutter_violations],
                },
            )
        )
    if helper_distance_violations:
        issues.append(
            AssessmentIssue(
                code=COMPILE_ISSUE_HELPER_DISTANCE_HIGH,
                message="Compiled helper node is too far from its connected layout context.",
                severity="warning" if large_workflow_soft_quality_gate else "error",
                refs=tuple(violation["helper_ref"] for violation in helper_distance_violations),
                detail={
                    "max_distance": round(helper_distance_max, 2),
                    "threshold": COMPILE_HELPER_DISTANCE_THRESHOLD,
                    "violations": [_helper_distance_violation_json(violation) for violation in helper_distance_violations],
                },
            )
        )
    if idempotence_delta > COMPILE_IDEMPOTENCE_DELTA_THRESHOLD:
        issues.append(
            AssessmentIssue(
                code=COMPILE_ISSUE_IDEMPOTENCE_DELTA,
                message="Compiler-owned layout sidecar changed on recompilation.",
                severity="error",
                detail={
                    **idempotence_detail,
                    "delta": round(idempotence_delta, 2),
                    "threshold": COMPILE_IDEMPOTENCE_DELTA_THRESHOLD,
                },
            )
        )
    if structural_hash_before != structural_hash_after:
        issues.append(
            AssessmentIssue(
                code=COMPILE_ISSUE_STRUCTURAL_HASH_CHANGED,
                message="Compiler changed the runtime structural hash.",
                severity="error",
                detail={
                    "before": structural_hash_before,
                    "after": structural_hash_after,
                },
            )
        )
    return metrics, tuple(issues)


def _large_workflow_soft_quality_gate(facts: GraphInventoryFacts) -> bool:
    """Allow huge graphs to preview with visible quality warnings.

    Large public Comfy graphs often contain long-range helper/set-get edges and
    crosslinks that cannot satisfy the small-graph crossing/backward/helper
    thresholds on the first deterministic pass. Those remain warnings; hard
    geometry failures and structural changes still block candidates.
    """
    node_count = len(facts.canonical_refs)
    root_node_count = next(
        (scope.node_count for scope in facts.summary.scopes if scope.scope_path == ""),
        node_count,
    )
    nested_scope_count = sum(1 for scope in facts.summary.scopes if scope.scope_path)
    if nested_scope_count and root_node_count <= 12:
        return False
    edge_count = sum(len(topology.effective_edges) for topology in facts.scope_topologies)
    return (
        node_count >= COMPILE_HUGE_WORKFLOW_NODE_THRESHOLD
        or edge_count >= COMPILE_HUGE_WORKFLOW_EDGE_THRESHOLD
        or _facts_projection_token_estimate(facts)
        >= COMPILE_HUGE_WORKFLOW_PROJECTION_TOKEN_THRESHOLD
    )


def _node_rects(node_layouts: Sequence[CompiledNodeLayout]) -> dict[CanonicalNodeRef, _CompileRect]:
    return {
        layout.ref: _CompileRect(
            key=json.dumps(layout.ref.to_json(), ensure_ascii=True),
            ref=layout.ref,
            x=layout.x,
            y=layout.y,
            width=layout.width,
            height=layout.height,
        )
        for layout in node_layouts
    }


def _group_rects(group_layouts: Sequence[CompiledGroupLayout]) -> dict[str, _CompileRect]:
    return {
        group.id: _CompileRect(
            key=group.id,
            group=group,
            x=group.x,
            y=group.y,
            width=group.width,
            height=group.height,
        )
        for group in group_layouts
    }


def _group_metric_rects(
    group_layouts: Sequence[CompiledGroupLayout],
    node_rects: Mapping[CanonicalNodeRef, _CompileRect],
) -> dict[str, _CompileRect]:
    rects: dict[str, _CompileRect] = {}
    for group in group_layouts:
        primary_rects = tuple(node_rects[ref] for ref in group.node_refs if ref in node_rects)
        if not primary_rects:
            rects[group.id] = _CompileRect(
                key=group.id,
                group=group,
                x=group.x,
                y=group.y,
                width=group.width,
                height=group.height,
            )
            continue
        left = min(rect.x for rect in primary_rects)
        top = min(rect.y for rect in primary_rects)
        right = max(rect.right for rect in primary_rects)
        bottom = max(rect.bottom for rect in primary_rects)
        rects[group.id] = _CompileRect(
            key=group.id,
            group=group,
            x=left,
            y=top,
            width=right - left,
            height=bottom - top,
        )
    return rects


def _compiled_group_whitespace(
    group_layouts: Sequence[CompiledGroupLayout],
    node_rects: Mapping[CanonicalNodeRef, _CompileRect],
) -> tuple[float, tuple[dict[str, Any], ...]]:
    max_ratio = 0.0
    warnings: list[dict[str, Any]] = []
    for group in group_layouts:
        group_area = float(group.width * group.height)
        if group_area <= 0.0:
            continue
        filled_area = sum(
            max(0.0, node_rects[ref].width * node_rects[ref].height)
            for ref in group.node_refs
            if ref in node_rects
        )
        ratio = max(0.0, min(1.0, 1.0 - min(filled_area, group_area) / group_area))
        max_ratio = max(max_ratio, ratio)
        if ratio > COMPILE_INTERNAL_WHITESPACE_RATIO_THRESHOLD:
            warnings.append({"group": group, "ratio": ratio, "filled_area": filled_area, "group_area": group_area})
    warnings.sort(key=lambda item: (-float(item["ratio"]), str(item["group"].id)))
    return max_ratio, tuple(warnings)


def _compiled_baseline_variance(
    node_layouts: Sequence[CompiledNodeLayout],
    facts: GraphInventoryFacts,
) -> tuple[float, tuple[dict[str, Any], ...]]:
    primary_layouts_by_section = _primary_layouts_by_section(node_layouts, facts)
    max_variance = 0.0
    warnings: list[dict[str, Any]] = []
    for section_id, layouts in sorted(primary_layouts_by_section.items()):
        rows = _cluster_layout_rows(layouts)
        for row_index, row in enumerate(rows):
            if len(row) < 2:
                continue
            y_values = [float(layout.y) for layout in row]
            mean_y = sum(y_values) / len(y_values)
            variance = sum((y_value - mean_y) ** 2 for y_value in y_values) / len(y_values)
            max_variance = max(max_variance, variance)
            if variance > COMPILE_BASELINE_VARIANCE_THRESHOLD:
                warnings.append(
                    {
                        "section_id": section_id,
                        "row_index": row_index,
                        "variance": variance,
                        "refs": tuple(layout.ref for layout in row),
                        "y_values": tuple(int(layout.y) for layout in row),
                    }
                )
    warnings.sort(key=lambda item: (-float(item["variance"]), str(item["section_id"]), int(item["row_index"])))
    return max_variance, tuple(warnings)


def _compiled_detached_group_distances(
    node_layouts: Sequence[CompiledNodeLayout],
    group_layouts: Sequence[CompiledGroupLayout],
    facts: GraphInventoryFacts,
) -> tuple[float, tuple[dict[str, Any], ...]]:
    section_rects = _section_metric_rects(node_layouts, group_layouts)
    section_by_ref = {layout.ref: layout.section_id for layout in node_layouts}
    max_distance = 0.0
    warnings: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for edge in _compiled_effective_edges(facts):
        source_section = section_by_ref.get(edge.source)
        target_section = section_by_ref.get(edge.target)
        if source_section is None or target_section is None or source_section == target_section:
            continue
        pair = tuple(sorted((source_section, target_section)))
        if pair in seen:
            continue
        seen.add(pair)
        source_rect = section_rects.get(source_section)
        target_rect = section_rects.get(target_section)
        if source_rect is None or target_rect is None:
            continue
        distance = _rect_gap(source_rect, target_rect)
        max_distance = max(max_distance, distance)
        if distance > COMPILE_DETACHED_GROUP_DISTANCE_THRESHOLD:
            warnings.append(
                {
                    "source_section": source_section,
                    "target_section": target_section,
                    "source_ref": edge.source,
                    "target_ref": edge.target,
                    "distance": distance,
                }
            )
    warnings.sort(key=lambda item: (-float(item["distance"]), str(item["source_section"]), str(item["target_section"])))
    return max_distance, tuple(warnings)


def _compiled_helper_sidecar_overlap_pairs(
    node_rects: Mapping[CanonicalNodeRef, _CompileRect],
    facts: GraphInventoryFacts,
) -> tuple[tuple[_CompileRect, _CompileRect], ...]:
    sidecar_refs = {
        fact.ref
        for fact in facts.canonical_refs
        if getattr(fact, "layout_behavior", None) == LAYOUT_BEHAVIOR_SIDECAR
    }
    pairs: list[tuple[_CompileRect, _CompileRect]] = []
    for left, right in _rect_pairs(tuple(node_rects.values())):
        left_is_sidecar = left.ref in sidecar_refs if left.ref is not None else False
        right_is_sidecar = right.ref in sidecar_refs if right.ref is not None else False
        if not (left_is_sidecar or right_is_sidecar):
            continue
        if _rects_overlap(left, right):
            pairs.append((left, right))
    return tuple(sorted(pairs, key=lambda pair: (pair[0].key, pair[1].key)))


def _compiled_note_section_mismatches(
    node_layouts: Sequence[CompiledNodeLayout],
    facts: GraphInventoryFacts,
) -> tuple[dict[str, Any], ...]:
    primary_owned = {
        layout.ref: layout.section_id
        for layout in node_layouts
        if _layout_behavior_for_ref(layout.ref, facts) in {LAYOUT_BEHAVIOR_PRIMARY, LAYOUT_BEHAVIOR_WALL}
    }
    furniture_by_ref = {fact.ref: fact for fact in facts.node_furniture}
    incident_adjacency = _incident_adjacency(facts)
    mismatches: list[dict[str, Any]] = []
    for layout in sorted(node_layouts, key=lambda item: _ref_sort_key(item.ref)):
        if _layout_behavior_for_ref(layout.ref, facts) != LAYOUT_BEHAVIOR_NOTE:
            continue
        expected_ref = _nearest_primary_attachment(
            layout.ref,
            primary_owned=primary_owned,
            candidate_refs=incident_adjacency.get(layout.ref, ()),
            furniture_by_ref=furniture_by_ref,
        )
        reason = "connected_primary"
        if expected_ref is None:
            expected_ref = _annotated_primary_attachment(
                layout.ref,
                primary_owned=primary_owned,
                furniture_by_ref=furniture_by_ref,
            )
            reason = "annotated_primary"
        if expected_ref is None:
            continue
        expected_section = primary_owned.get(expected_ref)
        if expected_section is None or expected_section == layout.section_id:
            continue
        mismatches.append(
            {
                "note_ref": layout.ref,
                "actual_section": layout.section_id,
                "expected_section": expected_section,
                "expected_ref": expected_ref,
                "reason": reason,
            }
        )
    return tuple(mismatches)


def _compiled_primary_row_density(
    node_layouts: Sequence[CompiledNodeLayout],
    facts: GraphInventoryFacts,
) -> tuple[int, tuple[dict[str, Any], ...]]:
    primary_layouts_by_section = _primary_layouts_by_section(node_layouts, facts)
    max_primary_nodes = 0
    warnings: list[dict[str, Any]] = []
    for section_id, layouts in sorted(primary_layouts_by_section.items()):
        rows = _cluster_layout_rows(layouts)
        for row_index, row in enumerate(rows):
            count = len(row)
            max_primary_nodes = max(max_primary_nodes, count)
            if count > COMPILE_MAX_PRIMARY_ROW_COUNT_THRESHOLD:
                warnings.append(
                    {
                        "section_id": section_id,
                        "row_index": row_index,
                        "count": count,
                        "refs": tuple(layout.ref for layout in row),
                    }
                )
    warnings.sort(key=lambda item: (-int(item["count"]), str(item["section_id"]), int(item["row_index"])))
    return max_primary_nodes, tuple(warnings)


def _compiled_long_edge_distances(
    facts: GraphInventoryFacts,
    rects: Mapping[CanonicalNodeRef, _CompileRect],
) -> tuple[float, tuple[dict[str, Any], ...]]:
    max_distance = 0.0
    warnings: list[dict[str, Any]] = []
    for edge in _compiled_effective_edges(facts):
        source = rects.get(edge.source)
        target = rects.get(edge.target)
        if source is None or target is None:
            continue
        distance = hypot(source.center[0] - target.center[0], source.center[1] - target.center[1])
        max_distance = max(max_distance, distance)
        if distance > COMPILE_LONG_EDGE_DISTANCE_THRESHOLD:
            warnings.append({"source": edge.source, "target": edge.target, "distance": distance})
    warnings.sort(key=lambda item: (-float(item["distance"]), _ref_sort_key(item["source"]), _ref_sort_key(item["target"])))
    return max_distance, tuple(warnings)


def _section_metric_rects(
    node_layouts: Sequence[CompiledNodeLayout],
    group_layouts: Sequence[CompiledGroupLayout],
) -> dict[str, _CompileRect]:
    rects: dict[str, _CompileRect] = {}
    for group in group_layouts:
        rects.setdefault(
            group.id,
            _CompileRect(
                key=f"section:{group.id}",
                group=group,
                x=group.x,
                y=group.y,
                width=group.width,
                height=group.height,
            ),
        )
    layouts_by_section: dict[str, list[CompiledNodeLayout]] = {}
    for layout in node_layouts:
        layouts_by_section.setdefault(layout.section_id, []).append(layout)
    for section_id, layouts in layouts_by_section.items():
        if section_id in rects:
            continue
        left = min(layout.x for layout in layouts)
        top = min(layout.y for layout in layouts)
        right = max(layout.x + layout.width for layout in layouts)
        bottom = max(layout.y + layout.height for layout in layouts)
        rects[section_id] = _CompileRect(
            key=f"section:{section_id}",
            x=left,
            y=top,
            width=right - left,
            height=bottom - top,
        )
    return rects


def _primary_layouts_by_section(
    node_layouts: Sequence[CompiledNodeLayout],
    facts: GraphInventoryFacts,
) -> dict[str, tuple[CompiledNodeLayout, ...]]:
    layouts_by_section: dict[str, list[CompiledNodeLayout]] = {}
    for layout in node_layouts:
        if _layout_behavior_for_ref(layout.ref, facts) != LAYOUT_BEHAVIOR_PRIMARY:
            continue
        layouts_by_section.setdefault(layout.section_id, []).append(layout)
    return {
        section_id: tuple(sorted(layouts, key=lambda item: (item.y, item.x, _ref_sort_key(item.ref))))
        for section_id, layouts in layouts_by_section.items()
    }


def _cluster_layout_rows(layouts: Sequence[CompiledNodeLayout]) -> tuple[tuple[CompiledNodeLayout, ...], ...]:
    rows: list[list[CompiledNodeLayout]] = []
    sorted_layouts = sorted(layouts, key=lambda item: (item.y, item.x, _ref_sort_key(item.ref)))
    for layout in sorted_layouts:
        placed = False
        for row in rows:
            row_top = min(item.y for item in row)
            row_bottom = max(item.y + item.height for item in row)
            if layout.y <= row_bottom and layout.y + layout.height >= row_top - MIN_NODE_GUTTER // 2:
                row.append(layout)
                placed = True
                break
        if not placed:
            rows.append([layout])
    return tuple(
        tuple(sorted(row, key=lambda item: (item.x, item.y, _ref_sort_key(item.ref))))
        for row in rows
    )


def _incident_adjacency(facts: GraphInventoryFacts) -> dict[CanonicalNodeRef, tuple[CanonicalNodeRef, ...]]:
    adjacency: dict[CanonicalNodeRef, set[CanonicalNodeRef]] = {}
    for edge in _compiled_effective_edges(facts):
        adjacency.setdefault(edge.source, set()).add(edge.target)
        adjacency.setdefault(edge.target, set()).add(edge.source)
    return {
        ref: tuple(sorted(neighbors, key=_ref_sort_key))
        for ref, neighbors in adjacency.items()
    }


def _rect_overlap_pairs(
    rects: Mapping[Any, _CompileRect],
) -> tuple[tuple[_CompileRect, _CompileRect], ...]:
    ordered = sorted(rects.values(), key=lambda rect: rect.key)
    pairs: list[tuple[_CompileRect, _CompileRect]] = []
    for index, left in enumerate(ordered):
        for right in ordered[index + 1:]:
            if _rects_overlap(left, right):
                pairs.append((left, right))
    return tuple(pairs)


def _unintended_group_overlap_pairs(
    rects: Mapping[str, _CompileRect],
) -> tuple[tuple[_CompileRect, _CompileRect], ...]:
    pairs: list[tuple[_CompileRect, _CompileRect]] = []
    for left, right in _rect_overlap_pairs(rects):
        if _rect_contains(left, right) or _rect_contains(right, left):
            continue
        pairs.append((left, right))
    return tuple(pairs)


def _rects_overlap(left: _CompileRect, right: _CompileRect) -> bool:
    return (
        left.x < right.right
        and left.right > right.x
        and left.y < right.bottom
        and left.bottom > right.y
    )


def _rect_contains(container: _CompileRect, child: _CompileRect) -> bool:
    return (
        child.x >= container.x
        and child.y >= container.y
        and child.right <= container.right
        and child.bottom <= container.bottom
    )


def _rect_gap(left: _CompileRect, right: _CompileRect) -> float:
    dx = max(left.x - right.right, right.x - left.right, 0.0)
    dy = max(left.y - right.bottom, right.y - left.bottom, 0.0)
    return hypot(dx, dy)


def _compiled_backward_edge_counts(
    facts: GraphInventoryFacts,
    rects: Mapping[CanonicalNodeRef, _CompileRect],
) -> tuple[int, int]:
    backward = 0
    measured = 0
    for edge in _compiled_effective_edges(facts):
        source = rects.get(edge.source)
        target = rects.get(edge.target)
        if source is None or target is None:
            continue
        measured += 1
        if target.center[0] < source.center[0] - COMPILE_BACKWARD_EDGE_X_TOLERANCE:
            backward += 1
    return backward, measured


def _compiled_crossing_proxy_pairs(
    facts: GraphInventoryFacts,
    rects: Mapping[CanonicalNodeRef, _CompileRect],
) -> tuple[tuple[Any, Any], ...]:
    edges = [
        edge
        for edge in _compiled_effective_edges(facts)
        if edge.source in rects and edge.target in rects and edge.source != edge.target
    ]
    pairs: list[tuple[Any, Any]] = []
    for index, left in enumerate(edges):
        left_refs = {left.source, left.target}
        for right in edges[index + 1:]:
            if left_refs & {right.source, right.target}:
                continue
            if _segments_cross(
                rects[left.source].center,
                rects[left.target].center,
                rects[right.source].center,
                rects[right.target].center,
            ):
                pairs.append((left, right))
    return tuple(sorted(pairs, key=lambda pair: (_edge_sort_key(pair[0]), _edge_sort_key(pair[1]))))


def _segments_cross(
    a: tuple[float, float],
    b: tuple[float, float],
    c: tuple[float, float],
    d: tuple[float, float],
) -> bool:
    def orientation(p: tuple[float, float], q: tuple[float, float], r: tuple[float, float]) -> float:
        return (q[0] - p[0]) * (r[1] - p[1]) - (q[1] - p[1]) * (r[0] - p[0])

    first = orientation(a, b, c)
    second = orientation(a, b, d)
    third = orientation(c, d, a)
    fourth = orientation(c, d, b)
    return (
        (first > 0 and second < 0 or first < 0 and second > 0)
        and (third > 0 and fourth < 0 or third < 0 and fourth > 0)
    )


def _compiled_minimum_gutter(
    primary_rects: Mapping[CanonicalNodeRef, _CompileRect],
    group_rects: Mapping[str, _CompileRect],
) -> tuple[float, tuple[dict[str, Any], ...]]:
    minimum = float(MIN_NODE_GUTTER)
    measured = False
    violations: list[dict[str, Any]] = []

    for left, right in _rect_pairs(primary_rects.values()):
        gap = _rect_gap(left, right)
        minimum = min(minimum, gap)
        measured = True
        if gap < MIN_NODE_GUTTER:
            violations.append(
                {
                    "kind": "node",
                    "gap": gap,
                    "threshold": MIN_NODE_GUTTER,
                    "left": left,
                    "right": right,
                    "refs": tuple(ref for ref in (left.ref, right.ref) if ref is not None),
                }
            )
    for left, right in _rect_pairs(group_rects.values()):
        if _rect_contains(left, right) or _rect_contains(right, left):
            continue
        gap = _rect_gap(left, right)
        minimum = min(minimum, gap)
        measured = True
        if gap < MIN_GROUP_GUTTER:
            violations.append(
                {
                    "kind": "group",
                    "gap": gap,
                    "threshold": MIN_GROUP_GUTTER,
                    "left": left,
                    "right": right,
                    "refs": tuple(
                        ref
                        for group in (left.group, right.group)
                        if group is not None
                        for ref in group.node_refs
                    ),
                }
            )
    return (minimum if measured else float(MIN_NODE_GUTTER)), tuple(
        sorted(violations, key=lambda item: (str(item["kind"]), float(item["gap"]), item["left"].key, item["right"].key))
    )


def _rect_pairs(rects: Sequence[_CompileRect] | Any) -> tuple[tuple[_CompileRect, _CompileRect], ...]:
    ordered = sorted(tuple(rects), key=lambda rect: rect.key)
    pairs: list[tuple[_CompileRect, _CompileRect]] = []
    for index, left in enumerate(ordered):
        for right in ordered[index + 1:]:
            pairs.append((left, right))
    return tuple(pairs)


def _compiled_helper_distance_violations(
    facts: GraphInventoryFacts,
    rects: Mapping[CanonicalNodeRef, _CompileRect],
    helper_refs: set[CanonicalNodeRef],
) -> tuple[float, tuple[dict[str, Any], ...]]:
    max_distance = 0.0
    violations: list[dict[str, Any]] = []
    for helper_ref in sorted(helper_refs, key=_ref_sort_key):
        helper_rect = rects.get(helper_ref)
        if helper_rect is None:
            continue
        neighbor_refs = _compiled_helper_neighbor_refs(helper_ref, facts, helper_refs)
        neighbor_rects = [rects[ref] for ref in neighbor_refs if ref in rects]
        if not neighbor_rects:
            continue
        distance = min(hypot(helper_rect.center[0] - rect.center[0], helper_rect.center[1] - rect.center[1]) for rect in neighbor_rects)
        if len(neighbor_rects) >= 2:
            distance = min(distance, _helper_bridge_distance(helper_rect, neighbor_rects))
        max_distance = max(max_distance, distance)
        if distance > COMPILE_HELPER_DISTANCE_THRESHOLD:
            violations.append(
                {
                    "helper_ref": helper_ref,
                    "distance": distance,
                    "neighbor_refs": tuple(rect.ref for rect in neighbor_rects if rect.ref is not None),
                }
            )
    return max_distance, tuple(violations)


def _helper_bridge_distance(helper_rect: _CompileRect, neighbor_rects: Sequence[_CompileRect]) -> float:
    best = float("inf")
    helper = helper_rect.center
    for index, left in enumerate(neighbor_rects):
        for right in neighbor_rects[index + 1:]:
            best = min(best, _point_to_segment_distance(helper, left.center, right.center))
    return best


def _point_to_segment_distance(
    point: tuple[float, float],
    start: tuple[float, float],
    end: tuple[float, float],
) -> float:
    px, py = point
    sx, sy = start
    ex, ey = end
    dx = ex - sx
    dy = ey - sy
    length_sq = dx * dx + dy * dy
    if length_sq <= 0:
        return hypot(px - sx, py - sy)
    t = max(0.0, min(1.0, ((px - sx) * dx + (py - sy) * dy) / length_sq))
    closest = (sx + t * dx, sy + t * dy)
    return hypot(px - closest[0], py - closest[1])


def _compiled_helper_neighbor_refs(
    helper_ref: CanonicalNodeRef,
    facts: GraphInventoryFacts,
    helper_refs: set[CanonicalNodeRef],
) -> tuple[CanonicalNodeRef, ...]:
    refs: set[CanonicalNodeRef] = set()
    for topology in facts.scope_topologies:
        for edge in topology.raw_edges:
            if edge.source == helper_ref and edge.target not in helper_refs:
                refs.add(edge.target)
            if edge.target == helper_ref and edge.source not in helper_refs:
                refs.add(edge.source)
    return tuple(sorted(refs, key=_ref_sort_key))


def _compiled_idempotence_delta(
    facts: GraphInventoryFacts,
    candidate_patch: LayoutCandidatePatch,
) -> tuple[float, dict[str, Any]]:
    sidecar = facts.sidecar_envelope
    if sidecar.get("schema_hash") != _candidate_schema_hash() or sidecar.get("reorganise_compiler") is not True:
        return 0.0, {"measured": False, "reason": "input sidecar was not marked compiler-owned"}
    patch = candidate_patch.to_json()
    max_delta = 0.0
    changed: list[dict[str, Any]] = []
    for key, compiled in sorted(patch.get("entries", {}).items()):
        current = sidecar.get("entries", {}).get(key) if isinstance(sidecar.get("entries"), Mapping) else None
        delta = _entry_layout_delta(current, compiled)
        if delta > 0:
            changed.append({"kind": "entry", "key": key, "delta": round(delta, 2)})
        max_delta = max(max_delta, delta)
    current_groups = sidecar.get("groups") if isinstance(sidecar.get("groups"), Sequence) and not isinstance(sidecar.get("groups"), (str, bytes)) else ()
    current_groups_by_key = {
        _candidate_group_match_key(group): group
        for group in current_groups
        if isinstance(group, Mapping)
    }
    for group in patch.get("groups", ()):
        if not isinstance(group, Mapping):
            continue
        group_key = _candidate_group_match_key(group)
        delta = _group_layout_delta(current_groups_by_key.get(group_key), group)
        if delta > 0:
            changed.append({"kind": "group", "key": group_key, "delta": round(delta, 2)})
        max_delta = max(max_delta, delta)
    return max_delta, {"measured": True, "changed": changed[:8], "changed_count": len(changed)}


def _candidate_group_match_key(group: Mapping[str, Any]) -> str:
    if group.get("id") is not None:
        return f"id:{group.get('id')}"
    nodes = door_get_nodes(group) if isinstance(door_get_nodes(group), Sequence) and not isinstance(door_get_nodes(group), (str, bytes)) else ()
    return json.dumps(
        {
            "title": group.get("title"),
            "nodes": list(nodes),
        },
        sort_keys=True,
        ensure_ascii=True,
    )


def _entry_layout_delta(current: Any, compiled: Any) -> float:
    if not isinstance(current, Mapping) or not isinstance(compiled, Mapping):
        return _IDEMPOTENCE_DRIFT_PENALTY
    geometric = max(
        _sequence_delta(current.get("pos"), compiled.get("pos")),
        _sequence_delta(current.get("size"), compiled.get("size")),
    )
    return max(
        geometric,
        _scalar_attribute_delta(current, compiled, _ENTRY_DRIFT_SCALAR_KEYS),
        _scalar_attribute_delta(current, compiled, _ENTRY_DRIFT_MAPPING_KEYS),
    )


def _group_layout_delta(current: Any, compiled: Any) -> float:
    if not isinstance(current, Mapping) or not isinstance(compiled, Mapping):
        return _IDEMPOTENCE_DRIFT_PENALTY
    return max(
        _sequence_delta(current.get("bounding"), compiled.get("bounding")),
        _scalar_attribute_delta(current, compiled, _GROUP_DRIFT_SCALAR_KEYS),
    )


def _scalar_attribute_delta(current: Any, compiled: Any, keys: Sequence[str]) -> float:
    """Return the fixed drift penalty when any scalar attribute changes.

    Fixed-point drift detection must be deterministic across snapped positions,
    groups, colors, sizes, and flags.  ``None`` and missing keys compare equal so
    that a sidecar written before an attribute existed never spuriously flags
    drift; only an actual value change between compiles is treated as drift.
    """
    for key in keys:
        left = current.get(key) if isinstance(current, Mapping) else None
        right = compiled.get(key) if isinstance(compiled, Mapping) else None
        if _freeze_jsonish(left) != _freeze_jsonish(right):
            return _IDEMPOTENCE_DRIFT_PENALTY
    return 0.0


def _sequence_delta(left: Any, right: Any) -> float:
    if not isinstance(left, Sequence) or isinstance(left, (str, bytes)):
        return float(COMPILE_IDEMPOTENCE_DELTA_THRESHOLD + 1)
    if not isinstance(right, Sequence) or isinstance(right, (str, bytes)):
        return float(COMPILE_IDEMPOTENCE_DELTA_THRESHOLD + 1)
    if len(left) != len(right):
        return float(COMPILE_IDEMPOTENCE_DELTA_THRESHOLD + 1)
    deltas: list[float] = []
    for left_item, right_item in zip(left, right):
        left_number = _number_float(left_item)
        right_number = _number_float(right_item)
        if left_number is None or right_number is None:
            return float(COMPILE_IDEMPOTENCE_DELTA_THRESHOLD + 1)
        deltas.append(abs(left_number - right_number))
    return max(deltas, default=0.0)


def _compiled_effective_edges(facts: GraphInventoryFacts) -> tuple[Any, ...]:
    edges = [
        edge
        for topology in facts.scope_topologies
        for edge in topology.effective_edges
    ]
    return tuple(sorted(edges, key=_edge_sort_key))


def _edge_sort_key(edge: Any) -> tuple[Any, ...]:
    return (
        getattr(edge, "scope_path", ""),
        *_ref_sort_key(edge.source),
        *_ref_sort_key(edge.target),
        str(getattr(edge, "source_slot", "")),
        str(getattr(edge, "target_slot", "")),
        str(getattr(edge, "link_id", "")),
    )


def _rect_ref_json(rect: _CompileRect) -> Any:
    return rect.ref.to_json() if rect.ref is not None else rect.key


def _rect_group_json(rect: _CompileRect) -> dict[str, Any]:
    group = rect.group
    if group is None:
        return {"id": rect.key}
    return {
        "id": group.id,
        "title": group.title,
        "scope_path": group.scope_path,
        "bounding": [group.x, group.y, group.width, group.height],
    }


def _edge_ref_json(edge: Any) -> dict[str, Any]:
    return {
        "source": edge.source.to_json(),
        "target": edge.target.to_json(),
        "scope_path": getattr(edge, "scope_path", ""),
    }


def _gutter_violation_json(violation: Mapping[str, Any]) -> dict[str, Any]:
    left = violation["left"]
    right = violation["right"]
    return {
        "kind": violation["kind"],
        "gap": round(float(violation["gap"]), 2),
        "threshold": violation["threshold"],
        "left": _rect_ref_json(left) if left.ref is not None else _rect_group_json(left),
        "right": _rect_ref_json(right) if right.ref is not None else _rect_group_json(right),
    }


def _group_whitespace_warning_json(warning: Mapping[str, Any]) -> dict[str, Any]:
    group = warning["group"]
    return {
        "id": group.id,
        "title": group.title,
        "ratio": round(float(warning["ratio"]), 4),
        "filled_area": round(float(warning["filled_area"]), 2),
        "group_area": round(float(warning["group_area"]), 2),
    }


def _baseline_variance_warning_json(warning: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "section_id": warning["section_id"],
        "row_index": warning["row_index"],
        "variance": round(float(warning["variance"]), 2),
        "refs": [ref.to_json() for ref in warning["refs"]],
        "y_values": list(warning["y_values"]),
    }


def _detached_group_warning_json(warning: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "source_section": warning["source_section"],
        "target_section": warning["target_section"],
        "distance": round(float(warning["distance"]), 2),
        "source_ref": warning["source_ref"].to_json(),
        "target_ref": warning["target_ref"].to_json(),
    }


def _note_section_mismatch_json(mismatch: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "note_ref": mismatch["note_ref"].to_json(),
        "actual_section": mismatch["actual_section"],
        "expected_section": mismatch["expected_section"],
        "expected_ref": mismatch["expected_ref"].to_json(),
        "reason": mismatch["reason"],
    }


def _primary_row_warning_json(warning: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "section_id": warning["section_id"],
        "row_index": warning["row_index"],
        "count": warning["count"],
        "refs": [ref.to_json() for ref in warning["refs"]],
    }


def _long_edge_warning_json(warning: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "source": warning["source"].to_json(),
        "target": warning["target"].to_json(),
        "distance": round(float(warning["distance"]), 2),
    }


def _helper_distance_violation_json(violation: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "helper_ref": violation["helper_ref"].to_json(),
        "distance": round(float(violation["distance"]), 2),
        "threshold": COMPILE_HELPER_DISTANCE_THRESHOLD,
        "neighbor_refs": [ref.to_json() for ref in violation["neighbor_refs"]],
    }


def _apply_floating_helper_positions(
    plan: LayoutPlanV1,
    node_layouts: Sequence[CompiledNodeLayout],
    spacing: _Spacing,
) -> tuple[CompiledNodeLayout, ...]:
    layout_by_ref = {layout.ref: layout for layout in node_layouts}
    placement_by_helper = {
        placement.helper: placement
        for placement in plan.helper_placements
    }
    adjusted: list[CompiledNodeLayout] = []
    for layout in node_layouts:
        if layout.section_id != "__helpers__":
            adjusted.append(layout)
            continue
        placement = placement_by_helper.get(layout.ref)
        if placement is None:
            adjusted.append(layout)
            continue
        pos = _floating_helper_pos(placement, layout, layout_by_ref, spacing)
        if pos is None:
            adjusted.append(layout)
            continue
        adjusted.append(
            CompiledNodeLayout(
                ref=layout.ref,
                section_id=layout.section_id,
                role_hint=layout.role_hint,
                x=pos[0],
                y=pos[1],
                width=layout.width,
                height=layout.height,
                pinned=layout.pinned,
                auto_collapsed=layout.auto_collapsed,
            )
        )
    return tuple(adjusted)


def _floating_helper_pos(
    placement: Any,
    helper: CompiledNodeLayout,
    layout_by_ref: Mapping[CanonicalNodeRef, CompiledNodeLayout],
    spacing: _Spacing,
) -> tuple[int, int] | None:
    anchor_gap = max(24, spacing.node_gap_y // 2)
    if placement.kind == HELPER_PLACEMENT_EDGE_PATH:
        source = layout_by_ref.get(placement.source)
        destination = layout_by_ref.get(placement.destination)
        if source is None or destination is None:
            return None
        source_center = _layout_center(source)
        target_center = _layout_center(destination)
        return (
            round((source_center[0] + target_center[0] - helper.width) / 2),
            round((source_center[1] + target_center[1] - helper.height) / 2),
        )
    target = layout_by_ref.get(placement.target)
    if target is None:
        return None
    y = target.y + max(0, (target.height - helper.height) // 2)
    if placement.kind == HELPER_PLACEMENT_NEAR_PRODUCER:
        return (target.x + target.width + anchor_gap, y)
    if placement.kind == HELPER_PLACEMENT_NEAR_CONSUMER:
        return (target.x - helper.width - anchor_gap, y)
    return None


def _layout_center(layout: CompiledNodeLayout) -> tuple[float, float]:
    return (layout.x + layout.width / 2, layout.y + layout.height / 2)


def _resolve_node_collisions(
    node_layouts: Sequence[CompiledNodeLayout],
    facts: GraphInventoryFacts,
    spacing: _Spacing,
) -> tuple[CompiledNodeLayout, ...]:
    helper_refs = {fact.ref for fact in facts.canonical_refs if fact.is_helper}
    rounded = tuple(_rounded_node_layout(layout) for layout in node_layouts)
    pinned = tuple(sorted((layout for layout in rounded if layout.pinned), key=_node_collision_sort_key))
    movable = tuple(sorted((layout for layout in rounded if not layout.pinned), key=_node_collision_sort_key))
    resolved: dict[CanonicalNodeRef, CompiledNodeLayout] = {layout.ref: layout for layout in pinned}
    obstacles = list(pinned)

    for layout in movable:
        if layout.ref in helper_refs:
            candidate = _nudge_layout_clear_of_obstacles(
                layout,
                obstacles,
                same_section_gutter=MIN_NODE_GUTTER,
                cross_section_gutter=MIN_NODE_GUTTER,
            )
        else:
            primary_obstacles = [obstacle for obstacle in obstacles if obstacle.ref not in helper_refs]
            candidate = _nudge_layout_clear_of_obstacles(
                layout,
                primary_obstacles,
                same_section_gutter=MIN_NODE_GUTTER,
                cross_section_gutter=_cross_section_node_gutter(spacing),
            )
        resolved[candidate.ref] = candidate
        obstacles.append(candidate)

    return tuple(resolved[layout.ref] for layout in rounded)


def _rounded_node_layout(layout: CompiledNodeLayout) -> CompiledNodeLayout:
    x, y = snap_pos((layout.x, layout.y))
    width, height = snap_size((layout.width, layout.height))
    return CompiledNodeLayout(
        ref=layout.ref,
        section_id=layout.section_id,
        role_hint=layout.role_hint,
        x=x,
        y=y,
        width=max(1, width),
        height=max(1, height),
        pinned=layout.pinned,
        auto_collapsed=layout.auto_collapsed,
    )


def _nudge_layout_clear_of_obstacles(
    layout: CompiledNodeLayout,
    obstacles: Sequence[CompiledNodeLayout],
    *,
    same_section_gutter: int,
    cross_section_gutter: int,
) -> CompiledNodeLayout:
    candidate = layout
    for _pass in range(len(obstacles) + 1):
        colliding = [
            obstacle
            for obstacle in obstacles
            if _layouts_violate_gutter(
                candidate,
                obstacle,
                same_section_gutter
                if candidate.section_id == obstacle.section_id
                else cross_section_gutter,
            )
        ]
        if not colliding:
            return candidate
        next_y = max(
            obstacle.y
            + obstacle.height
            + (
                same_section_gutter
                if candidate.section_id == obstacle.section_id
                else cross_section_gutter
            )
            for obstacle in colliding
        )
        if next_y <= candidate.y:
            next_y = candidate.y + same_section_gutter
        candidate = CompiledNodeLayout(
            ref=candidate.ref,
            section_id=candidate.section_id,
            role_hint=candidate.role_hint,
            x=candidate.x,
            y=next_y,
            width=candidate.width,
            height=candidate.height,
            pinned=candidate.pinned,
            auto_collapsed=candidate.auto_collapsed,
        )
    return candidate


def _layouts_violate_gutter(
    left: CompiledNodeLayout,
    right: CompiledNodeLayout,
    gutter: int,
) -> bool:
    return not (
        left.x + left.width + gutter <= right.x
        or right.x + right.width + gutter <= left.x
        or left.y + left.height + gutter <= right.y
        or right.y + right.height + gutter <= left.y
    )


def _cross_section_node_gutter(spacing: _Spacing) -> int:
    return max(
        MIN_NODE_GUTTER,
        MIN_GROUP_GUTTER + DEFAULT_GROUP_HEADER_HEIGHT + spacing.group_padding * 2,
    )


def _node_collision_sort_key(layout: CompiledNodeLayout) -> tuple[Any, ...]:
    return (
        0 if layout.pinned else 1,
        layout.y,
        layout.x,
        layout.section_id,
        *_ref_sort_key(layout.ref),
    )


def _compiled_group_layouts(
    sections: Sequence[_CompileSection],
    node_layouts: Sequence[CompiledNodeLayout],
    facts: GraphInventoryFacts,
    spacing: _Spacing,
    options: LayoutCompileOptions,
) -> tuple[CompiledGroupLayout, ...]:
    layouts_by_section: dict[str, list[CompiledNodeLayout]] = {}
    for layout in node_layouts:
        layouts_by_section.setdefault(layout.section_id, []).append(layout)
    templates = {
        section.id: _local_section_layout(
            section,
            facts,
            {fact.ref: fact for fact in facts.node_furniture},
            options,
            spacing,
            None,
        ).template
        for section in sections
        if section.node_refs
    }
    groups_by_id: dict[str, CompiledGroupLayout] = {}
    helper_refs = {fact.ref for fact in facts.canonical_refs if fact.is_helper}
    for section in sections:
        section_nodes = tuple(layouts_by_section.get(section.id, ()))
        if not section_nodes or section.id == "__helpers__":
            continue
        primary_nodes = tuple(layout for layout in section_nodes if layout.ref not in helper_refs)
        group_node_refs = (
            tuple(layout.ref for layout in primary_nodes)
            if primary_nodes
            else tuple(layout.ref for layout in section_nodes)
        )
        groups_by_id[section.id] = _group_for_section(
            section,
            section_nodes,
            spacing,
            templates.get(section.id, "single"),
            group_node_refs=group_node_refs,
        )

    plan_sections = {section.id: section for section in sections}
    pending = True
    while pending:
        pending = False
        for section in sorted(sections, key=lambda item: _section_depth(item, plan_sections), reverse=True):
            children = tuple(
                groups_by_id[child.id]
                for child in sections
                if child.id in groups_by_id and _plan_parent_id(child, plan_sections) == section.id
            )
            if not children:
                continue
            current = groups_by_id.get(section.id)
            if current is None:
                groups_by_id[section.id] = _group_for_container(section, children, spacing)
                pending = True
            else:
                expanded = _expand_group_for_children(current, children, spacing)
                if expanded != current:
                    groups_by_id[section.id] = expanded
                    pending = True

    return tuple(
        sorted(
            groups_by_id.values(),
            key=lambda layout: (-_scope_depth(layout.scope_path), layout.scope_path, layout.id),
        )
    )


def _resolve_group_collisions(
    sections: Sequence[_CompileSection],
    node_layouts: Sequence[CompiledNodeLayout],
    group_layouts: Sequence[CompiledGroupLayout],
    facts: GraphInventoryFacts,
    spacing: _Spacing,
    options: LayoutCompileOptions,
) -> tuple[tuple[CompiledNodeLayout, ...], tuple[CompiledGroupLayout, ...]]:
    """Move whole huge-wall sections down until generated group boxes clear.

    The huge-wall packer preserves compact visual columns, so independent
    semantic buckets can legitimately have overlapping vertical spans after
    node-level collision resolution. Since groups are derived from section
    boxes, translate the later section as a unit and recompute its group.
    """
    if not group_layouts:
        return tuple(node_layouts), tuple(group_layouts)

    section_by_id = {section.id: section for section in sections}
    primary_group_by_section = {
        group.id: group
        for group in group_layouts
        if group.id in section_by_id
    }
    if len(primary_group_by_section) < 2:
        return tuple(node_layouts), tuple(group_layouts)

    shift_by_section: dict[str, int] = {}
    placed: list[CompiledGroupLayout] = []
    for group in sorted(
        primary_group_by_section.values(),
        key=lambda item: (item.y, item.x, item.id),
    ):
        shift = shift_by_section.get(group.id, 0)
        candidate = _shift_group_layout(group, shift)
        for _pass in range(len(placed) + 1):
            colliding = [
                obstacle
                for obstacle in placed
                if _group_layouts_violate_gutter(candidate, obstacle, MIN_GROUP_GUTTER)
            ]
            if not colliding:
                break
            next_y = max(obstacle.y + obstacle.height + MIN_GROUP_GUTTER for obstacle in colliding)
            delta = max(0, next_y - candidate.y)
            shift += delta
            candidate = _shift_group_layout(group, shift)
        shift_by_section[group.id] = shift
        placed.append(candidate)

    if not any(shift_by_section.values()):
        return tuple(node_layouts), tuple(group_layouts)

    shifted_nodes = tuple(
        _shift_node_layout(layout, shift_by_section.get(layout.section_id, 0))
        for layout in node_layouts
    )
    shifted_groups = _compiled_group_layouts(sections, shifted_nodes, facts, spacing, options)
    return shifted_nodes, shifted_groups


def _shift_node_layout(layout: CompiledNodeLayout, dy: int) -> CompiledNodeLayout:
    if dy == 0:
        return layout
    return CompiledNodeLayout(
        ref=layout.ref,
        section_id=layout.section_id,
        role_hint=layout.role_hint,
        x=layout.x,
        y=layout.y + dy,
        width=layout.width,
        height=layout.height,
        pinned=layout.pinned,
        auto_collapsed=layout.auto_collapsed,
    )


def _shift_group_layout(group: CompiledGroupLayout, dy: int) -> CompiledGroupLayout:
    if dy == 0:
        return group
    return CompiledGroupLayout(
        id=group.id,
        scope_path=group.scope_path,
        title=group.title,
        kind=group.kind,
        role_hint=group.role_hint,
        node_refs=group.node_refs,
        x=group.x,
        y=group.y + dy,
        width=group.width,
        height=group.height,
        color=group.color,
        template=group.template,
    )


def _group_layouts_violate_gutter(
    left: CompiledGroupLayout,
    right: CompiledGroupLayout,
    gutter: int,
) -> bool:
    return not (
        left.x + left.width + gutter <= right.x
        or right.x + right.width + gutter <= left.x
        or left.y + left.height + gutter <= right.y
        or right.y + right.height + gutter <= left.y
    )


def _group_for_section(
    section: _CompileSection,
    nodes: Sequence[CompiledNodeLayout],
    spacing: _Spacing,
    template: SectionTemplate,
    *,
    group_node_refs: Sequence[CanonicalNodeRef] | None = None,
) -> CompiledGroupLayout:
    left = min(node.x for node in nodes) - spacing.group_padding
    top = min(node.y for node in nodes) - spacing.group_padding - DEFAULT_GROUP_HEADER_HEIGHT
    right = max(node.x + node.width for node in nodes) + spacing.group_padding
    bottom = max(node.y + node.height for node in nodes) + spacing.group_padding
    scope_path = _common_scope(section.node_refs)
    return CompiledGroupLayout(
        id=section.id,
        scope_path=scope_path,
        title=section.title,
        kind=section.kind,
        role_hint=section.role_hint,
        node_refs=tuple(sorted(group_node_refs if group_node_refs is not None else section.node_refs, key=_ref_sort_key)),
        x=left,
        y=top,
        width=right - left,
        height=bottom - top,
        color=_group_color_for_section(section),
        template=template,
    )


def _group_for_container(
    section: _CompileSection,
    children: Sequence[CompiledGroupLayout],
    spacing: _Spacing,
) -> CompiledGroupLayout:
    left = min(child.x for child in children) - spacing.group_padding
    top = min(child.y for child in children) - spacing.group_padding - DEFAULT_GROUP_HEADER_HEIGHT
    right = max(child.x + child.width for child in children) + spacing.group_padding
    bottom = max(child.y + child.height for child in children) + spacing.group_padding
    return CompiledGroupLayout(
        id=section.id,
        scope_path=_common_scope(section.node_refs) if section.node_refs else _common_group_scope(children),
        title=section.title,
        kind=section.kind,
        role_hint=section.role_hint,
        node_refs=(),
        x=left,
        y=top,
        width=right - left,
        height=bottom - top,
        color=_group_color_for_section(section),
        template=None,
    )


def _group_color_for_section(section: _CompileSection) -> str:
    if _is_support_section(section):
        return "#a8adb4"
    return _ROLE_COLORS.get(section.kind, _ROLE_COLORS[SECTION_KIND_CUSTOM])


def _is_support_section(section: _CompileSection) -> bool:
    title = (section.title or "").lower()
    bucket_id = _wall_bucket_id_from_section_id(section.id)
    return (
        "set / get" in title
        or "helper" in title
        or "label" in title
        or "note" in title
        or bucket_id in {"setget", "labels"}
    )


def _expand_group_for_children(
    group: CompiledGroupLayout,
    children: Sequence[CompiledGroupLayout],
    spacing: _Spacing,
) -> CompiledGroupLayout:
    left = min([group.x, *(child.x - spacing.group_padding for child in children)])
    top = min([group.y, *(child.y - spacing.group_padding for child in children)])
    right = max([group.x + group.width, *(child.x + child.width + spacing.group_padding for child in children)])
    bottom = max([group.y + group.height, *(child.y + child.height + spacing.group_padding for child in children)])
    return CompiledGroupLayout(
        id=group.id,
        scope_path=group.scope_path,
        title=group.title,
        kind=group.kind,
        role_hint=group.role_hint,
        node_refs=group.node_refs,
        x=left,
        y=top,
        width=right - left,
        height=bottom - top,
        color=group.color,
        template=group.template,
    )


def _section_sccs(
    section_edges: Mapping[str, set[str]],
) -> tuple[dict[str, str], dict[str, tuple[str, ...]]]:
    nodes = sorted(section_edges, key=_id_sort_key)
    raw_root_by_node = _tarjan(nodes, {node: tuple(sorted(section_edges.get(node, ()), key=_id_sort_key)) for node in nodes})
    roots = sorted(set(raw_root_by_node.values()), key=_id_sort_key)
    root_to_members = {
        root: tuple(node for node in nodes if raw_root_by_node[node] == root)
        for root in roots
    }
    ordered_roots = sorted(roots, key=lambda root: tuple(_id_sort_key(node) for node in root_to_members[root]))
    root_to_scc = {root: f"scc{index}" for index, root in enumerate(ordered_roots)}
    scc_by_section = {node: root_to_scc[root] for node, root in raw_root_by_node.items()}
    members_by_scc = {
        root_to_scc[root]: root_to_members[root]
        for root in ordered_roots
    }
    return scc_by_section, members_by_scc


def _tarjan(
    nodes: Sequence[str],
    adjacency: Mapping[str, Sequence[str]],
) -> dict[str, str]:
    index = 0
    stack: list[str] = []
    on_stack: set[str] = set()
    indices: dict[str, int] = {}
    lowlinks: dict[str, int] = {}
    root_by_node: dict[str, str] = {}

    def strongconnect(node: str) -> None:
        nonlocal index
        indices[node] = index
        lowlinks[node] = index
        index += 1
        stack.append(node)
        on_stack.add(node)

        for neighbor in adjacency.get(node, ()):
            if neighbor not in indices:
                strongconnect(neighbor)
                lowlinks[node] = min(lowlinks[node], lowlinks[neighbor])
            elif neighbor in on_stack:
                lowlinks[node] = min(lowlinks[node], indices[neighbor])

        if lowlinks[node] != indices[node]:
            return
        members: list[str] = []
        while stack:
            member = stack.pop()
            on_stack.remove(member)
            members.append(member)
            if member == node:
                break
        root = sorted(members, key=_id_sort_key)[0]
        for member in members:
            root_by_node[member] = root

    for node in nodes:
        if node not in indices:
            strongconnect(node)
    return root_by_node


def _component_edges(
    section_edges: Mapping[str, set[str]],
    scc_by_section: Mapping[str, str],
) -> dict[str, set[str]]:
    component_edges = {scc: set() for scc in scc_by_section.values()}
    for source, targets in section_edges.items():
        source_scc = scc_by_section[source]
        for target in targets:
            target_scc = scc_by_section[target]
            if source_scc != target_scc:
                component_edges.setdefault(source_scc, set()).add(target_scc)
                component_edges.setdefault(target_scc, set())
    return component_edges


def _component_islands(
    component_edges: Mapping[str, set[str]],
    members_by_scc: Mapping[str, tuple[str, ...]],
    section_by_id: Mapping[str, _CompileSection],
) -> dict[str, int]:
    undirected = {component: set(targets) for component, targets in component_edges.items()}
    for source, targets in component_edges.items():
        for target in targets:
            undirected.setdefault(target, set()).add(source)
            undirected.setdefault(source, set())

    seen: set[str] = set()
    islands: list[tuple[tuple[Any, ...], tuple[str, ...]]] = []
    for component in sorted(undirected, key=_id_sort_key):
        if component in seen:
            continue
        pending = [component]
        members: set[str] = set()
        while pending:
            current = pending.pop(0)
            if current in members:
                continue
            members.add(current)
            pending.extend(sorted(undirected.get(current, ()), key=_id_sort_key))
        seen.update(members)
        key = min(
            _component_sort_key(item, members_by_scc, section_by_id)
            for item in members
        )
        islands.append((key, tuple(sorted(members, key=_id_sort_key))))
    island_by_component: dict[str, int] = {}
    for index, (_key, components) in enumerate(sorted(islands, key=lambda item: item[0])):
        for component in components:
            island_by_component[component] = index
    return island_by_component


def _component_ranks(
    component_edges: Mapping[str, set[str]],
    island_by_component: Mapping[str, int],
    members_by_scc: Mapping[str, tuple[str, ...]],
    section_by_id: Mapping[str, _CompileSection],
) -> dict[str, int]:
    incoming: dict[str, set[str]] = {component: set() for component in component_edges}
    for source, targets in component_edges.items():
        for target in targets:
            incoming.setdefault(target, set()).add(source)
    ranks: dict[str, int] = {}
    for island in sorted(set(island_by_component.values())):
        components = sorted(
            (component for component, item in island_by_component.items() if item == island),
            key=lambda component: _component_sort_key(component, members_by_scc, section_by_id),
        )
        pending = [component for component in components if not incoming.get(component)]
        if not pending:
            pending = list(components)
        while pending:
            current = pending.pop(0)
            if current in ranks:
                continue
            predecessors = incoming.get(current, set())
            if any(predecessor not in ranks for predecessor in predecessors if predecessor in components):
                pending.append(current)
                continue
            ranks[current] = (
                max((ranks[predecessor] + 1 for predecessor in predecessors if predecessor in ranks), default=0)
            )
            for target in sorted(component_edges.get(current, ()), key=lambda component: _component_sort_key(component, members_by_scc, section_by_id)):
                if target in components and target not in ranks and target not in pending:
                    pending.append(target)
    return ranks


def _component_sort_key(
    component: str,
    members_by_scc: Mapping[str, tuple[str, ...]],
    section_by_id: Mapping[str, _CompileSection],
) -> tuple[Any, ...]:
    members = members_by_scc.get(component, ())
    return min((_section_semantic_sort_key(section_by_id[section_id]) for section_id in members), default=(component,))


def _section_layout_sort_key(
    section: _CompileSection,
    topology_by_section: Mapping[str, CompiledSectionTopology],
) -> tuple[Any, ...]:
    topology = topology_by_section.get(section.id)
    if topology is None:
        return (*_section_semantic_sort_key(section), section.id)
    return (
        topology.scope_path,
        topology.island_index,
        topology.rank,
        topology.scc_id,
        *_section_semantic_sort_key(section),
    )


def _section_placement_sort_key(
    section: _CompileSection,
    placements: Mapping[str, _SectionPlacement],
    topology_by_section: Mapping[str, CompiledSectionTopology],
) -> tuple[Any, ...]:
    topology = _topology_for(section, topology_by_section)
    placement = placements[section.id]
    return (
        topology.scope_path,
        topology.island_index,
        placement.rank,
        placement.band,
        placement.row,
        *_section_semantic_sort_key(section),
    )


def _section_semantic_sort_key(section: _CompileSection) -> tuple[Any, ...]:
    node_ranks = tuple(_ref_sort_key(ref) for ref in section.node_refs)
    return (
        _common_scope(section.node_refs),
        _section_title_sort_rank(section.title),
        section.kind,
        section.id,
        node_ranks,
    )


def _section_title_sort_rank(title: str) -> int:
    lowered = title.lower()
    if "model" in lowered:
        return 0
    if "lora" in lowered or "vae" in lowered or "clip" in lowered:
        return 1
    if "input" in lowered:
        return 2
    if "setting" in lowered:
        return 3
    if "conditioning" in lowered:
        return 10
    if "prompt" in lowered:
        return 11
    if "latent" in lowered or "prepare" in lowered:
        return 20
    if "first" in lowered and "sampler" in lowered:
        return 30
    if "sampler" in lowered or "sampling" in lowered:
        return 31
    if "optional" in lowered:
        return 32
    if "decode" in lowered:
        return 40
    if "postprocess" in lowered:
        return 41
    if "output" in lowered or "save" in lowered:
        return 50
    if "set / get" in lowered:
        return 80
    if "label" in lowered or "note" in lowered:
        return 81
    return 60


def _plan_parent_id(
    section: _CompileSection,
    section_by_id: Mapping[str, _CompileSection],
) -> str | None:
    parent_id = section.parent_id
    if parent_id is not None and parent_id in section_by_id:
        return parent_id
    return None


def _section_depth(
    section: _CompileSection,
    section_by_id: Mapping[str, _CompileSection],
) -> int:
    depth = 0
    seen: set[str] = set()
    parent_id = _plan_parent_id(section, section_by_id)
    while parent_id is not None and parent_id not in seen:
        seen.add(parent_id)
        depth += 1
        parent = section_by_id.get(parent_id)
        if parent is None:
            break
        parent_id = _plan_parent_id(parent, section_by_id)
    return depth


def _stable_auto_name(section: _CompileSection, scc_id: str) -> str:
    raw = section.title or section.id
    slug = "".join(char.lower() if char.isalnum() else "_" for char in raw).strip("_")
    while "__" in slug:
        slug = slug.replace("__", "_")
    if not slug:
        slug = "section"
    digest_payload = "|".join([section.id, section.kind, scc_id, *(_entry_key(ref) for ref in section.node_refs)])
    digest = hashlib.blake2b(digest_payload.encode("utf-8"), digest_size=4).hexdigest()
    return f"{slug}_{digest}"


def _effective_ref_adjacency(facts: GraphInventoryFacts) -> dict[CanonicalNodeRef, tuple[CanonicalNodeRef, ...]]:
    adjacency: dict[CanonicalNodeRef, set[CanonicalNodeRef]] = {
        fact.ref: set()
        for fact in facts.canonical_refs
    }
    for topology in facts.scope_topologies:
        for edge in topology.effective_edges:
            adjacency.setdefault(edge.source, set()).add(edge.target)
            adjacency.setdefault(edge.target, set())
    return {
        ref: tuple(sorted(targets, key=_ref_sort_key))
        for ref, targets in adjacency.items()
    }


def _normalized_sampler_pair(
    pair: tuple[CanonicalNodeRef, CanonicalNodeRef],
    claims: Sequence[SamplerRelationClaim],
    adjacency: Mapping[CanonicalNodeRef, Sequence[CanonicalNodeRef]],
    ref_to_section: Mapping[CanonicalNodeRef, str],
    canonical_by_ref: Mapping[CanonicalNodeRef, Any],
) -> CompiledSamplerRelation:
    left, right = pair
    left_path = _path_between_refs(left, right, adjacency)
    right_path = _path_between_refs(right, left, adjacency)
    directional: list[tuple[CanonicalNodeRef, CanonicalNodeRef, tuple[CanonicalNodeRef, ...]]] = []
    if left_path:
        directional.append((left, right, left_path))
    if right_path:
        directional.append((right, left, right_path))
    for claim in claims:
        if claim.kind in {"sampler_precedes", "sampler_refines"} and claim.source is not None and claim.target is not None:
            path = _path_between_refs(claim.source, claim.target, adjacency)
            directional.append((claim.source, claim.target, path or (claim.source, claim.target)))

    relation_kinds = {_claim_normalized_kind(claim) for claim in claims}
    relation_kinds.discard(None)
    bridge_path: tuple[CanonicalNodeRef, ...] = ()
    source: CanonicalNodeRef | None = None
    target: CanonicalNodeRef | None = None
    reasons = tuple(
        sorted(
            {
                claim.reason or claim.kind
                for claim in claims
            }
        )
    )

    if len({(item[0], item[1]) for item in directional}) > 1:
        kind: Literal["sequential", "parallel", "independent", "mixed"] = "mixed"
        source, target, bridge_path = sorted(directional, key=lambda item: (_ref_sort_key(item[0]), _ref_sort_key(item[1])))[0]
    elif directional:
        source, target, bridge_path = directional[0]
        if _bridge_path_whitelisted(bridge_path, canonical_by_ref):
            kind = "sequential"
        else:
            kind = "mixed"
        if relation_kinds and relation_kinds - {"sequential"}:
            kind = "mixed"
    elif "mixed" in relation_kinds:
        kind = "mixed"
    elif "parallel" in relation_kinds:
        kind = "parallel"
    elif "independent" in relation_kinds:
        kind = "independent"
    else:
        kind = "independent"

    section_ids = tuple(ref_to_section.get(ref, "__unowned__") for ref in pair)
    return CompiledSamplerRelation(
        kind=kind,
        samplers=pair,
        section_ids=section_ids,
        auto_name=_sampler_auto_name(kind, pair, source, target),
        source=source,
        target=target,
        bridge_path=bridge_path,
        reasons=reasons,
    )


def _claim_normalized_kind(claim: SamplerRelationClaim) -> str | None:
    if claim.kind in {"sampler_precedes", "sampler_refines"}:
        return "sequential"
    if claim.kind == "parallel_sampler_branch":
        return "parallel"
    if claim.kind == "independent_samplers":
        return "independent"
    if claim.kind == "same_sampler_pair":
        return "mixed"
    return None


def _path_between_refs(
    source: CanonicalNodeRef,
    target: CanonicalNodeRef,
    adjacency: Mapping[CanonicalNodeRef, Sequence[CanonicalNodeRef]],
) -> tuple[CanonicalNodeRef, ...]:
    pending: list[tuple[CanonicalNodeRef, tuple[CanonicalNodeRef, ...]]] = [
        (neighbor, (source, neighbor))
        for neighbor in adjacency.get(source, ())
    ]
    seen: set[CanonicalNodeRef] = set()
    while pending:
        ref, path = pending.pop(0)
        if ref == target:
            return path
        if ref in seen:
            continue
        seen.add(ref)
        for neighbor in adjacency.get(ref, ()):
            if neighbor not in seen:
                pending.append((neighbor, (*path, neighbor)))
    return ()


def _bridge_path_whitelisted(
    path: Sequence[CanonicalNodeRef],
    canonical_by_ref: Mapping[CanonicalNodeRef, Any],
) -> bool:
    if len(path) <= 2:
        return True
    return all(_is_bridge_ref(ref, canonical_by_ref) for ref in path[1:-1])


def _is_bridge_ref(
    ref: CanonicalNodeRef,
    canonical_by_ref: Mapping[CanonicalNodeRef, Any],
) -> bool:
    fact = canonical_by_ref.get(ref)
    if fact is None:
        return False
    if getattr(fact, "is_helper", False):
        return True
    class_type = str(getattr(fact, "class_type", "")).lower()
    role_hint = getattr(fact, "role_hint", ROLE_HINT_UNKNOWN)
    if role_hint in {
        ROLE_HINT_LATENT,
        ROLE_HINT_DECODE,
        ROLE_HINT_CONTROL,
        ROLE_HINT_POSTPROCESS,
        ROLE_HINT_HELPER,
        ROLE_HINT_UI,
        ROLE_HINT_UTILITY,
        ROLE_HINT_UNKNOWN,
    }:
        return True
    return any(token in class_type for token in ("latent", "upscale", "reroute", "pipe", "bridge"))


def _mixed_sampler_aggregate(
    relations: Sequence[CompiledSamplerRelation],
    ref_to_section: Mapping[CanonicalNodeRef, str],
) -> CompiledSamplerRelation | None:
    non_independent = [relation for relation in relations if relation.kind != "independent"]
    non_independent_kinds = {relation.kind for relation in non_independent}
    if len(non_independent_kinds) < 2:
        return None
    sampler_refs = tuple(
        sorted(
            {ref for relation in non_independent for ref in relation.samplers},
            key=_ref_sort_key,
        )
    )
    return CompiledSamplerRelation(
        kind="mixed",
        samplers=sampler_refs,
        section_ids=tuple(ref_to_section.get(ref, "__unowned__") for ref in sampler_refs),
        auto_name=_sampler_auto_name("mixed", sampler_refs, None, None),
        reasons=("sampler graph contains multiple non-independent relation kinds",),
    )


def _sampler_auto_name(
    kind: str,
    samplers: Sequence[CanonicalNodeRef],
    source: CanonicalNodeRef | None,
    target: CanonicalNodeRef | None,
) -> str:
    ordered = tuple(sorted(samplers, key=_ref_sort_key))
    direction = ""
    if source is not None and target is not None:
        direction = f"_{_entry_key(source)}_to_{_entry_key(target)}"
    raw = "_".join(_entry_key(ref) for ref in ordered)
    digest_payload = "|".join([kind, direction, *(_entry_key(ref) for ref in ordered)])
    digest = hashlib.blake2b(digest_payload.encode("utf-8"), digest_size=4).hexdigest()
    return f"samplers_{kind}_{raw}{direction}_{digest}"


def _sampler_claim_sort_key(claim: SamplerRelationClaim) -> tuple[Any, ...]:
    source = claim.source.to_json() if claim.source is not None else []
    target = claim.target.to_json() if claim.target is not None else []
    return (
        claim.kind,
        [ref.to_json() for ref in sorted(claim.samplers, key=_ref_sort_key)],
        source,
        target,
        claim.reason or "",
    )


def _compiled_sampler_relation_sort_key(relation: CompiledSamplerRelation) -> tuple[Any, ...]:
    source = relation.source.to_json() if relation.source is not None else []
    target = relation.target.to_json() if relation.target is not None else []
    return (
        1 if len(relation.samplers) > 2 else 0,
        relation.kind,
        [ref.to_json() for ref in relation.samplers],
        source,
        target,
    )


def _entry_for_layout(
    layout: CompiledNodeLayout,
    furniture: NodeFurnitureFact | None,
) -> Mapping[str, Any]:
    flags = _thaw_jsonish(furniture.flags) if furniture is not None else {}
    if layout.auto_collapsed:
        flags = dict(flags) if isinstance(flags, Mapping) else {}
        flags["collapsed"] = True
    properties = _thaw_jsonish(furniture.properties) if furniture is not None else {}
    mode = furniture.mode if furniture is not None and isinstance(furniture.mode, int) else 0
    return {
        "pos": snap_pos((layout.x, layout.y)),
        "size": snap_size((layout.width, layout.height)),
        "flags": flags,
        "color": furniture.color if furniture is not None else None,
        "bgcolor": furniture.bgcolor if furniture is not None else None,
        "mode": mode,
        "properties": properties if isinstance(properties, dict) else {},
    }


def _sidecar_group(group: CompiledGroupLayout) -> Mapping[str, Any]:
    return {
        "id": group.id,
        "scope_path": group.scope_path,
        "title": group.title,
        "bounding": [group.x, group.y, group.width, group.height],
        "color": group.color,
        "nodes": [_entry_key(ref) for ref in group.node_refs],
    }


def _spacing(preset: SpacingPreset) -> _Spacing:
    if preset == "compact":
        return _Spacing(
            section_gap_x=360,
            island_gap_x=3200,
            band_gap_y=640,
            section_gap_y=72,
            node_gap_y=96,
            group_padding=32,
        )
    if preset == "wide":
        return _Spacing(
            section_gap_x=560,
            island_gap_x=5200,
            band_gap_y=1120,
            section_gap_y=144,
            node_gap_y=180,
            group_padding=64,
        )
    return _Spacing(
        section_gap_x=440,
        island_gap_x=4000,
        band_gap_y=840,
        section_gap_y=96,
        node_gap_y=140,
        group_padding=48,
    )


def _node_size(
    furniture: NodeFurnitureFact | None,
    *,
    preserve: bool,
) -> tuple[int, int]:
    if preserve and furniture is not None:
        size = _size(furniture.size)
        if size is not None:
            return size
    return (DEFAULT_NODE_WIDTH, DEFAULT_NODE_HEIGHT)


def _node_size_for_ref(
    ref: CanonicalNodeRef,
    facts: GraphInventoryFacts,
    furniture: NodeFurnitureFact | None,
    *,
    preserve: bool,
    minimize_setget_helpers: bool,
) -> tuple[int, int]:
    source_size = _size(furniture.size) if furniture is not None else None
    if (
        minimize_setget_helpers
        and _large_workflow_soft_quality_gate(facts)
        and _is_setget_ref(ref, facts)
    ):
        source_width, source_height = source_size if source_size is not None else _node_size(furniture, preserve=preserve)
        return (
            min(164, max(112, round(source_width * 0.38))),
            min(48, max(36, round(source_height * 0.72))),
        )
    if _furniture_is_collapsed(furniture) and source_size is not None:
        return source_size
    width, height = _node_size(furniture, preserve=preserve)
    if not preserve and furniture is not None:
        measured = source_size
        if measured is not None:
            measured_width, measured_height = measured
            width = max(width, measured_width)
            height = max(height, measured_height)
    return (width, height)


def _auto_collapse_setget_ref(
    ref: CanonicalNodeRef,
    facts: GraphInventoryFacts,
    furniture: NodeFurnitureFact | None,
    *,
    minimize_setget_helpers: bool,
) -> bool:
    return (
        minimize_setget_helpers
        and _large_workflow_soft_quality_gate(facts)
        and _is_setget_ref(ref, facts)
        and not _furniture_is_collapsed(furniture)
    )


def _furniture_is_collapsed(furniture: NodeFurnitureFact | None) -> bool:
    if furniture is None:
        return False
    return _truthy_flag(furniture.flags, "collapsed")


def _is_setget_ref(ref: CanonicalNodeRef, facts: GraphInventoryFacts) -> bool:
    canonical_by_ref = {fact.ref: fact for fact in facts.canonical_refs}
    fact = canonical_by_ref.get(ref)
    if fact is None:
        return False
    class_type = str(getattr(fact, "class_type", "")).lower()
    return any(token in class_type for token in ("setnode", "getnode"))


def _is_label_ref(ref: CanonicalNodeRef, facts: GraphInventoryFacts) -> bool:
    canonical_by_ref = {fact.ref: fact for fact in facts.canonical_refs}
    fact = canonical_by_ref.get(ref)
    if fact is None:
        return False
    class_type = str(getattr(fact, "class_type", "")).lower()
    return any(token in class_type for token in ("markdown", "note", "annotation"))


def _pos(value: Any) -> tuple[int, int] | None:
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)) and len(value) >= 2:
        left, top = value[0], value[1]
        if _is_number(left) and _is_number(top):
            return (round(left), round(top))
    return None


def _size(value: Any) -> tuple[int, int] | None:
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)) and len(value) >= 2:
        width, height = value[0], value[1]
        if _is_number(width) and _is_number(height) and width > 0 and height > 0:
            return (round(width), round(height))
    return None


def _is_number(value: Any) -> bool:
    return isinstance(value, int | float) and not isinstance(value, bool)


def _helper_section_id(
    placement: Any,
    primary_owned: Mapping[CanonicalNodeRef, str],
) -> str:
    if placement.kind == HELPER_PLACEMENT_INSIDE_SECTION:
        for ref in (placement.target, placement.source, placement.destination):
            if ref in primary_owned:
                return primary_owned[ref]
        if placement.section_id is not None:
            return placement.section_id
    if placement.kind in {HELPER_PLACEMENT_NEAR_PRODUCER, HELPER_PLACEMENT_NEAR_CONSUMER}:
        if placement.target in primary_owned:
            return primary_owned[placement.target]
        return "__helpers__"
    if placement.kind == HELPER_PLACEMENT_EDGE_PATH:
        source_section = primary_owned.get(placement.source)
        destination_section = primary_owned.get(placement.destination)
        if source_section is not None and source_section == destination_section:
            return source_section
        return "__helpers__"
    return "__helpers__"


def _resolve_helper_ownership(
    helper_ref: CanonicalNodeRef,
    *,
    facts: GraphInventoryFacts,
    primary_owned: Mapping[CanonicalNodeRef, str],
    canonical_by_ref: Mapping[CanonicalNodeRef, Any],
    furniture_by_ref: Mapping[CanonicalNodeRef, NodeFurnitureFact],
    placement_by_helper: Mapping[CanonicalNodeRef, Any],
    incident_adjacency: Mapping[CanonicalNodeRef, Sequence[CanonicalNodeRef]],
) -> _OwnershipDecision:
    placement = placement_by_helper.get(helper_ref)
    if placement is not None:
        explicit = _placement_ownership_decision(placement, primary_owned)
        if explicit is not None:
            return explicit

    fact = canonical_by_ref.get(helper_ref)
    class_type = str(getattr(fact, "class_type", "")).lower()
    if _is_label_ref(helper_ref, facts):
        connected = _nearest_primary_attachment(
            helper_ref,
            primary_owned=primary_owned,
            candidate_refs=incident_adjacency.get(helper_ref, ()),
            furniture_by_ref=furniture_by_ref,
        )
        if connected is not None:
            return _OwnershipDecision(
                ref=helper_ref,
                section_id=primary_owned[connected],
                attachment_target=connected,
                reason="note_connected_primary",
            )
        annotated = _annotated_primary_attachment(
            helper_ref,
            primary_owned=primary_owned,
            furniture_by_ref=furniture_by_ref,
        )
        if annotated is not None:
            return _OwnershipDecision(
                ref=helper_ref,
                section_id=primary_owned[annotated],
                attachment_target=annotated,
                reason="note_annotated_primary",
            )
        return _OwnershipDecision(
            ref=helper_ref,
            section_id="__helpers__",
            reason="note_unowned_fallback",
        )

    incoming_primary = tuple(
        edge.source
        for topology in facts.scope_topologies
        for edge in topology.effective_edges
        if edge.target == helper_ref and edge.source in primary_owned
    )
    outgoing_primary = tuple(
        edge.target
        for topology in facts.scope_topologies
        for edge in topology.effective_edges
        if edge.source == helper_ref and edge.target in primary_owned
    )
    if "setnode" in class_type:
        target = _nearest_primary_attachment(
            helper_ref,
            primary_owned=primary_owned,
            candidate_refs=incoming_primary,
            furniture_by_ref=furniture_by_ref,
        )
        if target is not None:
            return _OwnershipDecision(
                ref=helper_ref,
                section_id=primary_owned[target],
                attachment_target=target,
                reason="sidecar_connected_producer",
            )
    if "getnode" in class_type:
        target = _nearest_primary_attachment(
            helper_ref,
            primary_owned=primary_owned,
            candidate_refs=outgoing_primary,
            furniture_by_ref=furniture_by_ref,
        )
        if target is not None:
            return _OwnershipDecision(
                ref=helper_ref,
                section_id=primary_owned[target],
                attachment_target=target,
                reason="sidecar_connected_consumer",
            )
    target = _nearest_primary_attachment(
        helper_ref,
        primary_owned=primary_owned,
        candidate_refs=incident_adjacency.get(helper_ref, ()),
        furniture_by_ref=furniture_by_ref,
        require_single_section=True,
    )
    if target is not None:
        return _OwnershipDecision(
            ref=helper_ref,
            section_id=primary_owned[target],
            attachment_target=target,
            reason="helper_connected_primary",
        )
    return _OwnershipDecision(
        ref=helper_ref,
        section_id="__helpers__",
        reason="helper_unowned_fallback",
    )


def _placement_ownership_decision(
    placement: Any,
    primary_owned: Mapping[CanonicalNodeRef, str],
) -> _OwnershipDecision | None:
    section_id = _helper_section_id(placement, primary_owned)
    if section_id == "__helpers__" and placement.section_id is None:
        return None
    attachment = _placement_attachment_target(placement, primary_owned)
    reason = (
        "helper_explicit_section"
        if placement.section_id is not None
        else "helper_targeted_placement"
        if attachment is not None
        else "helper_targeted_fallback"
    )
    return _OwnershipDecision(
        ref=placement.helper,
        section_id=section_id,
        attachment_target=attachment,
        reason=reason,
    )


def _placement_attachment_target(
    placement: Any,
    primary_owned: Mapping[CanonicalNodeRef, str],
) -> CanonicalNodeRef | None:
    if placement.target in primary_owned:
        return placement.target
    if placement.kind == HELPER_PLACEMENT_EDGE_PATH:
        source_section = primary_owned.get(placement.source)
        destination_section = primary_owned.get(placement.destination)
        if source_section is not None and source_section == destination_section:
            if placement.source in primary_owned:
                return placement.source
            if placement.destination in primary_owned:
                return placement.destination
        return None
    for ref in (placement.source, placement.destination):
        if ref in primary_owned:
            return ref
    return None


def _incident_ref_adjacency(
    facts: GraphInventoryFacts,
) -> dict[CanonicalNodeRef, tuple[CanonicalNodeRef, ...]]:
    adjacency: dict[CanonicalNodeRef, set[CanonicalNodeRef]] = {
        fact.ref: set() for fact in facts.canonical_refs
    }
    for topology in facts.scope_topologies:
        for edge in topology.effective_edges:
            adjacency.setdefault(edge.source, set()).add(edge.target)
            adjacency.setdefault(edge.target, set()).add(edge.source)
    return {
        ref: tuple(sorted(targets, key=_ref_sort_key))
        for ref, targets in adjacency.items()
    }


def _nearest_primary_attachment(
    helper_ref: CanonicalNodeRef,
    *,
    primary_owned: Mapping[CanonicalNodeRef, str],
    candidate_refs: Sequence[CanonicalNodeRef],
    furniture_by_ref: Mapping[CanonicalNodeRef, NodeFurnitureFact],
    require_single_section: bool = False,
) -> CanonicalNodeRef | None:
    primary_candidates = tuple(
        dict.fromkeys(ref for ref in candidate_refs if ref in primary_owned)
    )
    if not primary_candidates:
        return None
    if require_single_section and len({primary_owned[ref] for ref in primary_candidates}) != 1:
        return None
    helper_center = _furniture_center(furniture_by_ref.get(helper_ref))
    if helper_center is None:
        return sorted(primary_candidates, key=_ref_sort_key)[0]
    ranked: list[tuple[float, CanonicalNodeRef]] = []
    for ref in primary_candidates:
        center = _furniture_center(furniture_by_ref.get(ref))
        if center is None:
            continue
        ranked.append((hypot(center[0] - helper_center[0], center[1] - helper_center[1]), ref))
    if not ranked:
        return sorted(primary_candidates, key=_ref_sort_key)[0]
    ranked.sort(key=lambda item: (item[0], _ref_sort_key(item[1])))
    return ranked[0][1]


def _annotated_primary_attachment(
    note_ref: CanonicalNodeRef,
    *,
    primary_owned: Mapping[CanonicalNodeRef, str],
    furniture_by_ref: Mapping[CanonicalNodeRef, NodeFurnitureFact],
) -> CanonicalNodeRef | None:
    note_furniture = furniture_by_ref.get(note_ref)
    note_center = _furniture_center(note_furniture)
    if note_center is None:
        return None
    note_pos = _pos(note_furniture.pos) if note_furniture is not None else None
    note_size = _size(note_furniture.size) if note_furniture is not None else None
    ranked: list[tuple[float, CanonicalNodeRef]] = []
    for ref in sorted(primary_owned, key=_ref_sort_key):
        if ref.scope_path != note_ref.scope_path:
            continue
        furniture = furniture_by_ref.get(ref)
        center = _furniture_center(furniture)
        if center is None:
            continue
        if note_pos is not None and note_size is not None:
            primary_pos = _pos(furniture.pos) if furniture is not None else None
            primary_size = _size(furniture.size) if furniture is not None else None
            if primary_pos is not None and primary_size is not None and not _annotation_evidence(
                note_pos,
                note_size,
                primary_pos,
                primary_size,
            ):
                continue
        ranked.append((hypot(center[0] - note_center[0], center[1] - note_center[1]), ref))
    if not ranked:
        return None
    ranked.sort(key=lambda item: (item[0], _ref_sort_key(item[1])))
    if len(ranked) > 1 and abs(ranked[1][0] - ranked[0][0]) < 24.0:
        return None
    return ranked[0][1]


def _annotation_evidence(
    note_pos: tuple[int, int],
    note_size: tuple[int, int],
    primary_pos: tuple[int, int],
    primary_size: tuple[int, int],
) -> bool:
    note_center = (note_pos[0] + note_size[0] / 2.0, note_pos[1] + note_size[1] / 2.0)
    primary_center = (
        primary_pos[0] + primary_size[0] / 2.0,
        primary_pos[1] + primary_size[1] / 2.0,
    )
    expanded_width = primary_size[0] / 2.0 + max(120.0, note_size[0] / 2.0)
    expanded_height = primary_size[1] / 2.0 + max(96.0, note_size[1] / 2.0)
    return (
        abs(note_center[0] - primary_center[0]) <= expanded_width
        and abs(note_center[1] - primary_center[1]) <= expanded_height
    )


def _furniture_center(furniture: NodeFurnitureFact | None) -> tuple[float, float] | None:
    if furniture is None:
        return None
    pos = _pos(furniture.pos)
    size = _size(furniture.size)
    if pos is None or size is None:
        return None
    return (pos[0] + size[0] / 2.0, pos[1] + size[1] / 2.0)


def _can_preserve_existing_groups(options: LayoutCompileOptions) -> bool:
    return not _force_existing_regroup(options) and options.existing_group_policy not in {
        "dissolve_with_warning",
    }


def _preserved_existing_ownership(
    facts: GraphInventoryFacts,
    *,
    unassigned_refs: Sequence[CanonicalNodeRef],
    assigned_refs: set[CanonicalNodeRef],
    classification: ClassificationReport,
) -> dict[CanonicalNodeRef, tuple[str, _GeneratedSection]]:
    unassigned = set(unassigned_refs)
    helper_refs = {fact.ref for fact in facts.canonical_refs if fact.is_helper}
    ownership: dict[CanonicalNodeRef, tuple[str, _GeneratedSection]] = {}

    for scope in sorted(facts.scope_furniture, key=lambda item: item.scope_path):
        for group in sorted(scope.groups, key=lambda item: item.index):
            group_score = _score_existing_group(facts, group, classification)
            if group_score is None or not group_score.coherent:
                continue
            primary_refs = tuple(ref for ref in group_score.member_refs if ref not in helper_refs)
            if not primary_refs:
                continue
            if any(ref in assigned_refs for ref in primary_refs):
                continue
            group_refs = tuple(ref for ref in primary_refs if ref in unassigned and ref not in ownership)
            if not group_refs or len(group_refs) != len(primary_refs):
                continue
            if _prompt_text_refs(group_refs, facts):
                section_id = "__huge_prompt_conditioning__"
                generated = _GeneratedSection(
                    kind=SECTION_KIND_CONDITIONING,
                    title="Prompt / Conditioning",
                    role_hint=ROLE_HINT_CONDITIONING,
                )
            else:
                section_id = _existing_group_section_id(group.scope_path, group.index)
                title = group.title if isinstance(group.title, str) and group.title else _title_for(section_id, SECTION_KIND_CUSTOM)
                generated = _GeneratedSection(
                    kind=group_score.section_kind,
                    title=title,
                )
            for ref in sorted(group_refs, key=_ref_sort_key):
                ownership[ref] = (section_id, generated)
    return ownership


def _score_existing_group(
    facts: GraphInventoryFacts,
    group: GroupFact,
    classification: ClassificationReport,
) -> _ExistingGroupScore | None:
    helper_refs = {fact.ref for fact in facts.canonical_refs if fact.is_helper}
    rects = _node_rects_by_ref(facts.node_furniture)
    group_rect = _group_rect(group.bounding)
    contained_refs = _contained_group_refs(group.scope_path, group_rect, rects, helper_refs)
    refs = _group_node_refs(facts, group.scope_path, group.nodes)
    if refs is None:
        return None
    member_refs = tuple(ref for ref in refs if ref not in helper_refs) if refs else contained_refs
    if not member_refs:
        return None

    member_set = set(member_refs)
    contained_set = set(contained_refs)
    containment = _ratio_float(len(member_set & contained_set), len(member_refs))
    node_coverage = _ratio_float(len(member_set & contained_set), len(member_set | contained_set))
    topology = _existing_group_topology_coherence(member_refs, facts)
    section_kind = _common_section_kind(member_refs, classification, facts)
    title_role = _existing_group_title_role_match(group.title, member_refs, section_kind, classification, facts)
    score = (
        EXISTING_GROUP_CONTAINMENT_WEIGHT * containment
        + EXISTING_GROUP_TOPOLOGY_WEIGHT * topology
        + EXISTING_GROUP_TITLE_ROLE_WEIGHT * title_role
        + EXISTING_GROUP_NODE_COVERAGE_WEIGHT * node_coverage
    )
    return _ExistingGroupScore(
        scope_path=group.scope_path,
        index=group.index,
        title=group.title,
        section_kind=section_kind,
        member_refs=tuple(sorted(member_refs, key=_ref_sort_key)),
        contained_refs=tuple(sorted(contained_refs, key=_ref_sort_key)),
        containment=containment,
        topology=topology,
        title_role=title_role,
        node_coverage=node_coverage,
        score=score,
    )


def _node_rects_by_ref(
    node_furniture: Sequence[NodeFurnitureFact],
) -> dict[CanonicalNodeRef, _ExistingGroupRect]:
    rects: dict[CanonicalNodeRef, _ExistingGroupRect] = {}
    for furniture in node_furniture:
        pos = _pos_float(furniture.pos)
        size = _size_float(furniture.size)
        if pos is None or size is None:
            continue
        rects[furniture.ref] = _ExistingGroupRect(pos[0], pos[1], size[0], size[1])
    return rects


def _contained_group_refs(
    scope_path: str,
    group_rect: _ExistingGroupRect | None,
    rects: Mapping[CanonicalNodeRef, _ExistingGroupRect],
    helper_refs: set[CanonicalNodeRef],
) -> tuple[CanonicalNodeRef, ...]:
    if group_rect is None:
        return ()
    return tuple(
        sorted(
            (
                ref
                for ref, rect in rects.items()
                if ref.scope_path == scope_path
                and ref not in helper_refs
                and _rect_contains(group_rect, rect)
            ),
            key=_ref_sort_key,
        )
    )


def _existing_group_topology_coherence(
    member_refs: Sequence[CanonicalNodeRef],
    facts: GraphInventoryFacts,
) -> float:
    member_set = set(member_refs)
    incident = 0
    internal = 0
    seen: set[tuple[CanonicalNodeRef, CanonicalNodeRef]] = set()
    for topology in facts.scope_topologies:
        for edge in topology.effective_edges:
            if edge.source not in member_set and edge.target not in member_set:
                continue
            edge_key = tuple(sorted((edge.source, edge.target), key=_ref_sort_key))
            if edge_key in seen:
                continue
            seen.add(edge_key)
            incident += 1
            if edge.source in member_set and edge.target in member_set:
                internal += 1
    if incident == 0:
        return 1.0 if len(member_refs) == 1 else 0.0
    return _ratio_float(internal, incident)


def _existing_group_title_role_match(
    title: str | None,
    member_refs: Sequence[CanonicalNodeRef],
    section_kind: SectionKind,
    classification: ClassificationReport,
    facts: GraphInventoryFacts,
) -> float:
    if not isinstance(title, str) or not title.strip() or not member_refs:
        return 0.0
    title_tokens = _text_tokens(title)
    if not title_tokens:
        return 0.0
    member_kinds = [
        _section_kind_for_ref(ref, classification, facts)
        for ref in member_refs
    ]
    dominant_count = sum(1 for kind in member_kinds if kind == section_kind)
    homogeneity = _ratio_float(dominant_count, len(member_kinds))
    role_tokens = set(_SECTION_TITLE_TOKENS.get(section_kind, ()))
    canonical_by_ref = {fact.ref: fact for fact in facts.canonical_refs}
    for ref in member_refs:
        if _section_kind_for_ref(ref, classification, facts) != section_kind:
            continue
        fact = canonical_by_ref.get(ref)
        if fact is None:
            continue
        role_tokens.update(_text_tokens(getattr(fact, "class_type", "")))
        role_tokens.update(_text_tokens(getattr(fact, "display", "")))
        role_tokens.update(_text_tokens(getattr(fact, "title", "") or ""))
    title_match = 1.0 if title_tokens & role_tokens else 0.0
    return homogeneity * title_match


def _section_kind_for_ref(
    ref: CanonicalNodeRef,
    classification: ClassificationReport,
    facts: GraphInventoryFacts,
) -> SectionKind:
    canonical_by_ref = {fact.ref: fact for fact in facts.canonical_refs}
    fact = canonical_by_ref.get(ref)
    hint = classification.hint_for(ref)
    role = hint.role_hint if hint is not None else fact.role_hint if fact is not None else ROLE_HINT_UNKNOWN
    return _ROLE_TO_SECTION_KIND.get(role, SECTION_KIND_CUSTOM)


def _text_tokens(value: str) -> set[str]:
    tokens: set[str] = set()
    token = ""
    for char in value.lower():
        if char.isalnum():
            token += char
            continue
        if token:
            tokens.add(_normalize_token(token))
            token = ""
    if token:
        tokens.add(_normalize_token(token))
    return {item for item in tokens if item}


def _normalize_token(token: str) -> str:
    if len(token) > 3 and token.endswith("s"):
        return token[:-1]
    return token


def _group_rect(value: Any) -> _ExistingGroupRect | None:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)) or len(value) < 4:
        return None
    x = _number_float(value[0])
    y = _number_float(value[1])
    width = _number_float(value[2])
    height = _number_float(value[3])
    if x is None or y is None or width is None or height is None:
        return None
    if width <= 0.0 or height <= 0.0:
        return None
    return _ExistingGroupRect(x, y, width, height)


def _pos_float(value: Any) -> tuple[float, float] | None:
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)) and len(value) >= 2:
        x = _number_float(value[0])
        y = _number_float(value[1])
        if x is not None and y is not None:
            return (x, y)
    return None


def _size_float(value: Any) -> tuple[float, float] | None:
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)) and len(value) >= 2:
        width = _number_float(value[0])
        height = _number_float(value[1])
        if width is not None and height is not None and width > 0.0 and height > 0.0:
            return (width, height)
    return None


def _number_float(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int | float):
        return float(value)
    return None


def _rect_contains(container: _ExistingGroupRect, child: _ExistingGroupRect) -> bool:
    return (
        child.x >= container.x
        and child.y >= container.y
        and child.right <= container.right
        and child.bottom <= container.bottom
    )


def _ratio_float(numerator: int | float, denominator: int | float) -> float:
    if denominator == 0:
        return 0.0
    return float(numerator) / float(denominator)


def _group_node_refs(
    facts: GraphInventoryFacts,
    scope_path: str,
    group_nodes: Sequence[Any],
) -> tuple[CanonicalNodeRef, ...] | None:
    by_token: dict[Any, CanonicalNodeRef] = {}
    for fact in facts.canonical_refs:
        ref = fact.ref
        if ref.scope_path != scope_path:
            continue
        by_token[ref.uid] = ref
        by_token[_entry_key(ref)] = ref
        if fact.litegraph_id is not None:
            by_token[fact.litegraph_id] = ref
            by_token[str(fact.litegraph_id)] = ref
    refs: list[CanonicalNodeRef] = []
    seen: set[CanonicalNodeRef] = set()
    for raw in group_nodes:
        ref = by_token.get(raw)
        if ref is None:
            return None
        if ref in seen:
            continue
        seen.add(ref)
        refs.append(ref)
    return tuple(sorted(refs, key=_ref_sort_key))


def _existing_group_section_id(scope_path: str, index: int) -> str:
    scope_label = "root" if scope_path == "" else scope_path.replace("/", "_").replace(":", "_")
    return f"__existing_{scope_label}_{index}__"


def _common_section_kind(
    refs: Sequence[CanonicalNodeRef],
    classification: ClassificationReport,
    facts: GraphInventoryFacts,
) -> SectionKind:
    canonical_by_ref = {fact.ref: fact for fact in facts.canonical_refs}
    counts: dict[SectionKind, int] = {}
    for ref in refs:
        fact = canonical_by_ref.get(ref)
        hint = classification.hint_for(ref)
        role = hint.role_hint if hint is not None else fact.role_hint if fact is not None else ROLE_HINT_UNKNOWN
        kind = _ROLE_TO_SECTION_KIND.get(role, SECTION_KIND_CUSTOM)
        counts[kind] = counts.get(kind, 0) + 1
    if not counts:
        return SECTION_KIND_CUSTOM
    return sorted(counts.items(), key=lambda item: (-item[1], item[0]))[0][0]


def _section_for_role(
    role: RoleHint,
    section_defs: Mapping[str, LayoutSection],
) -> str:
    kind = _ROLE_TO_SECTION_KIND.get(role, SECTION_KIND_CUSTOM)
    for section_id, section in sorted(section_defs.items()):
        if section.kind == kind:
            return section_id
    return f"__{kind}__"


def _generated_section_kind(section_id: str) -> SectionKind:
    if section_id == "__helpers__":
        return SECTION_KIND_UTILITY
    if section_id.startswith("__") and section_id.endswith("__"):
        raw_kind = section_id[2:-2]
        if raw_kind in _ROLE_COLORS:
            return raw_kind  # type: ignore[return-value]
    return SECTION_KIND_CUSTOM


def _title_for(section_id: str, kind: SectionKind) -> str:
    if section_id.startswith("__") and section_id.endswith("__"):
        return kind.replace("_", " ").title()
    return section_id.replace("_", " ").replace("-", " ").title()


def _section_sort_key(
    section_id: str,
    section: LayoutSection | None,
    refs: Sequence[CanonicalNodeRef],
) -> tuple[str, str, str]:
    scope_key = _common_scope(refs)
    kind = section.kind if section is not None else _generated_section_kind(section_id)
    return (scope_key, kind, section_id)


def _common_scope(refs: Sequence[CanonicalNodeRef]) -> str:
    if not refs:
        return ""
    scopes = {ref.scope_path for ref in refs}
    return scopes.pop() if len(scopes) == 1 else ""


def _common_group_scope(groups: Sequence[CompiledGroupLayout]) -> str:
    if not groups:
        return ""
    scopes = {group.scope_path for group in groups}
    return scopes.pop() if len(scopes) == 1 else ""


def _scope_depth(scope_path: str) -> int:
    if not scope_path:
        return 0
    return scope_path.count("/") + 1


def _ref_sort_key(ref: CanonicalNodeRef) -> tuple[int, str, str]:
    return (0 if ref.scope_path == "" else 1, ref.scope_path, ref.uid)


def _id_sort_key(value: str) -> tuple[int, str]:
    return (0, value.zfill(20)) if value.isdigit() else (1, value)


def _entry_key(ref: CanonicalNodeRef) -> str:
    return make_uid(ref.scope_path, ref.uid)


__all__ = [
    "COMPILE_ISSUE_BASELINE_VARIANCE_HIGH",
    "COMPILE_ISSUE_DETACHED_GROUP_DISTANCE_HIGH",
    "COMPILE_METRIC_GROUP_LAYOUT_COUNT",
    "COMPILE_METRIC_BASELINE_VARIANCE_MAX",
    "COMPILE_METRIC_DETACHED_GROUP_DISTANCE_MAX",
    "COMPILE_METRIC_HELPER_LAYOUT_COUNT",
    "COMPILE_METRIC_HELPER_SIDECAR_OVERLAP_COUNT",
    "COMPILE_METRIC_INTERNAL_WHITESPACE_RATIO_MAX",
    "COMPILE_METRIC_LONG_EDGE_DISTANCE_MAX",
    "COMPILE_METRIC_MAX_PRIMARY_NODES_PER_ROW",
    "COMPILE_METRIC_NOTE_SECTION_MISMATCH_COUNT",
    "COMPILE_METRIC_NODE_LAYOUT_COUNT",
    "COMPILE_METRIC_ORDER",
    "COMPILE_METRIC_STRUCTURAL_HASH_UNCHANGED",
    "CompiledGroupLayout",
    "CompiledNodeLayout",
    "CompiledSamplerRelation",
    "CompiledSectionTopology",
    "ExistingGroupPolicy",
    "LayoutCandidatePatch",
    "LayoutCompileOptions",
    "LayoutCompileResult",
    "SectionTemplate",
    "SpacingPreset",
    "compile_layout_plan",
    "compile_layout_plan_from_ui",
    "structural_hash_for_layout_facts",
]
