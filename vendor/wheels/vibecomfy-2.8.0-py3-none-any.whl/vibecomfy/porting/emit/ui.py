"""Emit a VibeWorkflow IR back to a litegraph (ComfyUI editor) JSON envelope.

This is the inverse direction of ingest: ``from_ui`` reads litegraph
JSON into the ``VibeWorkflow`` IR; :func:`emit_ui_json` renders an IR back out to the
litegraph shape that the ComfyUI web editor loads. It is a NEW standalone function and
deliberately NOT a ``VibeWorkflow.compile`` backend — ``compile("api")`` must stay
byte-for-byte identical and only ever produces the runtime API dict.

Identity preservation is **best-effort**, not lossless:

- ``properties["vibecomfy_uid"]`` is the stable identity key for nodes that carry a uid
  (source-derived nodes ingested from litegraph JSON). Use this for round-trip lookup.
- ``properties["vibecomfy_id"]`` is a display-only forward label (the emitter's
  variable / role name, ``{class_type}_{order}``). It renumbers on edits and must NEVER
  be used as a match key. Always present as a fallback when uid is absent.
- ``properties["Node name for S&R"]`` is the litegraph node type, as the editor expects.
- ``properties["ir_node_id"]`` is **no longer emitted** (demoted in M5). Any stale
  ``ir_node_id`` value from a captured properties blob is scrubbed before emission.

Node ids in the litegraph envelope are integers (the editor format requires it): digit
VibeNode ids keep their numeric value (``"98"`` → ``98``); non-digit ids are assigned
fresh integers above the highest digit id. Parity is unaffected because the normalizer
``str()``-coerces every node id on read-back. The top-level ``links[]`` are 6-element
arrays ``[link_id, from_node, from_slot, to_node, to_slot, type]`` over those integer
ids; ``definitions.subgraphs[].links[]`` (emitted only when the IR carries definitions)
use the litegraph OBJECT shape. ``SetNode``/``GetNode`` broadcast helpers are resolved
into direct links via :func:`collect_broadcast_sources` and omitted from ``nodes``.

No promise of lossless preservation is made. The envelope is byte-deterministic for a
given IR: same IR in → same JSON out. All node geometry is stubbed and isolated in the
single :func:`_stub_layout` helper, which M2 will replace with real layout; this module
carries no layout-quality logic of its own.

``widgets_values`` emission rule (verified empirically against the Comfy oracle)
-------------------------------------------------------------------------------
ComfyUI's ``convert_ui_to_api`` reads ``widgets_values`` *positionally* against the
raw object-info widget order, including ``None``-named UI-only slots such as
KSampler's ``control_after_generate`` position. Therefore the emitted array is laid
out against that raw order: named positions take the node's current value, ``None``
positions preserve the captured source value when available, and seed control slots
fall back to the documented ``"fixed"`` value. Trailing ``None`` is trimmed.

The retained ``VibeNode.metadata["control_after_generate"]`` — or the documented
``"fixed"`` default when absent — is recorded in the recovery report under
``control_after_generate`` with a ``control_after_generate_defaulted`` flag.

Input-slot ``widget`` objects: only inputs that are actually LINKED get an entry in the
node ``inputs`` array; an entry whose name is a widget-type input additionally carries
``"widget": {"name": <name>}`` (a widget converted to a link). Unlinked widget-type
inputs get NO input-slot entry — they live in ``widgets_values``.
"""

from __future__ import annotations
import functools
import hashlib
import json
import os
import re
import uuid
import warnings
from collections import defaultdict
from copy import deepcopy
from pathlib import Path
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from vibecomfy._compile._helpers import (
    broadcast_name,
    collect_broadcast_sources,
    is_broadcast_helper_class_type,
)
from vibecomfy.contracts.intent_nodes import (
    CLASS_TYPE_TO_KIND,
    KIND_TO_CLASS_TYPE,
    is_intent_class_type,
    intent_node_payload_from_metadata,
    validate_intent_node_contract,
    validate_runtime_code_contract,
)
from vibecomfy.errors import RuntimeConfigurationError, _safe_value_label
from vibecomfy.identity.uid import mint_local_uid
from vibecomfy.porting.endpoint_invariant import schema_input_sockets_for_unwired_node
from vibecomfy.porting.widgets.compact_resolver import compact_widget_names_for_node
from vibecomfy.porting.widgets.aliases import widget_names_for_class, widget_names_from_schema
from vibecomfy.workflow import VibeEdge, VibeNode, _get_node_mode, _raise_embedded_api_links


@dataclass(frozen=True, slots=True)
class PresentationGraphRecords:
    """Detached structural records crossing the LiteGraph presentation door."""

    nodes: Any
    links: Any
    groups: Any
    groups_present: bool


def capture_presentation_graph_records(candidate: Mapping[str, Any]) -> PresentationGraphRecords:
    """Detach the three graph-shaped presentation records from *candidate*.

    This is deliberately a shape-neutral door.  The bundle boundary retains
    its context-specific validation: UI envelopes require a node list while
    strict sidecars require a UID-keyed node mapping.
    """
    return PresentationGraphRecords(
        nodes=deepcopy(candidate.get("nodes")),
        links=deepcopy(candidate.get("links")),
        groups=deepcopy(candidate.get("groups")),
        groups_present="groups" in candidate,
    )


def is_litegraph_candidate(candidate: Mapping[str, Any]) -> bool:
    """Return whether *candidate* has a LiteGraph node-list boundary shape."""
    return isinstance(capture_presentation_graph_records(candidate).nodes, list)


def capture_ui_candidate_sidecar(workflow: VibeWorkflow, candidate: Mapping[str, Any]) -> dict[str, Any]:
    """Convert one LiteGraph capture into presentation-only sidecar data.

    This is the only raw canvas-to-presentation adapter.  The bundle module
    owns custody and pair publication, while this door owns all inspection of
    LiteGraph node, link, widget, and group records.
    """
    from vibecomfy.workflow_bundle import (
        WorkflowBundleError,
        _SIDECAR_KEYS,
    )

    if set(candidate) >= _SIDECAR_KEYS:
        return dict(candidate)

    presentation = capture_presentation_graph_records(candidate)
    raw_nodes = presentation.nodes
    if not isinstance(raw_nodes, list):
        raise WorkflowBundleError("captured candidate is not a strict sidecar or LiteGraph UI envelope")
    ids: dict[str, str] = {}
    nodes: dict[str, Any] = {}
    raw_nodes_by_id: dict[str, Mapping[str, Any]] = {}
    workflow_by_id = {str(key): node for key, node in workflow.nodes.items()}
    workflow_by_uid = {str(node.uid): node for node in workflow.nodes.values() if node.uid}
    from vibecomfy.porting.emit.emit_constants import UI_ONLY_CLASS_TYPES
    from vibecomfy._compile._helpers import RESOLVABLE_HELPER_CLASS_TYPES
    annotations: list[dict[str, Any]] = []
    expanded_native_containers = {
        str(node_id).split("::", 1)[0]
        for node_id in workflow.nodes
        if "::" in str(node_id)
    }
    ignored_captured_nodes = set(expanded_native_containers)

    raw_groups = presentation.groups if presentation.groups_present else []
    if not isinstance(raw_groups, list):
        raise WorkflowBundleError("captured groups must be a list")
    group_for_node: dict[str, str] = {}
    for group in raw_groups:
        if not isinstance(group, Mapping):
            raise WorkflowBundleError("captured group is malformed")
        group_id = group.get("vibecomfy_group_id", group.get("id"))
        if group_id is None:
            raise WorkflowBundleError("captured group has no stable presentation id")
        members = group.get("nodes", [])
        if not isinstance(members, list):
            raise WorkflowBundleError("captured group nodes must be a list")
        for member in members:
            member_key = str(member)
            prior = group_for_node.get(member_key)
            if prior is not None and prior != str(group_id):
                raise WorkflowBundleError(f"captured node {member_key!r} has ambiguous group membership")
            group_for_node[member_key] = str(group_id)
    for node in raw_nodes:
        if not isinstance(node, Mapping) or type(node.get("id")) is not int:
            raise WorkflowBundleError("captured node must contain an integer native id")
        properties = node.get("properties")
        if "properties" in node and not isinstance(properties, Mapping):
            raise WorkflowBundleError("captured node properties must be a mapping")
        native_id = str(node["id"])
        if native_id in ids:
            raise WorkflowBundleError(f"duplicate captured native node id {native_id}")
        explicit_uid = properties.get("vibecomfy_uid") if isinstance(properties, Mapping) else None
        owner = workflow_by_uid.get(explicit_uid) if isinstance(explicit_uid, str) else None
        if explicit_uid is None:
            owner = workflow_by_id.get(native_id)
        raw_class_type = node.get("type", node.get("class_type"))
        if owner is None or not owner.uid:
            if native_id in expanded_native_containers or raw_class_type in RESOLVABLE_HELPER_CLASS_TYPES:
                ignored_captured_nodes.add(native_id)
                continue
            if raw_class_type not in UI_ONLY_CLASS_TYPES:
                raise WorkflowBundleError(f"captured node {native_id!r} cannot be mapped to one Python node")
            explicit_uid = properties.get("vibecomfy_uid") if isinstance(properties, Mapping) else None
            uid = str(explicit_uid) if isinstance(explicit_uid, str) and explicit_uid else f"ui_only_{native_id}"
        else:
            uid = str(owner.uid)
        if uid in nodes:
            raise WorkflowBundleError(f"duplicate captured node UID {uid!r}")
        ids[native_id] = uid
        raw_nodes_by_id[native_id] = node
        if isinstance(properties, Mapping) and properties.get("rejected"):
            raise WorkflowBundleError(f"known node {uid!r} contains rejected metadata; reconcile the node metadata")
        entry: dict[str, Any] = {}
        for key in ("id", "pos", "size", "color", "bgcolor", "title"):
            if key not in node:
                continue
            value = node[key]
            if key in {"color", "bgcolor", "title"} and not isinstance(value, str):
                continue
            entry[key] = deepcopy(value)
        if "order" in node:
            entry["z_order"] = deepcopy(node["order"])
        elif "z_order" in node:
            entry["z_order"] = deepcopy(node["z_order"])
        flags = node.get("flags")
        if isinstance(flags, Mapping) and "collapsed" in flags:
            entry["collapsed"] = flags["collapsed"]
        elif "collapsed" in node:
            entry["collapsed"] = node["collapsed"]
        group = group_for_node.get(native_id)
        if group is not None:
            entry["group"] = str(group)
        if owner is None or not owner.uid or raw_class_type in UI_ONLY_CLASS_TYPES:
            entry["class_type"] = str(raw_class_type)
        nodes[uid] = entry
        if raw_class_type in UI_ONLY_CLASS_TYPES:
            raw_widgets = node.get("widgets_values")
            if raw_widgets is None:
                content = ""
            elif isinstance(raw_widgets, list) and (not raw_widgets or isinstance(raw_widgets[0], str)):
                content = raw_widgets[0] if raw_widgets else ""
            else:
                raise WorkflowBundleError(f"captured presentation note {uid!r} has unsupported content")
            annotations.append({
                "annotation_id": uid,
                "scope_path": "",
                "owner": {"kind": "node", "uid": uid},
                "class_type": str(raw_class_type),
                "title": entry.get("title", "") if isinstance(entry.get("title", ""), str) else "",
                "content": content,
            })
    links: list[dict[str, Any]] = []

    def semantic_port(uid: str, native_id: Any, slot: Any, direction: str) -> Any:
        """Translate a LiteGraph socket slot to its Python native roster.

        UI input arrays omit widget-backed Python parameters, so their slot
        number can differ from the native input index retained by the
        workflow. Matching the named socket is the evidence that joins those
        two representations.
        """
        owner = workflow_by_uid.get(uid)
        raw_node = raw_nodes_by_id.get(str(native_id))
        sockets = (
            raw_node.get("outputs" if direction == "output" else "inputs")
            if isinstance(raw_node, Mapping)
            else None
        )
        try:
            slot_index = int(slot)
        except (TypeError, ValueError):
            return slot
        name = None
        if (
            isinstance(sockets, list)
            and 0 <= slot_index < len(sockets)
            and isinstance(sockets[slot_index], Mapping)
        ):
            candidate_name = sockets[slot_index].get("name")
            if isinstance(candidate_name, str):
                name = candidate_name
        roster = (
            getattr(owner, f"native_{direction}_names", None)
            if owner is not None
            else None
        )
        if isinstance(roster, (list, tuple)) and name is not None:
            matches = [index for index, roster_name in enumerate(roster) if roster_name == name]
            if len(matches) == 1:
                return matches[0]
        prefix = "output_" if direction == "output" else "input_"
        if isinstance(name, str) and name.startswith(prefix) and name[len(prefix):].isdigit():
            return int(name[len(prefix):])
        return slot

    for link in presentation.links if isinstance(presentation.links, list) else ():
        if isinstance(link, Mapping):
            allowed_link = {"id", "origin_id", "origin_slot", "target_id", "target_slot", "type", "reroute"}
            unknown_link = set(link) - allowed_link
            if unknown_link:
                raise WorkflowBundleError(f"captured link contains unsupported field(s): {', '.join(sorted(str(key) for key in unknown_link))}")
            if type(link.get("id")) is not int:
                raise WorkflowBundleError("captured link must contain an integer native id")
            if "reroute" in link:
                raise WorkflowBundleError("captured link reroute geometry is unsupported; use a Reroute node")
            link = [link["id"], link.get("origin_id"), link.get("origin_slot"), link.get("target_id"), link.get("target_slot"), link.get("type", "")]
        if not isinstance(link, (list, tuple)) or len(link) not in (5, 6):
            raise WorkflowBundleError("captured link is malformed")
        if type(link[0]) is not int:
            raise WorkflowBundleError("captured link must contain an integer native id")
        if len(link) > 5 and not isinstance(link[5], str):
            raise WorkflowBundleError("captured link sixth member is not a supported presentation field")
        source, target = ids.get(str(link[1])), ids.get(str(link[3]))
        if source is None or target is None:
            if str(link[1]) in ignored_captured_nodes or str(link[3]) in ignored_captured_nodes:
                continue
            raise WorkflowBundleError("captured link endpoint does not match a captured node")
        source_entry = nodes.get(source, {})
        target_entry = nodes.get(target, {})
        if source_entry.get("class_type") in UI_ONLY_CLASS_TYPES or target_entry.get("class_type") in UI_ONLY_CLASS_TYPES:
            continue
        ref = {
            "scope_path": "",
            "from_uid": source,
            "from_port": semantic_port(source, link[1], link[2], "output"),
            "to_uid": target,
            "to_port": semantic_port(target, link[3], link[4], "input"),
        }
        item: dict[str, Any] = {
            "edge_ref": ref,
            "occurrence_index": sum(1 for prior in links if prior["edge_ref"] == ref),
            "id": link[0],
        }
        links.append(item)
    groups: list[dict[str, Any]] = []
    for group_index, group in enumerate(raw_groups):
        if not isinstance(group, Mapping):
            raise WorkflowBundleError("captured group is malformed")
        presentation_id = group.get("presentation_id", group.get("vibecomfy_group_id", group.get("id")))
        if presentation_id is None:
            raise WorkflowBundleError("captured group has no stable presentation id")
        item = {"scope_path": str(group.get("scope_path", "")), "presentation_id": str(presentation_id)}
        bounds = group.get("bounds", group.get("bounding"))
        if bounds is not None:
            item["bounds"] = deepcopy(bounds)
        for key in ("title", "color"):
            if key not in group:
                continue
            value = group[key]
            if isinstance(value, str):
                item[key] = deepcopy(value)
        item["z_order"] = deepcopy(group.get("order", group.get("z_order", group_index)))
        groups.append(item)
    canvas: dict[str, Any] = {}
    raw_canvas = candidate.get("canvas")
    if isinstance(raw_canvas, Mapping):
        for key in ("zoom", "pan"):
            if key in raw_canvas:
                canvas[key] = deepcopy(raw_canvas[key])
    extra = candidate.get("extra")
    ds = extra.get("ds") if isinstance(extra, Mapping) else None
    if isinstance(ds, Mapping):
        canvas.setdefault("zoom", ds.get("scale"))
        canvas.setdefault("pan", ds.get("offset"))
    return {
        "format_version": 1,
        "bind": {"workflow_identity": workflow.id, "semantic_digest": workflow.semantic_digest()},
        "nodes": nodes,
        "links": links,
        "groups": groups,
        "canvas": canvas,
        "annotations": annotations,
    }


def canonical_presentation_to_layout_store(
    presentation: Mapping[str, Any],
) -> dict[str, Any]:
    """Adapt validated v2 presentation records to the legacy UI preserve seam.

    The canonical companion remains the source of truth.  This adapter exists
    only because the established UI emitter consumes the older furniture-store
    shape; custody and semantic graph records never cross this boundary.
    """
    entries: dict[str, dict[str, Any]] = {}
    raw_nodes = presentation.get("nodes", {})
    if isinstance(raw_nodes, Mapping):
        for uid, raw_entry in raw_nodes.items():
            if not isinstance(raw_entry, Mapping):
                continue
            entries[str(uid)] = {
                key: deepcopy(raw_entry[key])
                for key in (
                    "pos",
                    "size",
                    "flags",
                    "color",
                    "bgcolor",
                    "mode",
                    "properties",
                )
                if key in raw_entry
            }

    extra: dict[str, Any] = {}
    canvas = presentation.get("canvas")
    if isinstance(canvas, Mapping):
        ds: dict[str, Any] = {}
        if "zoom" in canvas:
            ds["scale"] = deepcopy(canvas["zoom"])
        if "pan" in canvas:
            ds["offset"] = deepcopy(canvas["pan"])
        if ds:
            extra["ds"] = ds

    return {
        "store_version": 2,
        "entries": entries,
        "groups": deepcopy(presentation.get("groups", [])),
        "extra": extra,
        "lastRerouteId": None,
        "definitions": {},
        "virtual_wires": {},
    }


def _overlay_from_store_on_canonical_presentation(
    presentation: Mapping[str, Any],
    from_store: Mapping[str, Any] | None,
) -> dict[str, Any]:
    """Apply explicit ``--from`` furniture edits without dropping annotations.

    A v2 companion is the authoritative presentation record.  The established
    layout store is useful for reading a user's explicit ``--from`` canvas, but
    its projection intentionally omits annotation content.  Merge only
    presentation fields for UIDs already owned by the canonical pair; semantic
    and annotation records remain sourced from the companion.
    """
    merged = deepcopy(presentation)
    canonical_nodes = merged.get("nodes")
    source_entries = from_store.get("entries") if isinstance(from_store, Mapping) else None
    if not isinstance(canonical_nodes, dict) or not isinstance(source_entries, Mapping):
        return merged

    furniture_fields = (
        "pos", "size", "collapsed", "color", "bgcolor", "title", "group", "z_order",
    )
    for uid, source_entry in source_entries.items():
        canonical_entry = canonical_nodes.get(str(uid))
        if not isinstance(canonical_entry, dict) or not isinstance(source_entry, Mapping):
            continue
        for field in furniture_fields:
            if field in source_entry:
                canonical_entry[field] = deepcopy(source_entry[field])
    return merged


# Documented default control_after_generate mode when none is retained in metadata.
_CONTROL_AFTER_GENERATE_DEFAULT = "fixed"

# Stable namespace so a given workflow id always yields the same envelope id.
_ENVELOPE_ID_NAMESPACE = uuid.UUID("6f1d2c3a-4b5e-4a6c-8d9e-0f1a2b3c4d5e")

# Litegraph editor format version this emitter targets.
_LITEGRAPH_VERSION = 1.0

# Layout-schema version stamped into the breadcrumb (extra.vibecomfy.layout_version).
# M2 replaces _stub_layout with real layout and will bump this. M3 preserve-mode keys
# off the breadcrumb, so the version travels with the file.
_LAYOUT_VERSION = "m4"

# Default directory and subdirectory for emitted UI exports.
_DEFAULT_OUT_DIR = "out"
_UI_EXPORT_SUBDIR = "ui_export"

# Deterministic grid geometry constants used only by ``_stub_layout``.
_STUB_COLUMN_WIDTH = 400
_STUB_ROW_HEIGHT = 200
_STUB_COLUMNS = 4
_STUB_NODE_SIZE = [320, 180]

# M2 canonicalization precision (2 decimal places) for all emitted coordinates.
# Every pos/size/group-bounding value is rounded through this precision so two
# machines emit byte-identical JSON regardless of CWD, env, or float quirks.
_M2_PRECISION = 2

# Fixed default canvas drag/scale state for ``extra.ds`` when
# ``include_main_positions=True`` and no sidecar ``extra`` provides overrides.
_DEFAULT_DS = {"scale": 1.0, "offset": [0.0, 0.0]}

# Door-owned wire-retention metadata key (mirror of
# ``vibecomfy.ingest.normalize._UI_DOOR_KEY``).  Only the door boundary reads
# or writes the blob; this literal avoids importing normalize at module level.
_UI_DOOR_KEY = "_ui_door"

# S4: chunked/lazy emit for 400+ node graphs (506ebd). A single-pass emit of a
# 500-node workflow allocates large intermediate lists and floods stderr with
# per-node schema-less warnings ( 500× UserWarning ), pushing wall-time past
# the 480s turn budget before the agent can reply. Chunked emit processes
# nodes in bounded slices and aggregates warnings so memory and wall-time stay
# linear; the emitted envelope is byte-identical to the single-pass path.
_CHUNKED_EMIT_NODE_THRESHOLD_DEFAULT = 400
_CHUNKED_EMIT_CHUNK_SIZE_DEFAULT = 128
_CHUNKED_EMIT_WARN_EVERY_DEFAULT = 50


def _positive_int_value(raw: Any, *, name: str) -> int:
    if isinstance(raw, bool):
        raise RuntimeConfigurationError(
            f"Invalid {name} value: booleans are not positive integers.",
            next_action=f"Unset {name} or set it to a positive integer.",
        )
    if type(raw) is int:
        value = raw
    elif type(raw) is str:
        try:
            value = int(raw)
        except (TypeError, ValueError, OverflowError) as exc:
            raise RuntimeConfigurationError(
                f"Invalid {name} value {_safe_value_label(raw)}; expected a positive integer.",
                next_action=f"Unset {name} or set it to a positive integer.",
            ) from exc
    else:
        raise RuntimeConfigurationError(
            f"Invalid {name} value {_safe_value_label(raw)}; expected a positive integer.",
            next_action=f"Unset {name} or set it to a positive integer.",
        )
    if value <= 0:
        raise RuntimeConfigurationError(
            f"Invalid {name} value {_safe_value_label(raw)}; expected a positive integer.",
            next_action=f"Unset {name} or set it to a positive integer.",
        )
    return value


def _positive_int_env(name: str, default: int) -> int:
    raw = os.environ.get(name)
    if raw is None or raw == "":
        return default
    return _positive_int_value(raw, name=name)


def _chunked_emit_settings() -> tuple[int, int, int]:
    """Read chunked-emitter settings at call time with actionable validation."""
    return (
        _positive_int_env(
            "VIBECOMFY_CHUNKED_EMIT_THRESHOLD",
            _CHUNKED_EMIT_NODE_THRESHOLD_DEFAULT,
        ),
        _positive_int_env(
            "VIBECOMFY_CHUNKED_EMIT_CHUNK_SIZE",
            _CHUNKED_EMIT_CHUNK_SIZE_DEFAULT,
        ),
        _positive_int_env(
            "VIBECOMFY_CHUNKED_EMIT_WARN_EVERY",
            _CHUNKED_EMIT_WARN_EVERY_DEFAULT,
        ),
    )

# Some custom nodes expose a variable number of LiteGraph output sockets while
# their object_info schema can only describe the base return type.  Inspire's
# batch splitters are the important example: ``split_count`` image/latent
# outputs are followed by one ``remained`` output, so the editor addresses
# them at slots 1..split_count (slot 0 is the remainder).  Keep this contract
# explicit and bounded rather than treating every schema/edge disagreement as
# an inferred output; ordinary phantom endpoints must still refuse emission.
_DYNAMIC_OUTPUT_COUNT_INPUTS = {
    "ImageBatchSplitter //Inspire": ("split_count", "IMAGE", 50),
    "LatentBatchSplitter //Inspire": ("split_count", "LATENT", 50),
}


@dataclass(frozen=True)
class _DynamicOutputSpec:
    type: str
    name: str


def _dynamic_output_count(
    node: Any,
    schema: Any | None,
) -> int | None:
    """Return dynamic output arity for the small, evidence-backed node set."""
    contract = _DYNAMIC_OUTPUT_COUNT_INPUTS.get(getattr(node, "class_type", ""))
    if contract is None:
        return None
    input_name, _output_type, maximum = contract
    candidates: list[Any] = []
    inputs = getattr(node, "inputs", None)
    widgets = getattr(node, "widgets", None)
    if isinstance(inputs, Mapping):
        candidates.append(inputs.get(input_name))
    if isinstance(widgets, Mapping):
        candidates.extend((widgets.get(input_name), widgets.get("widget_0")))
    raw_widgets = getattr(getattr(node, "raw_widgets", None), "values", None)
    if isinstance(raw_widgets, list) and raw_widgets:
        candidates.append(raw_widgets[-1])
    schema_inputs = getattr(schema, "inputs", None)
    if isinstance(schema_inputs, Mapping):
        spec = schema_inputs.get(input_name)
        candidates.append(getattr(spec, "default", None))
    for value in candidates:
        # bool is an int subclass but is not a valid Comfy widget value.
        if type(value) is int and 0 <= value <= maximum:
            return value + 1  # remainder slot + split_count item slots
    return None


def _materialized_schema_outputs(
    node: Any,
    schema: Any | None,
) -> list[Any]:
    """Expand an explicitly dynamic node's base output schema for the editor."""
    native_names = getattr(node, "native_output_names", None)
    native_types = getattr(node, "native_output_types", None)
    if isinstance(native_names, list):
        # A node's retained native roster is the exact materialized socket
        # shape.  A class schema is only a generic declaration and may be
        # older or shorter than a particular rendered node (including
        # positional holes), so it cannot collapse those retained indices.
        base = [
            _DynamicOutputSpec(
                (
                    native_types[slot]
                    if isinstance(native_types, list)
                    and slot < len(native_types)
                    and native_types[slot] is not None
                    else ""
                ),
                name or f"output_{slot}",
            )
            for slot, name in enumerate(native_names)
        ]
    else:
        base = list(getattr(schema, "outputs", None) or []) if schema else []
    count = _dynamic_output_count(node, schema)
    if count is None or not base:
        return base
    output_type = getattr(base[0], "type", None) or _DYNAMIC_OUTPUT_COUNT_INPUTS[node.class_type][1]
    output_name = getattr(base[0], "name", None) or output_type
    return [
        *base,
        *(_DynamicOutputSpec(output_type, f"{output_name}_{slot}") for slot in range(len(base), count)),
    ]


def _door_ui_passthrough_applicable(
    wf: Any,
    door: Any,
    *,
    include_virtual_wires: bool,
    include_main_positions: bool,
    extra: Mapping[str, Any] | None,
    definitions: Mapping[str, Any] | None,
    prior_store: Mapping[str, Any] | None,
    layout: Any,
    strict: bool,
) -> bool:
    """Law 1 passthrough gate: may this UNTOUCHED graph be re-emitted verbatim?

    The door blob is consulted only when the caller asks for the default output
    shape (no flat/virtual-wire toggle, no main positions, no explicit
    extra/definitions/prior_store/layout overrides, no strict request) and the
    graph was ingested through the OFFLINE normalizer (``use_comfy_converter``
    is recorded at ingest).  Comfy-converter ingest is not guaranteed to
    normalize back to the same API, so those graphs keep the deterministic
    reconstruction path.  The final fingerprint comparison proves the graph is
    untouched since ingest; anything else takes the reconstruction path (where
    captured wire values are still preferred for unaffected parts).
    """
    if not isinstance(door, Mapping):
        return False
    if door.get("shape") != "ui":
        return False
    if door.get("use_comfy_converter") is not False:
        return False
    if not include_virtual_wires or include_main_positions or strict:
        return False
    if extra is not None or definitions is not None:
        return False
    if prior_store or layout:
        return False
    if not isinstance(door.get("top"), Mapping) or not isinstance(door.get("nodes"), Mapping):
        return False
    if not isinstance(door.get("node_order"), list):
        return False
    from vibecomfy.ingest.normalize import _door_node_fingerprint  # noqa: PLC0415

    return _door_node_fingerprint(wf) == door.get("fingerprint")


def _emit_untouched_door_ui(door: Mapping[str, Any]) -> dict[str, Any]:
    """Rebuild the original litegraph envelope byte-for-byte from the door blob.

    Preserves the raw top-level key order, every raw top-level field (id,
    version, counters, links with ids/order/type, extra, definitions, state,
    config, revision, opaque keys), and the raw node payloads in raw order —
    node geometry, ``order``, ``properties``, ``widgets_values``, input/output
    link refs included.  The result is a detached deep copy.
    """
    from vibecomfy.ingest.normalize import _restore_untouched_door  # noqa: PLC0415

    return _restore_untouched_door(door)


def _door_top(door: Any) -> Mapping[str, Any] | None:
    """Return the door blob's captured top-level fields, or None."""
    if not isinstance(door, Mapping):
        return None
    top = door.get("top")
    return top if isinstance(top, Mapping) else None


def _wire_id(wf: Any, door: Any) -> str:
    """Envelope id: the captured wire id when present, else the deterministic id."""
    top = _door_top(door)
    if isinstance(top, Mapping) and isinstance(top.get("id"), str) and top["id"]:
        return top["id"]
    return _envelope_id(wf)


def _wire_version(door: Any) -> Any:
    """Envelope ``version``: the captured wire value when present."""
    top = _door_top(door)
    if isinstance(top, Mapping) and isinstance(top.get("version"), (int, float)) and not isinstance(
        top["version"], bool
    ):
        return top["version"]
    return _LITEGRAPH_VERSION


def _wire_counter(door: Any, key: str, computed: int) -> int:
    """Counter field: captured value when still consistent (>= computed), else recomputed."""
    top = _door_top(door)
    captured = top.get(key) if isinstance(top, Mapping) else None
    if isinstance(captured, int) and not isinstance(captured, bool) and captured >= computed:
        return captured
    return computed


def _captured_link_id_map(
    door: Any,
) -> dict[tuple[str, str, str, str], int]:
    """Map IR edge keys ``(from_node, from_output, to_node, to_input)`` to the
    ORIGINAL litegraph link ids captured at ingest.

    Endpoints resolve through the captured raw node payloads: each captured
    link id is located in the captured to-node's ``inputs`` (name) and the
    captured from-node's ``outputs`` (``slot_index``).  Links that cannot be
    resolved (helper endpoints, missing slots) are simply absent from the map —
    the emitter mints fresh ids for those.  This lets an edited graph keep the
    original ids for structurally unchanged links (Law 1, wire preference).
    """
    if not isinstance(door, Mapping):
        return {}
    top = _door_top(door)
    links = top.get("links") if isinstance(top, Mapping) else None
    nodes = door.get("nodes") if isinstance(door.get("nodes"), Mapping) else {}
    if not isinstance(links, list):
        return {}
    input_name_by_link: dict[int, tuple[str, str]] = {}
    output_slot_by_link: dict[int, tuple[str, str]] = {}
    for nid, payload in nodes.items():
        if not isinstance(payload, Mapping):
            continue
        for entry in payload.get("inputs") or []:
            if not isinstance(entry, Mapping):
                continue
            link_ref = entry.get("link")
            if isinstance(link_ref, int):
                input_name_by_link[link_ref] = (str(nid), str(entry.get("name", "")))
        for output_index, entry in enumerate(payload.get("outputs") or []):
            if not isinstance(entry, Mapping):
                continue
            # Ordinary ComfyUI workflow JSON identifies an output's socket by
            # its array position and usually omits ``slot_index``.  Treat the
            # explicit field as an override, not a prerequisite, otherwise the
            # captured map is empty and every preserved link is spuriously
            # renumbered after the first structural edit.
            slot = entry.get("slot_index", output_index)
            try:
                slot_int = int(slot)
            except (TypeError, ValueError):
                continue
            for link_ref in entry.get("links") or []:
                if isinstance(link_ref, int):
                    output_slot_by_link[link_ref] = (str(nid), str(slot_int))
    result: dict[tuple[str, str, str, str], int] = {}
    for link in links:
        if not isinstance(link, (list, tuple)) or len(link) < 5:
            continue
        lid = link[0]
        if not isinstance(lid, int):
            continue
        from_node, to_node = str(link[1]), str(link[3])
        in_info = input_name_by_link.get(lid)
        out_info = output_slot_by_link.get(lid)
        if in_info is None or out_info is None:
            continue
        if in_info[0] != to_node or out_info[0] != from_node:
            continue
        result[(from_node, out_info[1], to_node, in_info[1])] = lid
    return result


def _captured_link_id_map_from_ui_payload(
    payload: Mapping[str, Any] | None,
) -> dict[tuple[str, str, str, str], int]:
    """Read retained link identities from a detached LiteGraph envelope.

    Bundle companions do not carry the ingest door, but the edit evaluator
    still has the materialized UI snapshot that preserves native link ids.
    Reuse the door mapper's endpoint checks rather than inventing a second
    link identity rule for that presentation boundary.
    """
    if not isinstance(payload, Mapping) or not isinstance(payload.get("nodes"), list):
        return {}
    nodes = {
        str(node.get("id")): node
        for node in payload.get("nodes", [])
        if isinstance(node, Mapping) and node.get("id") is not None
    }
    if not nodes:
        return {}
    return _captured_link_id_map(
        {
            "top": payload,
            "nodes": nodes,
        }
    )


def _intent_recovery_fields(node: Any) -> dict[str, Any]:
    class_type = str(getattr(node, "class_type", ""))
    payload = intent_node_payload_from_metadata(getattr(node, "metadata", None))
    intent_result = validate_intent_node_contract(
        node_id=str(getattr(node, "id", "")),
        class_type=class_type,
        metadata=getattr(node, "metadata", None),
    )
    runtime_result = validate_runtime_code_contract(
        class_type=class_type,
        payload=payload,
        require_runtime=True,
    )
    runtime_backed = (
        class_type == KIND_TO_CLASS_TYPE["code"]
        and intent_result.ok
        and runtime_result.ok
    )
    return {
        "uid": getattr(node, "uid", None) or intent_result.vibecomfy_uid,
        "kind": intent_result.kind or CLASS_TYPE_TO_KIND.get(class_type),
        "lowered": False,
        "runtime_backed": runtime_backed,
        "runtime_contract_valid": runtime_result.ok,
        "intent_contract_valid": intent_result.ok,
        "contract_problem_codes": [
            problem.code for problem in (*intent_result.problems, *runtime_result.problems)
        ],
    }

# Confidence threshold at or below which a node is considered low-confidence.
# widget_schema_fallback tier uses confidence=0.3; strict=True rejects it.
_LOW_CONFIDENCE_THRESHOLD = 0.3
_STATIC_WIDGET_OVERFLOW_TOLERANCE = 4
_STATIC_RAW_WIDGET_SLACK_CLASSES = frozenset(
    {"CheckpointLoaderSimple", "KSampler", "KSamplerAdvanced"}
)
_PRIMITIVE_CONTROL_WIDGET_CLASSES = frozenset(
    {"PrimitiveBoolean", "PrimitiveFloat", "PrimitiveInt"}
)


@dataclass(frozen=True, slots=True)
class WidgetShapeEvidence:
    node_id: str
    class_type: str
    schema_less: bool
    confidence: float | None
    raw_widget_count: int | None
    candidate_widget_count: int
    schema_widget_count: int | None
    compacted_widget_names: tuple[str, ...]
    raw_widget_shape: str | None
    has_dict_rows: bool
    overflow: bool
    provider: str | None
    explicit_widget_overflow: bool = False
    raw_widget_length_recovered: bool = False
    value_domain: str = "compact"


def _canonicalize_coord(value: float) -> float:
    """Round a coordinate value to M2 precision (2 decimal places).

    Every pos/size/group-bounding value emitted by this module passes through this
    helper so two machines produce byte-identical JSON regardless of CWD, env,
    or minor float-representation differences.
    """
    return round(value, _M2_PRECISION)


def _canonicalize_group_geometry(groups: list[dict[str, Any]]) -> None:
    """Canonicalize ``bounding`` arrays in-place for every group in ``groups``.

    Each group's ``bounding`` is ``[x, y, width, height]`` — all four values are
    rounded to M2 precision.  Groups without a valid ``bounding`` are left alone.
    This guarantees byte-identical group geometry across machines when
    ``include_main_positions=True``.
    """
    for g in groups:
        bbox = g.get("bounding")
        if isinstance(bbox, (list, tuple)) and len(bbox) == 4:
            g["bounding"] = [
                _canonicalize_coord(float(bbox[0])),
                _canonicalize_coord(float(bbox[1])),
                _canonicalize_coord(float(bbox[2])),
                _canonicalize_coord(float(bbox[3])),
            ]


def _extend_groups_for_anchored_nodes(
    groups: list[dict[str, Any]],
    nodes: list[dict[str, Any]],
    anchors: Mapping[str, Any],
    explicit_groups: Mapping[str, str],
) -> None:
    """Keep anchor-placed nodes inside their retained regular canvas group."""
    if not groups or not anchors:
        return

    node_by_uid: dict[str, Mapping[str, Any]] = {}
    for node in nodes:
        properties = node.get("properties") if isinstance(node, Mapping) else None
        uid = properties.get("vibecomfy_uid") if isinstance(properties, Mapping) else None
        if uid not in (None, ""):
            node_by_uid[str(uid)] = node

    base_bounds: list[tuple[float, float, float, float] | None] = []
    for group in groups:
        bounding = group.get("bounding") if isinstance(group, Mapping) else None
        if not isinstance(bounding, (list, tuple)) or len(bounding) < 4:
            base_bounds.append(None)
            continue
        try:
            base_bounds.append(tuple(float(value) for value in bounding[:4]))
        except (TypeError, ValueError):
            base_bounds.append(None)

    def _node_box(uid: str) -> tuple[float, float, float, float] | None:
        node = node_by_uid.get(uid)
        if node is None:
            return None
        pos, size = node.get("pos"), node.get("size")
        if not isinstance(pos, (list, tuple)) or not isinstance(size, (list, tuple)):
            return None
        if len(pos) < 2 or len(size) < 2:
            return None
        try:
            return float(pos[0]), float(pos[1]), float(size[0]), float(size[1])
        except (TypeError, ValueError):
            return None

    def _containing_group(uid: str) -> int | None:
        box = _node_box(uid)
        if box is None:
            return None
        x, y, width, height = box
        center_x, center_y = x + width / 2.0, y + height / 2.0
        candidates: list[tuple[float, int]] = []
        for index, bounds in enumerate(base_bounds):
            if bounds is None:
                continue
            gx, gy, gw, gh = bounds
            if gx <= center_x <= gx + gw and gy <= center_y <= gy + gh:
                candidates.append((gw * gh, index))
        return min(candidates)[1] if candidates else None

    assignments: dict[str, int] = {}
    pending = {str(uid): str(anchor) for uid, anchor in anchors.items()}
    for uid, title in explicit_groups.items():
        matches = [
            index
            for index, group in enumerate(groups)
            if str(group.get("title") or "") == str(title)
        ]
        if matches:
            assignments[str(uid)] = min(
                matches,
                key=lambda index: (
                    float("inf")
                    if base_bounds[index] is None
                    else base_bounds[index][2] * base_bounds[index][3],
                    index,
                ),
            )

    while pending:
        progressed = False
        for uid, anchor_uid in tuple(pending.items()):
            group_index = assignments.get(uid)
            if group_index is None:
                group_index = assignments.get(anchor_uid)
            if group_index is None:
                group_index = _containing_group(anchor_uid)
            if group_index is None:
                continue
            assignments[uid] = group_index
            pending.pop(uid)
            progressed = True
        if not progressed:
            break

    for uid, group_index in assignments.items():
        box = _node_box(uid)
        if box is None or group_index >= len(groups):
            continue
        x, y, width, height = box
        group = groups[group_index]
        bounding = group.get("bounding")
        if not isinstance(bounding, (list, tuple)) or len(bounding) < 4:
            continue
        gx, gy, gw, gh = (float(value) for value in bounding[:4])
        left, top = min(gx, x), min(gy, y)
        right, bottom = max(gx + gw, x + width), max(gy + gh, y + height)
        group["bounding"] = [left, top, right - left, bottom - top]


def _stub_layout(order: int) -> dict[str, list[float]]:
    """Return deterministic placeholder geometry for the ``order``-th emitted node.

    ALL layout decisions live here. The grid is a pure function of emission order, so
    the same IR always produces identical positions. M2 replaces this helper with real
    layout; nothing elsewhere in the emitter reasons about geometry.
    """
    col = order % _STUB_COLUMNS
    row = order // _STUB_COLUMNS
    return {
        "pos": [
            _canonicalize_coord(float(col * _STUB_COLUMN_WIDTH)),
            _canonicalize_coord(float(row * _STUB_ROW_HEIGHT)),
        ],
        "size": [_canonicalize_coord(s) for s in _STUB_NODE_SIZE],
    }


def _extract_geometry(layout_entry: dict | None) -> dict[str, list[float]] | None:
    """Extract {pos, size} from a layout-store entry, or None.

    This isolates the pos/size geometry chain from the furniture resolver so the
    two paths never accidentally couple.  A layout entry that is ``None`` or
    lacks a valid ``pos`` returns ``None``, letting the caller fall through to
    ``_captured_geometry`` or ``_stub_layout``.
    """
    if not isinstance(layout_entry, dict):
        return None
    pos = layout_entry.get("pos")
    size = layout_entry.get("size")
    if not isinstance(pos, (list, tuple)) or len(pos) < 2:
        return None
    if not isinstance(size, (list, tuple)) or len(size) < 2:
        return None
    return {
        "pos": [_canonicalize_coord(float(pos[0])), _canonicalize_coord(float(pos[1]))],
        "size": [_canonicalize_coord(float(size[0])), _canonicalize_coord(float(size[1]))],
    }


def _resolve_furniture(
    node: Any,
    layout_entry: dict | None,
) -> dict[str, Any]:
    """Resolve display furniture while taking mode only from the IR node.

    This is a SEPARATE path from the pos/size geometry chain
    (:func:`_captured_geometry`).  Precedence:

    1. Sidecar entry (``layout_entry``) for flags, colors, properties, and title.
    2. ``node.metadata['_ui']`` for those same fields when no sidecar exists.
    3. :func:`vibecomfy.workflow._get_node_mode` for mode.  This is the exact
       authority used by compilation, including its single legacy ``_ui.mode``
       fallback.
    4. Fixed defaults (``flags={}``, ``color=None``, ``bgcolor=None``,
       ``properties={}``, ``title=None``).

    Returns a dict with keys ``flags``, ``color``, ``bgcolor``, ``mode``,
    ``properties``, ``title``.
    """
    # Source 1: sidecar entry (authoritative)
    if layout_entry:
        flags = layout_entry.get("flags")
        color = layout_entry.get("color")
        bgcolor = layout_entry.get("bgcolor")
        properties = layout_entry.get("properties")
        title = layout_entry.get("title")
    else:
        # Source 2: node.metadata['_ui'] (direct-ingest fallback)
        _ui = getattr(node, "metadata", {}).get("_ui")
        if isinstance(_ui, dict):
            flags = _ui.get("flags")
            color = _ui.get("color")
            bgcolor = _ui.get("bgcolor")
            properties = _ui.get("properties")
            title = _ui.get("title")
        else:
            flags = None
            color = None
            bgcolor = None
            properties = None
            title = None

    # Source 3: fixed defaults
    if not isinstance(flags, dict):
        flags = {}
    if not isinstance(properties, dict):
        properties = {}
    # title stays None for absent/default — the caller decides whether to emit it

    return {
        "flags": flags,
        "color": color,
        "bgcolor": bgcolor,
        "mode": _get_node_mode(node),
        "properties": properties,
        "title": title,
    }


def _captured_geometry(node: Any) -> dict[str, list[float]] | None:
    """Return first-class ``{pos, size}``, or ``None`` when either is absent.

    The ``None`` fallthrough is intentional: callers should chain through to
    ``_stub_layout`` when no captured geometry exists (e.g. programmatic nodes
    or workflows loaded from a .py file without a sidecar).
    """
    pos = getattr(node, "pos", None)
    size = getattr(node, "size", None)
    if not isinstance(pos, (list, tuple)) or len(pos) < 2:
        return None
    if not isinstance(size, (list, tuple)) or len(size) < 2:
        return None
    return {
        "pos": [_canonicalize_coord(float(pos[0])), _canonicalize_coord(float(pos[1]))],
        "size": [_canonicalize_coord(float(size[0])), _canonicalize_coord(float(size[1]))],
    }


def _envelope_id(wf: Any) -> str:
    """Deterministic envelope id derived from the workflow id."""
    return str(uuid.uuid5(_ENVELOPE_ID_NAMESPACE, str(getattr(wf, "id", "workflow"))))


def _source_template_name(wf: Any) -> str | None:
    """Best-effort source-template name for the breadcrumb / output path.

    Prefers an explicit source id, then the source file stem.  The ingest default
    id ``"workflow"`` (and an empty value) is treated as *unnamed* so the IR-hash
    fallback path takes over.  Returns ``None`` when no real name is available.
    """
    source = getattr(wf, "source", None)
    candidate = getattr(source, "id", None) if source is not None else None
    if isinstance(candidate, str) and candidate and candidate != "workflow":
        return candidate
    path = getattr(source, "path", None) if source is not None else None
    if isinstance(path, str) and path:
        stem = Path(path).stem
        if stem:
            return stem
    wf_id = getattr(wf, "id", None)
    if isinstance(wf_id, str) and wf_id and wf_id != "workflow":
        return wf_id
    return None


def _source_prior_path(wf: Any) -> str | None:
    """The originating file path (M3 preserve-mode reads extra.vibecomfy.prior_path)."""
    source = getattr(wf, "source", None)
    path = getattr(source, "path", None) if source is not None else None
    return path if isinstance(path, str) and path else None


def _ir_hash(wf: Any) -> str:
    """Stable short hash of the IR structure, for naming unnamed sources.

    Hashes a canonical, order-independent projection of nodes (id + class_type)
    and edges so the same IR always yields the same name and the path is never
    empty or raising.
    """
    nodes = sorted((nid, node.class_type) for nid, node in wf.nodes.items())
    edges = sorted(
        (e.from_node, e.from_output, e.to_node, e.to_input) for e in wf.edges
    )
    payload = json.dumps({"nodes": nodes, "edges": edges}, sort_keys=True)
    return hashlib.sha1(payload.encode("utf-8")).hexdigest()[:16]


def _breadcrumb(wf: Any, source_template: str | None, prior_path: str | None) -> dict[str, Any]:
    """Build the ``extra.vibecomfy`` breadcrumb stamped on the envelope/subgraphs."""
    return {
        "layout_version": _LAYOUT_VERSION,
        "source_template": source_template if source_template is not None else _source_template_name(wf),
        "prior_path": prior_path if prior_path is not None else _source_prior_path(wf),
    }


def default_output_path(
    wf: Any,
    *,
    out: str | None = None,
    source_template: str | None = None,
    out_dir: str = _DEFAULT_OUT_DIR,
) -> Path:
    """Deterministic output path for an emitted UI export.

    ``--out`` (the ``out`` argument) overrides everything.  Otherwise the path is
    ``<out_dir>/ui_export/<source_template>.json`` when a source-template name is
    available, falling back to ``<out_dir>/ui_export/<ir-hash>.json`` for unnamed
    (programmatic) sources.  The fallback hash guarantees the path is never empty
    and never raises.
    """
    if out:
        return Path(out)
    name = source_template if source_template is not None else _source_template_name(wf)
    if name:
        safe = re.sub(r"[^A-Za-z0-9._/-]", "_", name)
        # Collapse path-traversal and leading separators so the name stays under out_dir.
        safe = safe.replace("..", "_").lstrip("/") or _ir_hash(wf)
    else:
        safe = _ir_hash(wf)
    return Path(out_dir) / _UI_EXPORT_SUBDIR / f"{safe}.json"


def _emission_order(wf: Any) -> list[str]:
    """Deterministic node emission order: numeric ids ascending, then lexical."""

    def key(node_id: str) -> tuple[int, str]:
        return (int(node_id), node_id) if node_id.isdigit() else (1 << 30, node_id)

    return sorted(wf.nodes.keys(), key=key)


def _flat_layout_workflow(
    wf: Any,
    virtual_wire_ids: set[str],
    flat_edges: list[Any],
) -> Any:
    """Return a shallow flat-graph view of *wf* for layout computation.

    Flat mode (``include_virtual_wires=False``) drops virtual-wire nodes
    (SetNode/GetNode/Reroute) from the emitted node list and resolves their
    edges into direct links.  The layout engine must therefore compute
    positions against the same flat projection — otherwise a workflow whose
    helpers were retained in the IR (``--keep-virtual-wires``) would lay out
    real nodes at different layers/lanes than an identical flat graph whose
    helpers were resolved during conversion, breaking flat round-trip
    byte-equivalence (``test_keep_virtual_wires_round_trip``).

    The view is a shallow ``dataclasses.replace``: node objects, inputs and
    metadata are shared with the original workflow (never mutated by the
    engine); only the node dict and edge list are the flat projection.  Node
    uids are preserved, so ``engine_positions[uid]`` still resolves for every
    surviving node in the caller's ``order_list``.
    """
    import dataclasses  # noqa: PLC0415

    flat_nodes = {
        node_id: node
        for node_id, node in wf.nodes.items()
        if node_id not in virtual_wire_ids
    }
    flat_inputs = {
        name: value
        for name, value in (getattr(wf, "inputs", None) or {}).items()
        if str(getattr(value, "node_id", "") or "") in flat_nodes
    }
    return dataclasses.replace(
        wf,
        nodes=flat_nodes,
        edges=list(flat_edges),
        inputs=flat_inputs,
    )


def _build_id_remap(order_list: list[str]) -> dict[str, int]:
    """Map string VibeNode ids → litegraph integer node ids.

    Digit ids keep their numeric value (so source-derived ``"98"`` stays ``98`` and the
    envelope matches the litegraph reference field-for-field).  Non-digit ids (e.g.
    typed-wrapper labels) are assigned fresh integers above the highest digit id, never
    colliding with a preserved value.  This mapping only governs the litegraph ``id`` field
    and the node-id slots inside ``links[]``.
    """
    remap: dict[str, int] = {}
    used: set[int] = set()
    for node_id in order_list:
        if node_id.isdigit():
            value = int(node_id)
            remap[node_id] = value
            used.add(value)
    nxt = (max(used) + 1) if used else 1
    for node_id in order_list:
        if node_id in remap:
            continue
        while nxt in used:
            nxt += 1
        remap[node_id] = nxt
        used.add(nxt)
        nxt += 1
    return remap


def _remap_ir_groups(
    wf: Any,
    order_list: list[str],
    id_remap: Mapping[str, int],
) -> list[dict[str, Any]]:
    """Deep-copy IR groups and resolve live members to LiteGraph integer ids.

    Group membership may have been captured at different boundaries, so each
    live node contributes aliases for its workflow mapping key, ``node.id``,
    stable uid, and captured ``_ui.id``.  Numeric aliases accept either their
    integer or decimal-string form.  Ambiguous aliases and stale members are
    omitted instead of emitting a dangling reference.
    """
    candidates: dict[tuple[str, Any], set[int]] = defaultdict(set)

    def add_alias(value: Any, emitted_id: int) -> None:
        if isinstance(value, bool):
            return
        if isinstance(value, int):
            candidates[("int", value)].add(emitted_id)
            candidates[("str", str(value))].add(emitted_id)
        elif isinstance(value, str) and value:
            candidates[("str", value)].add(emitted_id)
            if value.isdigit():
                candidates[("int", int(value))].add(emitted_id)

    for workflow_node_id in order_list:
        node = wf.nodes[workflow_node_id]
        emitted_id = id_remap[workflow_node_id]
        add_alias(workflow_node_id, emitted_id)
        add_alias(getattr(node, "id", None), emitted_id)
        add_alias(getattr(node, "uid", None), emitted_id)
        raw_ui = getattr(node, "metadata", {}).get("_ui")
        if isinstance(raw_ui, dict):
            add_alias(raw_ui.get("id"), emitted_id)

    aliases = {key: next(iter(ids)) for key, ids in candidates.items() if len(ids) == 1}
    remapped: list[dict[str, Any]] = []
    for raw_group in deepcopy(getattr(wf, "groups", [])):
        group = dict(raw_group)
        members = group.get("nodes")
        if isinstance(members, list):
            resolved: list[int] = []
            for member in members:
                if isinstance(member, bool):
                    continue
                key = (
                    ("int", member)
                    if isinstance(member, int)
                    else ("str", member)
                    if isinstance(member, str)
                    else None
                )
                if key is not None and key in aliases:
                    resolved.append(aliases[key])
            group["nodes"] = resolved
        elif "nodes" in group:
            group["nodes"] = []
        remapped.append(group)
    return remapped


# ── Virtual-wire classification ────────────────────────────────────────────
# Get/Set broadcast wires + Reroute passthrough are the virtual-wire nodes
# whose stable channel name (not the edge) is the routing key.
_VIRTUAL_WIRE_CLASS_TYPES: frozenset[str] = frozenset({"SetNode", "GetNode", "Reroute"})


def _resolve_broadcast_edges(
    wf: Any,
) -> tuple[list[Any], set[str], set[str]]:
    """Resolve SetNode/GetNode broadcast indirection into direct edges.

    Reuses :func:`collect_broadcast_sources` (porting/helpers.py) — the broadcast
    resolution is NOT reimplemented here.  A ``SetNode`` captures the value on its input
    under a broadcast name; each ``GetNode`` re-emits that name to one or more consumers
    (one source → many links).  For the litegraph envelope we drop the helper nodes and
    rewire every ``GetNode``-origin edge to the captured real source, so a fan-out of N
    consumers becomes N direct links.  Edges feeding a helper are dropped; an unresolved
    ``GetNode`` reference drops its dangling edges.

    Returns ``(effective_edges, broadcast_helper_ids, orphaned_get_ids)`` where
    *orphaned_get_ids* are GetNode IDs whose broadcast name could not be resolved
    to a SetNode source (used for the recovery report in display mode).  When the
    IR carries no broadcast helpers (the common case) the original edge list is
    returned unchanged, so emission stays byte-identical.
    """
    helper_ids = {
        node_id
        for node_id, node in wf.nodes.items()
        if is_broadcast_helper_class_type(node.class_type)
    }
    if not helper_ids:
        return list(wf.edges), helper_ids, set()

    sources = collect_broadcast_sources(wf.nodes, wf.edges)
    get_source: dict[str, tuple[str, str]] = {}
    orphaned: set[str] = set()
    for node_id in helper_ids:
        node = wf.nodes[node_id]
        if node.class_type != "GetNode":
            continue
        name = broadcast_name(node)
        src = sources.get(name) if name else None
        if src is not None:
            get_source[node_id] = (str(src[0]), str(src[1]))
        else:
            orphaned.add(node_id)

    effective: list[Any] = []
    for edge in wf.edges:
        if edge.to_node in helper_ids:
            continue  # edge into a SetNode/GetNode helper — not a runtime link
        if edge.from_node in helper_ids:
            redirect = get_source.get(edge.from_node)
            if redirect is None:
                continue  # unresolved broadcast — drop the dangling edge
            effective.append(VibeEdge(redirect[0], redirect[1], edge.to_node, edge.to_input))
        else:
            effective.append(edge)
    return effective, helper_ids, orphaned


def _resolve_reroute_edges(
    edges: list[Any],
    nodes: dict[str, Any],
) -> list[Any]:
    """Passthrough Reroute nodes: A→Reroute→B becomes A→B (transitive chains).

    Returns a new edge list where every edge that originates from a Reroute is
    rewritten to originate from the terminal non-Reroute source, and edges into
    Reroutes are dropped.  When no Reroute nodes exist the list is returned
    unchanged.
    """
    reroute_ids = {nid for nid, n in nodes.items() if n.class_type == "Reroute"}
    if not reroute_ids:
        return list(edges)

    # Build inbound map: reroute_id → [(from_node, from_output), ...]
    inbound: dict[str, list[tuple[str, str]]] = {}
    for edge in edges:
        if edge.to_node in reroute_ids:
            inbound.setdefault(edge.to_node, []).append(
                (edge.from_node, edge.from_output)
            )

    # Recursive terminal-source lookup (follows Reroute chains transitively)
    def _terminal(nid: str, visited: frozenset[str]) -> tuple[str, str] | None:
        if nid in visited:
            return None
        ins = inbound.get(nid, [])
        if not ins:
            return None
        src_id, src_out = ins[0]
        if src_id in reroute_ids:
            return _terminal(src_id, visited | {nid})
        return (src_id, src_out)

    result: list[Any] = []
    for edge in edges:
        if edge.from_node in reroute_ids:
            terminal = _terminal(edge.from_node, frozenset())
            if terminal is None:
                continue  # orphaned Reroute — drop
            result.append(
                VibeEdge(terminal[0], terminal[1], edge.to_node, edge.to_input)
            )
        elif edge.to_node in reroute_ids:
            continue  # edge into a Reroute — dropped
        else:
            result.append(edge)
    return result


def _array_link_to_object(link: list[Any]) -> dict[str, Any]:
    """Convert a 6-element array link to litegraph subgraph OBJECT-link shape."""
    return {
        "id": link[0],
        "origin_id": link[1],
        "origin_slot": link[2],
        "target_id": link[3],
        "target_slot": link[4],
        "type": link[5],
    }


def _emit_definitions(wf: Any) -> dict[str, Any] | None:
    """Emit ``definitions.subgraphs[]`` from IR metadata, if any are carried.

    Subgraph links use the litegraph OBJECT shape (``id``/``origin_id``/``origin_slot``/
    ``target_id``/``target_slot``/``type``) rather than the 6-element arrays used at the
    top level; array-style links present in metadata are converted.  Each subgraph's
    ``state.lastRerouteId`` is ensured (default ``0``).

    Step 6 (T8): Every inner subgraph node has ``properties['vibecomfy_uid']`` stamped
    via ``mint_local_uid`` (pre-existing uid wins, otherwise the inner integer id).
    Returns ``None`` when the IR carries no definitions (the common post-ingest case),
    so the envelope omits both ``definitions`` and the top-level ``state`` and stays
    byte-identical.
    """
    typed_defs = getattr(wf, "definitions", None)
    metadata = getattr(wf, "metadata", None)
    legacy_defs = metadata.get("definitions") if isinstance(metadata, dict) else None
    # An empty typed mapping is an authoritative remove-all edit.  Falling
    # through on truthiness would resurrect the stale ingest compatibility
    # alias after ``workflow.definitions.clear()``.
    defs = typed_defs if isinstance(typed_defs, Mapping) else legacy_defs
    if isinstance(defs, dict) and isinstance(defs.get("subgraphs"), (list, tuple)):
        subgraphs = list(defs["subgraphs"])
    elif isinstance(defs, dict):
        subgraphs = list(defs.values())
    elif isinstance(defs, (list, tuple)):
        subgraphs = list(defs)
    else:
        subgraphs = []
    if not subgraphs:
        return None
    from vibecomfy.identity.scope import compose_scope_path, sg_key
    from vibecomfy.identity.uid import make_uid

    def emit_subgraph(raw_sg: Mapping[str, Any], parent_scope: tuple[str, ...] = ()) -> dict[str, Any]:
        # Detached copy: stamping uids/state below must never mutate the IR's
        # metadata definitions (``dict(raw_sg)`` alone would alias the inner
        # ``nodes`` list into the caller's data).
        sg = deepcopy(raw_sg)
        scope_key = sg_key(raw_sg)
        scope = compose_scope_path((*parent_scope, scope_key))
        links = sg.get("links")
        if isinstance(links, list):
            sg["links"] = [
                link if isinstance(link, dict) else _array_link_to_object(link)
                for link in links
            ]
        state = dict(sg.get("state") or {})
        state.setdefault("lastRerouteId", 0)
        sg["state"] = state
        # ── T8: stamp vibecomfy_uid on every inner subgraph node ──
        inner_nodes = sg.get("nodes")
        if isinstance(inner_nodes, list):
            for inner_node in inner_nodes:
                if isinstance(inner_node, dict):
                    props = inner_node.get("properties")
                    if not isinstance(props, dict):
                        props = {}
                        inner_node["properties"] = props
                    if "vibecomfy_uid" not in props:
                        authored_uid = inner_node.get("uid")
                        local_uid = (
                            str(authored_uid)
                            if isinstance(authored_uid, str) and authored_uid.strip()
                            else mint_local_uid(inner_node, str(inner_node.get("id", "")))
                        )
                        props["vibecomfy_uid"] = local_uid
        # Python-authored virtual legs are represented in the disposable UI as
        # ordinary endpoint links.  The sidecar may decorate those links, but
        # it never supplies their endpoints or leg ordering.
        inner_nodes_by_alias: dict[str, Mapping[str, Any]] = {}
        for inner_node in sg.get("nodes", []) if isinstance(sg.get("nodes"), list) else []:
            if not isinstance(inner_node, Mapping):
                continue
            local_uid = str((inner_node.get("properties") or {}).get("vibecomfy_uid", inner_node.get("uid", inner_node.get("id", ""))))
            inner_nodes_by_alias[local_uid] = inner_node
            if inner_node.get("id") is not None:
                inner_nodes_by_alias[str(inner_node["id"])] = inner_node
        virtual_wires = sg.get("virtual_wires", {})
        if isinstance(virtual_wires, Mapping):
            from vibecomfy.workflow import WorkflowCompileError, _resolve_virtual_wire_legs

            existing = defaultdict(int)
            for link in sg.get("links", []):
                if isinstance(link, Mapping):
                    existing[(str(link.get("origin_id")), link.get("origin_slot"), str(link.get("target_id")), link.get("target_slot"))] += 1
            # Keep every authored node as resolver evidence.  Keying this
            # temporary map by qualified UID would overwrite duplicate local
            # identities before the shared resolver can reject them.
            resolver_nodes: dict[str, Mapping[str, Any]] = {}
            resolver_endpoint_nodes: dict[str, Mapping[str, Any]] = {}
            for ordinal, inner_node in enumerate(sg.get("nodes", [])):
                if not isinstance(inner_node, Mapping):
                    continue
                properties = inner_node.get("properties")
                local_uid = inner_node.get("uid")
                if not isinstance(local_uid, str) or not local_uid.strip():
                    local_uid = properties.get("vibecomfy_uid") if isinstance(properties, Mapping) else None
                if not isinstance(local_uid, str) or not local_uid.strip():
                    local_uid = str(inner_node.get("id", ""))
                qualified_uid = make_uid(scope, local_uid)
                # Keep the qualified identity in each unique temporary key so
                # the shared resolver returns the exact lookup used below.
                # The ordinal only prevents a pre-resolver dict overwrite;
                # duplicate semantic UIDs still fail inside that resolver.
                resolver_key = f"{qualified_uid}@{ordinal}"
                resolver_nodes[resolver_key] = inner_node
                resolver_endpoint_nodes[resolver_key] = inner_node
            next_id = max(
                [int(link.get("id")) for link in sg.get("links", []) if isinstance(link, Mapping) and type(link.get("id")) is int]
                + [0]
            ) + 1
            try:
                resolved_legs = _resolve_virtual_wire_legs(
                    resolver_nodes,
                    virtual_wires,
                    scope_path=scope,
                )
            except WorkflowCompileError as exc:
                raise ValueError(str(exc)) from exc
            for leg in resolved_legs:
                    source = resolver_endpoint_nodes.get(leg.from_lookup)
                    target = resolver_endpoint_nodes.get(leg.to_lookup)
                    if source is None or target is None:
                        raise ValueError("Python virtual-wire leg endpoint is not local to its definition")
                    key = (str(source.get("id")), leg.from_port, str(target.get("id")), leg.to_port)
                    if existing[key]:
                        existing[key] -= 1
                        continue
                    sg.setdefault("links", []).append({
                        "id": next_id,
                        "origin_id": source.get("id"),
                        "origin_slot": leg.from_port,
                        "target_id": target.get("id"),
                        "target_slot": leg.to_port,
                        "type": "",
                    })
                    next_id += 1
        nested = sg.get("definitions")
        if nested:
            if isinstance(nested, Mapping) and isinstance(nested.get("subgraphs"), (list, tuple)):
                nested_items = list(nested["subgraphs"])
            elif isinstance(nested, Mapping):
                nested_items = list(nested.values())
            elif isinstance(nested, (list, tuple)):
                nested_items = list(nested)
            else:
                raise ValueError("definition definitions must be a mapping or sequence")
            sg["definitions"] = {
                "subgraphs": [
                    emit_subgraph(item, (*parent_scope, scope_key))
                    for item in nested_items if isinstance(item, Mapping)
                ]
            }
        return sg

    out_subgraphs: list[dict[str, Any]] = []
    for raw_sg in subgraphs:
        if isinstance(raw_sg, Mapping):
            out_subgraphs.append(emit_subgraph(raw_sg))
    return {"subgraphs": out_subgraphs}


def _root_virtual_display_edges(wf: Any) -> list[VibeEdge]:
    """Materialize explicit root Python virtual legs for the UI display graph."""
    from vibecomfy.workflow import _resolve_workflow_virtual_wire_records

    # The resolver records the detached lookup identity that was used to find
    # each endpoint.  Build the root lookup table once; do not decode a
    # qualified UID or re-resolve aliases in this consumer.
    by_lookup: dict[str, str] = {}
    for key, node in wf.nodes.items():
        by_lookup[str(key)] = str(node.id)
        if node.uid:
            by_lookup[str(node.uid)] = str(node.id)
    result: list[VibeEdge] = []
    for (scope, _name), legs in sorted(_resolve_workflow_virtual_wire_records(wf).items()):
        if scope != "":
            continue
        for leg in legs:
            source = by_lookup.get(leg.from_lookup)
            target = by_lookup.get(leg.to_lookup)
            if source is None or target is None:
                raise ValueError(
                    f"Python virtual-wire leg endpoint is not a root node: {leg.from_node!r}->{leg.to_node!r}"
                )
            result.append(VibeEdge(source, leg.from_output, target, leg.to_input))
    return result


def _canonical_emitted_output_name(from_output: Any, slot: int) -> str:
    """Canonical socket name an emitted output carries for *from_output*."""
    text = str(from_output)
    return f"output_{slot}" if text.isdigit() else text


def _emitted_socket_slot_for_link(
    sockets: list[dict[str, Any]] | None,
    slot: int,
    canonical_name: str,
) -> int | None:
    """Resolve a link endpoint against the node's *emitted* socket array.

    Working-graph sockets are authoritative.  An in-range slot is kept whenever
    the socket plausibly corresponds to the link (name match, ``None``-named
    UI-only slot, or a matching ``slot_index`` label); a phantom/absent slot is
    resolved to the socket whose canonical name matches, else ``None`` so the
    caller can deterministically drop the dangling link with a diagnostic
    instead of projecting a port the emitted graph does not have.
    """
    if not isinstance(sockets, list) or not isinstance(slot, int):
        return None
    if 0 <= slot < len(sockets):
        socket = sockets[slot]
        if not isinstance(socket, dict):
            return slot
        name = socket.get("name")
        if name == canonical_name or name in (None, "") or socket.get("slot_index") == slot:
            return slot
    for index, socket in enumerate(sockets):
        if isinstance(socket, dict) and socket.get("name") == canonical_name:
            return index
    for index, socket in enumerate(sockets):
        if isinstance(socket, dict) and socket.get("slot_index") == slot:
            return index
    return None


def _parse_ui_link(link: Any) -> tuple[str, int, str, int] | None:
    """Return ``(from_id, from_slot, to_id, to_slot)`` for a LiteGraph link."""
    if isinstance(link, (list, tuple)) and len(link) >= 5:
        try:
            return str(link[1]), int(link[2]), str(link[3]), int(link[4])
        except (TypeError, ValueError):
            return None
    if isinstance(link, Mapping):
        try:
            return (
                str(link.get("origin_id")),
                int(link.get("origin_slot", 0)),
                str(link.get("target_id")),
                int(link.get("target_slot", 0)),
            )
        except (TypeError, ValueError):
            return None
    return None


def _original_ui_payloads(
    wf: Any,
    prior_ui_payload: Mapping[str, Any] | None,
    guard_original_ui: Mapping[str, Any] | None,
) -> list[Mapping[str, Any]]:
    payloads: list[Mapping[str, Any]] = []
    for candidate in (prior_ui_payload, guard_original_ui):
        if isinstance(candidate, Mapping) and isinstance(candidate.get("links"), list):
            payloads.append(candidate)
    door = (getattr(wf, "metadata", None) or {}).get(_UI_DOOR_KEY)
    top = _door_top(door)
    if isinstance(top, Mapping) and isinstance(top.get("links"), list):
        payloads.append(top)
    return payloads


def _thaw_json_view(value: Any) -> Any:
    """Detach Mapping/sequence read views into ordinary JSON containers."""
    if isinstance(value, Mapping):
        return {key: _thaw_json_view(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_thaw_json_view(item) for item in value]
    return deepcopy(value)


def _original_link_slots_if_present(
    wf: Any,
    edge: Any,
    *,
    from_slot: int,
    to_slot: int,
    prior_ui_payload: Mapping[str, Any] | None,
    guard_original_ui: Mapping[str, Any] | None,
) -> tuple[int, int] | None:
    """Return original UI slots for a pre-existing edge, else None.

    Full-graph re-emits of corpus fixtures must round-trip links whose
    reconstructed sockets cannot be uniquely named (schema-less Inspire
    grids, duplicate ``width`` / ``coordinates``).  Only edges that already
    exist on the original UI are carried; newly introduced dangling
    endpoints still refuse.
    """
    from_id = str(getattr(edge, "from_node", ""))
    to_id = str(getattr(edge, "to_node", ""))
    to_input = str(getattr(edge, "to_input", "") or "")
    pair_matches: list[tuple[int, int, str | None]] = []
    for payload in _original_ui_payloads(wf, prior_ui_payload, guard_original_ui):
        nodes = {
            str(node.get("id")): node
            for node in (payload.get("nodes") or [])
            if isinstance(node, Mapping) and node.get("id") is not None
        }
        for link in payload.get("links") or []:
            parsed = _parse_ui_link(link)
            if parsed is None:
                continue
            o_from, o_from_slot, o_to, o_to_slot = parsed
            if o_from != from_id or o_to != to_id:
                continue
            orig_name: str | None = None
            target = nodes.get(to_id)
            if isinstance(target, Mapping):
                inputs = target.get("inputs")
                if isinstance(inputs, list) and 0 <= o_to_slot < len(inputs):
                    socket = inputs[o_to_slot]
                    if isinstance(socket, Mapping):
                        name = socket.get("name")
                        orig_name = str(name) if isinstance(name, str) and name else None
            if o_from_slot == from_slot and o_to_slot == to_slot:
                return o_from_slot, o_to_slot
            if orig_name and to_input and orig_name == to_input:
                return o_from_slot, o_to_slot
            pair_matches.append((o_from_slot, o_to_slot, orig_name))
        if len(pair_matches) == 1:
            return pair_matches[0][0], pair_matches[0][1]
        pair_matches.clear()
    return None


def _emitted_input_slot_for_link(
    sockets: list[dict[str, Any]] | None,
    canonical_name: str,
    requested_slot: int | None = None,
) -> int | None:
    """Resolve an inbound endpoint by canonical input name.

    A unique name is preferred.  When the emitted node still carries
    duplicate names (pin-opaque ImageScale ``width`` x2, ``coordinates`` x2),
    the first match is returned rather than failing closed on pre-existing
    corpus ambiguity — the linked socket is authoritative (Equip, Trust
    Judgment).  Reroute ``*`` wildcard synthetic ``_un<N>`` matches any
    wildcard/empty socket (ff076a, 2x2-seed, 0c2716).
    """
    if not isinstance(sockets, list) or not canonical_name:
        return None
    matches = [
        index
        for index, socket in enumerate(sockets)
        if isinstance(socket, dict) and socket.get("name") == canonical_name
    ]
    if matches:
        if len(matches) > 1 and isinstance(requested_slot, int):
            if requested_slot in matches:
                return requested_slot
            for index in matches:
                socket = sockets[index]
                if isinstance(socket, dict) and socket.get("slot_index") == requested_slot:
                    return index
        return matches[0]
    is_synthetic = canonical_name.startswith("_un")
    for index, socket in enumerate(sockets):
        if not isinstance(socket, dict):
            continue
        name = socket.get("name")
        sock_type = socket.get("type")
        if sock_type == "*" and is_synthetic:
            return index
        if name in ("", "*") and is_synthetic:
            return index
        if isinstance(name, str) and name.startswith("_un") and canonical_name in ("", "*"):
            return index
    return None
    matches = [
        index
        for index, socket in enumerate(sockets)
        if isinstance(socket, dict) and socket.get("name") == canonical_name
    ]
    if len(matches) == 1:
        return matches[0]
    if len(matches) > 1 and isinstance(requested_slot, int):
        if requested_slot in matches:
            return requested_slot
        for index in matches:
            socket = sockets[index]
            if isinstance(socket, dict) and socket.get("slot_index") == requested_slot:
                return index
    return None


def _emitted_socket_array_evidence(
    sockets: list[dict[str, Any]] | None,
) -> list[dict[str, Any]]:
    """Project an emitted socket array into JSONable refusal evidence.

    Each entry records the physical ``slot`` index plus whatever identity the
    emitted socket carries (``name`` and/or ``slot_index``).  ``None``/non-list
    inputs (no emitted sockets for the node) project to ``[]``.
    """
    if not isinstance(sockets, list):
        return []
    out: list[dict[str, Any]] = []
    for index, socket in enumerate(sockets):
        if isinstance(socket, dict):
            out.append(
                {
                    "slot": index,
                    "name": socket.get("name"),
                    "slot_index": socket.get("slot_index"),
                }
            )
        else:
            out.append({"slot": index, "name": socket})
    return out


def _remap_attempts_evidence(
    sockets: list[dict[str, Any]] | None,
    slot: int,
    canonical_name: str,
) -> list[dict[str, Any]]:
    """Reconstruct the deterministic remap strategies tried for a phantom endpoint.

    Mirrors :func:`_emitted_socket_slot_for_link` — in-range slot acceptance,
    then a canonical-name scan, then a ``slot_index`` scan.  This is called
    only after that function returned ``None``, so every ``found_at`` list is
    empty by construction: the evidence documents what was attempted (and
    rejected) for the refusal, not a second lookup.
    """
    if not isinstance(sockets, list):
        return [
            {
                "strategy": "invalid_socket_array",
                "detail": type(sockets).__name__,
            }
        ]
    in_range: dict[str, Any] | None = None
    in_range_rejected: str | None = None
    if isinstance(slot, int) and 0 <= slot < len(sockets):
        socket = sockets[slot]
        if isinstance(socket, dict):
            in_range = {
                "slot": slot,
                "name": socket.get("name"),
                "slot_index": socket.get("slot_index"),
            }
            name = socket.get("name")
            if name != canonical_name and name not in (None, "") and socket.get("slot_index") != slot:
                in_range_rejected = (
                    f"name {name!r} != canonical {canonical_name!r} and slot_index != {slot}"
                )
        else:
            in_range = {"slot": slot, "name": socket}
    return [
        {
            "strategy": "in_range_slot",
            "requested_slot": slot,
            "socket_at_slot": in_range,
            "out_of_range": not (isinstance(slot, int) and 0 <= slot < len(sockets)),
            "rejected_reason": in_range_rejected,
        },
        {
            "strategy": "canonical_name_scan",
            "sought_name": canonical_name,
            "found_at": [
                index
                for index, socket in enumerate(sockets)
                if isinstance(socket, dict) and socket.get("name") == canonical_name
            ],
        },
        {
            "strategy": "slot_index_scan",
            "sought_slot": slot,
            "found_at": [
                index
                for index, socket in enumerate(sockets)
                if isinstance(socket, dict) and socket.get("slot_index") == slot
            ],
        },
    ]


def _input_remap_attempts_evidence(
    sockets: list[dict[str, Any]] | None,
    slot: int,
    canonical_name: str,
) -> list[dict[str, Any]]:
    """Evidence for strict canonical-name inbound endpoint resolution."""
    if not isinstance(sockets, list):
        return [{"strategy": "invalid_socket_array", "detail": type(sockets).__name__}]
    return [
        {
            "strategy": "canonical_input_name_scan",
            "sought_name": canonical_name,
            "requested_slot": slot,
            "found_at": [
                index
                for index, socket in enumerate(sockets)
                if isinstance(socket, dict) and socket.get("name") == canonical_name
            ],
            "requires_unique_match": True,
        }
    ]


def _resolve_output_slot_and_type(
    from_output: str,
    class_type: str,
    schema_cache: dict[str, Any],
    node: Any | None = None,
) -> tuple[int, str]:
    """Return (slot_index, socket_type) for a VibeEdge.from_output value.

    ``from_output`` may be a numeric string (use directly) or an output NAME
    (look up list position in the schema's OutputSpec list).  UUID class types
    (subgraph nodes) pass through: if ``from_output`` is numeric it works as-is;
    if it is a name and no schema exists we return slot 0 with an empty type.
    """
    schema = schema_cache.get(class_type)
    native_roster = getattr(node, "native_output_names", None) if node is not None else None
    native_types = getattr(node, "native_output_types", None) if node is not None else None
    if from_output.isdigit():
        slot = int(from_output)
        if isinstance(native_roster, list) and slot < len(native_roster):
            socket_type = (
                native_types[slot]
                if isinstance(native_types, list)
                and slot < len(native_types)
                and native_types[slot] is not None
                else ""
            )
            if schema is not None and slot < len(getattr(schema, "outputs", ()) or ()):
                socket_type = getattr(schema.outputs[slot], "type", "") or ""
            return slot, socket_type
        if schema is not None:
            outputs = getattr(schema, "outputs", None) or []
            if slot < len(outputs):
                return slot, outputs[slot].type or ""
            # Inspire batch splitters materialize additional IMAGE/LATENT
            # sockets from ``split_count`` at runtime.  Their static schema
            # intentionally contains only the base return type, so preserve
            # the type for an out-of-range dynamic slot while endpoint
            # validation still checks the materialized socket array.
            dynamic = _DYNAMIC_OUTPUT_COUNT_INPUTS.get(class_type)
            if dynamic is not None and outputs:
                return slot, outputs[0].type or dynamic[1]
        return slot, ""
    # Name lookup against OutputSpec list position
    if isinstance(native_roster, list):
        try:
            slot = native_roster.index(from_output)
        except ValueError:
            slot = -1
        if slot >= 0:
            socket_type = (
                native_types[slot]
                if isinstance(native_types, list)
                and slot < len(native_types)
                and native_types[slot] is not None
                else ""
            )
            if schema is not None and slot < len(getattr(schema, "outputs", ()) or ()):
                socket_type = getattr(schema.outputs[slot], "type", "") or ""
            return slot, socket_type
    if schema is not None:
        outputs = getattr(schema, "outputs", None) or []
        for idx, out_spec in enumerate(outputs):
            if out_spec.name == from_output:
                return idx, out_spec.type or ""
        # The editable renderer disambiguates repeated output types with a
        # positional TYPE_N alias (for example CONDITIONING_1 or LATENT_2).
        # Preserve that exact slot when it agrees with the frozen schema;
        # falling through to slot 0 silently cross-wires multi-output nodes.
        import re

        typed = re.fullmatch(r"(.+)_(\d+)", from_output)
        if typed is not None:
            idx = int(typed.group(2))
            if 0 <= idx < len(outputs):
                out_spec = outputs[idx]
                token = typed.group(1).casefold()
                if token in {
                    str(out_spec.name or "").casefold(),
                    str(out_spec.type or "").casefold(),
                }:
                    return idx, out_spec.type or ""
    # Unresolvable name: best-effort slot 0, empty type
    return 0, ""


def _ordered_incoming_edges(
    edges: list[Any],
    schema: Any | None,
    node: Any | None = None,
) -> list[Any]:
    """Order linked inputs by their physical ComfyUI socket position.

    LiteGraph link records address a target by *input-array index*, not by
    input name.  Alphabetizing linked fields therefore corrupts any node whose
    authoring names do not happen to match its physical socket order (notably
    KSampler: ``model, positive, negative, latent_image``).  Runtime schema
    input order mirrors ComfyUI's declared order, so use it whenever present;
    retain a deterministic name-based fallback for schema-less nodes.
    """
    native_inputs = getattr(node, "native_input_names", None) if node is not None else None
    schema_inputs = getattr(schema, "inputs", None)
    ordered_names = (
        [name for name in native_inputs if isinstance(name, str)]
        if isinstance(native_inputs, list)
        else list(schema_inputs) if isinstance(schema_inputs, Mapping) else []
    )
    position = {name: index for index, name in enumerate(ordered_names)}
    unknown_offset = len(position)
    return sorted(
        edges,
        key=lambda edge: (
            position.get(edge.to_input, unknown_offset),
            edge.to_input,
            edge.from_node,
            edge.from_output,
        ),
    )


def _get_node_schema_provenance(
    class_type: str,
    schema: Any,
) -> dict[str, Any]:
    """Return a provenance dict describing how the schema was sourced."""
    if schema is None:
        return {
            "provider": None,
            "confidence": None,
            "schema_less": True,
        }
    confidence = getattr(schema, "confidence", 1.0)
    provider = getattr(schema, "source_provider", "unknown")
    return {
        "provider": provider,
        "confidence": confidence,
        "schema_less": False,
    }


def _widget_names_for_emission(
    class_type: str,
    schema: Any,
    *,
    node: Any | None = None,
    schema_provider: Any | None = None,
    name_authority: Mapping[str, Sequence[str | None]] | None = None,
) -> list[str | None]:
    """Return widget names in the value domain this node can safely emit.

    ``name_authority`` (the sealed snapshot table) wins over every ambient
    source when the node carries a uid present in it (P0-WIDGET-CANON).
    """
    if node is not None and isinstance(name_authority, Mapping):
        uid = getattr(node, "uid", None) or getattr(node, "id", None)
        authority_names = name_authority.get(str(uid)) if uid is not None else None
        if isinstance(authority_names, (list, tuple)) and authority_names:
            count = _compact_widget_count_for_emission(node) or len(authority_names)
            return list(
                compact_widget_names_for_node(
                    node,
                    class_type,
                    value_count=count,
                    schema_provider=schema_provider,
                    name_authority=name_authority,
                ).names
            )

    committed = widget_names_for_class(class_type)
    object_info_order = _object_info_widget_order_for_emission(
        class_type, schema_provider
    )
    if _widget_value_domain_for_emission(node, committed, object_info_order) == "raw_object_info":
        if committed is not None and any(name is None for name in committed):
            return list(committed)
        if object_info_order:
            return list(object_info_order)
        if committed is not None:
            return list(committed)

    if node is not None:
        count = _compact_widget_count_for_emission(node)
        if count:
            return list(
                compact_widget_names_for_node(
                    node,
                    class_type,
                    value_count=count,
                    schema_provider=schema_provider,
                    name_authority=name_authority,
                ).names
            )

    if committed is not None:
        return list(committed)
    return list(widget_names_from_schema(class_type, schema))


def _primitive_union_dynamic_input_names(
    node: Any,
    incoming_names: set[str],
) -> tuple[list[str], list[str]]:
    """Return present primitive-union dynamic inputs and unlinked literals."""
    names: list[str] = []
    unlinked: list[str] = []
    native_names = getattr(node, "native_input_names", None)
    native_types = getattr(node, "native_input_types", None)
    inputs = getattr(node, "inputs", {})
    if not isinstance(native_names, list) or not isinstance(native_types, list):
        return names, unlinked
    primitive_union = {"FLOAT", "INT", "BOOLEAN"}
    for index, name in enumerate(native_names):
        if not isinstance(name, str) or not name.startswith("values.") or index >= len(native_types):
            continue
        type_spec = native_types[index]
        if not isinstance(type_spec, str) or {part.strip().upper() for part in type_spec.split(",")} != primitive_union:
            continue
        if name not in inputs and name not in incoming_names:
            continue
        names.append(name)
        if name not in incoming_names and inputs.get(name) is not None:
            unlinked.append(name)
    return names, unlinked


def _widget_value_domain_for_emission(
    node: Any | None,
    committed: list[str | None] | None,
    object_info_order: list[str | None],
) -> str:
    if committed is not None and any(name is None for name in committed):
        return "raw_object_info"
    raw_count = _captured_raw_widget_count(node)
    if raw_count is not None and object_info_order and raw_count == len(object_info_order):
        return "raw_object_info"
    return "compact"


def _compact_widget_count_for_emission(node: Any) -> int:
    raw_count = _captured_raw_widget_count(node)
    widget_key_count = _widget_key_count(getattr(node, "widgets", None))
    if raw_count is not None and widget_key_count and raw_count == widget_key_count:
        return raw_count
    if widget_key_count:
        return widget_key_count
    return raw_count or 0


def _captured_raw_widget_count(node: Any | None) -> int | None:
    if node is None:
        return None
    raw_ui = getattr(node, "metadata", {}).get("_ui", {})
    raw_widgets = raw_ui.get("widgets_values") if isinstance(raw_ui, dict) else None
    if isinstance(raw_widgets, list):
        return len(raw_widgets)
    raw_widget_payload = getattr(node, "raw_widgets", None)
    length = getattr(raw_widget_payload, "length", None)
    if isinstance(length, int):
        return length
    values = getattr(raw_widget_payload, "values", None)
    if isinstance(values, list):
        return len(values)
    return None


def _widget_key_count(values: Any) -> int:
    if not isinstance(values, Mapping):
        return 0
    indices: list[int] = []
    for key in values:
        key_str = str(key)
        if not key_str.startswith("widget_"):
            continue
        try:
            indices.append(int(key_str.split("_", 1)[1]))
        except ValueError:
            continue
    if not indices:
        return 0
    expected = list(range(max(indices) + 1))
    return max(indices) + 1 if sorted(indices) == expected else 0


def _authored_widget_count(node: Any) -> int:
    """Return the highest explicitly retained widget slot, if any.

    Canonical generated templates retain ``keep_defaults`` as custody for
    widget-only fields that are not present in the compact schema roster. A
    generated workflow therefore has valid widget evidence even after its
    captured raw UI payload has been discarded.
    """
    metadata = getattr(node, "metadata", None)
    keep_defaults = (
        metadata.get("keep_defaults")
        if isinstance(metadata, Mapping)
        else None
    )
    if not isinstance(keep_defaults, (list, tuple)):
        return 0
    indices: list[int] = []
    for field in keep_defaults:
        text = str(field)
        if not text.startswith("widget_"):
            continue
        suffix = text.split("_", 1)[1]
        if suffix.isdigit():
            indices.append(int(suffix))
    return max(indices) + 1 if indices else 0


_UI_ONLY_OBJECT_INFO_NAMES = frozenset({"control_after_generate"})


def _object_info_order_safely_extends_committed(
    committed: list[str | None],
    object_info_order: list[str | None],
) -> bool:
    if not object_info_order or len(object_info_order) <= len(committed):
        return False
    if any(name is None for name in committed):
        return False
    committed_names = [name for name in committed if isinstance(name, str)]
    object_info_names = [
        name
        for name in object_info_order
        if isinstance(name, str) and name not in _UI_ONLY_OBJECT_INFO_NAMES
    ]
    return object_info_names == committed_names


def _raw_widget_order_from_provider(
    class_type: str,
    schema_provider: Any | None,
) -> list[str | None] | None:
    """Return the raw ``object_info_widget_order`` including ``None`` entries.

    Probes the provider for a ``raw_widget_order`` method (added to
    ``ObjectInfoIndexSchemaProvider``) or, when the provider is a
    ``ConversionSchemaProvider``, reaches into its ``_object_info_index``
    delegate.  Returns ``None`` when no raw order is available.
    """
    if schema_provider is None:
        return None
    # Direct method (e.g. ObjectInfoIndexSchemaProvider.raw_widget_order)
    raw_method = getattr(schema_provider, "raw_widget_order", None)
    if callable(raw_method):
        try:
            result = raw_method(class_type)
            if isinstance(result, list):
                return result
        except Exception:
            pass
    # ConversionSchemaProvider delegates to _object_info_index
    obj_idx = getattr(schema_provider, "_object_info_index", None)
    if obj_idx is not None:
        raw_method = getattr(obj_idx, "raw_widget_order", None)
        if callable(raw_method):
            try:
                result = raw_method(class_type)
                if isinstance(result, list):
                    return result
            except Exception:
                pass
    return None


def _object_info_widget_order_for_emission(
    class_type: str,
    schema_provider: Any | None,
) -> list[str | None]:
    """Return only the widget roster bound to this emission authority.

    A supplied provider represents the retained ingress generation.  If it
    does not expose raw object-info order, an ambient process-global cache is
    advisory and cannot fill that gap.  Providerless legacy emission keeps
    its historical cache lookup.
    """
    retained = _raw_widget_order_from_provider(class_type, schema_provider)
    if retained is not None:
        return retained
    if schema_provider is not None:
        return []
    from vibecomfy.porting.object_info.consume import object_info_widget_order  # noqa: PLC0415

    return list(object_info_widget_order(class_type))


# Schema inputs whose type suggests a seed-bearing INT field that ComfyUI
# pairs with a ``control_after_generate`` widget slot.
_SEED_INPUT_NAMES: frozenset[str] = frozenset({"seed", "noise_seed"})

# Input-name suffixes that signal an upload widget slot.
_UPLOAD_SUFFIXES: tuple[str, ...] = ("_upload",)


def _extra_widgets_after(
    class_type: str,
    schema: Any | None,
    schema_provider: Any | None = None,
) -> list[str | None]:
    """Offline heuristic: extra widget slots beyond the schema/widget table.

    Only fires when the *snapshot* lacks the class (raw_widget_order is None
    or empty).  Heuristics:

    - ``control_after_generate`` (``None``-named UI-only slot) appended when
      any input is an INT ``seed`` or ``noise_seed``.
    - An upload slot (``None``-named) appended when any input name ends with
      ``_upload`` and its type is ``IMAGE``, ``VIDEO``, or ``AUDIO``.

    These are marked as informational ``guess`` entries in the recovery report
    and do NOT trigger ``--strict`` failures.
    """
    raw = _raw_widget_order_from_provider(class_type, schema_provider)
    if raw is not None and len(raw) > 0:
        # Snapshot HAS the class — raw order is authoritative, no guessing.
        return []

    # Snapshot lacks the class — apply heuristics (informational only).
    hints: list[str | None] = []

    # control_after_generate for INT seed/noise_seed fields
    has_seed = False
    if schema is not None:
        inputs = getattr(schema, "inputs", None)
        if isinstance(inputs, dict):
            for name, spec in inputs.items():
                input_type = str(getattr(spec, "type", "") or "").upper()
                if name in _SEED_INPUT_NAMES and input_type == "INT":
                    has_seed = True
                    break
    if has_seed:
        hints.append(None)  # control_after_generate is a None-named slot

    # Upload slot for image/video/audio+_upload input names
    upload_types = frozenset({"IMAGE", "VIDEO", "AUDIO"})
    if schema is not None:
        inputs = getattr(schema, "inputs", None)
        if isinstance(inputs, dict):
            for name, spec in inputs.items():
                input_type = str(getattr(spec, "type", "") or "").upper()
                if name.endswith(_UPLOAD_SUFFIXES) and input_type in upload_types:
                    hints.append(None)  # upload is a None-named slot
                    break

    return hints


def _full_widget_name_count(
    class_type: str,
    schema: Any,
    *,
    schema_provider: Any | None = None,
) -> int | None:
    """Schema widget-slot count (including ``None`` UI-only slots), or ``None``.

    Precedence:
    1. Raw ``object_info_widget_order`` from the provider (nulls included)
       — the authoritative slot count when the snapshot has the class.
    2. Committed ``WIDGET_SCHEMA`` table.
    3. Provider schema (null-free by construction).

    ``None`` means the class is schema-less for widget purposes so the
    length assertion is skipped.
    """
    # 1. Committed table, extended only by reconciled object_info metadata when
    # it is clearly the same named order plus UI-only slots.
    committed = widget_names_for_class(class_type)
    if committed is not None:
        object_info_order = _object_info_widget_order_for_emission(
            class_type, schema_provider
        )
        if _object_info_order_safely_extends_committed(committed, object_info_order):
            return len(object_info_order)
        return len(committed)

    # 2. Raw object_info_widget_order from the provider (nulls included).
    raw = _raw_widget_order_from_provider(class_type, schema_provider)
    if raw is not None and len(raw) > 0:
        return len(raw)

    # 3. Provider schema (null-free)
    names = widget_names_from_schema(class_type, schema)
    return len(names) if names else None


def _build_widget_values(
    node: Any,
    widget_names: list[str | None],
    *,
    default_values: Mapping[str, Any] | None = None,
    value_domain: str = "compact",
) -> Any:
    """Reverse the normalizer's positional widget read-back.

    The value pool is the node's widget-sourced data: ``node.widgets`` (``widget_<N>``
    carriers) plus ``node.inputs`` (non-link named values; link inputs never land
    here — ingest routes them to edges).  Position ``idx`` takes the value under
    ``widget_names[idx]`` when present, else the captured raw widget value at that
    position, else the ``widget_<idx>`` carrier.  ``None`` slots are UI-only widget
    positions; preserve their captured value, or emit the retained/default
    control-after-generate value when available.  Trailing ``None`` is trimmed so
    the array matches the litegraph reference length.
    """
    pool: dict[str, Any] = {}
    pool.update(node.widgets)
    pool.update(node.inputs)
    defaults = dict(default_values or {})
    use_schema_defaults = bool(defaults)

    widget_idxs: list[int] = []
    for key in pool:
        if key.startswith("widget_"):
            try:
                widget_idxs.append(int(key.split("_", 1)[1]))
            except ValueError:
                continue
    max_widget = (max(widget_idxs) + 1) if widget_idxs else 0

    raw_ui = getattr(node, "metadata", {}).get("_ui", {})
    raw_widgets = raw_ui.get("widgets_values") if isinstance(raw_ui, dict) else None
    if isinstance(raw_widgets, Mapping):
        # Comfy/LiteGraph uses a mapping for dynamic ``values`` inputs.  Keep
        # that canonical editor representation and overlay the effective IR
        # values onto its leaves; flattening it into positional widget_N rows
        # loses edits such as ComfyMathExpression.values.a = 6.
        result = deepcopy(dict(raw_widgets))
        for key, value in pool.items():
            if key.startswith("widget_"):
                continue
            dynamic_key = key.rsplit(".", 1)[-1]
            if dynamic_key in result or key in result:
                result[dynamic_key if dynamic_key in result else key] = deepcopy(value)
        return result
    if not isinstance(raw_widgets, list):
        raw_widget_payload = getattr(node, "raw_widgets", None)
        raw_widget_values = getattr(raw_widget_payload, "values", None)
        raw_widgets = list(raw_widget_values) if isinstance(raw_widget_values, list) else []

    preserve_observed_widget_carriers = _preserve_observed_widget_carriers(
        node,
        raw_widgets=raw_widgets,
    )
    has_seed_control_slot = any(
        isinstance(name, str) and name in _SEED_INPUT_NAMES
        for name in widget_names
    )
    if value_domain == "compact":
        length = max(len(widget_names), max_widget, len(raw_widgets))
    elif use_schema_defaults:
        length = max(len(widget_names), len(raw_widgets))
    else:
        length = max(len(widget_names), max_widget, len(raw_widgets))
    values: list[Any] = []
    for idx in range(length):
        name = widget_names[idx] if idx < len(widget_names) else None
        has_raw = idx < len(raw_widgets)
        raw_value = raw_widgets[idx] if has_raw else None
        if isinstance(name, str) and name in pool:
            pool_value = pool[name]
            if pool_value is None and has_raw and raw_value is not None:
                # RRSYN2-5: a ``None`` carrier (unset/socket-shaped entry
                # riding in ``inputs``) never masks the immutable captured
                # literal at that position.  Overwriting only its resolved
                # position is why accepted deltas must replay byte-for-byte:
                # [null, null, 1.0, "multiply"] once emitted as
                # [null, null, 1.8], silently dropping strength_type.
                values.append(raw_value)
            else:
                values.append(pool_value)
        elif (
            use_schema_defaults
            and preserve_observed_widget_carriers
            and f"widget_{idx}" in pool
        ):
            values.append(pool[f"widget_{idx}"])
        elif not use_schema_defaults and f"widget_{idx}" in pool:
            values.append(pool[f"widget_{idx}"])
        elif isinstance(name, str) and name in defaults:
            values.append(deepcopy(defaults[name]))
        elif has_raw:
            values.append(raw_value)
        elif name is None and isinstance(node.metadata.get("control_after_generate"), str):
            values.append(node.metadata["control_after_generate"])
        elif name is None and has_seed_control_slot:
            values.append(_CONTROL_AFTER_GENERATE_DEFAULT)
        else:
            values.append(None)

    # Trailing ``None`` slots are trimmed to match the litegraph reference
    # length — but a CAPTURED raw row is never trimmed (RRSYN2-5): every
    # untouched raw value AND the immutable source array length survive,
    # including trailing nulls ([1.0, null] emits [1.0, null]).  Stopping at
    # the last non-None raw position shortened captured rows whose tail
    # control was simply untouched.  Only GENERATED positions beyond
    # len(raw_widgets) may shrink.
    raw_tail_floor = len(raw_widgets) if raw_widgets else 0
    while len(values) > raw_tail_floor and values[-1] is None:
        values.pop()
    return values


def _preserve_observed_widget_carriers(
    node: Any,
    *,
    raw_widgets: list[Any],
) -> bool:
    if raw_widgets:
        return True
    raw_widget_payload = getattr(node, "raw_widgets", None)
    raw_widget_values = getattr(raw_widget_payload, "values", None)
    if isinstance(raw_widget_values, list) and raw_widget_values:
        return True
    metadata = getattr(node, "metadata", {})
    if not isinstance(metadata, Mapping):
        return False
    raw_ui = metadata.get("_ui")
    if isinstance(raw_ui, Mapping) and isinstance(raw_ui.get("widgets_values"), list):
        return True
    return bool(metadata.get("provenance"))


def _schema_outputs_for_unwired_node(schema: Any | None) -> list[dict[str, Any]]:
    schema_outputs = list(getattr(schema, "outputs", None) or []) if schema else []
    return [
        {
            "name": out_spec.name or f"output_{slot_idx}",
            "type": out_spec.type or "",
            "links": None,
            "slot_index": slot_idx,
        }
        for slot_idx, out_spec in enumerate(schema_outputs)
    ]


def _exec_node_field(node: Any, key: str) -> Any:
    """Return a vibecomfy.exec field from widgets first, then inputs."""
    node_widgets = getattr(node, "widgets", None)
    if isinstance(node_widgets, Mapping) and key in node_widgets:
        return node_widgets[key]
    node_inputs = getattr(node, "inputs", None)
    if isinstance(node_inputs, Mapping) and key in node_inputs:
        return node_inputs[key]
    return None


def _normalize_exec_io_entries(value: Any) -> list[tuple[str, str]]:
    entries: list[tuple[str, str]] = []
    raw_items: Any
    if isinstance(value, Mapping):
        raw_items = [[name, socket_type] for name, socket_type in value.items()]
    elif isinstance(value, list):
        raw_items = value
    else:
        return entries
    for index, item in enumerate(raw_items):
        name: Any
        socket_type: Any
        if isinstance(item, Mapping):
            name = item.get("name")
            socket_type = item.get("type")
        elif isinstance(item, (list, tuple)) and len(item) >= 1:
            name = item[0]
            socket_type = item[1] if len(item) >= 2 else None
        else:
            continue
        clean_name = str(name or f"value_{index}").strip() or f"value_{index}"
        clean_type = str(socket_type or "*").strip() or "*"
        entries.append((clean_name, clean_type))
    return entries


def _normalize_exec_io(value: Any) -> dict[str, list[tuple[str, str]]] | None:
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
        except (TypeError, ValueError):
            return None
        if not isinstance(parsed, Mapping):
            return None
        return _normalize_exec_io(parsed)
    if not isinstance(value, Mapping):
        return None
    inputs = _normalize_exec_io_entries(value.get("inputs"))
    outputs = _normalize_exec_io_entries(value.get("outputs"))
    if not inputs and not outputs:
        return None
    return {"inputs": inputs, "outputs": outputs}


def _exec_io_for_node(node: Any) -> dict[str, list[tuple[str, str]]] | None:
    if getattr(node, "class_type", None) != "vibecomfy.exec":
        return None
    return _normalize_exec_io(_exec_node_field(node, "io"))


def _exec_io_properties_payload(io: dict[str, list[tuple[str, str]]]) -> dict[str, list[list[str]]]:
    return {
        "inputs": [[name, socket_type] for name, socket_type in io["inputs"]],
        "outputs": [[name, socket_type] for name, socket_type in io["outputs"]],
    }


def _exec_dynamic_inputs(
    io: dict[str, list[tuple[str, str]]],
    incoming_by_input: Mapping[str, list[int]],
) -> list[dict[str, Any]]:
    inputs: list[dict[str, Any]] = []
    for slot_idx, (name, socket_type) in enumerate(io["inputs"]):
        slot_name = f"in_{slot_idx}"
        link_ids = sorted(incoming_by_input.get(slot_name, []))
        entry: dict[str, Any] = {
            "name": slot_name,
            "label": f"{name}: {socket_type}",
            "type": socket_type,
        }
        if link_ids:
            entry["link"] = link_ids[0]
        inputs.append(entry)
    return inputs


def _exec_dynamic_outputs(
    io: dict[str, list[tuple[str, str]]],
    output_links_by_slot: Mapping[int, list[int]],
) -> list[dict[str, Any]]:
    outputs: list[dict[str, Any]] = []
    for slot_idx, (name, socket_type) in enumerate(io["outputs"]):
        link_list = sorted(output_links_by_slot.get(slot_idx, []))
        outputs.append(
            {
                "name": f"out_{slot_idx}",
                "label": f"{name}: {socket_type}",
                "type": socket_type,
                "links": link_list if link_list else None,
                "slot_index": slot_idx,
            }
        )
    return outputs


def _emit_litegraph_node_dict(
    node: Any,
    *,
    litegraph_node_id: int,
    order: int,
    geometry: Mapping[str, Any],
    furniture: Mapping[str, Any],
    inputs: list[dict[str, Any]],
    outputs: list[dict[str, Any]],
    schema: Any | None,
    schema_provider: Any | None,
    include_main_positions: bool,
    widget_default_values: Mapping[str, Any] | None = None,
    name_authority: Mapping[str, Sequence[str | None]] | None = None,
) -> dict[str, Any]:
    widget_names = _widget_names_for_emission(
        node.class_type,
        schema,
        node=node,
        schema_provider=schema_provider,
        name_authority=name_authority,
    )
    incoming_names = {
        str(item["name"])
        for item in inputs
        if isinstance(item, Mapping) and item.get("link") is not None
    }
    _dynamic_names, unlinked_dynamic_names = _primitive_union_dynamic_input_names(
        node, incoming_names
    )
    if unlinked_dynamic_names:
        expanded_widget_names: list[str | None] = []
        for name in widget_names:
            if name == "values":
                expanded_widget_names.extend(
                    item for item in unlinked_dynamic_names
                    if item not in expanded_widget_names
                )
            else:
                expanded_widget_names.append(name)
        if "values" not in widget_names:
            expanded_widget_names.extend(
                item for item in unlinked_dynamic_names
                if item not in expanded_widget_names
            )
        widget_names = expanded_widget_names

    # Step 6 (T8): re-stamp the verbatim captured properties blob as the base,
    # then overlay the IR identity keys.  When no captured blob exists (e.g.
    # programmatic workflows), fall back to fresh-construction — no regression.
    captured_blob = furniture.get("properties")
    if isinstance(captured_blob, dict) and captured_blob:
        properties = dict(captured_blob)
    else:
        properties = {}

    # ── IR identity keys ALWAYS win (merged ON TOP of any captured value) ──
    # Scrub stale ir_node_id from captured blobs (demoted in M5).
    properties.pop("ir_node_id", None)
    properties["vibecomfy_id"] = f"{node.class_type}_{order}"
    properties["Node name for S&R"] = node.class_type

    if schema is not None:
        properties["_vibecomfy_schema_provider"] = getattr(schema, "source_provider", "unknown")

    if node.uid:
        properties["vibecomfy_uid"] = node.uid

    if node.class_type == "vibecomfy.exec":
        exec_io = _exec_io_for_node(node)
        exec_source = _exec_node_field(node, "source")
        if exec_io is not None:
            vibecomfy_props = properties.get("vibecomfy")
            if not isinstance(vibecomfy_props, dict):
                vibecomfy_props = {}
                properties["vibecomfy"] = vibecomfy_props
            vibecomfy_props["kind"] = "code"
            vibecomfy_props["io"] = _exec_io_properties_payload(exec_io)
            intent_props = vibecomfy_props.get("intent")
            if not isinstance(intent_props, dict):
                intent_props = {}
                vibecomfy_props["intent"] = intent_props
            if isinstance(exec_source, str):
                intent_props["source"] = exec_source

    value_domain = _widget_value_domain_for_emission(
        node,
        widget_names_for_class(node.class_type),
        _object_info_widget_order_for_emission(node.class_type, schema_provider),
    )
    node_dict: dict[str, Any] = {
        "id": litegraph_node_id,
        "type": node.class_type,
        "pos": geometry["pos"],
        "size": geometry["size"],
        "flags": furniture["flags"],
        "order": order,
        "mode": furniture["mode"],
        "inputs": inputs,
        "outputs": outputs,
        "properties": properties,
        "widgets_values": _build_widget_values(
            node,
            widget_names,
            default_values=widget_default_values,
            value_domain=value_domain,
        ),
    }
    # Emit color / bgcolor only when non-None (litegraph convention: absent = default)
    if furniture["color"] is not None:
        node_dict["color"] = furniture["color"]
    if furniture["bgcolor"] is not None:
        node_dict["bgcolor"] = furniture["bgcolor"]
    # Node title: emit only when include_main_positions=True and non-None,
    # so the lean default (include_main_positions=False) omits it entirely.
    if include_main_positions and furniture["title"] is not None:
        node_dict["title"] = furniture["title"]
    return node_dict


class _MaterializeSchemaProvider:
    """Bind one supplied node schema as the materialization authority."""

    __slots__ = ("_class_type", "_schema")

    def __init__(self, class_type: str, schema: Any) -> None:
        self._class_type = class_type
        self._schema = schema

    def get_schema(self, class_type: str) -> Any | None:
        return self._schema if class_type == self._class_type else None

    def raw_widget_order(self, class_type: str) -> list[str | None]:
        if class_type != self._class_type:
            return []
        order = getattr(self._schema, "widget_input_order", ())
        return list(order) if isinstance(order, (list, tuple)) else []


def materialize_litegraph_node(
    class_type: str,
    fields: Mapping[str, Any],
    schema: Any | None,
    node_id: int,
    uid: str,
    pos: list[float] | tuple[float, float],
) -> dict[str, Any]:
    """Materialize one unlinked LiteGraph node using emitter-equivalent defaults.

    This is the creation-path substrate helper for agent-edit v2. It deliberately
    reuses the same widget ordering, property stamping, size defaults, and output
    slot construction that :func:`emit_ui_json` uses for a single node.
    """
    merged_fields: dict[str, Any] = {}
    schema_inputs = getattr(schema, "inputs", None)
    if isinstance(schema_inputs, dict):
        for name, spec in schema_inputs.items():
            default = getattr(spec, "default", None)
            if default is not None:
                merged_fields[name] = deepcopy(default)
    merged_fields.update(dict(fields))

    metadata: dict[str, Any] = {}
    retained_control = merged_fields.pop("control_after_generate", None)
    if isinstance(retained_control, str):
        metadata["control_after_generate"] = retained_control

    node = VibeNode(
        id=str(node_id),
        class_type=class_type,
        inputs=merged_fields,
        metadata=metadata,
        uid=uid,
    )
    geometry = {
        "pos": [
            _canonicalize_coord(float(pos[0])),
            _canonicalize_coord(float(pos[1])),
        ],
        "size": [_canonicalize_coord(s) for s in _STUB_NODE_SIZE],
    }
    furniture = _resolve_furniture(node, None)
    inputs: list[dict[str, Any]] = schema_input_sockets_for_unwired_node(
        schema,
        class_type,
        fields=merged_fields,
    )
    outputs: list[dict[str, Any]] = _schema_outputs_for_unwired_node(schema)
    if class_type in _DYNAMIC_OUTPUT_COUNT_INPUTS:
        dynamic_count = _dynamic_output_count(node, schema)
        if dynamic_count is not None and schema and schema.outputs:
            output_type = schema.outputs[0].type or _DYNAMIC_OUTPUT_COUNT_INPUTS[class_type][1]
            output_name = schema.outputs[0].name or output_type
            outputs.extend(
                {
                    "name": f"{output_name}_{slot}",
                    "type": output_type,
                    "links": None,
                    "slot_index": slot,
                }
                for slot in range(len(outputs), dynamic_count)
            )
    if class_type == "vibecomfy.exec":
        exec_io = _exec_io_for_node(node)
        if exec_io is not None:
            inputs = _exec_dynamic_inputs(exec_io, {})
            outputs = _exec_dynamic_outputs(exec_io, {})
    schema_provider = (
        _MaterializeSchemaProvider(class_type, schema)
        if schema is not None
        else None
    )
    return _emit_litegraph_node_dict(
        node,
        litegraph_node_id=int(node_id),
        order=0,
        geometry=geometry,
        furniture=furniture,
        inputs=inputs,
        outputs=outputs,
        schema=schema,
        schema_provider=schema_provider,
        include_main_positions=False,
    )


def _schema_for_provider(schema_provider: Any | None, class_type: str) -> Any | None:
    if schema_provider is None:
        return None
    getter = getattr(schema_provider, "get_schema", None) or getattr(schema_provider, "get", None)
    if not callable(getter):
        return None
    return getter(class_type)


def _raw_widget_shape_from_value(values: Any) -> tuple[int, str, bool]:
    if values is None:
        return 0, "none", False
    if isinstance(values, dict):
        return len(values), "dict", True
    if isinstance(values, list):
        return len(values), "list", any(isinstance(item, dict) for item in values)
    return 1, "scalar", False


def _raw_widget_shape_from_node(node: Any) -> tuple[int | None, str | None, bool]:
    raw_widgets = getattr(node, "raw_widgets", None)
    if raw_widgets is not None:
        length = getattr(raw_widgets, "length", None)
        shape = getattr(raw_widgets, "shape", None)
        has_dict_rows = bool(getattr(raw_widgets, "has_dict_rows", False))
        if length is None:
            length, recovered_shape, recovered_has_dict_rows = _raw_widget_shape_from_value(
                getattr(raw_widgets, "values", None)
            )
            if shape is None:
                shape = recovered_shape
            has_dict_rows = has_dict_rows or recovered_has_dict_rows
        return (
            int(length) if length is not None else None,
            str(shape or "unknown"),
            has_dict_rows,
        )

    raw_ui = getattr(node, "metadata", {}).get("_ui")
    if isinstance(raw_ui, dict) and "widgets_values" in raw_ui:
        count, shape, has_dict_rows = _raw_widget_shape_from_value(raw_ui.get("widgets_values"))
        return count, shape, has_dict_rows

    return None, None, False


def extract_raw_ui_node_map(
    ui_payload: Mapping[str, Any] | None,
) -> dict[str, dict[str, Any]]:
    """Return full raw LiteGraph node payloads keyed by stable lookup ids.

    This is deliberately separate from ``prior_store``.  The layout store is a
    furniture/identity envelope built by :func:`store_from_ui_json`; it must not
    become evidence that a dynamic widget node can be preserved opaque.  Pinning
    decisions need the original full node dict from an actual UI JSON payload.
    """
    if not isinstance(ui_payload, Mapping):
        return {}
    nodes = ui_payload.get("nodes")
    if not isinstance(nodes, list):
        return {}

    out: dict[str, dict[str, Any]] = {}
    for raw_node in nodes:
        if not isinstance(raw_node, dict):
            continue
        node_copy = dict(raw_node)
        node_id = raw_node.get("id")
        if node_id is not None:
            out[str(node_id)] = node_copy
        props = raw_node.get("properties")
        if isinstance(props, Mapping):
            uid = props.get("vibecomfy_uid")
            if uid:
                out[str(uid)] = node_copy
    return out


def _raw_ui_node_for_node(
    node_id: str,
    node: Any,
    raw_ui_node_map: Mapping[str, Mapping[str, Any]],
) -> Mapping[str, Any] | None:
    uid = getattr(node, "uid", "")
    if raw_ui_node_map:
        if uid and uid in raw_ui_node_map:
            return raw_ui_node_map[uid]
        if node_id in raw_ui_node_map:
            return raw_ui_node_map[node_id]
    raw_ui = getattr(node, "metadata", {}).get("_ui")
    if isinstance(raw_ui, Mapping) and "widgets_values" in raw_ui:
        return raw_ui
    return None


def _layout_entry_for_widget_shape(
    node_id: str,
    node: Any,
    matched_entries: Mapping[str, Mapping[str, Any]],
) -> Mapping[str, Any] | None:
    uid = getattr(node, "uid", "")
    key = uid or node_id
    entry = matched_entries.get(key)
    if entry is not None:
        return entry
    raw_ui = getattr(node, "metadata", {}).get("_ui")
    if isinstance(raw_ui, Mapping):
        return raw_ui
    return None


def _widget_shape_identity_match(
    node_id: str,
    node: Any,
    matched_entries: Mapping[str, Mapping[str, Any]],
    raw_ui_node: Mapping[str, Any] | None,  # noqa: ARG001
) -> bool:
    uid = getattr(node, "uid", "")
    key = uid or node_id
    return key in matched_entries


def _has_object_info_widget_schema(
    class_type: str,
    schema_provider: Any | None,
) -> bool:
    raw_order = _raw_widget_order_from_provider(class_type, schema_provider)
    if raw_order:
        return True
    return bool(
        _object_info_widget_order_for_emission(class_type, schema_provider)
    )


def _has_schema_default_regeneration_basis(
    node: Any,
    schema: Any | None,
    schema_provider: Any | None,
) -> bool:
    if _has_object_info_widget_schema(node.class_type, schema_provider):
        return True
    committed = widget_names_for_class(node.class_type)
    if committed is not None:
        return True
    schema_inputs = getattr(schema, "inputs", None)
    if isinstance(schema_inputs, dict) and schema_inputs:
        return True
    return bool(_schema_default_widget_values_for_node(node, schema))


def _schema_default_widget_values_for_node(
    node: Any,
    schema: Any | None,
) -> dict[str, Any]:
    defaults: dict[str, Any] = {}
    schema_inputs = getattr(schema, "inputs", None)
    if isinstance(schema_inputs, dict):
        for name, spec in schema_inputs.items():
            default = getattr(spec, "default", None)
            if default is not None:
                defaults[str(name)] = deepcopy(default)
    from vibecomfy.porting.object_info.consume import class_defaults  # noqa: PLC0415

    for name, value in class_defaults(node.class_type).items():
        defaults.setdefault(str(name), deepcopy(value))
    return defaults


def _jsonable_widget_shape_value(value: Any) -> Any:
    raw_value = getattr(value, "value", value)
    if isinstance(raw_value, Mapping):
        return {str(k): _jsonable_widget_shape_value(v) for k, v in raw_value.items()}
    if isinstance(raw_value, tuple):
        return [_jsonable_widget_shape_value(v) for v in raw_value]
    if isinstance(raw_value, list):
        return [_jsonable_widget_shape_value(v) for v in raw_value]
    if isinstance(raw_value, (str, int, float, bool)) or raw_value is None:
        return raw_value
    return repr(raw_value)


def _widget_shape_evidence_summary(evidence: WidgetShapeEvidence) -> dict[str, Any]:
    return {
        "node_id": evidence.node_id,
        "class_type": evidence.class_type,
        "schema_less": evidence.schema_less,
        "confidence": evidence.confidence,
        "raw_widget_count": evidence.raw_widget_count,
        "candidate_widget_count": evidence.candidate_widget_count,
        "schema_widget_count": evidence.schema_widget_count,
        "raw_widget_shape": evidence.raw_widget_shape,
        "has_dict_rows": evidence.has_dict_rows,
        "overflow": evidence.overflow,
        "provider": evidence.provider,
        "explicit_widget_overflow": evidence.explicit_widget_overflow,
        "raw_widget_length_recovered": evidence.raw_widget_length_recovered,
        "value_domain": evidence.value_domain,
    }


def _widget_shape_report_fields(verdict: Any) -> dict[str, Any]:
    reasons = [_jsonable_widget_shape_value(reason) for reason in getattr(verdict, "reasons", ())]
    fields: dict[str, Any] = {
        "widget_shape_verdict": _jsonable_widget_shape_value(getattr(verdict, "decision", None)),
    }
    if reasons:
        fields["widget_shape_reasons"] = reasons
    if getattr(verdict, "pin_opaque", False) or getattr(verdict, "refuse", False):
        details: dict[str, Any] = {
            "reasons": reasons,
            "evidence": _widget_shape_evidence_summary(verdict.evidence),
        }
        if getattr(verdict, "field_delta", None):
            details["field_delta"] = _jsonable_widget_shape_value(verdict.field_delta)
        if getattr(verdict, "link_delta", None):
            details["link_delta"] = _jsonable_widget_shape_value(verdict.link_delta)
        fields["widget_shape_details"] = details
    return fields


def _node_delta(
    deltas: Mapping[str, Mapping[str, Any]],
    node_id: str,
    node: Any,
) -> Mapping[str, Any]:
    uid = getattr(node, "uid", "")
    if uid and uid in deltas:
        return deltas[uid]
    return deltas.get(node_id, {})


def _split_widget_shape_deltas(
    deltas: Mapping[str, Mapping[str, Any]],
    node_id: str,
    node: Any,
) -> tuple[dict[str, Any], dict[str, Any]]:
    delta = dict(_node_delta(deltas, node_id, node))
    field_delta: dict[str, Any] = {}
    link_delta: dict[str, Any] = {}
    if "widget_values_sig" in delta:
        field_delta["widgets_values"] = delta["widget_values_sig"]
    if "public_input_binding" in delta:
        field_delta["public_input_binding"] = delta["public_input_binding"]
    for key in ("incoming_edge_sig", "outgoing_edge_sig", "semantic_link_set"):
        if key in delta:
            link_delta[key] = delta[key]
    for key, value in delta.items():
        if key not in {
            "widget_values_sig",
            "public_input_binding",
            "incoming_edge_sig",
            "outgoing_edge_sig",
            "semantic_link_set",
        }:
            field_delta[key] = value
    return field_delta, link_delta


def _build_recovery_entry(
    p: Mapping[str, Any],
    verdict: Any,
    *,
    has_raw_ui_payload: bool,
) -> dict[str, Any]:
    entry: dict[str, Any] = {
        "node_id": p["node_id"],
        "class_type": p["class_type"],
        "provider": p.get("provider"),
        "confidence": p.get("confidence"),
        "schema_less": p["schema_less"],
        "control_after_generate": p.get("control_after_generate"),
        "control_after_generate_defaulted": p.get("control_after_generate_defaulted"),
        "widget_length_check": p.get("widget_length_check"),
        "value_domain": getattr(getattr(verdict, "evidence", None), "value_domain", None),
        "has_raw_ui_payload": has_raw_ui_payload,
    }
    entry.update(_widget_shape_report_fields(verdict))
    recovery = getattr(verdict, "recovery", None)
    if getattr(verdict, "evidence", None) is not None and getattr(
        verdict.evidence, "raw_widget_length_recovered", False
    ):
        recovery = "raw_widgets_values_length"
    if recovery is not None:
        entry["widget_shape_recovery"] = recovery
    if p.get("widget_order_guesses"):
        entry["widget_order_guesses"] = p["widget_order_guesses"]
    if p["schema_less"]:
        entry["diagnostic"] = "schema-less: emitting best-effort slots from link appearance order"
    elif p.get("confidence") is not None and p["confidence"] <= _LOW_CONFIDENCE_THRESHOLD:
        entry["diagnostic"] = f"low-confidence ({p['confidence']}): widget_schema_fallback"
    return entry


def _pinned_link_ref_refusal(
    node_id: str,
    class_type: str,
    reason: str,
    *,
    details: Mapping[str, Any],
) -> None:
    from vibecomfy.porting.refuse import RefusedEmit  # noqa: PLC0415

    typed_reason = (
        "pinned_link_id_mismatch"
        if reason
        in {
            "unmappable_input_link",
            "ambiguous_input_link",
            "missing_raw_input_link",
            "unmappable_output_links",
            "output_link_count_mismatch",
            "missing_raw_output_links",
            "missing_raw_output_slot",
        }
        else "pinned_link_surface_changed"
    )

    raise RefusedEmit(
        f"Refusing to emit pinned raw UI node {node_id}: {typed_reason}",
        diff={
            str(node_id): {
                "axis": "pinned_link_refs",
                "node_id": str(node_id),
                "class_type": class_type,
                "reason": typed_reason,
                "details": {**dict(details), "original_reason": reason},
            }
        },
    )


def _pinned_uid_refusal(
    node_id: str,
    class_type: str,
    *,
    axis: str,
    reason: str,
    details: Mapping[str, Any],
) -> None:
    from vibecomfy.porting.refuse import RefusedEmit  # noqa: PLC0415

    raise RefusedEmit(
        f"Refusing to emit pinned raw UI node {node_id}: {reason}",
        diff={
            str(node_id): {
                "axis": axis,
                "node_id": str(node_id),
                "class_type": class_type,
                "reason": reason,
                "details": {**dict(details)},
            }
        },
    )


def _coerce_link_refs(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, tuple):
        return list(value)
    return [value]


def _normalize_pinned_node_link_refs(
    node_dict: dict[str, Any],
    *,
    node_id: str,
    class_type: str,
    incoming_link_ids_by_input: Mapping[str, list[int]],
    outgoing_link_ids_by_slot: Mapping[int, list[int]],
) -> dict[str, Any]:
    """Rewrite copied pinned-node link refs to the emitted global ``links[]`` ids."""
    raw_inputs = node_dict.get("inputs") or []
    if not isinstance(raw_inputs, list):
        _pinned_link_ref_refusal(
            node_id,
            class_type,
            "invalid_raw_inputs",
            details={"raw_inputs_type": type(raw_inputs).__name__},
        )

    # Rich edges are structural authority. Extra/stale/nameless captured
    # input links are dropped; IR-only incoming edges are appended. Duplicate
    # captured names keep the first slot and clear the rest.
    seen_linked_inputs: set[str] = set()
    for raw_input in raw_inputs:
        if not isinstance(raw_input, dict) or raw_input.get("link") is None:
            continue
        input_name = raw_input.get("name")
        if input_name is None or str(input_name) == "":
            raw_input["link"] = None
            continue
        input_key = str(input_name)
        if input_key in seen_linked_inputs:
            raw_input["link"] = None
            continue
        current_link_ids = list(incoming_link_ids_by_input.get(input_key, []))
        if len(current_link_ids) == 1:
            raw_input["link"] = current_link_ids[0]
            seen_linked_inputs.add(input_key)
        elif current_link_ids:
            raw_input["link"] = current_link_ids[0]
            seen_linked_inputs.add(input_key)
        else:
            raw_input["link"] = None

    for input_name, link_ids in incoming_link_ids_by_input.items():
        if not link_ids or input_name in seen_linked_inputs:
            continue
        raw_inputs.append(
            {
                "name": input_name,
                "type": "*",
                "link": link_ids[0],
            }
        )
        seen_linked_inputs.add(input_name)

    raw_outputs = node_dict.get("outputs") or []
    if not isinstance(raw_outputs, list):
        _pinned_link_ref_refusal(
            node_id,
            class_type,
            "invalid_raw_outputs",
            details={"raw_outputs_type": type(raw_outputs).__name__},
        )

    seen_output_slots: set[int] = set()
    for idx, raw_output in enumerate(raw_outputs):
        if not isinstance(raw_output, dict):
            continue
        slot_raw = raw_output.get("slot_index", idx)
        try:
            slot = int(idx if slot_raw is None else slot_raw)
        except (TypeError, ValueError):
            slot = idx
        raw_output["slot_index"] = slot
        raw_link_refs = _coerce_link_refs(raw_output.get("links"))
        current_link_ids = sorted(outgoing_link_ids_by_slot.get(slot, []))
        if raw_link_refs or current_link_ids:
            # Rich-edge authority: always stamp the IR's current ids.
            # Extra captured output links are stale and are dropped.
            # Missing captured output links are filled from the IR.
            # Preserve an observed list-shaped link field when a touched
            # output becomes unwired; fresh schema-derived outputs continue to
            # use null in the normal emission path.
            raw_output["links"] = current_link_ids
            seen_output_slots.add(slot)

    missing_output_slots = sorted(
        slot
        for slot, link_ids in outgoing_link_ids_by_slot.items()
        if link_ids and slot not in seen_output_slots
    )
    for slot in missing_output_slots:
        raw_outputs.append(
            {
                "name": f"output_{slot}",
                "type": "*",
                "links": sorted(outgoing_link_ids_by_slot.get(slot, [])),
                "slot_index": slot,
            }
        )
    return node_dict


def _dict_row_widget_overlay(node: Any) -> dict[str, Any]:
    """Named widget/input values from the IR for dict-row pin merge."""
    overlay: dict[str, Any] = {}
    widgets = getattr(node, "widgets", None) or {}
    if isinstance(widgets, Mapping):
        overlay.update({str(key): value for key, value in widgets.items()})
    inputs = getattr(node, "inputs", None) or {}
    if isinstance(inputs, Mapping):
        for key, value in inputs.items():
            if isinstance(value, (list, tuple)) and len(value) == 2:
                continue
            overlay.setdefault(str(key), value)
    return overlay


def _apply_dict_row_widget_overlay(
    values: dict[str, Any], overlay: Mapping[str, Any]
) -> None:
    for key, value in overlay.items():
        if key in values:
            values[key] = deepcopy(value)
            continue
        stripped = key[:-1] if key.endswith("_") else key
        if stripped in values:
            values[stripped] = deepcopy(value)
            continue
        underscored = f"{key}_"
        if underscored in values:
            values[underscored] = deepcopy(value)


def _raw_ui_payload_for_pin(
    raw_ui_node: Mapping[str, Any],
    *,
    node_id: str,
    class_type: str,
    canonical_uid: str,
    litegraph_node_id: int,
    order: int,
    incoming_link_ids_by_input: Mapping[str, list[int]],
    outgoing_link_ids_by_slot: Mapping[int, list[int]],
    widget_overlay: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    # Stable-UID gate: a pinned raw node is only emitted under an explicit
    # canonical uid from the VibeNode. Never fall back to captured properties,
    # node id, or stale captured identity — fail closed instead.
    if not isinstance(canonical_uid, str) or not canonical_uid.strip():
        _pinned_uid_refusal(
            node_id,
            class_type,
            axis="pinned_stable_uid",
            reason="missing_stable_uid",
            details={
                "canonical_uid_type": type(canonical_uid).__name__,
                "canonical_uid": canonical_uid if isinstance(canonical_uid, str) else None,
            },
        )

    node_dict = deepcopy(dict(raw_ui_node))
    _normalize_pinned_node_link_refs(
        node_dict,
        node_id=node_id,
        class_type=class_type,
        incoming_link_ids_by_input=incoming_link_ids_by_input,
        outgoing_link_ids_by_slot=outgoing_link_ids_by_slot,
    )
    node_dict["id"] = litegraph_node_id
    node_dict["order"] = order
    if widget_overlay:
        raw_values = node_dict.get("widgets_values")
        if isinstance(raw_values, dict):
            _apply_dict_row_widget_overlay(raw_values, widget_overlay)

    # Properties gate: the copied payload must expose a dict to stamp into.
    properties = node_dict.get("properties")
    if properties is None:
        properties = {}
        node_dict["properties"] = properties
    elif not isinstance(properties, dict):
        _pinned_uid_refusal(
            node_id,
            class_type,
            axis="pinned_properties",
            reason="invalid_captured_properties",
            details={"properties_type": type(properties).__name__},
        )

    # Canonical identity overlay: scrub the demoted stale key, then stamp the
    # canonical uid so it always wins over missing/stale captured values.
    properties.pop("ir_node_id", None)
    properties["vibecomfy_uid"] = canonical_uid
    return node_dict


def derive_widget_shape_evidence(
    node: Any,
    schema_provider: Any | None,
) -> WidgetShapeEvidence:
    """Derive widget-shape proof for one node before UI widget regeneration.

    The candidate count intentionally goes through the same compacted-name vector
    and ``_build_widget_values`` logic that emission uses, so fresh programmatic
    ``widget_N`` overflow is visible even when no raw UI payload exists.
    """
    schema = _schema_for_provider(schema_provider, node.class_type)
    provenance = _get_node_schema_provenance(node.class_type, schema)
    widget_names = _widget_names_for_emission(
        node.class_type,
        schema,
        node=node,
        schema_provider=schema_provider,
    )
    value_domain = _widget_value_domain_for_emission(
        node,
        widget_names_for_class(node.class_type),
        _object_info_widget_order_for_emission(node.class_type, schema_provider),
    )
    candidate_widget_count = len(
        _build_widget_values(node, widget_names, value_domain=value_domain)
    )
    schema_widget_count = _full_widget_name_count(
        node.class_type,
        schema,
        schema_provider=schema_provider,
    )
    authored_widget_count = _authored_widget_count(node)
    if authored_widget_count:
        schema_widget_count = max(schema_widget_count or 0, authored_widget_count)
    raw_widget_count, raw_widget_shape, has_dict_rows = _raw_widget_shape_from_node(node)
    if node.class_type == "vibecomfy.exec" and _exec_io_for_node(node) is not None:
        # The exec node's `io` mapping is its validated socket declaration,
        # not a dynamic widget-row schema.  Treating that fixed builtin row as
        # opaque dynamic shape incorrectly refuses every authorized topology
        # edit involving an existing exec node.
        has_dict_rows = False
    schema_inputs = getattr(schema, "inputs", None)
    provider_widget_count = len(schema_inputs) if isinstance(schema_inputs, dict) else None
    if (
        has_dict_rows
        and provider_widget_count is not None
        and schema_widget_count is not None
        and _raw_widget_order_from_provider(node.class_type, schema_provider) is None
    ):
        schema_widget_count = min(schema_widget_count, provider_widget_count)
    elif (
        provider_widget_count is not None
        and schema_widget_count is not None
        and _raw_widget_order_from_provider(node.class_type, schema_provider) is None
    ):
        schema_widget_count = max(schema_widget_count, provider_widget_count)
    largest_observed_count = candidate_widget_count
    if raw_widget_count is not None:
        largest_observed_count = max(largest_observed_count, raw_widget_count)
    programmatic_widget_count = 0
    node_widgets = getattr(node, "widgets", None)
    if isinstance(node_widgets, dict):
        widget_idxs: list[int] = []
        for key in node_widgets:
            if str(key).startswith("widget_"):
                try:
                    widget_idxs.append(int(str(key).split("_", 1)[1]))
                except ValueError:
                    continue
        if widget_idxs:
            programmatic_widget_count = max(widget_idxs) + 1
    primitive_control_widget = (
        node.class_type in _PRIMITIVE_CONTROL_WIDGET_CLASSES
        and schema_widget_count == 1
        and candidate_widget_count == 2
        and programmatic_widget_count == 2
        and raw_widget_count is None
        and isinstance(node_widgets, dict)
        and node_widgets.get("widget_1") in {"fixed", "randomize", "increment", "decrement"}
    )
    overflow = False
    explicit_widget_overflow = False
    if schema_widget_count is not None and not provenance["schema_less"]:
        if has_dict_rows:
            overflow = largest_observed_count > schema_widget_count
        elif primitive_control_widget:
            overflow = False
        elif (
            node.class_type in _STATIC_RAW_WIDGET_SLACK_CLASSES
            and candidate_widget_count <= schema_widget_count + _STATIC_WIDGET_OVERFLOW_TOLERANCE
            and (
                raw_widget_count is not None
                or programmatic_widget_count <= schema_widget_count
            )
            and (
                raw_widget_count is None
                or programmatic_widget_count <= raw_widget_count
            )
        ):
            overflow = False
        elif (
            programmatic_widget_count > schema_widget_count
            and not (raw_widget_count is not None and programmatic_widget_count <= raw_widget_count)
        ):
            overflow = True
            explicit_widget_overflow = True
        else:
            overflow = largest_observed_count > schema_widget_count
            explicit_widget_overflow = (
                programmatic_widget_count > schema_widget_count
                and not (
                    raw_widget_count is not None
                    and programmatic_widget_count <= raw_widget_count
                )
            )

    raw_widget_length_recovered = False
    raw_widgets = getattr(node, "raw_widgets", None)
    if raw_widgets is not None and getattr(raw_widgets, "length", None) is None:
        raw_widget_length_recovered = raw_widget_count is not None

    return WidgetShapeEvidence(
        node_id=str(node.id),
        class_type=str(node.class_type),
        schema_less=bool(provenance["schema_less"]),
        confidence=provenance.get("confidence"),
        raw_widget_count=raw_widget_count,
        candidate_widget_count=candidate_widget_count,
        schema_widget_count=schema_widget_count,
        compacted_widget_names=tuple(
            name
            for index, name in enumerate(widget_names)
            if name is not None and name != f"widget_{index}"
        ),
        raw_widget_shape=raw_widget_shape,
        has_dict_rows=has_dict_rows,
        overflow=overflow,
        provider=provenance.get("provider"),
        explicit_widget_overflow=explicit_widget_overflow,
        raw_widget_length_recovered=raw_widget_length_recovered,
        value_domain=value_domain,
    )


def _with_emit_object_info_snapshot(func):
    """Keep cached class evidence coherent for one UI serialization."""
    @functools.wraps(func)
    def wrapped(wf: Any, *args: Any, **kwargs: Any):
        from vibecomfy.porting.object_info.consume import class_entry_snapshot

        classes = {str(node.class_type) for node in wf.nodes.values()}
        definitions = getattr(wf, "definitions", None)
        if definitions:
            classes.update(
                str(node["class_type"])
                for node in wf._semantic_definition_nodes(definitions)
            )
        with class_entry_snapshot(classes):
            return func(wf, *args, **kwargs)

    return wrapped


@_with_emit_object_info_snapshot
def emit_ui_json(
    wf: Any,
    *,
    schema_provider: Any = None,
    prior_store: Mapping[str, Any] | None = None,
    layout: Any = None,
    anchors: dict[str, Any] | None = None,
    strict: bool = False,
    recovery_report: list[dict[str, Any]] | None = None,
    source_template: str | None = None,
    prior_path: str | None = None,
    include_main_positions: bool = False,
    include_virtual_wires: bool = True,
    extra: dict[str, Any] | None = None,
    definitions: dict[str, Any] | None = None,
    change_report_out: list | None = None,
    guard_original_ui: Mapping[str, Any] | None = None,
    guard_resolved_ops: Any = None,
    prior_ui_payload: Mapping[str, Any] | None = None,
    force_drop_editor_only: bool = False,
    presentation: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Render ``wf`` (a ``VibeWorkflow``) to a litegraph JSON envelope.

    Args:
        wf: The IR workflow to emit.
        schema_provider: Schema source used for slot/type resolution.  Consulted
            via ``get_schema(class_type)`` for each node.  Pass ``None`` to skip
            schema resolution (all edges emit with slot 0 and empty type).
        prior_store: Full prior-store envelope (``{entries, groups, extra,
            definitions, virtual_wires}``) from a previously written sidecar.
            ``entries`` (keyed by node uid) feeds the legacy
            ``_resolve_furniture`` precedence chain and is passed as ``pinned``
            to the layout engine.  The full envelope is also handed to
            :func:`reconcile` once at the top of the function; the resulting
            ``ReconcileResult`` is exposed to the per-node loop as a local
            (``reconcile_result``) for later steps (Step 9b+).
        anchors: New-node placement hints ``{new_uid: anchor_uid, ...}``.
            Routed to :func:`~vibecomfy.porting.layout.placement.place_constrained`
            in the engine (Phase 8) as a dedicated kwarg.  Passing ``None`` or
            ``{}`` leaves existing behavior unchanged.
        strict: When ``True``, raises ``ValueError`` if any node has a schema-less
            class type (``get_schema() == None``) or a low-confidence schema
            (``confidence <= 0.3``, i.e. the ``widget_schema_fallback`` tier).
        recovery_report: Optional mutable list.  If provided, one provenance dict
            is appended per node with keys ``node_id``, ``class_type``,
            ``provider``, ``confidence``, ``schema_less``.  This is the
            **authoritative** record of which schema tier supplied each node's
            output/input resolution.
        extra: Optional ``extra`` dict (canvas drag/scale state under ``extra.ds``).
            When provided, merged with the ``vibecomfy`` breadcrumb; otherwise
            only the breadcrumb is emitted.
        definitions: Optional subgraph definitions blob.  When provided from a
            sidecar envelope, used directly instead of re-emitting from IR
            metadata via ``_emit_definitions``.  The caller is responsible for
            passing definitions as they appear in the sidecar's envelope.
        prior_ui_payload: Optional full raw LiteGraph UI JSON used only as raw
            node evidence for future dynamic widget pin/refuse decisions.
            ``prior_store`` remains furniture-only and is not treated as a raw
            node payload source.

    Returns:
        A litegraph envelope dict: ``version``, deterministic ``id``,
        ``last_node_id``, ``last_link_id``, ``groups``, ``nodes``, and ``links``.
        Every node carries stamped ``properties`` and stub geometry.  Node outputs
        include ``slot_index``, ``name``, ``type``, and ``links`` (``null`` for
        unwired outputs).  The global ``links`` list holds 6-element arrays
        ``[link_id, from_node, from_slot, to_node, to_slot, type]``.
    """
    if prior_ui_payload is not None:
        prior_ui_payload = _thaw_json_view(prior_ui_payload)
    if guard_original_ui is not None:
        guard_original_ui = _thaw_json_view(guard_original_ui)
    presentation_mode = presentation is not None
    if presentation_mode:
        # The bundle route has one explicit source-separation mode.  Do not
        # permit the legacy furniture/raw payload arguments to be combined
        # with it; doing so would create an ambiguous presentation authority.
        if any(value is not None for value in (prior_store, layout, extra, definitions, source_template, prior_path, prior_ui_payload)):
            raise ValueError("presentation mode cannot be combined with prior/layout/raw UI authorities")
        from vibecomfy.workflow_bundle import validate_sidecar

        presentation = validate_sidecar(presentation, wf)
        # Strip import/replay evidence before the existing serializer runs.
        wf = wf.copy()
        metadata = getattr(wf, "metadata", None)
        if isinstance(metadata, dict):
            wf.metadata = {
                key: value for key, value in metadata.items()
                if key not in {
                    _UI_DOOR_KEY, "_ingest_snapshot", "_ingest_raw", "_raw_ui",
                    "_edit_link_id_hints", "definitions",
                }
            }
        for node in wf.nodes.values():
            node.raw_widgets = None
            if isinstance(getattr(node, "metadata", None), dict):
                node.metadata = {
                    key: value for key, value in node.metadata.items()
                    if key != "_ui" and not str(key).startswith("_ui_")
                }
        layout = dict(presentation.get("nodes", {}))
        canvas = presentation.get("canvas", {})
        extra = {}
        if isinstance(canvas, Mapping):
            ds = {}
            if "zoom" in canvas:
                ds["scale"] = deepcopy(canvas["zoom"])
            if "pan" in canvas:
                ds["offset"] = deepcopy(canvas["pan"])
            if ds:
                extra["ds"] = ds
        include_main_positions = True

    (
        chunked_emit_node_threshold,
        chunked_emit_chunk_size,
        chunked_emit_warn_every,
    ) = _chunked_emit_settings()
    _raise_embedded_api_links(wf, surface="UI serialization")

    # P0-WIDGET-CANON: sealed snapshot table is the sole name authority for
    # widget-name derivation during UI emission.
    from vibecomfy.ingest.snapshot import frozen_widget_names_by_uid  # noqa: PLC0415

    name_authority = frozen_widget_names_by_uid(wf)

    # ── Law 1 door passthrough (batch 2) ───────────────────────────────────
    # An UNTOUCHED graph (fingerprint unchanged since offline ingest) is
    # re-emitted byte-faithfully from the wire data captured at the ingest
    # boundary: original id/version/counters, link ids/order/type,
    # extra/definitions/state, groups, node geometry/order/properties, and
    # opaque keys.  A semantic edit (node/widget/edge change) takes the
    # deterministic reconstruction path below instead.  The passthrough is
    # bypassed whenever the caller asks for a different output shape (flat/
    # virtual-wire toggle, include_main_positions, explicit extra/definitions/
    # prior_store/layout overrides, strict) or the graph was ingested through
    # the comfy converter.  ``guard_original_ui`` (guard_full_ui) is still
    # enforced on the passthrough envelope — the exit fidelity is not weakened.
    _door = (wf.metadata or {}).get(_UI_DOOR_KEY)
    if _door_ui_passthrough_applicable(
        wf,
        _door,
        include_virtual_wires=include_virtual_wires,
        include_main_positions=include_main_positions,
        extra=extra,
        definitions=definitions,
        prior_store=prior_store,
        layout=layout,
        strict=strict,
    ):
        envelope = _emit_untouched_door_ui(_door)
        # Subgraph definitions are retained outside the root-node fingerprint.
        # Keep the byte-faithful root graph (including node order/geometry) for
        # a definitions-only edit, while replacing just the changed definitions
        # blob with the IR-authoritative form.
        captured_defs = _door_top(_door).get("definitions")
        ir_defs = getattr(wf, "definitions", None)
        if not isinstance(ir_defs, Mapping):
            ir_metadata = getattr(wf, "metadata", None)
            ir_defs = ir_metadata.get("definitions") if isinstance(ir_metadata, Mapping) else None
        if isinstance(captured_defs, Mapping) and isinstance(ir_defs, Mapping):
            from vibecomfy.ingest.normalize import _door_freeze  # noqa: PLC0415

            if _door_freeze(captured_defs) != _door_freeze(ir_defs):
                emitted_defs = _emit_definitions(wf)
                if emitted_defs is not None:
                    envelope["definitions"] = emitted_defs
                else:
                    envelope.pop("definitions", None)
                    envelope.pop("state", None)
        if guard_original_ui is not None:
            from vibecomfy.porting.layout.delta import compute_field_delta  # noqa: PLC0415
            from vibecomfy.porting.refuse import guard_emit as _guard_emit  # noqa: PLC0415

            _snap = (wf.metadata or {}).get("_ingest_snapshot", {})
            _delta = compute_field_delta(_snap, wf) if _snap else {}
            _guard_emit(guard_original_ui, envelope, _delta, resolved_ops=guard_resolved_ops)
        return envelope

    # T9a: prior_store is the full envelope ({entries, groups, extra, definitions,
    # virtual_wires}); reconcile() is called once at top and the result exposed to
    # the per-node loop as a local. Presentation is a separate source boundary:
    # its validated entries are already keyed by structural UID, so invoking the
    # legacy furniture reconciler would reintroduce an unapproved authority.
    _prior_store: dict[str, Any] = dict(prior_store) if prior_store else {}
    raw_ui_node_map = extract_raw_ui_node_map(prior_ui_payload)
    if presentation_mode:
        from vibecomfy.porting.layout.reconcile import ReconcileResult  # noqa: PLC0415

        current_uids = {
            str(node.uid)
            for node in wf.nodes.values()
            if getattr(node, "uid", None)
        }
        presentation_entries = presentation.get("nodes", {})
        matched = {
            str(uid): dict(entry)
            for uid, entry in presentation_entries.items()
            if str(uid) in current_uids and isinstance(entry, Mapping)
        }
        reconcile_result = ReconcileResult(
            matched=matched,
            new=sorted(current_uids - set(matched)),
            removed=[],
            degraded_virtual_wires=[],
        )
        layout = {}
    else:
        from vibecomfy.porting.layout.reconcile import reconcile as _reconcile  # noqa: PLC0415

        # Back-compat: callers that still pass the flat ``layout=`` kwarg are wrapped
        # into a minimal envelope so reconcile() sees the entries. Step 9b retires
        # ``layout`` entirely once all call sites migrate to prior_store.
        if layout is not None and not _prior_store:
            _prior_store = {"entries": dict(layout) if isinstance(layout, dict) else {}}
        reconcile_result = _reconcile(wf, _prior_store)
        layout = _prior_store.get("entries", {}) or {}
    anchors = anchors or {}

    # ── Editor-ahead detection (T3) ───────────────────────────────────────────
    # When guard_original_ui is supplied, detect editor-only uids early (before
    # expensive emission) and raise EditorAheadError so the caller can abort.
    # An editor-only uid is in the prior store, absent from the IR, and NOT in
    # the VibeComfy-authored set.
    #
    # Authored-uid heuristic: if the prior-store breadcrumb's prior_path matches
    # the current workflow's source path, all prior-store uids were authored by a
    # previous VibeComfy emit of this file → treat them all as authored.
    # If no breadcrumb or path mismatch → authored set is EMPTY so every
    # prior-only uid is conservatively flagged as editor-added.
    if guard_original_ui is not None:
        _prior_store_uids: set[str] = set(_prior_store.get("entries", {}).keys())
        _ir_uids: set[str] = set(wf.nodes.keys())
        _prior_breadcrumb: dict = (_prior_store.get("extra") or {}).get("vibecomfy") or {}
        _bc_prior_path = _prior_breadcrumb.get("prior_path")
        _wf_source_path = _source_prior_path(wf)
        if (
            _bc_prior_path is not None
            and _wf_source_path is not None
            and _bc_prior_path == _wf_source_path
        ):
            _vibecomfy_authored: set[str] = set(_prior_store_uids)
        else:
            _vibecomfy_authored = set()
        _editor_only: set[str] = _prior_store_uids - _ir_uids - _vibecomfy_authored
        if _editor_only:
            _entries = _prior_store.get("entries", {})
            if force_drop_editor_only:
                # Suppress the editor-ahead error: fold editor-only uids into
                # reconcile_result.removed so build_change_report can populate
                # removed_named with class_type information.
                _sorted_editor_only = sorted(_editor_only)
                reconcile_result.removed.extend(_sorted_editor_only)
            else:
                from vibecomfy.porting.refuse import EditorAheadError as _EditorAheadError  # noqa: PLC0415
                raise _EditorAheadError(
                    [
                        {"uid": u, "class_type": _entries.get(u, {}).get("class_type", "")}
                        for u in sorted(_editor_only)
                    ]
                )

    # Build ChangeReport if the caller requested it via change_report_out.
    _change_report_ref: list = []  # mutable container so we can set stripped_helpers later
    if change_report_out is not None:
        from vibecomfy.porting.layout.delta import compute_field_delta  # noqa: PLC0415
        from vibecomfy.porting.layout.reconcile import build_change_report  # noqa: PLC0415
        _snapshot = (wf.metadata or {}).get("_ingest_snapshot", {})
        _field_delta = compute_field_delta(_snapshot, wf) if _snapshot else {}
        _report = build_change_report(
            reconcile_result,
            _field_delta,
            prior_store_entries=_prior_store.get("entries"),
        )
        change_report_out.append(_report)
        _change_report_ref.append(_report)

    # ── Resolve broadcast helpers (SetNode / GetNode) into direct edges ────
    # effective_edges: direct links for the EXECUTION (flat) graph
    # broadcast_ids: SetNode/GetNode node ids to drop from flat graph
    # orphaned_get_ids: GetNode ids whose broadcast name has no SetNode source
    if presentation_mode:
        # Canonical materialization displays the Python graph as authored.  Do
        # not lower broadcast/reroute helpers or infer a flat execution graph
        # from transient UI-era helper conventions at this boundary.
        effective_edges = list(wf.edges)
        broadcast_ids: set[str] = set()
        orphaned_get_ids: set[str] = set()
    else:
        effective_edges, broadcast_ids, orphaned_get_ids = _resolve_broadcast_edges(wf)

    presentation_virtual_edges = _root_virtual_display_edges(wf) if presentation_mode else []

    # Collect the full set of virtual-wire node ids (broadcast + Reroute)
    reroute_ids = {
        node_id
        for node_id, node in wf.nodes.items()
        if node.class_type == "Reroute"
    }
    virtual_wire_ids: set[str] = broadcast_ids | reroute_ids

    # Populate stripped_helpers on the change report (now that virtual_wire_ids is computed).
    if _change_report_ref:
        _change_report_ref[0].content_edits.stripped_helpers = sorted(virtual_wire_ids) if virtual_wire_ids else []

    # ── Choose edge list and node filter based on virtual-wire toggle ───────
    if include_virtual_wires:
        # DISPLAY mode: keep all nodes, use ALL original edges (helpers visible)
        order_list = _emission_order(wf)
        display_edges = list(wf.edges) + presentation_virtual_edges
    else:
        # EXECUTION (flat) mode: drop virtual-wire nodes, resolve edges
        order_list = [
            nid for nid in _emission_order(wf) if nid not in virtual_wire_ids
        ]
        # First resolve broadcast indirection, then passthrough Reroutes
        flat_edges = _resolve_reroute_edges(effective_edges, wf.nodes)
        display_edges = flat_edges

    # Remap string node ids → litegraph integer ids (digit ids preserve their value).
    id_remap = _build_id_remap(order_list)

    # Build schema cache (one get_schema call per unique class_type)
    schema_cache: dict[str, Any] = {}
    if schema_provider is not None:
        for node_id in order_list:
            ct = wf.nodes[node_id].class_type
            if ct not in schema_cache:
                schema_cache[ct] = schema_provider.get_schema(ct)

    # ── Layout engine: compute fresh positions for every node ───────────────
    # T9b: reconcile-driven merge.
    #   pinned   = {uid: {pos,size} for uid in reconcile_result.matched}
    #              → engine never re-positions matched nodes.
    #   anchors  = caller-supplied anchors ∪ computed_anchors, where
    #              computed_anchors[new_uid] = nearest_wired_neighbor_uid(new_node, matched).
    #              unmatched_legacy / removed-then-readded nodes (i.e. nodes whose
    #              key is neither matched nor in reconcile_result.new but were once
    #              in the store) route through the engine WITHOUT anchors.
    from vibecomfy.porting.layout import layout as _compute_layout  # noqa: PLC0415
    from vibecomfy.porting.layout.reconcile import (  # noqa: PLC0415
        nearest_wired_neighbor_uid as _nearest_wired_neighbor_uid,
    )

    matched_entries: dict[str, dict[str, Any]] = reconcile_result.matched

    def _node_key(node_id: str) -> str:
        n = wf.nodes.get(node_id)
        return (n.uid or node_id) if n is not None else node_id

    pinned_for_engine: dict[str, dict[str, Any]] = {}
    for uid_key, m_entry in matched_entries.items():
        if isinstance(m_entry, dict) and "pos" in m_entry and "size" in m_entry:
            pinned_for_engine[uid_key] = {"pos": m_entry["pos"], "size": m_entry["size"]}

    computed_anchors: dict[str, Any] = {}
    new_keys_set: set[str] = set(reconcile_result.new)
    for node_id in order_list:
        key = _node_key(node_id)
        if key not in new_keys_set:
            continue
        anchor = _nearest_wired_neighbor_uid(node_id, wf, matched_entries)
        if anchor is not None:
            computed_anchors[key] = anchor

    effective_anchors: dict[str, Any] = dict(anchors) if anchors else {}
    group_anchors: dict[str, Any] = dict(effective_anchors)
    topology_between_keys: set[str] = set()
    explicit_anchor_groups: dict[str, str] = {}
    for node_id in order_list:
        node = wf.nodes[node_id]
        key = _node_key(node_id)
        metadata = getattr(node, "metadata", None)
        if not isinstance(metadata, Mapping):
            continue
        retained_anchor = metadata.get("_edit_anchor_uid")
        retained_relation = metadata.get("_edit_anchor_relation")
        retained_between = metadata.get("_edit_anchor_between_uids")
        is_complete_between = (
            retained_relation == "between"
            and isinstance(retained_between, (list, tuple))
            and len(retained_between) == 2
            and all(value not in (None, "") for value in retained_between)
        )
        if is_complete_between and key not in effective_anchors:
            # The topology engine already places a true splice between its
            # two wired endpoints.  Collapsing this to a one-sided constrained
            # anchor pushes it to the right of the downstream node.  Retain
            # the full relation as the reason to suppress that lossy override.
            topology_between_keys.add(key)
            group_anchors.setdefault(key, str(retained_between[1]))
        elif retained_anchor not in (None, ""):
            effective_anchors.setdefault(key, str(retained_anchor))
            group_anchors.setdefault(key, str(retained_anchor))
        retained_group = metadata.get("_edit_group_title")
        if retained_group not in (None, ""):
            explicit_anchor_groups[key] = str(retained_group)
    for k, v in computed_anchors.items():
        if k not in topology_between_keys:
            effective_anchors.setdefault(k, v)
            group_anchors.setdefault(k, v)

    # Flat mode (include_virtual_wires=False): the layout engine must compute
    # positions against the FLAT execution graph — virtual-wire nodes removed,
    # broadcast/Reroute edges already resolved — so emitted geometry is a pure
    # function of the flat graph.  Without this, a workflow whose helpers were
    # retained in the IR (--keep-virtual-wires) would lay out real nodes at
    # different layers/lanes than the same flat graph whose helpers were
    # resolved during conversion, breaking flat round-trip byte-equivalence.
    _layout_wf = wf
    if not include_virtual_wires and virtual_wire_ids:
        _layout_wf = _flat_layout_workflow(wf, virtual_wire_ids, display_edges)

    _engine_result = _compute_layout(
        _layout_wf,
        schema_provider=schema_provider,
        schema_cache=schema_cache,
        pinned=pinned_for_engine,
        anchors=effective_anchors,
    )
    engine_positions: dict[str, Any] = _engine_result.positions
    engine_groups: list[dict[str, Any]] = _engine_result.groups  # used in T8 group merge

    # Per-node provenance (keyed by node_id)
    node_prov: dict[str, dict[str, Any]] = {}
    for node_id in order_list:
        ct = wf.nodes[node_id].class_type
        schema = schema_cache.get(ct)
        prov = _get_node_schema_provenance(ct, schema)
        prov["node_id"] = node_id
        prov["class_type"] = ct
        node_prov[node_id] = prov

    # Strict check: fail early if any node is low-confidence or schema-less
    if strict:
        failures: list[str] = []
        for node_id in order_list:
            p = node_prov[node_id]
            conf = p["confidence"]
            if p["schema_less"] or (conf is not None and conf <= _LOW_CONFIDENCE_THRESHOLD):
                reason = "schema-less" if p["schema_less"] else f"confidence={conf}"
                failures.append(f"{node_id}({p['class_type']}): {reason}")
        if failures:
            raise ValueError(f"strict=True: low-confidence or schema-less nodes: {failures}")

    # Widget-shape fence pre-pass: evidence -> verdict happens before any node is
    # emitted. Refusals abort before ``nodes.append(...)`` can return a partial
    # invalid envelope; safe nodes regenerate widgets inside the node loop; pinned
    # nodes copy their raw LiteGraph payload without rebuilding widgets.
    from vibecomfy.porting.layout.delta import compute_field_delta  # noqa: PLC0415
    from vibecomfy.porting.refuse import refused_widget_shape as _refused_widget_shape  # noqa: PLC0415
    from vibecomfy.porting.widget_shape_fence import decide_widget_shape as _decide_widget_shape  # noqa: PLC0415

    _snapshot = (wf.metadata or {}).get("_ingest_snapshot", {})
    _field_delta_by_uid = compute_field_delta(_snapshot, wf) if _snapshot else {}
    widget_shape_verdicts: dict[str, Any] = {}
    widget_shape_raw_payloads: dict[str, Mapping[str, Any] | None] = {}
    widget_shape_default_values: dict[str, Mapping[str, Any] | None] = {}
    new_node_keys: set[str] = set(reconcile_result.new)
    for node_id in order_list:
        node = wf.nodes[node_id]
        schema = schema_cache.get(node.class_type)
        prov = node_prov[node_id]

        retained_control = node.metadata.get("control_after_generate")
        if isinstance(retained_control, str):
            prov["control_after_generate"] = retained_control
            prov["control_after_generate_defaulted"] = False
        else:
            prov["control_after_generate"] = _CONTROL_AFTER_GENERATE_DEFAULT
            prov["control_after_generate_defaulted"] = True

        expected_widget_count = _full_widget_name_count(
            node.class_type, schema, schema_provider=schema_provider
        )
        extra_hints = _extra_widgets_after(
            node.class_type, schema, schema_provider=schema_provider
        )
        if extra_hints:
            prov["widget_order_guesses"] = [
                "(control_after_generate)" if name is None else name
                for name in extra_hints
            ]

        evidence = derive_widget_shape_evidence(node, schema_provider)
        if expected_widget_count is None:
            prov["widget_length_check"] = "skipped: schema-less"
        elif evidence.overflow:
            prov["widget_length_check"] = (
                f"overflow {evidence.candidate_widget_count}>{expected_widget_count}"
            )
        else:
            prov["widget_length_check"] = (
                f"{evidence.candidate_widget_count}<={expected_widget_count}"
            )

        raw_ui_node = _raw_ui_node_for_node(node_id, node, raw_ui_node_map)
        widget_shape_raw_payloads[node_id] = raw_ui_node
        identity_matched = _widget_shape_identity_match(
            node_id,
            node,
            matched_entries,
            raw_ui_node,
        )
        field_delta, link_delta = _split_widget_shape_deltas(_field_delta_by_uid, node_id, node)
        layout_entry = _layout_entry_for_widget_shape(node_id, node, matched_entries)
        allow_schema_defaults = (
            raw_ui_node is None
            and not identity_matched
            and schema is not None
            and not prov["schema_less"]
            and prov.get("provider") == "object_info_index"
            and expected_widget_count is not None
            and expected_widget_count > 1
            and (prov.get("confidence") is None or prov["confidence"] > _LOW_CONFIDENCE_THRESHOLD)
            and not evidence.has_dict_rows
            and _has_schema_default_regeneration_basis(node, schema, schema_provider)
        )
        verdict = _decide_widget_shape(
            evidence,
            raw_widget_payloads={node_id: getattr(node, "raw_widgets", None)},
            raw_payloads={node_id: raw_ui_node} if raw_ui_node is not None else {},
            layout_entries={node_id: layout_entry} if layout_entry is not None else {},
            field_deltas={node_id: field_delta} if field_delta else {},
            link_deltas={node_id: link_delta} if link_delta else {},
            identity_matched=identity_matched,
            allow_schema_default_regenerate=allow_schema_defaults,
            is_new_node=(
                (node.uid or node_id) in new_node_keys
                and getattr(node, "raw_widgets", None) is None
                and raw_ui_node is None
            ),
        )
        widget_shape_verdicts[node_id] = verdict
        widget_shape_default_values[node_id] = (
            _schema_default_widget_values_for_node(node, schema)
            if getattr(verdict, "use_schema_defaults", False)
            else None
        )

    refused_verdicts = [
        verdict
        for verdict in widget_shape_verdicts.values()
        if verdict.refuse
    ]
    if refused_verdicts:
        if recovery_report is not None:
            for node_id in order_list:
                recovery_report.append(
                    _build_recovery_entry(
                        node_prov[node_id],
                        widget_shape_verdicts[node_id],
                        has_raw_ui_payload=widget_shape_raw_payloads[node_id] is not None,
                    )
                )
        raise _refused_widget_shape(refused_verdicts)

    # Sort edges deterministically (from_node asc, from_output, to_node, to_input)
    sorted_edges = sorted(
        display_edges,
        key=lambda e: (e.from_node.zfill(20), e.from_output, e.to_node.zfill(20), e.to_input),
    )

    # Assign link IDs: prefer the captured wire ids for structurally unchanged
    # links (Law 1 wire preference); mint fresh ids above the captured maximum
    # for changed/added links.  Non-door workflows keep the deterministic
    # 1-indexed numbering (the captured map is empty there).
    EdgeKey = tuple[str, str, str, str]
    captured_link_ids = _captured_link_id_map(_door)
    for key, link_id in _captured_link_id_map_from_ui_payload(prior_ui_payload).items():
        captured_link_ids.setdefault(key, link_id)
    edit_link_hints = (wf.metadata or {}).get("_edit_link_id_hints", {})
    used_link_ids: set[int] = set()
    link_id_map: dict[EdgeKey, int] = {}
    next_link_id = max(captured_link_ids.values(), default=0) + 1
    for edge in sorted_edges:
        key = (edge.from_node, edge.from_output, edge.to_node, edge.to_input)
        hint_key = "\x1f".join(key)
        hinted = edit_link_hints.get(hint_key) if isinstance(edit_link_hints, Mapping) else None
        if isinstance(hinted, int) and hinted not in used_link_ids:
            link_id_map[key] = hinted
            used_link_ids.add(hinted)
            continue
        captured = captured_link_ids.get(key)
        if captured is not None and captured not in used_link_ids:
            link_id_map[key] = captured
            used_link_ids.add(captured)
            continue
        while next_link_id in used_link_ids:
            next_link_id += 1
        link_id_map[key] = next_link_id
        used_link_ids.add(next_link_id)
        next_link_id += 1
    last_link_id = max(used_link_ids) + 1 if used_link_ids else 0

    # Edge lookup by node
    edges_from: dict[str, list[Any]] = defaultdict(list)
    edges_to: dict[str, list[Any]] = defaultdict(list)
    for edge in sorted_edges:
        edges_from[edge.from_node].append(edge)
        edges_to[edge.to_node].append(edge)

    # Build nodes — S4 chunked/lazy: process in bounded slices so a 500-node
    # graph does not allocate massive intermediate structures in one go and
    # the warning aggregation above can run per-chunk. Envelope stays byte-
    # identical; only the emission is sliced.
    nodes: list[dict[str, Any]] = []
    last_node_id = max(id_remap.values()) if id_remap else 0
    # COW removal records the highest retired native id so a rebuild or later
    # add cannot rewind LiteGraph's monotonic node counter.
    edit_counter = (getattr(wf, "metadata", {}) or {}).get("_edit_last_node_id")
    if isinstance(edit_counter, int) and not isinstance(edit_counter, bool):
        last_node_id = max(last_node_id, edit_counter)
    emitted_outputs_by_node: dict[str, list[dict[str, Any]]] = {}
    emitted_inputs_by_node: dict[str, list[dict[str, Any]]] = {}

    def _chunked_order():
        if len(order_list) <= chunked_emit_node_threshold:
            for idx, nid in enumerate(order_list):
                yield idx, nid
        else:
            for _base in range(0, len(order_list), chunked_emit_chunk_size):
                _slice = order_list[_base:_base + chunked_emit_chunk_size]
                for _off, _nid in enumerate(_slice):
                    yield _base + _off, _nid

    for order, node_id in _chunked_order():
        node = wf.nodes[node_id]
        key = _node_key(node_id)
        verdict = widget_shape_verdicts[node_id]
        if verdict.pin_opaque and _exec_io_for_node(node) is None:
            incoming_link_ids_by_input: dict[str, list[int]] = defaultdict(list)
            for edge in edges_to[node_id]:
                lid = link_id_map[(edge.from_node, edge.from_output, edge.to_node, edge.to_input)]
                incoming_link_ids_by_input[edge.to_input].append(lid)
            outgoing_link_ids_by_slot: dict[int, list[int]] = defaultdict(list)
            for edge in edges_from[node_id]:
                slot, _ = _resolve_output_slot_and_type(edge.from_output, node.class_type, schema_cache, node)
                lid = link_id_map[(edge.from_node, edge.from_output, edge.to_node, edge.to_input)]
                outgoing_link_ids_by_slot[slot].append(lid)
            pinned = _raw_ui_payload_for_pin(
                verdict.raw_ui_node or {},
                node_id=node_id,
                class_type=node.class_type,
                canonical_uid=node.uid,
                litegraph_node_id=id_remap[node_id],
                order=order,
                incoming_link_ids_by_input=incoming_link_ids_by_input,
                outgoing_link_ids_by_slot=outgoing_link_ids_by_slot,
                widget_overlay=_dict_row_widget_overlay(node),
            )
            # The pinned raw copy comes from raw UI evidence and may lack mode;
            # stamp the same IR-authoritative mode used by compilation.
            pinned["mode"] = _resolve_furniture(node, matched_entries.get(key))["mode"]
            emitted_outputs_by_node[node_id] = pinned.get("outputs") or []
            emitted_inputs_by_node[node_id] = pinned.get("inputs") or []
            nodes.append(pinned)
            continue
        matched_entry = matched_entries.get(key)
        # T9b: reconcile-driven merge.
        #   matched → verbatim pos/size/flags/color/properties/group/title from the entry;
        #             mode remains IR-authoritative.
        #   else    → engine_positions (already incorporates anchors / pinning), else _stub.
        if matched_entry is not None:
            geometry = (
                _extract_geometry(matched_entry)
                or engine_positions.get(node.uid)
                or _stub_layout(order)
            )
            furniture = _resolve_furniture(node, matched_entry)
        else:
            # Unmatched (new / unmatched_legacy / removed-then-readded).
            # First-class node geometry is the direct-ingest source of truth; the
            # engine owns geometry only when no complete captured pair exists.
            geometry = (
                _captured_geometry(node)
                or engine_positions.get(node.uid)
                or _stub_layout(order)
            )
            furniture = _resolve_furniture(node, None)
        schema = schema_cache.get(node.class_type)
        raw_ui_node = _raw_ui_node_for_node(node_id, node, raw_ui_node_map)
        exec_io = _exec_io_for_node(node)

        # --- outputs list ---
        outputs: list[dict[str, Any]] = []
        # Build a set of (from_output_val) → links for this node from edges
        output_links_by_slot: dict[int, list[int]] = defaultdict(list)
        for edge in edges_from[node_id]:
            slot, _ = _resolve_output_slot_and_type(edge.from_output, node.class_type, schema_cache, node)
            eid = link_id_map[(edge.from_node, edge.from_output, edge.to_node, edge.to_input)]
            output_links_by_slot[slot].append(eid)

        schema_outputs = _materialized_schema_outputs(
            node,
            schema,
        )

        # T04 native rosters are the canonical socket shape when present.  A
        # roster may intentionally contain ``None`` holes; retain those slots
        # verbatim rather than inferring an ordinal from UI/schema evidence.
        if not schema_outputs and isinstance(node.native_output_names, list):
            schema_outputs = [
                _DynamicOutputSpec(
                    (
                        node.native_output_types[slot]
                        if isinstance(node.native_output_types, list)
                        and slot < len(node.native_output_types)
                        and node.native_output_types[slot] is not None
                        else ""
                    ),
                    name or f"output_{slot}",
                )
                for slot, name in enumerate(node.native_output_names)
            ]

        if exec_io is not None:
            outputs = _exec_dynamic_outputs(exec_io, output_links_by_slot)
        elif schema_outputs:
            for slot_idx, out_spec in enumerate(schema_outputs):
                link_list = sorted(output_links_by_slot.get(slot_idx, []))
                raw_outputs = raw_ui_node.get("outputs") if isinstance(raw_ui_node, Mapping) else None
                raw_output = (
                    raw_outputs[slot_idx]
                    if isinstance(raw_outputs, list) and slot_idx < len(raw_outputs)
                    and isinstance(raw_outputs[slot_idx], Mapping)
                    else None
                )
                raw_links = raw_output.get("links") if raw_output is not None else None
                emitted_links = link_list if link_list else ([] if isinstance(raw_links, list) else None)
                outputs.append({
                    "name": out_spec.name or f"output_{slot_idx}",
                    "type": out_spec.type or "",
                    "links": emitted_links,
                    "slot_index": slot_idx,
                })
        elif edges_from[node_id]:
            # Schema-less best-effort: emit one output entry per distinct from_output value,
            # ordered by numeric slot if numeric or by appearance order otherwise.
            seen: dict[str, int] = {}
            for edge in edges_from[node_id]:
                fo = edge.from_output
                if fo not in seen:
                    seen[fo] = int(fo) if fo.isdigit() else len(seen)

            for fo, slot_idx in sorted(seen.items(), key=lambda kv: kv[1]):
                link_list = sorted(output_links_by_slot.get(slot_idx, []))
                outputs.append({
                    "name": fo if not fo.isdigit() else f"output_{slot_idx}",
                    "type": fo.upper() if not fo.isdigit() else "",
                    "links": link_list if link_list else None,
                    "slot_index": slot_idx,
                })
            # Record schema-less diagnostic in recovery_report (populated below)
            if recovery_report is not None:
                pass  # appended after the loop; diagnostic is in the provenance entry

        # --- widget metadata for this class ---
        widget_names = _widget_names_for_emission(
            node.class_type,
            schema,
            node=node,
            schema_provider=schema_provider,
            name_authority=name_authority,
        )
        incoming_dynamic_names = {
            str(edge.to_input) for edge in edges_to[node_id]
        }
        dynamic_names, unlinked_dynamic_names = _primitive_union_dynamic_input_names(
            node, incoming_dynamic_names
        )
        if unlinked_dynamic_names:
            expanded_widget_names: list[str | None] = []
            for name in widget_names:
                if name == "values":
                    expanded_widget_names.extend(
                        item for item in unlinked_dynamic_names
                        if item not in expanded_widget_names
                    )
                else:
                    expanded_widget_names.append(name)
            if "values" not in widget_names:
                expanded_widget_names.extend(
                    item for item in unlinked_dynamic_names
                    if item not in expanded_widget_names
                )
            widget_names = expanded_widget_names
        widget_name_set = {
            name for name in widget_names if name is not None
        } | set(dynamic_names)
        preserve_widget_roster = bool(dynamic_names)
        full_committed = widget_names_for_class(node.class_type)
        if full_committed is not None:
            widget_name_set.update(n for n in full_committed if n is not None)

        # --- inputs list (physical ComfyUI socket order) ---
        # Only LINKED inputs get an input-slot entry; a linked input whose name is a
        # widget-type input additionally carries widget:{name:...} (widget→link).
        incoming_sorted = _ordered_incoming_edges(edges_to[node_id], schema, node)
        incoming_link_ids_by_input: dict[str, list[int]] = defaultdict(list)
        for edge in incoming_sorted:
            lid = link_id_map[(edge.from_node, edge.from_output, edge.to_node, edge.to_input)]
            incoming_link_ids_by_input[edge.to_input].append(lid)
        inputs: list[dict[str, Any]] = []
        if exec_io is not None:
            inputs = _exec_dynamic_inputs(exec_io, incoming_link_ids_by_input)
        elif isinstance(node.native_input_names, list) and node.native_input_names:
            incoming_by_name = {edge.to_input: edge for edge in incoming_sorted}
            for slot_idx, name in enumerate(node.native_input_names):
                edge = incoming_by_name.get(name) if isinstance(name, str) else None
                if (
                    edge is None
                    and isinstance(name, str)
                    and name in widget_name_set
                    and not preserve_widget_roster
                ):
                    # Unlinked widgets live in widgets_values, not the physical
                    # input array.  A prior widget→link conversion that was
                    # auto-unlinked by SetNodeField must not keep a dead slot.
                    continue
                socket_type = (
                    node.native_input_types[slot_idx]
                    if isinstance(node.native_input_types, list)
                    and slot_idx < len(node.native_input_types)
                    and node.native_input_types[slot_idx] is not None
                    else "UNKNOWN"
                )
                link_id = None
                if edge is not None:
                    from_class = wf.nodes[edge.from_node].class_type if edge.from_node in wf.nodes else ""
                    _, source_type = _resolve_output_slot_and_type(edge.from_output, from_class, schema_cache, wf.nodes.get(edge.from_node))
                    if not socket_type or socket_type == "UNKNOWN":
                        socket_type = source_type
                    link_id = link_id_map[(edge.from_node, edge.from_output, edge.to_node, edge.to_input)]
                slot = {
                    "name": name or f"input_{slot_idx}",
                    "type": socket_type or "UNKNOWN",
                    "link": link_id,
                }
                if (
                    isinstance(node.native_input_optional, list)
                    and slot_idx < len(node.native_input_optional)
                    and node.native_input_optional[slot_idx]
                ):
                    slot["shape"] = 7
                if isinstance(name, str) and name in widget_name_set:
                    slot["widget"] = {"name": name}
                inputs.append(slot)
        else:
            for edge in incoming_sorted:
                from_class = wf.nodes[edge.from_node].class_type if edge.from_node in wf.nodes else ""
                _, socket_type = _resolve_output_slot_and_type(edge.from_output, from_class, schema_cache, wf.nodes.get(edge.from_node))
                if not socket_type or socket_type in {"*", "UNKNOWN"}:
                    raw_inputs = raw_ui_node.get("inputs") if isinstance(raw_ui_node, Mapping) else None
                    raw_input = next(
                        (
                            item
                            for item in raw_inputs or ()
                            if isinstance(item, Mapping) and item.get("name") == edge.to_input
                        ),
                        None,
                    )
                    raw_type = raw_input.get("type") if isinstance(raw_input, Mapping) else None
                    if isinstance(raw_type, str) and raw_type:
                        socket_type = raw_type
                lid = link_id_map[(edge.from_node, edge.from_output, edge.to_node, edge.to_input)]
                slot: dict[str, Any] = {
                    "name": edge.to_input,
                    "type": socket_type or "UNKNOWN",
                    "link": lid,
                }
                if edge.to_input in widget_name_set:
                    slot["widget"] = {"name": edge.to_input}
                inputs.append(slot)

        emitted_outputs_by_node[node_id] = outputs
        emitted_inputs_by_node[node_id] = inputs
        nodes.append(
            _emit_litegraph_node_dict(
                node,
                litegraph_node_id=id_remap[node_id],
                order=order,
                geometry=geometry,
                furniture=furniture,
                inputs=inputs,
                outputs=outputs,
                schema=schema,
                schema_provider=schema_provider,
                include_main_positions=include_main_positions,
                widget_default_values=widget_shape_default_values[node_id],
                name_authority=name_authority,
            )
        )

    # Build global links array: [link_id, from_node, from_slot, to_node, to_slot, type]
    links: list[list[Any]] = []
    dangling_links: list[dict[str, Any]] = []
    for edge in sorted_edges:
        from_class = wf.nodes[edge.from_node].class_type if edge.from_node in wf.nodes else ""
        from_slot, socket_type = _resolve_output_slot_and_type(edge.from_output, from_class, schema_cache, wf.nodes.get(edge.from_node))
        from_exec_io = _exec_io_for_node(wf.nodes[edge.from_node]) if edge.from_node in wf.nodes else None
        if from_exec_io is not None:
            try:
                candidate_slot = int(edge.from_output.split("_", 1)[1]) if edge.from_output.startswith("out_") else int(edge.from_output)
            except (TypeError, ValueError):
                candidate_slot = from_slot
            if 0 <= candidate_slot < len(from_exec_io["outputs"]):
                from_slot = candidate_slot
                socket_type = from_exec_io["outputs"][candidate_slot][1]
        # to_slot = index of this input in the to-node's physical input array.
        to_exec_io = _exec_io_for_node(wf.nodes[edge.to_node]) if edge.to_node in wf.nodes else None
        if to_exec_io is not None and edge.to_input.startswith("in_"):
            try:
                to_slot = int(edge.to_input.split("_", 1)[1])
            except ValueError:
                to_slot = 0
        else:
            target_schema = schema_cache.get(wf.nodes[edge.to_node].class_type)
            incoming_sorted = _ordered_incoming_edges(edges_to[edge.to_node], target_schema, wf.nodes.get(edge.to_node))
            to_slot = next(
                (
                    i
                    for i, e in enumerate(incoming_sorted)
                    if e.to_input == edge.to_input
                    and e.from_node == edge.from_node
                    and e.from_output == edge.from_output
                ),
                0,
            )
            target_node = wf.nodes.get(edge.to_node)
            native_inputs = getattr(target_node, "native_input_names", None) if target_node is not None else None
            if isinstance(native_inputs, list) and edge.to_input in native_inputs:
                to_slot = native_inputs.index(edge.to_input)
        if (
            to_exec_io is not None
            and 0 <= to_slot < len(to_exec_io["inputs"])
            and (not socket_type or socket_type in {"*", "UNKNOWN"})
        ):
            socket_type = to_exec_io["inputs"][to_slot][1]
        # R2-D1: repair malformed endpoints BEFORE projection.  The working
        # graph's emitted sockets are authoritative — never emit a link whose
        # source/target port does not exist in the emitted node.  Remap the
        # phantom slot to the matching emitted socket by canonical name.  When
        # no remap exists the edge is NOT dropped: it accumulates into a single
        # RefusedEmit (B2) so every input edge is either emitted/remapped or the
        # whole emit is refused with full endpoint evidence.
        emitted_outputs = emitted_outputs_by_node.get(edge.from_node)
        emitted_inputs = emitted_inputs_by_node.get(edge.to_node)
        source_endpoint: dict[str, Any] = {
            "node_id": edge.from_node,
            "requested_output": edge.from_output,
            "requested_slot": from_slot,
            "emitted_sockets": _emitted_socket_array_evidence(emitted_outputs),
        }
        target_endpoint: dict[str, Any] = {
            "node_id": edge.to_node,
            "requested_input": edge.to_input,
            "requested_slot": to_slot,
            "emitted_sockets": _emitted_socket_array_evidence(emitted_inputs),
        }
        source_socket_missing = False
        target_socket_missing = False
        if emitted_outputs is not None:
            canonical_from_name = _canonical_emitted_output_name(
                edge.from_output, from_slot
            )
            remapped = _emitted_socket_slot_for_link(
                emitted_outputs, from_slot, canonical_from_name
            )
            if remapped is None:
                source_socket_missing = True
                source_endpoint["canonical_socket_name"] = canonical_from_name
                source_endpoint["attempted_remaps"] = _remap_attempts_evidence(
                    emitted_outputs, from_slot, canonical_from_name
                )
            else:
                from_slot = remapped
        if emitted_inputs is not None:
            remapped = _emitted_input_slot_for_link(
                emitted_inputs, edge.to_input, to_slot
            )
            if remapped is None:
                target_socket_missing = True
                target_endpoint["attempted_remaps"] = _input_remap_attempts_evidence(
                    emitted_inputs, to_slot, edge.to_input
                )
            else:
                to_slot = remapped
        if not socket_type or socket_type in {"*", "UNKNOWN"}:
            source_socket = (
                emitted_outputs[from_slot]
                if isinstance(emitted_outputs, list)
                and 0 <= from_slot < len(emitted_outputs)
                and isinstance(emitted_outputs[from_slot], Mapping)
                else None
            )
            target_socket = (
                emitted_inputs[to_slot]
                if isinstance(emitted_inputs, list)
                and 0 <= to_slot < len(emitted_inputs)
                and isinstance(emitted_inputs[to_slot], Mapping)
                else None
            )
            projected_type = (
                source_socket.get("type") if source_socket is not None else None
            ) or (
                target_socket.get("type") if target_socket is not None else None
            )
            if isinstance(projected_type, str) and projected_type not in {"", "*", "UNKNOWN"}:
                socket_type = projected_type
        if source_socket_missing or target_socket_missing:
            carried = _original_link_slots_if_present(
                wf,
                edge,
                from_slot=from_slot,
                to_slot=to_slot,
                prior_ui_payload=prior_ui_payload,
                guard_original_ui=guard_original_ui,
            )
            if carried is not None:
                from_slot, to_slot = carried
                lid = link_id_map[(edge.from_node, edge.from_output, edge.to_node, edge.to_input)]
                links.append(
                    [lid, id_remap[edge.from_node], from_slot, id_remap[edge.to_node], to_slot, socket_type or ""]
                )
                continue
            missing = (
                "source_socket"
                if target_socket_missing is False
                else "target_socket"
                if source_socket_missing is False
                else "source_and_target_socket"
            )
            dangling_links.append(
                {
                    "key": (
                        f"{edge.from_node}.{edge.from_output} "
                        f"-> {edge.to_node}.{edge.to_input}"
                    ),
                    "evidence": {
                        "source": source_endpoint,
                        "target": target_endpoint,
                        "missing": missing,
                    },
                }
            )
            continue
        lid = link_id_map[(edge.from_node, edge.from_output, edge.to_node, edge.to_input)]
        links.append(
            [lid, id_remap[edge.from_node], from_slot, id_remap[edge.to_node], to_slot, socket_type or ""]
        )

    if dangling_links:
        from vibecomfy.porting.refuse import (  # noqa: PLC0415
            refused_dangling_links as _refused_dangling_links,
        )

        raise _refused_dangling_links(dangling_links)

    links.sort(key=lambda lnk: lnk[0])

    # Populate recovery_report
    if recovery_report is not None:
        for node_id in order_list:
            entry = _build_recovery_entry(
                node_prov[node_id],
                widget_shape_verdicts[node_id],
                has_raw_ui_payload=widget_shape_raw_payloads[node_id] is not None,
            )
            node = wf.nodes.get(node_id)
            if node is not None and is_intent_class_type(node.class_type):
                entry.update(_intent_recovery_fields(node))
            recovery_report.append(entry)

        # ── Orphaned virtual-wire routes (display mode) ─────────────────
        if include_virtual_wires and orphaned_get_ids:
            for gid in sorted(orphaned_get_ids):
                node = wf.nodes.get(gid)
                name = broadcast_name(node) if node else None
                recovery_report.append({
                    "node_id": gid,
                    "class_type": "GetNode",
                    "provider": None,
                    "confidence": None,
                    "schema_less": False,
                    "diagnostic": (
                        f"orphaned virtual-wire: GetNode {gid} "
                        f"(broadcast name={name!r}) has no matching SetNode source — "
                        "emitted as visible node with dangling links in display graph"
                    ),
                    "orphaned_route": True,
                    "broadcast_name": name,
                    "widget_shape_verdict": "not_applicable",
                })

        # ── Stripped virtual-wire helpers summary (T7) ───────────────────
        # Always append this entry (zero-count or non-zero) so JSON-mode
        # consumers can detect the emit-mode. Text mode prints only when N > 0.
        recovery_report.append({
            "stripped_helpers": sorted(virtual_wire_ids),
            "count": len(virtual_wire_ids),
            "widget_shape_verdict": "not_applicable",
        })

    # Warn for schema-less nodes when not strict — S4 chunked/lazy: aggregate
    # warnings so a 500-node graph with ~100 schema-less annotation nodes does
    # not flood stderr with 100× UserWarning and push past the 480s budget.
    # The envelope is still emitted node-by-node; only the warning emission is
    # chunked/aggregated. Byte-identical output, linear wall-time.
    if not strict:
        _schema_less = [(nid, node_prov[nid]) for nid in order_list if node_prov[nid].get("schema_less")]
        if _schema_less:
            if len(order_list) <= chunked_emit_node_threshold:
                for node_id, p in _schema_less:
                    warnings.warn(
                        f"emit_ui_json: schema-less node {node_id}({p['class_type']}); "
                        "emitting best-effort slots. Pass strict=True to hard-fail.",
                        stacklevel=2,
                    )
            else:
                for _ci in range(0, len(_schema_less), chunked_emit_chunk_size):
                    _chunk = _schema_less[_ci:_ci + chunked_emit_chunk_size]
                    if _ci == 0:
                        _sample = ", ".join(f"{nid}({p['class_type']})" for nid, p in _chunk[:5])
                        warnings.warn(
                            f"emit_ui_json: {len(_schema_less)} schema-less nodes "
                            f"(e.g. {_sample}); emitting best-effort slots in "
                            f"{(len(_schema_less) + chunked_emit_chunk_size - 1)//chunked_emit_chunk_size} chunks. "
                            "Pass strict=True to hard-fail.",
                            stacklevel=2,
                        )
                    elif _ci % (chunked_emit_warn_every * chunked_emit_chunk_size) == 0:
                        warnings.warn(
                            f"emit_ui_json: chunk {_ci // chunked_emit_chunk_size + 1} "
                            f"emitted ({_ci + len(_chunk)}/{len(_schema_less)} schema-less nodes)",
                            stacklevel=2,
                        )

    breadcrumb = _breadcrumb(wf, source_template, prior_path)

    # --- extra: merge caller-provided extra (e.g. sidecar ds) with vibecomfy breadcrumb ---
    # ``extra`` has exactly ONE storage owner per emit: the caller's explicit
    # ``extra`` kwarg XOR the door-captured wire ``extra`` — never both.  When
    # the caller supplies ``extra`` it is the sole source (sidecar/ds state);
    # otherwise the door-captured wire ``extra`` is the sole source so
    # ds/frontendVersion/VHS_* and opaque keys survive re-emission (Law 1
    # wire preference).  The fresh breadcrumb is stamped on top either way.
    merged_extra: dict[str, Any] = {}
    if extra:
        merged_extra.update(dict(extra))
    else:
        captured_extra = _door_top(_door).get("extra") if isinstance(_door_top(_door), Mapping) else None
        if isinstance(captured_extra, Mapping):
            merged_extra.update(dict(captured_extra))
    merged_extra["vibecomfy"] = dict(breadcrumb)

    # When include_main_positions=True, ensure extra.ds (canvas drag/scale state) is
    # present, falling back to a fixed machine-independent default.  The lean default
    # (include_main_positions=False) omits ds entirely.
    if include_main_positions and "ds" not in merged_extra:
        merged_extra["ds"] = dict(_DEFAULT_DS)

    # --- groups: merge remapped IR groups with engine-generated subgraph groups ---
    #   Order: IR groups first, then engine_groups (suppressing duplicates whose
    #   ``title`` matches an IR group title).  All groups are
    #   canonicalized when ``include_main_positions=True``.
    ir_groups = _remap_ir_groups(wf, order_list, id_remap)
    ir_titles: set[str] = {g.get("title", "") for g in ir_groups if g.get("title")}
    emitted_groups: list[dict[str, Any]] = list(ir_groups)
    for eg in engine_groups:
        if eg.get("title", "") not in ir_titles:
            emitted_groups.append(eg)
    _extend_groups_for_anchored_nodes(
        emitted_groups,
        nodes,
        group_anchors,
        explicit_anchor_groups,
    )
    if include_main_positions and emitted_groups:
        _canonicalize_group_geometry(emitted_groups)

    envelope: dict[str, Any] = {
        "id": _wire_id(wf, _door),
        "version": _wire_version(_door),
        "last_node_id": _wire_counter(_door, "last_node_id", last_node_id),
        "last_link_id": _wire_counter(_door, "last_link_id", last_link_id),
        "groups": emitted_groups,
        "nodes": nodes,
        "links": links,
        "extra": merged_extra,
    }

    # Subgraph definitions: caller-provided `definitions` (from sidecar envelope)
    # takes precedence.  When the retained IR definitions differ from the
    # door-captured blob (a definitions-only edit: label, ports, add/remove),
    # emit from the IR so the edit is not silently discarded.  Otherwise keep
    # the captured wire blob so untouched subgraph bodies stay byte-stable.
    effective_defs = definitions
    if effective_defs is None:
        captured_defs = (
            _door_top(_door).get("definitions")
            if isinstance(_door_top(_door), Mapping)
            else None
        )
        ir_defs = getattr(wf, "definitions", None)
        if not isinstance(ir_defs, Mapping):
            metadata = getattr(wf, "metadata", None)
            ir_defs = metadata.get("definitions") if isinstance(metadata, Mapping) else None
        from vibecomfy.ingest.normalize import _door_freeze  # noqa: PLC0415

        if (
            isinstance(ir_defs, Mapping)
            and isinstance(captured_defs, Mapping)
            and _door_freeze(ir_defs) != _door_freeze(captured_defs)
        ):
            effective_defs = _emit_definitions(wf)
        else:
            effective_defs = (
                deepcopy(captured_defs) if isinstance(captured_defs, Mapping) else _emit_definitions(wf)
            )
    if effective_defs is not None:
        if effective_defs is definitions:
            effective_defs = deepcopy(effective_defs)
        for sg in effective_defs.get("subgraphs", []):
            sg_extra = dict(sg.get("extra") or {})
            sg_extra["vibecomfy"] = dict(breadcrumb)
            sg["extra"] = sg_extra
        envelope["definitions"] = effective_defs
        envelope["state"] = {
            "lastNodeId": _wire_counter(_door, "last_node_id", last_node_id),
            "lastLinkId": _wire_counter(_door, "last_link_id", last_link_id),
            "lastRerouteId": 0,
        }

    # Python-owned recursive interfaces and their local endpoint bindings are
    # semantic carriers.  They are not recoverable from LiteGraph's native
    # inputNode/outputNode or -10/-20 boundary encoding, which is deliberately
    # unsupported.  Emit the exact detached typed carriers even when empty so
    # a remove-all edit cannot be resurrected from definition port decoration
    # during the next ingest.
    if effective_defs is not None or wf.interfaces or wf.boundary_ports:
        envelope["interfaces"] = deepcopy(wf.interfaces)
        envelope["boundary_ports"] = deepcopy(wf.boundary_ports)

    # When include_main_positions=True, always emit state counters even if there
    # are no definitions (the lean default ties state to definitions presence).
    if include_main_positions and "state" not in envelope:
        envelope["state"] = {
            "lastNodeId": _wire_counter(_door, "last_node_id", last_node_id),
            "lastLinkId": _wire_counter(_door, "last_link_id", last_link_id),
            "lastRerouteId": 0,
        }

    # M5 Step 16: refusal-spine on APPLIED re-emit. When the caller supplies the
    # pre-edit UI JSON as guard_original_ui, run convert_ui_to_api over both
    # original and candidate (this envelope) and refuse if any uid-matched,
    # snapshot-present node diverges outside snapshot_delta. RefusedEmit bubbles
    # up so the caller can abort the write.
    if guard_original_ui is not None:
        from vibecomfy.porting.layout.delta import compute_field_delta  # noqa: PLC0415
        from vibecomfy.porting.refuse import guard_emit as _guard_emit  # noqa: PLC0415

        _snap = (wf.metadata or {}).get("_ingest_snapshot", {})
        _delta = compute_field_delta(_snap, wf) if _snap else {}
        _guard_emit(guard_original_ui, envelope, _delta, resolved_ops=guard_resolved_ops)

    if presentation_mode:
        _overlay_validated_presentation(envelope, presentation, wf)

    return envelope


def materialize_ui_json(
    wf: Any,
    sidecar: Mapping[str, Any] | None = None,
    *,
    schema_provider: Any = None,
    strict: bool = False,
) -> dict[str, Any]:
    """Materialize the canonical UI projection for one validated presentation.

    This is the narrow bundle-facing boundary.  It deliberately invokes the
    existing emitter exactly once, with a detached workflow whose import/raw UI
    evidence has been removed.  The sidecar is presentation-only: it is used
    for furniture, link identities/occurrences, groups, and canvas after the
    semantic node/link projection has been emitted from Python.

    ``sidecar`` is validated by :func:`vibecomfy.workflow_bundle.validate_sidecar`
    before this function is normally called by ``WorkflowBundle``.  Repeating
    the validation here keeps this public emitter seam fail-closed for direct
    callers and, importantly, means no emitter work occurs for an invalid pair.
    """
    from vibecomfy.workflow_bundle import validate_sidecar

    if not hasattr(wf, "copy") or not hasattr(wf, "nodes"):
        raise TypeError("materialize_ui_json requires a VibeWorkflow")
    if sidecar is None:
        sidecar = {
            "format_version": 1,
            "bind": {
                "workflow_identity": wf.id,
                "semantic_digest": wf.semantic_digest(),
            },
            "nodes": {},
            "links": [],
            "groups": [],
            "canvas": {},
        }
    normalized = validate_sidecar(sidecar, wf)

    # Raw UI, snapshots, and the door are evidence at import/replay boundaries;
    # none can affect a canonical bundle materialization.  Keep only authored
    # semantic metadata and the typed node fields already present in Python.
    materialized_wf = wf.copy()
    metadata = getattr(materialized_wf, "metadata", None)
    if isinstance(metadata, dict):
        materialized_wf.metadata = {
            key: value
            for key, value in metadata.items()
            if key not in {
                _UI_DOOR_KEY,
                "_ingest_snapshot",
                "_ingest_raw",
                "_raw_ui",
                "_edit_link_id_hints",
                "definitions",
            }
        }
    for node in materialized_wf.nodes.values():
        node.raw_widgets = None
        node_metadata = getattr(node, "metadata", None)
        if isinstance(node_metadata, dict):
            node.metadata = {
                key: value for key, value in node_metadata.items()
                if key != "_ui" and not str(key).startswith("_ui_")
            }

    canvas = normalized.get("canvas", {})
    extra: dict[str, Any] = {}
    if isinstance(canvas, Mapping):
        ds: dict[str, Any] = {}
        if "zoom" in canvas:
            ds["scale"] = deepcopy(canvas["zoom"])
        if "pan" in canvas:
            ds["offset"] = deepcopy(canvas["pan"])
        if ds:
            extra["ds"] = ds

    envelope = emit_ui_json(
        materialized_wf,
        schema_provider=schema_provider,
        strict=strict,
        presentation=normalized,
    )
    structural_report = structural_validate(envelope, schema_provider=schema_provider)
    if not structural_report.get("ok", False):
        raise ValueError(
            "canonical UI materialization failed structural validation: "
            f"{structural_report.get('errors', [])}"
        )
    return envelope


def _overlay_validated_presentation(
    envelope: dict[str, Any],
    sidecar: Mapping[str, Any],
    wf: Any,
) -> None:
    """Overlay the closed v1 presentation allowlist onto a fresh envelope."""
    side_nodes = sidecar.get("nodes", {})
    if not isinstance(side_nodes, Mapping):
        raise ValueError("validated sidecar nodes must be a mapping")
    emitted_nodes = envelope.get("nodes", [])
    if not isinstance(emitted_nodes, list):
        raise ValueError("emitter returned an invalid nodes list")
    from vibecomfy.porting.emit.emit_constants import UI_ONLY_CLASS_TYPES

    by_uid: dict[str, dict[str, Any]] = {}
    old_id_by_uid: dict[str, int] = {}
    for node in emitted_nodes:
        if not isinstance(node, dict):
            continue
        props = node.get("properties")
        uid = props.get("vibecomfy_uid") if isinstance(props, Mapping) else None
        if isinstance(uid, str):
            by_uid[uid] = node
            if type(node.get("id")) is int:
                old_id_by_uid[uid] = int(node["id"])
    uid_by_old_id = {native_id: uid for uid, native_id in old_id_by_uid.items()}
    native_ids: set[int] = {
        int(node["id"]) for node in emitted_nodes
        if isinstance(node, Mapping) and type(node.get("id")) is int
    }

    def _remint_conflicting_emitted_node(native_id: int) -> None:
        """Move an auto-assigned semantic node out of a retained canvas ID.

        Nested native expansion can allocate an executable node ID that was
        used by an authored UI-only note in the source canvas.  The note's
        captured ID is part of presentation custody, so preserve it and
        remint only the generated semantic node.  Top-level links are the
        only graph records that carry node IDs in this envelope.
        """
        replacement = max(native_ids, default=0) + 1
        while replacement in native_ids:
            replacement += 1
        conflict = next(
            (
                node
                for node in emitted_nodes
                if isinstance(node, Mapping) and node.get("id") == native_id
            ),
            None,
        )
        if conflict is None:
            raise ValueError(f"sidecar native node id collision for {native_id}")
        conflict_uid = (
            conflict.get("properties", {}).get("vibecomfy_uid")
            if isinstance(conflict.get("properties"), Mapping)
            else None
        )
        conflict["id"] = replacement
        if isinstance(conflict_uid, str):
            old_id_by_uid[conflict_uid] = replacement
            uid_by_old_id.pop(native_id, None)
            uid_by_old_id[replacement] = conflict_uid
        links = envelope.get("links", [])
        if isinstance(links, list):
            for link in links:
                if isinstance(link, list) and len(link) >= 4:
                    if link[1] == native_id:
                        link[1] = replacement
                    if link[3] == native_id:
                        link[3] = replacement
                elif isinstance(link, Mapping):
                    if link.get("origin_id") == native_id:
                        link["origin_id"] = replacement
                    if link.get("target_id") == native_id:
                        link["target_id"] = replacement
        native_ids.discard(native_id)
        native_ids.add(replacement)

    # UI-only furniture has no executable VibeNode, but it is still part of
    # the captured presentation custody.  Recreate the allowlisted note
    # classes from their sidecar record so materialization does not silently
    # discard authored canvas annotations.  Their synthetic UID is a custody
    # key only; no semantic links are synthesized for them.
    next_ui_only_id = max(native_ids, default=0) + 1
    for uid, entry in side_nodes.items():
        if uid in by_uid or not isinstance(entry, Mapping):
            continue
        class_type = entry.get("class_type")
        if class_type not in UI_ONLY_CLASS_TYPES:
            continue
        native_id = entry.get("id")
        if type(native_id) is not int:
            while next_ui_only_id in native_ids:
                next_ui_only_id += 1
            native_id = next_ui_only_id
            next_ui_only_id += 1
        if native_id in native_ids:
            _remint_conflicting_emitted_node(native_id)
        node: dict[str, Any] = {
            "id": native_id,
            "type": class_type,
            "properties": {
                "Node name for S&R": class_type,
                "vibecomfy_uid": str(uid),
            },
        }
        for field in ("pos", "size", "color", "bgcolor", "title"):
            if field in entry:
                node[field] = deepcopy(entry[field])
        if "z_order" in entry:
            node["order"] = deepcopy(entry["z_order"])
        if "collapsed" in entry:
            node["flags"] = {"collapsed": entry["collapsed"]}
        if "group" in entry:
            node["group"] = deepcopy(entry["group"])
        emitted_nodes.append(node)
        by_uid[str(uid)] = node
        native_ids.add(native_id)

    # Annotation content is carried in the v2 presentation section rather
    # than in the semantic Python graph. Reattach it only to the matching
    # allowlisted canvas node, preserving Markdown/Unicode/empty content
    # exactly once for the editor projection.
    raw_annotations = sidecar.get("annotations", [])
    if isinstance(raw_annotations, list):
        for annotation in raw_annotations:
            if not isinstance(annotation, Mapping):
                continue
            owner = annotation.get("owner")
            if not isinstance(owner, Mapping) or owner.get("kind") != "node":
                continue
            target = by_uid.get(str(owner.get("uid")))
            if target is None or annotation.get("class_type") not in UI_ONLY_CLASS_TYPES:
                continue
            target["widgets_values"] = [deepcopy(annotation.get("content", ""))]

    # Preserve the emitted ids for link remapping, then apply native sidecar ids.
    old_to_new: dict[int, int] = {}
    for uid, entry in side_nodes.items():
        node = by_uid.get(str(uid))
        if node is None or not isinstance(entry, Mapping):
            continue
        old_id = node.get("id")
        if type(entry.get("id")) is int:
            new_id = int(entry["id"])
            if new_id in native_ids and new_id != old_id:
                raise ValueError(f"sidecar native node id collision for {new_id}")
            native_ids.discard(old_id)
            native_ids.add(new_id)
            if type(old_id) is int:
                old_to_new[old_id] = new_id
            node["id"] = new_id
        if "pos" in entry:
            node["pos"] = deepcopy(entry["pos"])
        if "size" in entry:
            node["size"] = deepcopy(entry["size"])
        if "collapsed" in entry:
            flags = node.get("flags")
            flags = dict(flags) if isinstance(flags, Mapping) else {}
            flags["collapsed"] = entry["collapsed"]
            node["flags"] = flags
        for field in ("color", "bgcolor", "title"):
            if field in entry:
                node[field] = deepcopy(entry[field])
        if "z_order" in entry:
            node["order"] = deepcopy(entry["z_order"])
        if "group" in entry:
            # Keep the direct parent marker as well as the group member list;
            # Comfy/LiteGraph consumers use both forms in different versions.
            node["group"] = deepcopy(entry["group"])

    # Rebuild links from Python-emitted endpoint geometry and sidecar foreign
    # keys.  This preserves duplicate visual occurrences while never accepting
    # sidecar endpoints as new semantic edges.
    side_links = sidecar.get("links", [])
    if not isinstance(side_links, list):
        raise ValueError("validated sidecar links must be a list")
    wf_by_uid = {
        str(node.uid): node
        for node in getattr(wf, "nodes", {}).values()
        if getattr(node, "uid", None)
    }

    def _semantic_port(node_obj: Any, ui_node: Mapping[str, Any] | None, slot: int, direction: str) -> int:
        roster = getattr(node_obj, f"native_{direction}_names", None)
        sockets = ui_node.get("outputs" if direction == "output" else "inputs") if isinstance(ui_node, Mapping) else None
        name = None
        if isinstance(sockets, list) and 0 <= slot < len(sockets) and isinstance(sockets[slot], Mapping):
            raw_name = sockets[slot].get("name")
            name = raw_name if isinstance(raw_name, str) else None
        if isinstance(roster, list) and name is not None:
            matches = [
                index for index, roster_name in enumerate(roster)
                if roster_name == name
            ]
            if len(matches) == 1:
                return matches[0]
        # Schema-less emit names native slots output_N / input_N. Sidecar
        # edge_ref already stores that native index, so index emitted links
        # the same way when the roster is missing or does not uniquely match.
        prefix = "output_" if direction == "output" else "input_"
        if isinstance(name, str) and name.startswith(prefix) and name[len(prefix):].isdigit():
            return int(name[len(prefix):])
        return slot

    emitted_by_key: dict[tuple[str, int, str, int], list[list[Any]]] = defaultdict(list)
    for link in envelope.get("links", []):
        if not isinstance(link, (list, tuple)) or len(link) < 6:
            continue
        source_uid = uid_by_old_id.get(link[1])
        target_uid = uid_by_old_id.get(link[3])
        if source_uid is None or target_uid is None:
            continue
        from_port = int(link[2])
        to_port = int(link[4])
        source_node = wf_by_uid.get(source_uid)
        target_node = wf_by_uid.get(target_uid)
        if source_node is not None:
            from_port = _semantic_port(source_node, by_uid.get(source_uid), from_port, "output")
        if target_node is not None:
            to_port = _semantic_port(target_node, by_uid.get(target_uid), to_port, "input")
        emitted_by_key[(source_uid, from_port, target_uid, to_port)].append(list(link))

    rebuilt_links: list[list[Any]] = []
    used_link_ids: set[int] = set()
    next_link_id = max(
        [int(item.get("id")) for item in side_links if isinstance(item, Mapping) and type(item.get("id")) is int]
        + [int(link[0]) for link in envelope.get("links", []) if isinstance(link, (list, tuple)) and type(link[0]) is int]
        + [0]
    ) + 1
    root_side_links = [
        item for item in side_links
        if isinstance(item, Mapping)
        and str((item.get("edge_ref") or item.get("virtual_wire_ref") or {}).get("scope_path", "")) == ""
    ]
    # Every Python-emitted semantic link remains in the result.  Sidecar rows
    # are optional presentation overrides, not a second edge list: rows that
    # are absent leave their Python link untouched, while duplicate rows create
    # duplicate visual occurrences of the same Python endpoint.
    side_overrides: dict[tuple[str, int, str, int], list[Mapping[str, Any]]] = defaultdict(list)
    for item in root_side_links:
        if not isinstance(item, Mapping):
            raise ValueError("validated sidecar link must be a mapping")
        ref = item.get("edge_ref")
        key: tuple[str, int, str, int] | None = None
        if isinstance(ref, Mapping):
            key = (
                str(ref["from_uid"]), int(ref["from_port"]),
                str(ref["to_uid"]), int(ref["to_port"]),
            )
        if key is None:
            # A virtual leg is Python-owned and must have a corresponding
            # materialized endpoint; never synthesize an endpoint from sidecar.
            ref = item.get("virtual_wire_ref")
            if not isinstance(ref, Mapping):
                raise ValueError("validated sidecar link has no semantic reference")
            from vibecomfy.workflow_bundle import _virtual_legs
            legs = _virtual_legs(wf).get((str(ref["scope_path"]), str(ref["name"])))
            matching = [
                leg for leg in (legs or ())
                if leg[5] == int(ref["leg_index"]) and leg[6] == int(item.get("occurrence_index", 0))
            ]
            if not matching:
                raise ValueError("virtual sidecar link has no Python-owned materialized leg")
            leg = matching[0]
            key = (str(leg[1]), int(leg[2]), str(leg[3]), int(leg[4]))
        candidates = emitted_by_key.get(key, [])
        if not candidates:
            raise ValueError(f"sidecar link {key!r} has no Python-emitted endpoint")
        side_overrides[key].append(item)

    def materialize_link(
        link: list[Any], item: Mapping[str, Any] | None = None
    ) -> list[Any]:
        nonlocal next_link_id
        result = list(link)
        result[1] = old_to_new.get(result[1], result[1])
        result[3] = old_to_new.get(result[3], result[3])
        lid = item.get("id") if isinstance(item, Mapping) else None
        if type(lid) is not int:
            lid = result[0]
            while lid in used_link_ids:
                lid = next_link_id
                next_link_id += 1
        if lid in used_link_ids:
            raise ValueError(f"duplicate materialized native link id {lid}")
        used_link_ids.add(lid)
        result[0] = lid
        # Reroute geometry is a presentation member of the link record.  The
        # seventh array member is retained for round-trip callers while the six
        # LiteGraph endpoint members remain untouched.
        if isinstance(item, Mapping) and "reroute" in item:
            result.append(deepcopy(item["reroute"]))
        return result

    for key, candidates in emitted_by_key.items():
        overrides = side_overrides.get(key)
        if overrides:
            # A sidecar is optional presentation evidence.  It may override
            # only the first authored occurrence; omitted Python occurrences
            # must remain visible.  Extra sidecar rows intentionally duplicate
            # the first Python endpoint, preserving the v1 occurrence model.
            rebuilt_links.extend(
                materialize_link(candidates[min(index, len(candidates) - 1)], item)
                for index, item in enumerate(overrides)
            )
            rebuilt_links.extend(
                materialize_link(candidate)
                for candidate in candidates[len(overrides):]
            )
        else:
            rebuilt_links.extend(materialize_link(candidate) for candidate in candidates)

    # Preserve non-semantic emitter links (for example explicit virtual-wire
    # display links) when no sidecar row can identify their endpoint.  Key
    # through the same native-roster mapping used to index emitted_by_key so a
    # visual-slot link is not appended again after its semantic key was kept.
    for raw_link in envelope.get("links", []):
        if not isinstance(raw_link, (list, tuple)) or len(raw_link) < 6:
            continue
        source_uid = uid_by_old_id.get(raw_link[1])
        target_uid = uid_by_old_id.get(raw_link[3])
        from_port = int(raw_link[2])
        to_port = int(raw_link[4])
        source_node = wf_by_uid.get(source_uid) if source_uid is not None else None
        target_node = wf_by_uid.get(target_uid) if target_uid is not None else None
        if source_node is not None:
            from_port = _semantic_port(source_node, by_uid.get(source_uid), from_port, "output")
        if target_node is not None:
            to_port = _semantic_port(target_node, by_uid.get(target_uid), to_port, "input")
        key = (source_uid, from_port, target_uid, to_port)
        if key not in emitted_by_key:
            rebuilt_links.append(materialize_link(list(raw_link)))
    envelope["links"] = rebuilt_links

    # Link references inside node socket arrays are derived from the rebuilt
    # links, never copied from sidecar endpoint data.
    for node in emitted_nodes:
        for output in node.get("outputs", []) if isinstance(node, Mapping) else []:
            if isinstance(output, dict) and isinstance(output.get("links"), list):
                output["links"] = []
        for input_slot in node.get("inputs", []) if isinstance(node, Mapping) else []:
            if isinstance(input_slot, dict) and "link" in input_slot:
                input_slot["link"] = None
    for link in rebuilt_links:
        source = next((node for node in emitted_nodes if node.get("id") == link[1]), None)
        target = next((node for node in emitted_nodes if node.get("id") == link[3]), None)
        if isinstance(source, dict) and isinstance(source.get("outputs"), list) and 0 <= link[2] < len(source["outputs"]):
            output = source["outputs"][link[2]]
            if isinstance(output, dict):
                output.setdefault("links", []).append(link[0])
        if isinstance(target, dict) and isinstance(target.get("inputs"), list) and 0 <= link[4] < len(target["inputs"]):
            target_slot = target["inputs"][link[4]]
            if isinstance(target_slot, dict):
                target_slot["link"] = link[0]

    # Groups are wholly presentation-owned.  Build LiteGraph groups from the
    # validated scoped records and parent markers; never title-deduplicate.
    groups_out: list[dict[str, Any]] = []
    for group in sidecar.get("groups", []):
        if not isinstance(group, Mapping):
            continue
        scope = str(group["scope_path"])
        if scope != "":
            continue
        pid = str(group["presentation_id"])
        member_ids: list[int] = []
        for uid, entry in side_nodes.items():
            if not isinstance(entry, Mapping) or entry.get("group") != pid:
                continue
            node_scope = uid.rsplit("#", 1)[0] if "#" in uid else ""
            if node_scope == scope:
                node = by_uid.get(str(uid))
                if isinstance(node, Mapping) and type(node.get("id")) is int:
                    member_ids.append(int(node["id"]))
        out: dict[str, Any] = {
            "id": pid,
            "vibecomfy_group_id": pid,
            "nodes": member_ids,
        }
        if "bounds" in group:
            out["bounding"] = deepcopy(group["bounds"])
        if "title" in group:
            out["title"] = deepcopy(group["title"])
        if "color" in group:
            out["color"] = deepcopy(group["color"])
        if "z_order" in group:
            out["order"] = deepcopy(group["z_order"])
        groups_out.append(out)
    envelope["groups"] = groups_out

    _overlay_nested_presentation(envelope, sidecar, wf, handled=set(by_uid))


def _overlay_nested_presentation(
    envelope: Mapping[str, Any],
    sidecar: Mapping[str, Any],
    wf: Any,
    *,
    handled: set[str],
) -> None:
    """Apply the same allowlist to recursively emitted definition nodes.

    Definitions are Python-owned semantic data; this helper only edits their
    disposable UI furniture.  Structural scope keys are recomputed from each
    definition, so nested clones never fall back to ordinal or title aliases.
    """
    definitions = envelope.get("definitions")
    if not isinstance(definitions, Mapping):
        missing = [str(uid) for uid in sidecar.get("nodes", {}) if str(uid) not in handled]
        if missing:
            raise ValueError(f"sidecar contains unmaterialized recursive node(s): {missing!r}")
        return
    from vibecomfy.identity.scope import compose_scope_path, sg_key
    from vibecomfy.identity.uid import make_uid

    side_nodes = sidecar.get("nodes", {})
    side_links = sidecar.get("links", [])

    def entries(raw: Any) -> list[Mapping[str, Any]]:
        if isinstance(raw, Mapping) and isinstance(raw.get("subgraphs"), list):
            return [item for item in raw["subgraphs"] if isinstance(item, Mapping)]
        if isinstance(raw, Mapping):
            return [item for item in raw.values() if isinstance(item, Mapping)]
        if isinstance(raw, list):
            return [item for item in raw if isinstance(item, Mapping)]
        return []

    def node_local(node: Mapping[str, Any]) -> str | None:
        props = node.get("properties")
        value = props.get("vibecomfy_uid") if isinstance(props, Mapping) else None
        if value is None:
            value = node.get("uid", node.get("id"))
        return str(value) if value is not None else None

    def walk(raw_defs: Any, parent: tuple[str, ...]) -> None:
        for definition in entries(raw_defs):
            key = sg_key(definition)
            scope = compose_scope_path((*parent, key))
            out_nodes = definition.get("nodes", [])
            out_nodes = out_nodes if isinstance(out_nodes, list) else list(out_nodes.values()) if isinstance(out_nodes, Mapping) else []
            by_local = {local: node for node in out_nodes if isinstance(node, Mapping) and (local := node_local(node)) is not None}
            original_node_ids = {
                local: node.get("id") for local, node in by_local.items()
            }
            node_id_remap: dict[int, int] = {}
            occupied_node_ids = {
                int(node["id"])
                for node in out_nodes
                if isinstance(node, Mapping) and type(node.get("id")) is int
            }
            for local, node in by_local.items():
                uid = make_uid(scope, local)
                entry = side_nodes.get(uid)
                if not isinstance(entry, Mapping):
                    continue
                handled.add(uid)
                if type(entry.get("id")) is int:
                    old_id = node.get("id")
                    new_id = int(entry["id"])
                    if new_id in occupied_node_ids and new_id != old_id:
                        raise ValueError(
                            f"sidecar native nested node id collision in {scope!r}: {new_id}"
                        )
                    if type(old_id) is int:
                        occupied_node_ids.discard(old_id)
                        node_id_remap[old_id] = new_id
                    occupied_node_ids.add(new_id)
                    node["id"] = new_id
                if "pos" in entry: node["pos"] = deepcopy(entry["pos"])
                if "size" in entry: node["size"] = deepcopy(entry["size"])
                if "collapsed" in entry:
                    flags = dict(node.get("flags") or {}) if isinstance(node.get("flags"), Mapping) else {}
                    flags["collapsed"] = entry["collapsed"]
                    node["flags"] = flags
                for field in ("color", "bgcolor", "title"):
                    if field in entry: node[field] = deepcopy(entry[field])
                if "z_order" in entry: node["order"] = deepcopy(entry["z_order"])
                if "group" in entry: node["group"] = deepcopy(entry["group"])

            # Scoped annotation notes are presentation custody, not semantic
            # definition nodes.  Materialize them in the same definition when
            # their validated scoped sidecar entry is present.
            next_ui_id = max(occupied_node_ids, default=0) + 1
            for uid, entry in side_nodes.items():
                if not isinstance(entry, Mapping) or not str(uid).startswith(f"{scope}#"):
                    continue
                local = str(uid).split("#", 1)[1]
                if local in by_local or entry.get("class_type") not in UI_ONLY_CLASS_TYPES:
                    continue
                while next_ui_id in occupied_node_ids:
                    next_ui_id += 1
                note = {
                    "id": next_ui_id,
                    "type": entry["class_type"],
                    "properties": {
                        "Node name for S&R": entry["class_type"],
                        "vibecomfy_uid": str(uid),
                    },
                    "widgets_values": [""],
                }
                for field in ("pos", "size", "color", "bgcolor", "title"):
                    if field in entry:
                        note[field] = deepcopy(entry[field])
                out_nodes.append(note)
                by_local[local] = note
                occupied_node_ids.add(next_ui_id)
                next_ui_id += 1

            for annotation in sidecar.get("annotations", []) if isinstance(sidecar.get("annotations"), list) else []:
                if not isinstance(annotation, Mapping) or str(annotation.get("scope_path")) != scope:
                    continue
                owner = annotation.get("owner")
                if not isinstance(owner, Mapping) or owner.get("kind") != "node":
                    continue
                owner_uid = str(owner.get("uid"))
                local = owner_uid.split("#", 1)[1] if "#" in owner_uid else owner_uid
                target = by_local.get(local)
                if isinstance(target, dict) and annotation.get("class_type") in UI_ONLY_CLASS_TYPES:
                    target["widgets_values"] = [deepcopy(annotation.get("content", ""))]

            # Groups inside definitions are presentation records too.  Rebuild
            # them by structural scope and sidecar presentation id, retaining
            # Python-emitted membership ids while overlaying only the closed
            # furniture fields.  A sidecar group may be present even when the
            # raw definition carried no group object, so construct that object
            # from the already validated node parent markers.
            raw_groups = definition.get("groups", [])
            groups_out = list(raw_groups) if isinstance(raw_groups, list) else []
            groups_by_id = {
                str(group.get("vibecomfy_group_id", group.get("id"))): group
                for group in groups_out
                if isinstance(group, Mapping)
            }
            for group in sidecar.get("groups", []) if isinstance(sidecar.get("groups"), list) else []:
                if not isinstance(group, Mapping) or str(group.get("scope_path")) != scope:
                    continue
                presentation_id = str(group["presentation_id"])
                member_ids = [
                    node.get("id")
                    for local, node in by_local.items()
                    if isinstance(node, Mapping)
                    and isinstance(side_nodes.get(make_uid(scope, local)), Mapping)
                    and side_nodes[make_uid(scope, local)].get("group") == presentation_id
                    and type(node.get("id")) is int
                ]
                target = groups_by_id.get(presentation_id)
                if target is None:
                    target = {"id": presentation_id, "vibecomfy_group_id": presentation_id}
                    groups_out.append(target)
                    groups_by_id[presentation_id] = target
                target["nodes"] = member_ids
                if "bounds" in group: target["bounding"] = deepcopy(group["bounds"])
                if "title" in group: target["title"] = deepcopy(group["title"])
                if "color" in group: target["color"] = deepcopy(group["color"])
                if "z_order" in group: target["order"] = deepcopy(group["z_order"])
            if groups_out:
                definition["groups"] = groups_out

            # Definition links are object records.  Select by Python-owned
            # local endpoints, then apply only native id/reroute presentation.
            raw_def_links = definition.get("links", [])
            if isinstance(raw_def_links, list):
                overridden: set[int] = set()
                link_id_remap: dict[int, int] = {}
                occupied_link_ids = {
                    int(link.get("id"))
                    for link in raw_def_links
                    if isinstance(link, Mapping) and type(link.get("id")) is int
                }
                next_nested_link_id = max(
                    [
                        int(link.get("id"))
                        for link in raw_def_links
                        if isinstance(link, Mapping) and type(link.get("id")) is int
                    ]
                    + [0]
                ) + 1
                for item in side_links if isinstance(side_links, list) else []:
                    if not isinstance(item, Mapping): continue
                    ref = item.get("edge_ref")
                    if isinstance(ref, Mapping):
                        if ref.get("scope_path") != scope:
                            continue
                        from_local = str(ref.get("from_uid"))
                        from_port = ref.get("from_port")
                        to_local = str(ref.get("to_uid"))
                        to_port = ref.get("to_port")
                    else:
                        virtual_ref = item.get("virtual_wire_ref")
                        if not isinstance(virtual_ref, Mapping) or virtual_ref.get("scope_path") != scope:
                            continue
                        from vibecomfy.workflow_bundle import _virtual_legs
                        legs = _virtual_legs(wf).get((scope, str(virtual_ref.get("name"))))
                        leg_index = virtual_ref.get("leg_index")
                        matching = [
                            leg for leg in (legs or ())
                            if leg[5] == leg_index and leg[6] == int(item.get("occurrence_index", 0))
                        ]
                        if not matching:
                            continue
                        leg = matching[0]
                        from_local, from_port, to_local, to_port = str(leg[1]), leg[2], str(leg[3]), leg[4]
                    matching = [
                        link for link in raw_def_links
                        if isinstance(link, Mapping)
                        and str(link.get("origin_id")) == str(original_node_ids.get(from_local))
                        and str(link.get("target_id")) == str(original_node_ids.get(to_local))
                        and link.get("origin_slot") == from_port
                        and link.get("target_slot") == to_port
                    ]
                    if not matching:
                        continue
                    target = matching[0]
                    if id(target) in overridden:
                        target = deepcopy(target)
                        raw_def_links.append(target)
                        if type(item.get("id")) is not int:
                            target["id"] = next_nested_link_id
                            next_nested_link_id += 1
                    overridden.add(id(target))
                    if type(item.get("id")) is int:
                        new_link_id = int(item["id"])
                        old_link_id = target.get("id")
                        if new_link_id in occupied_link_ids and new_link_id != old_link_id:
                            raise ValueError(
                                f"sidecar native nested link id collision in {scope!r}: {new_link_id}"
                            )
                        if type(old_link_id) is int:
                            occupied_link_ids.discard(old_link_id)
                            link_id_remap.setdefault(old_link_id, new_link_id)
                        occupied_link_ids.add(new_link_id)
                        target["id"] = new_link_id
                    if "reroute" in item:
                        target["reroute"] = deepcopy(item["reroute"])
            for link in raw_def_links:
                if not isinstance(link, Mapping):
                    continue
                if type(link.get("origin_id")) is int:
                    link["origin_id"] = node_id_remap.get(link["origin_id"], link["origin_id"])
                if type(link.get("target_id")) is int:
                    link["target_id"] = node_id_remap.get(link["target_id"], link["target_id"])
            if isinstance(raw_def_links, list):
                for node in out_nodes:
                    if not isinstance(node, Mapping):
                        continue
                    inputs = node.get("inputs")
                    if isinstance(inputs, list):
                        for input_slot in inputs:
                            if isinstance(input_slot, Mapping) and type(input_slot.get("link")) is int:
                                input_slot["link"] = link_id_remap.get(input_slot["link"], input_slot["link"])
                    outputs = node.get("outputs")
                    if isinstance(outputs, list):
                        for output_slot in outputs:
                            if not isinstance(output_slot, Mapping) or not isinstance(output_slot.get("links"), list):
                                continue
                            output_slot["links"] = [
                                link_id_remap.get(link_id, link_id)
                                for link_id in output_slot["links"]
                            ]
            walk(definition.get("definitions"), (*parent, key))

    walk(definitions.get("subgraphs", definitions), ())
    missing = [str(uid) for uid in side_nodes if str(uid) not in handled]
    if missing:
        raise ValueError(f"sidecar contains unmaterialized recursive node(s): {missing!r}")


def offline_emitter_normalizer_self_consistency_check(
    wf: Any,
    *,
    schema_provider: Any = None,
) -> tuple[bool, list[str]]:
    """Self-consistency check: emitter and normalizer agree on the same IR.

    Proves that ``emit_ui_json`` and ``_normalize_ui_to_api`` are inverses of
    each other on the given workflow — NOT that the result is correct relative
    to ComfyUI's own output.  After compile('api') drops muted/bypassed nodes,
    the compare is against the potentially-smaller compiled graph.

    This NEVER imports ComfyUI — it calls the pure-Python ``_normalize_ui_to_api``
    fallback directly rather than ``normalize_to_api`` (which would try the comfy
    converter).  Returns ``(equivalent, diffs)``.
    """
    from vibecomfy.ingest.normalize import _normalize_ui_to_api
    from vibecomfy.porting.parity import compile_equivalent

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        ui = emit_ui_json(wf, schema_provider=schema_provider)
    api = wf.compile("api")
    normalized = _normalize_ui_to_api(ui, schema_provider=schema_provider)
    return compile_equivalent(normalized, api)


def _node_schema_for_structural(
    class_type: str,
    schema_provider: Any,
    cache: dict[str, Any],
) -> Any:
    if class_type not in cache:
        cache[class_type] = (
            schema_provider.get_schema(class_type) if schema_provider is not None else None
        )
    return cache[class_type]


def structural_validate(
    envelope: dict[str, Any],
    *,
    schema_provider: Any = None,
) -> dict[str, Any]:
    """Structural-validation pass over an emitted litegraph envelope.

    Checks performed:

    - **Link endpoints exist.** Every ``links[]`` entry's ``from_node``/``to_node``
      must be a node in the envelope, and ``from_slot``/``to_slot`` must index into
      that node's ``outputs``/``inputs`` arrays.
    - **Slot counts vs schema** and **widgets_values length vs widget count** — ONLY
      for nodes that have a schema (committed widget table or provider schema).  For
      schema-less nodes these assertions are SKIPPED and the skip is recorded.

    Returns a report dict ``{"ok": bool, "errors": [...], "skipped": [...]}``.  ``ok``
    is ``True`` iff ``errors`` is empty; the caller decides whether to raise.
    """
    errors: list[str] = []
    skipped: list[dict[str, Any]] = []
    nodes_by_id = {n["id"]: n for n in envelope.get("nodes", [])}

    # 1) Link endpoints (node + slot) exist.
    for link in envelope.get("links", []):
        lid, from_node, from_slot, to_node, to_slot = link[0], link[1], link[2], link[3], link[4]
        src = nodes_by_id.get(from_node)
        dst = nodes_by_id.get(to_node)
        if src is None:
            errors.append(f"link {lid}: from_node {from_node} not in nodes")
        elif not (0 <= from_slot < len(src.get("outputs", []))):
            errors.append(
                f"link {lid}: from_slot {from_slot} out of range for node {from_node} "
                f"({len(src.get('outputs', []))} outputs)"
            )
        if dst is None:
            errors.append(f"link {lid}: to_node {to_node} not in nodes")
        elif not (0 <= to_slot < len(dst.get("inputs", []))):
            errors.append(
                f"link {lid}: to_slot {to_slot} out of range for node {to_node} "
                f"({len(dst.get('inputs', []))} inputs)"
            )

    # 2) Per-node slot/widget-length assertions for nodes WITH a schema only.
    cache: dict[str, Any] = {}
    for node in envelope.get("nodes", []):
        class_type = node["type"]
        schema = _node_schema_for_structural(class_type, schema_provider, cache)
        widget_count = _full_widget_name_count(class_type, schema, schema_provider=schema_provider)
        schema_outputs = list(getattr(schema, "outputs", None) or []) if schema else None

        if widget_count is None and not schema_outputs:
            # Schema-less for both widget and output purposes: skip + record.
            skipped.append(
                {
                    "node_id": node["id"],
                    "class_type": class_type,
                    "reason": "schema-less: slot/widget-length assertions skipped",
                }
            )
            continue

        if widget_count is not None:
            wv_len = len(node.get("widgets_values", []))
            if wv_len > widget_count:
                # Committed widget tables can be a named subset of live
                # source slots (widget_N / extra UI widgets).  Extra values
                # are retained; they are not a missing-schema hard error.
                skipped.append(
                    {
                        "node_id": node["id"],
                        "class_type": class_type,
                        "reason": (
                            f"widgets_values length {wv_len} exceeds schema "
                            f"widget count {widget_count}; extra source slots retained"
                        ),
                    }
                )
        else:
            skipped.append(
                {
                    "node_id": node["id"],
                    "class_type": class_type,
                    "reason": "no widget schema: widgets_values length check skipped",
                }
            )

        if schema_outputs is not None:
            emitted_outputs = len(node.get("outputs", []))
            schema_output_count = len(schema_outputs)
            if class_type in _DYNAMIC_OUTPUT_COUNT_INPUTS and emitted_outputs >= schema_output_count:
                # The static object_info row contains only the base return
                # type; the editor's split_count-derived sockets are valid
                # and have already been checked by the link endpoint pass.
                skipped.append(
                    {
                        "node_id": node["id"],
                        "class_type": class_type,
                        "reason": (
                            f"dynamic output count {emitted_outputs} is derived "
                            f"from split_count; schema base {schema_output_count}"
                        ),
                    }
                )
                continue
            if emitted_outputs > schema_output_count:
                errors.append(
                    f"node {node['id']}({class_type}): output slot count "
                    f"{emitted_outputs} != schema output count {schema_output_count}"
                )
            elif emitted_outputs < schema_output_count:
                # Source-faithful pin (SaveImage/SaveVideo often emit
                # outputs=[] while the schema lists a dummy socket).
                skipped.append(
                    {
                        "node_id": node["id"],
                        "class_type": class_type,
                        "reason": (
                            f"source-faithful output count {emitted_outputs} "
                            f"< schema {schema_output_count}"
                        ),
                    }
                )

    return {"ok": not errors, "errors": errors, "skipped": skipped}


__all__ = [
    "WidgetShapeEvidence",
    "derive_widget_shape_evidence",
    "extract_raw_ui_node_map",
    "materialize_litegraph_node",
    "materialize_ui_json",
    "_normalize_pinned_node_link_refs",
    "_raw_ui_payload_for_pin",
    "emit_ui_json",
    "offline_emitter_normalizer_self_consistency_check",
    "structural_validate",
    "default_output_path",
    "ExitGuardResult",
    "guard_exit_ui",
    "pin_untouched_ui",
]


# ── Emit-exit fidelity guard (batch 15) ──
"""Independent emit-exit fidelity guard.

Validates that ``emit(workflow)`` differs from the original ingest UI only
where the accepted Δ (landed ops) attributes a change.  This is the
IR/emit successor of the raw-JSON ``guard_full_ui`` invariant: untouched
nodes, links, and scope fields stay byte-identical.
"""

from dataclasses import dataclass
from typing import Any, Iterable, Literal, Mapping, Sequence

from vibecomfy.porting.edit.ops import (
    AddNodeOp,
    EditOp,
    LinkTargetRef,
    RemoveLinkOp,
    RemoveNodeOp,
    SetModeOp,
    SetNodeFieldOp,
    SubgraphInterfaceOp,
    UpsertLinkOp,
)
from vibecomfy.porting.report import PortIssue


def _issue(
    code: str,
    message: str,
    *,
    severity: Literal["error", "warning", "info"] = "error",
    detail: Mapping[str, Any] | None = None,
) -> PortIssue:
    return PortIssue(code=code, message=message, severity=severity, detail=dict(detail or {}))


@dataclass(frozen=True, slots=True)
class ExitGuardResult:
    ok: bool
    diagnostics: tuple[PortIssue, ...] = ()
    normalize_fallback_used: bool = False
    normalize_allow_list_used: bool = False


def _node_uid(node: Mapping[str, Any]) -> str | None:
    properties = node.get("properties")
    if isinstance(properties, Mapping):
        uid = properties.get("vibecomfy_uid")
        if isinstance(uid, str) and uid:
            return uid
    node_id = node.get("id")
    if node_id is None:
        return None
    text = str(node_id)
    return text or None


def _link_id(link: Any) -> int | None:
    if isinstance(link, Mapping):
        value = link.get("id")
        return value if type(value) is int else None
    if isinstance(link, Sequence) and not isinstance(link, (str, bytes)):
        if link and type(link[0]) is int:
            return link[0]
    return None


def _canonical_native_int(value: Any) -> int | None:
    """Return a LiteGraph native ID/slot only when its wire type is canonical."""
    if type(value) is int and value >= 0:
        return value
    if isinstance(value, str) and value.isdigit():
        return int(value)
    return None


def _iter_scopes(graph: Mapping[str, Any], scope_path: str = "") -> list[tuple[str, Mapping[str, Any]]]:
    scopes: list[tuple[str, Mapping[str, Any]]] = [(scope_path, graph)]
    definitions = graph.get("definitions")
    if not isinstance(definitions, Mapping):
        return scopes
    subgraphs = definitions.get("subgraphs")
    if not isinstance(subgraphs, list):
        return scopes
    for index, definition in enumerate(subgraphs):
        if isinstance(definition, Mapping):
            child = f"{scope_path}/sg{index}" if scope_path else f"sg{index}"
            scopes.extend(_iter_scopes(definition, child))
    return scopes


def _index_nodes(graph: Mapping[str, Any]) -> dict[tuple[str, str], Mapping[str, Any]]:
    index: dict[tuple[str, str], Mapping[str, Any]] = {}
    for scope_path, scope in _iter_scopes(graph):
        nodes = scope.get("nodes")
        if not isinstance(nodes, list):
            continue
        for node in nodes:
            if not isinstance(node, Mapping):
                continue
            uid = _node_uid(node)
            if uid is not None:
                index[(scope_path, uid)] = node
    return index


def _index_links(graph: Mapping[str, Any]) -> dict[tuple[str, int], Any]:
    index: dict[tuple[str, int], Any] = {}
    for scope_path, scope in _iter_scopes(graph):
        links = scope.get("links")
        if not isinstance(links, list):
            continue
        for link in links:
            link_id = _link_id(link)
            if link_id is not None:
                index[(scope_path, link_id)] = link
    return index


def _nodes_by_native_id(scope: Mapping[str, Any]) -> dict[str, Mapping[str, Any]]:
    nodes = scope.get("nodes")
    if not isinstance(nodes, list):
        return {}
    return {
        str(node.get("id")): node
        for node in nodes
        if isinstance(node, Mapping) and node.get("id") is not None
    }


def _socket_name_at(node: Mapping[str, Any] | None, direction: str, slot: Any) -> str | None:
    if not isinstance(node, Mapping) or not isinstance(slot, int):
        return None
    sockets = node.get("inputs" if direction == "input" else "outputs")
    if not isinstance(sockets, list) or not (0 <= slot < len(sockets)):
        return None
    socket = sockets[slot]
    if not isinstance(socket, Mapping):
        return None
    name = socket.get("name")
    return str(name) if isinstance(name, str) and name else None


def _remap_preserved_inbound_links(
    original_scope: Mapping[str, Any],
    candidate_scope: Mapping[str, Any],
    links: Sequence[Any],
    *,
    changed_target_ids: set[str],
    materialized_input_names: Mapping[str, set[str]] | None = None,
) -> list[Any]:
    """Re-slot preserved links whose target input array was materialized anew."""
    if not changed_target_ids:
        return deepcopy(list(links))
    original_nodes = _nodes_by_native_id(original_scope)
    candidate_nodes = _nodes_by_native_id(candidate_scope)
    remapped_links: list[Any] = []
    dangling_links: list[dict[str, Any]] = []
    for raw_link in links:
        if not isinstance(raw_link, (list, tuple)) or len(raw_link) != 6:
            remapped_links.append(deepcopy(raw_link))
            continue
        link = list(raw_link)
        _, from_node, from_slot, to_node, to_slot, _socket_type = link
        target_id = str(to_node)
        if target_id not in changed_target_ids:
            remapped_links.append(deepcopy(link))
            continue
        original_target = original_nodes.get(target_id)
        candidate_target = candidate_nodes.get(target_id)
        canonical_name = _socket_name_at(original_target, "input", to_slot)
        candidate_inputs = (
            candidate_target.get("inputs")
            if isinstance(candidate_target, Mapping)
            else None
        )
        remapped = _emitted_input_slot_for_link(
            candidate_inputs, canonical_name or "", to_slot if isinstance(to_slot, int) else None
        )
        if remapped is not None:
            link[4] = remapped
            remapped_links.append(link)
            continue
        if canonical_name in (materialized_input_names or {}).get(target_id, set()):
            # The field write itself replaces this inbound link with a widget
            # value.  Only that explicitly named endpoint may disappear; all
            # remaining links must resolve by canonical name below.
            continue
        source = candidate_nodes.get(str(from_node)) or original_nodes.get(str(from_node))
        outputs = source.get("outputs") if isinstance(source, Mapping) else None
        dangling_links.append(
            {
                "key": f"{from_node}.{from_slot} -> {to_node}.{canonical_name or to_slot}",
                "evidence": {
                    "source": {
                        "node_id": str(from_node),
                        "requested_output": _socket_name_at(source, "output", from_slot)
                        or str(from_slot),
                        "requested_slot": from_slot,
                        "emitted_sockets": _emitted_socket_array_evidence(outputs),
                    },
                    "target": {
                        "node_id": target_id,
                        "requested_input": canonical_name,
                        "requested_slot": to_slot,
                        "emitted_sockets": _emitted_socket_array_evidence(candidate_inputs),
                        "attempted_remaps": _input_remap_attempts_evidence(
                            candidate_inputs,
                            to_slot,
                            canonical_name or "",
                        ),
                    },
                    "missing": "target_socket",
                },
            }
        )
    if dangling_links:
        from vibecomfy.porting.refuse import (  # noqa: PLC0415
            refused_dangling_links as _refused_dangling_links,
        )

        raise _refused_dangling_links(dangling_links)
    return remapped_links


def _scope_node_uids(scope_graph: Mapping[str, Any]) -> list[str]:
    nodes = scope_graph.get("nodes")
    if not isinstance(nodes, list):
        return []
    result: list[str] = []
    for node in nodes:
        if not isinstance(node, Mapping):
            continue
        uid = _node_uid(node)
        if uid is not None:
            result.append(uid)
    return result


def _value_diff_paths(original: Any, candidate: Any, prefix: str = "") -> list[str]:
    if original == candidate:
        return []
    if isinstance(original, Mapping) and isinstance(candidate, Mapping):
        paths: list[str] = []
        for key in sorted(set(original) | set(candidate)):
            child_prefix = f"{prefix}.{key}" if prefix else str(key)
            paths.extend(_value_diff_paths(original.get(key), candidate.get(key), child_prefix))
        return paths
    if isinstance(original, list) and isinstance(candidate, list):
        paths: list[str] = []
        max_len = max(len(original), len(candidate))
        for index in range(max_len):
            child_prefix = f"{prefix}[{index}]"
            left = original[index] if index < len(original) else None
            right = candidate[index] if index < len(candidate) else None
            paths.extend(_value_diff_paths(left, right, child_prefix))
        return paths
    return [prefix or "<root>"]


# Emit may materialize derived identity/layout furniture on every node
# even when the accepted Δ did not touch that node.  These paths are not
# editable-quotient changes and must not fail the exit guard closed.
_EMIT_FURNITURE_PREFIXES = (
    "order",
    "properties.vibecomfy_id",
    "properties._vibecomfy_schema_provider",
)
_EMIT_SCOPE_FURNITURE = frozenset({"version", "id", "extra", "config"})


def _path_is_at_or_below(path: str, allowed: str) -> bool:
    return path == allowed or path.startswith(f"{allowed}.") or path.startswith(f"{allowed}[")


def _is_emit_furniture_path(path: str) -> bool:
    return any(
        path == prefix or path.startswith(f"{prefix}.") or path.startswith(f"{prefix}[")
        for prefix in _EMIT_FURNITURE_PREFIXES
    )


def _is_stable_uid_materialization(
    path: str,
    original_node: Mapping[str, Any],
    candidate_node: Mapping[str, Any],
) -> bool:
    """Allow only the emitter's missing-UID identity stamp.

    An arbitrary vibecomfy_uid rewrite changes node identity and must remain
    visible to the guard. The sole furniture case is materializing a missing
    UID with the native identity already used to match the original node.
    """
    if path != "properties.vibecomfy_uid":
        return False
    original_properties = original_node.get("properties")
    candidate_properties = candidate_node.get("properties")
    if not isinstance(candidate_properties, Mapping):
        return False
    original_uid = (
        original_properties.get("vibecomfy_uid")
        if isinstance(original_properties, Mapping)
        else None
    )
    if original_uid not in (None, ""):
        return False
    native_id = original_node.get("id")
    if native_id is None:
        return False
    return str(candidate_properties.get("vibecomfy_uid") or "") == str(native_id)


def _all_diffs_op_allowed(diffs: list[str], allowed_paths: set[str]) -> bool:
    if not allowed_paths:
        return False
    return all(any(_path_is_at_or_below(diff, allowed) for allowed in allowed_paths) for diff in diffs)


def _set_node_field_allowed_ui_paths(
    original_node: Mapping[str, Any],
    candidate_node: Mapping[str, Any],
    field_paths: set[str],
    *,
    topology_input_fields: set[str] | None = None,
) -> set[str]:
    """Resolve semantic field attribution to the exact LiteGraph paths it owns.

    SetNodeFieldOp names an IR field such as steps, while the UI projection
    stores that value positionally in widgets_values. Do not authorize the
    whole widget array merely because one field was edited.
    """
    allowed: set[str] = set()
    original_widgets = original_node.get("widgets_values")
    candidate_widgets = candidate_node.get("widgets_values")
    if isinstance(original_widgets, Mapping) and isinstance(candidate_widgets, Mapping):
        # Some captured nodes serialize their authored widget surface as a
        # name-keyed mapping rather than LiteGraph's positional array.  Keep
        # attribution equally narrow: a SetNodeField operation owns only the
        # exact pre-existing mapping key it names.
        for field in field_paths:
            field = str(field)
            if field in original_widgets and field in candidate_widgets:
                allowed.add(f"widgets_values.{field}")
    class_type = str(candidate_node.get("type") or original_node.get("type") or "")
    widget_names = widget_names_for_class(class_type) or []
    if not widget_names:
        try:
            from vibecomfy.porting.object_info.consume import (  # noqa: PLC0415
                object_info_widget_value_order,
            )

            widget_names = list(object_info_widget_value_order(class_type))
        except Exception:
            widget_names = []

    # A captured UI node is stronger evidence than a registry/object_info
    # roster.  Registry hydration can fill in a schema for an existing node
    # without knowing the exact compact widget projection that was serialized
    # by that canvas.  In that case the captured input records (when present)
    # are the only reliable source for the widgets_values position.
    captured_widget_names: list[str] = []
    original_inputs = original_node.get("inputs")
    if isinstance(original_inputs, list):
        for item in original_inputs:
            if not isinstance(item, Mapping) or item.get("link") is not None:
                continue
            widget = item.get("widget")
            name = widget.get("name") if isinstance(widget, Mapping) else None
            if isinstance(name, str) and name:
                captured_widget_names.append(name)
    if captured_widget_names:
        # Keep the captured order and only use it when the requested field is
        # actually represented by an input widget.  A schema may contain
        # hidden/UI-only rows which are not input records.
        for field in field_paths:
            if field in captured_widget_names:
                allowed.add(f"widgets_values[{captured_widget_names.index(field)}]")

    attributed_input_names: set[str] = set()
    for field_path in field_paths:
        field = str(field_path)
        index: int | None = None
        if field.startswith("widgets_values[") and field.endswith("]"):
            raw_index = field[len("widgets_values["):-1]
            if raw_index.isdigit():
                index = int(raw_index)
        elif field.startswith("widgets_values."):
            raw_index = field.split(".", 1)[1]
            if raw_index.isdigit():
                index = int(raw_index)
        elif field.startswith("widget_") and field[len("widget_"):].isdigit():
            index = int(field[len("widget_"):])
        else:
            if field in captured_widget_names:
                index = captured_widget_names.index(field)
            else:
                try:
                    index = widget_names.index(field)
                except ValueError:
                    index = None
            attributed_input_names.add(field)
        if index is not None:
            allowed.add(f"widgets_values[{index}]")

    original_inputs = original_node.get("inputs")
    candidate_inputs = candidate_node.get("inputs")
    if (
        attributed_input_names
        and isinstance(original_inputs, list)
        and isinstance(candidate_inputs, list)
        and original_inputs != candidate_inputs
    ):
        # Assigning a literal to a linked input removes precisely that socket.
        # Authorize the array projection only when every other raw socket is
        # byte-identical; unrelated socket drift must still fail closed.
        expected_inputs = [
            item
            for item in original_inputs
            if not (
                isinstance(item, Mapping)
                and str(item.get("name")) in attributed_input_names
            )
        ]
        if candidate_inputs == expected_inputs:
            allowed.add("inputs")
    if (
        topology_input_fields
        and isinstance(original_inputs, list)
        and isinstance(candidate_inputs, list)
        and len(original_inputs) == len(candidate_inputs)
    ):
        # A cumulative UpsertLink/RemoveLink may legitimately update only the
        # native link reference of an input socket.  Keep this authorization
        # byte-precise: a candidate that also changes type/widget/name remains
        # outside the topology operation and fails the strict guard.
        for index, (original_input, candidate_input) in enumerate(
            zip(original_inputs, candidate_inputs)
        ):
            diffs = _value_diff_paths(
                original_input,
                candidate_input,
                f"inputs[{index}]",
            )
            if (
                diffs == [f"inputs[{index}].link"]
                and isinstance(original_input, Mapping)
                and str(original_input.get("name")) in topology_input_fields
            ):
                allowed.add(f"inputs[{index}].link")
    return allowed


def _recomputed_link_counter(scope: Mapping[str, Any] | None) -> int | None:
    """Return the emitter's next link id for a candidate scope."""
    if not isinstance(scope, Mapping):
        return None
    links = scope.get("links")
    if not isinstance(links, list):
        return None
    link_ids: list[int] = []
    for link in links:
        link_id = _link_id(link)
        if link_id is None or link_id < 0:
            return None
        link_ids.append(link_id)
    return max(link_ids, default=-1) + 1


def _recomputed_node_counter(scope: Mapping[str, Any] | None) -> int | None:
    """Return the emitter's highest native node id for a candidate scope."""
    if not isinstance(scope, Mapping):
        return None
    nodes = scope.get("nodes")
    if not isinstance(nodes, list):
        return None
    numeric_ids: list[int] = []
    for node in nodes:
        if not isinstance(node, Mapping) or node.get("id") is None:
            continue
        value = node["id"]
        if type(value) is int and value >= 0:
            numeric_ids.append(value)
        elif isinstance(value, str) and value.isdigit():
            numeric_ids.append(int(value))
        else:
            return None
    return max(numeric_ids, default=0)


def _raw_link_parts(link: Any) -> tuple[Any, Any, Any, Any, Any, Any] | None:
    if isinstance(link, Mapping):
        keys = ("id", "from_node", "from_slot", "to_node", "to_slot", "type")
        if not all(key in link for key in keys):
            # Subgraph definitions in the Comfy/LiteGraph corpus use the
            # historical origin/target spelling.  Keep these links in the
            # raw fold so an untouched subgraph can still be compared
            # exactly (including its negative interface sentinels).
            keys = ("id", "origin_id", "origin_slot", "target_id", "target_slot", "type")
            if not all(key in link for key in keys):
                return None
        return tuple(link[key] for key in keys)  # type: ignore[return-value]
    if isinstance(link, Sequence) and not isinstance(link, (str, bytes)) and len(link) == 6:
        return tuple(link)  # type: ignore[return-value]
    return None


def _scope_node_for_uid(scope: Mapping[str, Any], uid: str) -> Mapping[str, Any] | None:
    nodes = scope.get("nodes")
    if not isinstance(nodes, list):
        return None
    for node in nodes:
        if isinstance(node, Mapping) and _node_uid(node) == str(uid):
            return node
    return None


def _native_node_id(node: Mapping[str, Any] | None) -> int | None:
    if not isinstance(node, Mapping) or node.get("id") is None:
        return None
    return _canonical_native_int(node["id"])


def _input_slot_for_name(node: Mapping[str, Any], name: str) -> int | None:
    inputs = node.get("inputs")
    if not isinstance(inputs, list):
        return None
    for index, slot in enumerate(inputs):
        if isinstance(slot, Mapping) and slot.get("name") == name:
            return index
    return None


def _output_slot_for_ref(node: Mapping[str, Any], output: str | int) -> int | None:
    if type(output) is int and output >= 0:
        return output
    outputs = node.get("outputs")
    if not isinstance(outputs, list) or not isinstance(output, str):
        return None
    for index, slot in enumerate(outputs):
        if not isinstance(slot, Mapping):
            continue
        if slot.get("name") == output:
            slot_index = slot.get("slot_index", index)
            return slot_index if type(slot_index) is int and slot_index >= 0 else None
    # Virtual/helper outputs are serialized as ``unknown_<N>`` by the IR
    # authoring surface, while schema-less LiteGraph nodes expose the same
    # socket as ``*`` (or ``output_<N>``). The numeric suffix is the stable
    # slot identity; resolving it here keeps topology-fold attribution
    # consistent with the emitter and avoids false
    # ``full_ui_link_changed_unattributed`` failures.
    import re

    match = re.fullmatch(r"(?:unknown|output)_(\d+)", output)
    if match is not None:
        index = int(match.group(1))
        if 0 <= index < len(outputs):
            return index
    typed = re.fullmatch(r"(.+)_(\d+)", output)
    if typed is not None:
        index = int(typed.group(2))
        if 0 <= index < len(outputs):
            slot = outputs[index]
            if isinstance(slot, Mapping):
                token = typed.group(1).casefold()
                if token in {
                    str(slot.get("name") or "").casefold(),
                    str(slot.get("type") or "").casefold(),
                }:
                    return index
    return None


def _link_matches_remove_target(
    link: Any,
    target: Any,
    scope: Mapping[str, Any],
) -> bool:
    parts = _raw_link_parts(link)
    node = _scope_node_for_uid(scope, target.uid)
    native_id = _native_node_id(node)
    input_slot = _input_slot_for_name(node, target.input_field) if node is not None else None
    native_int = _canonical_native_int(native_id)
    target_int = _canonical_native_int(parts[3]) if parts is not None else None
    input_int = _canonical_native_int(parts[4]) if parts is not None else None
    return bool(
        parts is not None
        and native_int is not None
        and input_slot is not None
        and target_int == native_int
        and input_int == input_slot
    )


def _link_matches_upsert(link: Any, op: UpsertLinkOp, scope: Mapping[str, Any]) -> bool:
    parts = _raw_link_parts(link)
    source = _scope_node_for_uid(scope, op.source.uid)
    target = _scope_node_for_uid(scope, op.target.uid)
    source_id = _native_node_id(source)
    target_id = _native_node_id(target)
    source_slot = _output_slot_for_ref(source, op.source.output_slot) if source is not None else None
    target_slot = _input_slot_for_name(target, op.target.input_field) if target is not None else None
    source_int = _canonical_native_int(source_id)
    target_int = _canonical_native_int(target_id)
    from_node = _canonical_native_int(parts[1]) if parts is not None else None
    from_slot = _canonical_native_int(parts[2]) if parts is not None else None
    to_node = _canonical_native_int(parts[3]) if parts is not None else None
    to_slot = _canonical_native_int(parts[4]) if parts is not None else None
    return bool(
        parts is not None
        and source_int is not None
        and target_int is not None
        and source_slot is not None
        and target_slot is not None
        and from_node == source_int
        and from_slot == source_slot
        and to_node == target_int
        and to_slot == target_slot
    )


def _link_ids_by_id(scope: Mapping[str, Any] | None) -> dict[int, Any] | None:
    if not isinstance(scope, Mapping):
        return None
    links = scope.get("links")
    if not isinstance(links, list):
        return None
    indexed: dict[int, Any] = {}
    for link in links:
        link_id = _link_id(link)
        if link_id is None or link_id < 0:
            return None
        if link_id in indexed:
            return None
        indexed[link_id] = link
    return indexed


def _counter_value_valid(value: Any) -> bool:
    return type(value) is int and value >= 0


def _counter_advanced_or_materialized(
    original: Any,
    candidate: Any,
    *,
    field: str,
    original_scope: Mapping[str, Any] | None = None,
    candidate_scope: Mapping[str, Any] | None = None,
    allow_link_removal: bool = False,
    authorized_removed_link_ids: set[int] | None = None,
    allowed_changed_link_ids: set[int] | None = None,
) -> bool:
    if original is None and candidate is None:
        return True
    if original is not None and not _counter_value_valid(original):
        return False
    if candidate is not None and not _counter_value_valid(candidate):
        return False
    if original is None:
        expected = (
            _recomputed_link_counter(candidate_scope)
            if field.rsplit(".", 1)[-1] in {"last_link_id", "lastLinkId"}
            else _recomputed_node_counter(candidate_scope)
        )
        return candidate is not None and expected is not None and candidate == expected
    if candidate is None:
        return False
    if candidate >= original:
        return True
    # Node counters are LiteGraph high-water marks and may never decrease.
    if field.rsplit(".", 1)[-1] not in {"last_link_id", "lastLinkId"}:
        return False
    if not allow_link_removal:
        return False
    original_links = _link_ids_by_id(original_scope)
    candidate_links = _link_ids_by_id(candidate_scope)
    if original_links is None or candidate_links is None:
        return False
    removed_ids = set(original_links) - set(candidate_links)
    added_ids = set(candidate_links) - set(original_links)
    changed_ids: set[int] = set()
    for link_id in set(original_links) & set(candidate_links):
        original_parts = _raw_link_parts(original_links[link_id])
        candidate_parts = _raw_link_parts(candidate_links[link_id])
        if (
            original_parts is None
            or candidate_parts is None
            or original_parts[1:] != candidate_parts[1:]
        ):
            if link_id not in (allowed_changed_link_ids or set()):
                changed_ids.add(link_id)
    expected_removed = authorized_removed_link_ids or set()
    if not removed_ids or removed_ids != expected_removed:
        return False
    if added_ids or changed_ids:
        return False
    return candidate == _recomputed_link_counter(candidate_scope)


def _scope_definition_id(scope: Any) -> str | None:
    if not isinstance(scope, Mapping):
        return None
    scope_id = scope.get("id")
    if scope_id is None:
        return None
    text = str(scope_id)
    return text or None


def _attribution(ops: Iterable[EditOp]) -> dict[str, Any]:
    node_paths: dict[tuple[str, str], set[str]] = {}
    scope_field_paths: dict[str, set[str]] = {}
    removed_nodes: set[tuple[str, str]] = set()
    new_nodes: set[tuple[str, str]] = set()
    touched_scopes: set[str] = set()
    link_ops: set[str] = set()
    link_ops_by_scope: dict[str, list[EditOp]] = {}
    link_removal_ops: set[str] = set()
    new_scope_ids: set[str] = set()
    removed_scope_ids: set[str] = set()
    changed_scope_ids: set[str] = set()
    set_node_fields: dict[tuple[str, str], set[str]] = {}
    # ``SetNodeFieldOp`` and topology ops may touch the same node.  The
    # former owns only its named literal; a target-side link op owns the
    # current link reference in the input socket.  Keep this distinction so
    # pinning does not restore an old link from the ingest snapshot after a
    # cumulative rewire.
    topology_input_fields: dict[tuple[str, str], set[str]] = {}
    topology_output_refs: dict[tuple[str, str], set[str | int]] = {}

    def allow_node_paths(scope_path: str, uid: str, *paths: str) -> None:
        node_paths.setdefault((scope_path, uid), set()).update(paths)
        touched_scopes.add(scope_path)
    def record_link_op(scope_path: str, op: EditOp) -> None:
        link_ops.add(scope_path)
        link_ops_by_scope.setdefault(scope_path, []).append(op)

    def mark_topology_node(scope_path: str, uid: str) -> None:
        # Keep a node in the attribution index without granting either of its
        # socket arrays wholesale.  Exact socket ownership is resolved later
        # against the captured scope (including RemoveLink source inference).
        node_paths.setdefault((scope_path, uid), set())
        touched_scopes.add(scope_path)

    for op in ops:
        if isinstance(op, SetNodeFieldOp):
            allow_node_paths(op.target.scope_path, op.target.uid, "widgets_values", "inputs")
            set_node_fields.setdefault(
                (op.target.scope_path, op.target.uid), set()
            ).add(op.target.field_path)
            # A literal assignment on a previously linked widget auto-unlinks
            # that input. Record the op so later folding can attribute the
            # target socket and the inferred source output; unlinked fields
            # remain a topology no-op.
            record_link_op(op.target.scope_path, op)
            continue
        if isinstance(op, SetModeOp):
            allow_node_paths(op.target.scope_path, op.target.uid, "mode")
            continue
        if isinstance(op, UpsertLinkOp):
            mark_topology_node(op.source.scope_path, op.source.uid)
            mark_topology_node(op.target.scope_path, op.target.uid)
            topology_input_fields.setdefault(
                (op.target.scope_path, op.target.uid), set()
            ).add(str(op.target.input_field))
            topology_output_refs.setdefault(
                (op.source.scope_path, op.source.uid), set()
            ).add(op.source.output_slot)
            record_link_op(op.target.scope_path, op)
            continue
        if isinstance(op, RemoveLinkOp):
            if op.target is not None:
                mark_topology_node(op.target.scope_path, op.target.uid)
                topology_input_fields.setdefault(
                    (op.target.scope_path, op.target.uid), set()
                ).add(str(op.target.input_field))
                record_link_op(op.target.scope_path, op)
                link_removal_ops.add(op.target.scope_path)
            continue
        if isinstance(op, RemoveNodeOp):
            removed_nodes.add((op.target.scope_path, op.target.uid))
            record_link_op(op.target.scope_path, op)
            link_removal_ops.add(op.target.scope_path)
            continue
        if isinstance(op, AddNodeOp):
            uid = op.uid or ""
            if uid:
                new_nodes.add((op.scope_path, uid))
                allow_node_paths(op.scope_path, uid, "widgets_values", "inputs", "outputs", "pos", "size", "properties", "mode", "type", "id", "order", "flags")
            if op.inputs:
                for source in op.inputs.values():
                    allow_node_paths(source.scope_path, source.uid, "outputs")
            scope_field_paths.setdefault(op.scope_path, set()).update({"groups", "last_node_id", "last_link_id"})
            record_link_op(op.scope_path, op)
            continue
        if isinstance(op, SubgraphInterfaceOp):
            # Attribute only the emitted paths this op can touch: root
            # revision / state.lastRerouteId, and the named subgraph
            # signature.  Never the whole state/definitions objects.
            touched_scopes.add("")
            scope_field_paths.setdefault("", set()).update(
                {"revision", "state.lastRerouteId"}
            )
            if op.id:
                sid = str(op.id)
                if op.action == "add":
                    new_scope_ids.add(sid)
                elif op.action == "remove":
                    removed_scope_ids.add(sid)
                else:
                    changed_scope_ids.add(sid)
            continue
    return {
        "node_paths": node_paths,
        "scope_field_paths": scope_field_paths,
        "removed_nodes": removed_nodes,
        "new_nodes": new_nodes,
        "touched_scopes": touched_scopes,
        "link_ops": link_ops,
        "link_ops_by_scope": link_ops_by_scope,
        "link_removal_ops": link_removal_ops,
        "new_scope_ids": new_scope_ids,
        "removed_scope_ids": removed_scope_ids,
        "changed_scope_ids": changed_scope_ids,
        "set_node_fields": set_node_fields,
        "topology_input_fields": topology_input_fields,
        "topology_output_refs": topology_output_refs,
    }


def _unattributed_node_order_change(
    original_ui: Mapping[str, Any],
    candidate_ui: Mapping[str, Any],
    ops: Sequence[EditOp] = (),
) -> bool:
    """Detect node-order drift before furniture pinning can hide it.

    ``pin_untouched_ui`` restores the retained order so ordinary
    reconstructive emission is stable.  The evaluator must nevertheless
    inspect the raw candidate first; otherwise a forged projection that only
    reverses the node list becomes indistinguishable from a valid candidate.
    New and removed nodes are excluded because their relative placement is
    already attributed by the accepted edit.
    """
    attribution = _attribution(ops)
    original_scopes = dict(_iter_scopes(_thaw_json_view(original_ui)))
    candidate_scopes = dict(_iter_scopes(_thaw_json_view(candidate_ui)))

    def _is_deterministic_emitter_order(scope: Mapping[str, Any]) -> bool:
        """Return whether a candidate scope has the emitter's native order.

        The Python surface is dependency ordered, while the UI emitter's
        stable tie-breaker is the canonical native node id.  During
        ``interpret(∅, emit(wf))`` those orders can legitimately differ from
        the retained canvas order as nodes are added one statement at a time.
        This narrow allowance does not make arbitrary projection furniture
        authoritative: a forged permutation still fails unless it is exactly
        the deterministic native-id order produced by this emitter.
        """
        nodes = scope.get("nodes")
        if not isinstance(nodes, list):
            return False
        native_ids: list[int] = []
        for node in nodes:
            if not isinstance(node, Mapping) or type(node.get("id")) is not int:
                return False
            native_ids.append(int(node["id"]))
        return len(native_ids) == len(set(native_ids)) and native_ids == sorted(native_ids)

    for scope_path in set(original_scopes) | set(candidate_scopes):
        original_scope = original_scopes.get(scope_path)
        candidate_scope = candidate_scopes.get(scope_path)
        if not isinstance(original_scope, Mapping) or not isinstance(candidate_scope, Mapping):
            continue
        original_order = [
            uid
            for uid in _scope_node_uids(original_scope)
            if (scope_path, uid) not in attribution["removed_nodes"]
        ]
        candidate_order = [
            uid
            for uid in _scope_node_uids(candidate_scope)
            if uid in set(original_order)
        ]
        if original_order != candidate_order:
            if _is_deterministic_emitter_order(candidate_scope):
                continue
            return True
    return False


def _link_attributed_to_add(
    link: Any,
    scope: Mapping[str, Any],
    ops: Sequence[EditOp],
) -> bool:
    for op in ops:
        if not isinstance(op, AddNodeOp) or not op.uid:
            continue
        target = _scope_node_for_uid(scope, op.uid)
        target_id = _native_node_id(target)
        if target_id is None:
            continue
        for input_name, source in op.inputs.items():
            source_node = _scope_node_for_uid(scope, source.uid)
            source_id = _native_node_id(source_node)
            source_slot = (
                _output_slot_for_ref(source_node, source.output_slot)
                if source_node is not None
                else None
            )
            target_slot = _input_slot_for_name(target, input_name)
            parts = _raw_link_parts(link)
            if (
                parts is not None
                and source_id is not None
                and source_slot is not None
                and target_slot is not None
                and _canonical_native_int(parts[1]) == source_id
                and _canonical_native_int(parts[2]) == source_slot
                and _canonical_native_int(parts[3]) == target_id
                and _canonical_native_int(parts[4]) == target_slot
            ):
                return True
    return False


def _scope_identity_issues(scope: Mapping[str, Any], *, scope_path: str) -> list[PortIssue]:
    """Validate raw UI-list identity before any dict index or attribution."""
    diagnostics: list[PortIssue] = []
    nodes = scope.get("nodes")
    seen_uids: set[str] = set()
    seen_native_ids: set[int] = set()
    if isinstance(nodes, list):
        for node in nodes:
            if not isinstance(node, Mapping):
                diagnostics.append(
                    _issue(
                        "full_ui_identity_malformed",
                        "UI node identity is malformed.",
                        detail={"scope_path": scope_path, "reason": "malformed_node"},
                    )
                )
                continue
            uid = _node_uid(node)
            if uid is None:
                diagnostics.append(
                    _issue(
                        "full_ui_identity_malformed",
                        "UI node has no stable identity.",
                        detail={"scope_path": scope_path, "reason": "missing_uid"},
                    )
                )
            elif uid in seen_uids:
                diagnostics.append(
                    _issue(
                        "full_ui_identity_malformed",
                        "UI node identity is duplicated.",
                        detail={"scope_path": scope_path, "reason": "duplicate_uid", "uid": uid},
                    )
                )
            else:
                seen_uids.add(uid)
            native_id = _canonical_native_int(node.get("id"))
            if native_id is None:
                diagnostics.append(
                    _issue(
                        "full_ui_identity_malformed",
                        "UI native node ID is malformed.",
                        detail={"scope_path": scope_path, "reason": "malformed_native_id"},
                    )
                )
            elif native_id in seen_native_ids:
                    diagnostics.append(
                        _issue(
                            "full_ui_identity_malformed",
                            "UI native node ID is duplicated.",
                            detail={"scope_path": scope_path, "reason": "duplicate_native_id", "id": native_id},
                        )
                    )
            else:
                seen_native_ids.add(native_id)
    links = scope.get("links")
    seen_link_ids: set[int] = set()
    if isinstance(links, list):
        for link in links:
            parts = _raw_link_parts(link)
            legacy_interface = (
                isinstance(link, Mapping)
                and "origin_id" in link
                and "target_id" in link
                and "from_node" not in link
            )
            malformed = (
                parts is None
                or type(parts[0]) is not int
                or parts[0] < 0
                or any(
                    type(value) is not int
                    or (value < 0 and not (legacy_interface and index in (0, 2)))
                    for index, value in enumerate(parts[1:5])
                )
            )
            if malformed:
                diagnostics.append(
                    _issue(
                        "full_ui_identity_malformed",
                        "UI link identity or native endpoint types are malformed.",
                        detail={"scope_path": scope_path, "reason": "malformed_link"},
                    )
                )
                continue
            link_id = parts[0]
            if link_id in seen_link_ids:
                diagnostics.append(
                    _issue(
                        "full_ui_identity_malformed",
                        "UI link ID is duplicated.",
                        detail={"scope_path": scope_path, "reason": "duplicate_link_id", "link_id": link_id},
                    )
                )
            else:
                seen_link_ids.add(link_id)
    return diagnostics


def _expected_ui_links(
    original_scope: Mapping[str, Any],
    scope_ops: Sequence[EditOp],
    candidate_scope: Mapping[str, Any] | None = None,
) -> tuple[list[dict[str, Any]], set[int], set[int], list[PortIssue]]:
    """Fold landed topology ops using the retained UI projection.

    The fold is the producing projection for the exit guard.  Native
    LiteGraph node IDs may be rematerialized by the emitter, so once the
    canonical operation fold is complete, existing endpoint records are
    projected onto the candidate's native IDs by stable UID.  The comparator
    remains deliberately strict: it sees the repaired fold and compares raw
    endpoint tuples exactly, while unknown/ambiguous identities remain
    unprojected and therefore fail closed.
    """
    records: list[dict[str, Any]] = []
    diagnostics: list[PortIssue] = []
    original_ids: set[int] = set()
    for link in original_scope.get("links") or ():
        parts = _raw_link_parts(link)
        if parts is not None:
            records.append({"parts": tuple(parts), "locked": True})
            if type(parts[0]) is int:
                original_ids.add(parts[0])

    def endpoint_match(record: Mapping[str, Any], op: RemoveLinkOp | UpsertLinkOp) -> bool:
        if isinstance(op, RemoveLinkOp):
            return op.target is not None and _link_matches_remove_target(
                record["parts"], op.target, original_scope
            )
        prior_upsert = record.get("origin_op")
        if isinstance(prior_upsert, UpsertLinkOp):
            return prior_upsert.target == op.target
        return _link_matches_remove_target(record["parts"], op.target, original_scope)

    added_uids: set[str] = set()
    for op in scope_ops:
        if isinstance(op, AddNodeOp):
            if op.uid:
                added_uids.add(str(op.uid))
            if op.node_id:
                added_uids.add(str(op.node_id))
            continue
        if isinstance(op, RemoveLinkOp):
            if op.target is not None:
                records = [record for record in records if not endpoint_match(record, op)]
            continue
        if isinstance(op, SetNodeFieldOp):
            unlink_target = LinkTargetRef(
                op.target.scope_path,
                op.target.uid,
                op.target.field_path,
            )
            records = [
                record
                for record in records
                if not _link_matches_remove_target(
                    record["parts"], unlink_target, original_scope
                )
            ]
            continue
        if isinstance(op, UpsertLinkOp):
            source = _scope_node_for_uid(original_scope, op.source.uid)
            target = _scope_node_for_uid(original_scope, op.target.uid)
            source_id = _native_node_id(source)
            target_id = _native_node_id(target)
            source_slot = _output_slot_for_ref(source, op.source.output_slot) if source is not None else None
            target_slot = _input_slot_for_name(target, op.target.input_field) if target is not None else None
            concrete = (
                source_id is not None
                and target_id is not None
                and source_slot is not None
                and target_slot is not None
            )
            references_added_node = (
                (source is None and str(op.source.uid) in added_uids)
                or (target is None and str(op.target.uid) in added_uids)
            )
            if not concrete and not references_added_node:
                # Interpret rejects unresolved endpoints in normal operation.
                # A caller-supplied unresolved upsert must remain a fold no-op.
                continue
            dropped = [record for record in records if endpoint_match(record, op)]
            records = [record for record in records if not endpoint_match(record, op)]
            link_type = dropped[0]["parts"][5] if dropped else ""
            records.append({
                # For a newly-added endpoint the exact candidate coordinates
                # are matched from ``origin_op`` below. Existing endpoints keep
                # their concrete fold coordinates, preserving repeated-upsert
                # and unresolved-upsert semantics.
                "parts": (
                    (None, None, None, None, None, link_type)
                    if references_added_node
                    else (None, source_id, source_slot, target_id, target_slot, link_type)
                ),
                "locked": False,
                "origin_op": op,
            })
            continue
        if isinstance(op, RemoveNodeOp):
            node = _scope_node_for_uid(original_scope, op.target.uid)
            native_id = _native_node_id(node)
            if native_id is None:
                diagnostics.append(
                    _issue(
                        "full_ui_identity_malformed",
                        "RemoveNode target cannot be resolved in the original UI scope.",
                        detail={"reason": "unresolved_remove_node"},
                    )
                )
                continue
            incoming = [record for record in records if record["parts"][3] == native_id]
            outgoing = [record for record in records if record["parts"][1] == native_id]
            records = [
                record
                for record in records
                if record not in incoming and record not in outgoing
            ]
            if (
                isinstance(node, Mapping)
                and node.get("type") == "Reroute"
                and incoming
                and outgoing
            ):
                for source_record, target_record in (
                    (left, right) for left in incoming for right in outgoing
                ):
                    target_parts = target_record["parts"]
                    source_parts = source_record["parts"]
                    link_id = (
                        target_parts[0]
                        if len(incoming) == 1 and len(outgoing) == 1
                        else None
                    )
                    records.append({
                        "parts": (
                            link_id,
                            source_parts[1],
                            source_parts[2],
                            target_parts[3],
                            target_parts[4],
                            target_parts[5],
                        ),
                        "locked": link_id is not None,
                        "origin_op": None,
                        "required_link_ids": (
                            {record["parts"][0] for record in outgoing}
                            if link_id is None
                            else None
                        ),
                    })
    locked_ids = {
        record["parts"][0]
        for record in records
        if record["locked"] and type(record["parts"][0]) is int
    }
    fold_removed_ids = original_ids - locked_ids
    original_by_id = {
        parts[0]: parts
        for link in original_scope.get("links") or ()
        for parts in [_raw_link_parts(link)]
        if parts is not None and type(parts[0]) is int
    }
    allowed_changed_ids = {
        record["parts"][0]
        for record in records
        if record["locked"]
        and type(record["parts"][0]) is int
        and record["parts"][0] in original_by_id
        and tuple(record["parts"][1:]) != tuple(original_by_id[record["parts"][0]][1:])
    }
    if candidate_scope is not None:
        original_nodes_by_id = {
            _canonical_native_int(node.get("id")): _node_uid(node)
            for node in original_scope.get("nodes") or ()
            if isinstance(node, Mapping)
            and _canonical_native_int(node.get("id")) is not None
            and _node_uid(node) is not None
        }
        candidate_ids_by_uid = {
            _node_uid(node): _canonical_native_int(node.get("id"))
            for node in candidate_scope.get("nodes") or ()
            if isinstance(node, Mapping)
            and _node_uid(node) is not None
            and _canonical_native_int(node.get("id")) is not None
        }
        projected: list[dict[str, Any]] = []
        for record in records:
            parts = record["parts"]
            source_uid = original_nodes_by_id.get(_canonical_native_int(parts[1]))
            target_uid = original_nodes_by_id.get(_canonical_native_int(parts[3]))
            source_id = candidate_ids_by_uid.get(source_uid)
            target_id = candidate_ids_by_uid.get(target_uid)
            if source_id is not None and target_id is not None:
                record = dict(record)
                record["parts"] = (
                    parts[0], source_id, parts[2], target_id, parts[4], parts[5]
                )
            projected.append(record)
        records = projected
        allowed_changed_ids = {
            record["parts"][0]
            for record in records
            if record["locked"]
            and type(record["parts"][0]) is int
            and record["parts"][0] in original_by_id
            and tuple(record["parts"][1:]) != tuple(original_by_id[record["parts"][0]][1:])
        }
    return records, fold_removed_ids, allowed_changed_ids, diagnostics


def _compare_expected_ui_links(
    expected: Sequence[Mapping[str, Any]],
    candidate_links: Sequence[Any],
    original_scope: Mapping[str, Any],
    candidate_scope: Mapping[str, Any],
    scope_ops: Sequence[EditOp],
    *,
    scope_path: str,
) -> list[PortIssue]:
    diagnostics: list[PortIssue] = []
    candidate_parts = [_raw_link_parts(link) for link in candidate_links]
    candidate_parts = [parts for parts in candidate_parts if parts is not None]
    by_id = {parts[0]: parts for parts in candidate_parts}
    original_ids = {
        parts[0]
        for link in original_scope.get("links") or ()
        for parts in [_raw_link_parts(link)]
        if parts is not None
    }
    used: set[int] = set()

    for record in expected:
        parts = record["parts"]
        if record["locked"]:
            link_id = parts[0]
            actual = by_id.get(link_id)
            if actual is None:
                diagnostics.append(
                    _issue(
                        "full_ui_link_removed_unattributed",
                        "Candidate removed a link required by the landed topology fold.",
                        detail={"scope_path": scope_path, "link_id": link_id},
                    )
                )
                continue
            used.add(link_id)
            if tuple(actual[1:]) != tuple(parts[1:]):
                diagnostics.append(
                    _issue(
                        "full_ui_link_changed_unattributed",
                        "Candidate changed a link required by the landed topology fold.",
                        detail={"scope_path": scope_path, "link_id": link_id},
                    )
                )
            continue
        origin_op = record.get("origin_op")
        if isinstance(origin_op, UpsertLinkOp):
            matches = (
                actual
                for actual in candidate_parts
                if actual[0] not in used
                and _link_matches_upsert(actual, origin_op, candidate_scope)
            )
        else:
            matches = (
                actual
                for actual in candidate_parts
                if actual[0] not in used
                and tuple(actual[1:]) == tuple(parts[1:])
            )
        match = next(matches, None)
        if match is None:
            diagnostics.append(
                _issue(
                    "full_ui_link_removed_unattributed",
                    "Candidate omitted an unlocked link required by the landed topology fold.",
                    detail={"scope_path": scope_path, "origin": "upsert_or_reroute"},
                )
            )
        else:
            used.add(match[0])
    required_link_ids = {
        link_id
        for record in expected
        for link_id in (record.get("required_link_ids") or ())
    }
    if required_link_ids - used:
        diagnostics.append(
            _issue(
                "full_ui_link_removed_unattributed",
                "Candidate omitted an original Reroute outgoing link ID from the rewired topology.",
                detail={"scope_path": scope_path, "link_ids": sorted(required_link_ids - used)},
            )
        )
    for actual in candidate_parts:
        if actual[0] in used:
            continue
        if actual[0] in original_ids:
            diagnostics.append(
                _issue(
                    "full_ui_link_changed_unattributed",
                    "Candidate retained an original link outside the folded topology.",
                    detail={"scope_path": scope_path, "link_id": actual[0]},
                )
            )
        elif _link_attributed_to_add(actual, candidate_scope, scope_ops):
            continue
        else:
            diagnostics.append(
                _issue(
                    "full_ui_link_added_unattributed",
                    "Candidate added a link outside the folded topology.",
                    detail={"scope_path": scope_path, "link_id": actual[0]},
                )
            )
    return diagnostics


def _guard_counter(
    scope_path: str,
    field: str,
    original: Any,
    candidate: Any,
    *,
    original_scope: Mapping[str, Any] | None = None,
    candidate_scope: Mapping[str, Any] | None = None,
    allow_link_removal: bool = False,
    authorized_removed_link_ids: set[int] | None = None,
    allowed_changed_link_ids: set[int] | None = None,
) -> list[PortIssue]:
    if _counter_advanced_or_materialized(
        original,
        candidate,
        field=field,
        original_scope=original_scope,
        candidate_scope=candidate_scope,
        allow_link_removal=allow_link_removal,
        authorized_removed_link_ids=authorized_removed_link_ids,
        allowed_changed_link_ids=allowed_changed_link_ids,
    ):
        return []
    return [
        _issue(
            "full_ui_counter_changed_unattributed",
            "Candidate changed a LiteGraph id counter except for monotonic advancement.",
            detail={"scope_path": scope_path, "field": field, "original": original, "candidate": candidate},
        )
    ]


def _guard_subgraph_state(
    scope_path: str,
    original: Any,
    candidate: Any,
    allowed_paths: set[str] | None = None,
    *,
    original_scope: Mapping[str, Any] | None = None,
    candidate_scope: Mapping[str, Any] | None = None,
    allow_link_removal: bool = False,
    authorized_removed_link_ids: set[int] | None = None,
    allowed_changed_link_ids: set[int] | None = None,
) -> list[PortIssue]:
    allowed_paths = allowed_paths or set()
    original_state = original if isinstance(original, Mapping) else {}
    candidate_state = candidate if isinstance(candidate, Mapping) else {}
    diagnostics: list[PortIssue] = []
    keys = set(original_state) | set(candidate_state)
    for key in sorted(keys):
        field = f"state.{key}"
        if key in {"lastNodeId", "lastLinkId"}:
            diagnostics.extend(
                _guard_counter(
                    scope_path,
                    field,
                    original_state.get(key),
                    candidate_state.get(key),
                    original_scope=original_scope,
                    candidate_scope=candidate_scope,
                    allow_link_removal=allow_link_removal,
                    authorized_removed_link_ids=authorized_removed_link_ids,
                    allowed_changed_link_ids=allowed_changed_link_ids,
                )
            )
            continue
        if "state" in allowed_paths or any(
            _path_is_at_or_below(field, allowed) for allowed in allowed_paths
        ):
            continue
        if original_state.get(key) != candidate_state.get(key):
            diagnostics.append(
                _issue(
                    "full_ui_scope_field_changed_unattributed",
                    "Candidate changed a subgraph state field without an attributed operation.",
                    detail={"scope_path": scope_path, "field": field},
                )
            )
    return diagnostics


def _socket_link_value(socket: Any) -> Any:
    if not isinstance(socket, Mapping):
        return None
    return socket.get("link")


def _socket_name(socket: Any) -> str | None:
    if not isinstance(socket, Mapping):
        return None
    name = socket.get("name")
    return str(name) if isinstance(name, str) and name else None


def _topology_owned_refs(
    scope_path: str,
    uid: str,
    scope_ops: Sequence[EditOp],
    original_scope: Mapping[str, Any],
) -> tuple[set[str], set[str | int]]:
    """Resolve the exact input/output sockets owned by topology ops.

    ``RemoveLinkOp`` names only its target, so its source output is recovered
    from the current folded endpoint map.  Folding in order is important for
    a remove/upsert/remove batch: the source being removed may have been
    introduced by an earlier upsert rather than exist in the ingest snapshot.
    """
    inputs: set[str] = set()
    outputs: set[str | int] = set()
    endpoint_sources: dict[tuple[str, str], tuple[str, str, str | int]] = {}

    nodes = original_scope.get("nodes")
    native_to_uid: dict[int, str] = {}
    if isinstance(nodes, list):
        for node in nodes:
            if not isinstance(node, Mapping):
                continue
            native = _native_node_id(node)
            node_uid = _node_uid(node)
            if native is not None and node_uid is not None:
                native_to_uid[native] = node_uid

    for link in original_scope.get("links") or ():
        parts = _raw_link_parts(link)
        if parts is None:
            continue
        source_native = _canonical_native_int(parts[1])
        target_native = _canonical_native_int(parts[3])
        source_uid = native_to_uid.get(source_native) if source_native is not None else None
        target_uid = native_to_uid.get(target_native) if target_native is not None else None
        if source_uid is None or target_uid is None:
            continue
        target_node = _scope_node_for_uid(original_scope, target_uid)
        input_name = (
            _socket_name_at(target_node, "input", parts[4])
            if target_node is not None
            else None
        )
        if input_name is not None:
            endpoint_sources[(target_uid, input_name)] = (
                source_uid,
                scope_path,
                parts[2],
            )

    for op in scope_ops:
        if isinstance(op, UpsertLinkOp):
            if op.target.scope_path == scope_path:
                previous = endpoint_sources.get(
                    (op.target.uid, str(op.target.input_field))
                )
                if previous is not None:
                    previous_uid, previous_scope, previous_slot = previous
                    if previous_scope == scope_path and previous_uid == uid:
                        outputs.add(previous_slot)
                endpoint_sources[(op.target.uid, str(op.target.input_field))] = (
                    op.source.uid,
                    op.source.scope_path,
                    op.source.output_slot,
                )
            if op.source.scope_path == scope_path and op.source.uid == uid:
                source_node = _scope_node_for_uid(original_scope, uid)
                output_slot = (
                    _output_slot_for_ref(source_node, op.source.output_slot)
                    if source_node is not None
                    else None
                )
                outputs.add(
                    output_slot
                    if output_slot is not None
                    else op.source.output_slot
                )
            if op.target.scope_path == scope_path and op.target.uid == uid:
                inputs.add(str(op.target.input_field))
            continue
        if isinstance(op, SetNodeFieldOp):
            target_key = (op.target.uid, str(op.target.field_path))
            source = endpoint_sources.get(target_key)
            if source is None:
                continue
            endpoint_sources.pop(target_key, None)
            if op.target.scope_path == scope_path and op.target.uid == uid:
                inputs.add(str(op.target.field_path))
            source_uid, source_scope, source_slot = source
            if source_scope == scope_path and source_uid == uid:
                outputs.add(source_slot)
            continue
        if not isinstance(op, RemoveLinkOp) or op.target is None:
            continue
        target_key = (op.target.uid, str(op.target.input_field))
        if op.target.scope_path == scope_path and op.target.uid == uid:
            inputs.add(str(op.target.input_field))
        source = endpoint_sources.pop(target_key, None)
        if source is not None:
            source_uid, source_scope, source_slot = source
            if source_scope == scope_path and source_uid == uid:
                outputs.add(source_slot)
    return inputs, outputs


def _topology_removed_inputs(
    scope_path: str,
    uid: str,
    scope_ops: Sequence[EditOp],
) -> set[str]:
    state: dict[tuple[str, str], bool] = {}
    for op in scope_ops:
        if isinstance(op, UpsertLinkOp) and op.target.scope_path == scope_path:
            state[(op.target.uid, str(op.target.input_field))] = True
        elif isinstance(op, RemoveLinkOp) and op.target is not None and op.target.scope_path == scope_path:
            state[(op.target.uid, str(op.target.input_field))] = False
        elif isinstance(op, SetNodeFieldOp) and op.target.scope_path == scope_path:
            state[(op.target.uid, str(op.target.field_path))] = False
    return {
        input_name
        for (target_uid, input_name), present in state.items()
        if target_uid == uid and not present
    }


def _topology_allowed_ui_paths(
    original_node: Mapping[str, Any],
    candidate_node: Mapping[str, Any],
    input_names: set[str],
    output_refs: set[str | int],
) -> set[str]:
    """Return exact socket paths, never an entire inputs/outputs array."""
    allowed: set[str] = set()
    original_inputs = original_node.get("inputs")
    if isinstance(original_inputs, list):
        for index, socket in enumerate(original_inputs):
            if isinstance(socket, Mapping) and str(socket.get("name")) in input_names:
                allowed.add(f"inputs[{index}].link")
                # Emitters commonly omit a linked input record after removal.
                if (
                    isinstance(candidate_node.get("inputs"), list)
                    and not any(
                        isinstance(candidate, Mapping)
                        and candidate.get("name") == socket.get("name")
                        for candidate in candidate_node["inputs"]
                    )
                ):
                    allowed.add(f"inputs[{index}]")
    original_outputs = original_node.get("outputs")
    if isinstance(original_outputs, list):
        for index, socket in enumerate(original_outputs):
            if not isinstance(socket, Mapping):
                continue
            name = socket.get("name")
            slot_index = socket.get("slot_index", index)
            if any(
                ref == name or (type(ref) is int and ref == slot_index)
                for ref in output_refs
            ):
                allowed.add(f"outputs[{index}].links")
    return allowed


def _merge_topology_sockets(
    original_node: Mapping[str, Any],
    candidate_node: Mapping[str, Any],
    input_names: set[str],
    output_refs: set[str | int],
    removed_input_names: set[str] | None = None,
    candidate_links: Sequence[Any] | None = None,
) -> dict[str, Any]:
    """Apply only owned link values while preserving socket presentation."""
    merged = deepcopy(dict(original_node))
    removed_input_names = removed_input_names or set()
    candidate_link_parts = [
        parts
        for link in candidate_links or ()
        for parts in [_raw_link_parts(link)]
        if parts is not None
    ]
    native_id = _native_node_id(original_node)
    original_inputs = original_node.get("inputs")
    candidate_inputs = candidate_node.get("inputs")
    if isinstance(original_inputs, list) and isinstance(candidate_inputs, list):
        candidates = {
            str(item.get("name")): item
            for item in candidate_inputs
            if isinstance(item, Mapping) and item.get("name") is not None
        }
        inputs: list[Any] = []
        for original in original_inputs:
            name = _socket_name(original)
            candidate = candidates.get(name or "")
            if name in input_names:
                if name in removed_input_names and _socket_link_value(original) is not None:
                    # A later SetNodeField may reconstruct the stale captured
                    # link record after RemoveLink; the folded topology is
                    # authoritative and the removal must survive pinning.
                    continue
                if candidate is None and _socket_link_value(original) is not None:
                    # Canonical remove projection: linked socket record gone.
                    continue
                current = deepcopy(original)
                input_index = next(
                    (
                        index
                        for index, item in enumerate(original_inputs)
                        if item is original
                    ),
                    None,
                )
                candidate_target_links = (
                    [
                        parts[0]
                        for parts in candidate_link_parts
                        if native_id is not None
                        and _canonical_native_int(parts[3]) == native_id
                        and input_index is not None
                        and _canonical_native_int(parts[4]) == input_index
                    ]
                    if candidate_links is not None
                    else []
                )
                if candidate_links is not None:
                    if candidate_target_links:
                        current["link"] = candidate_target_links[-1]
                    elif _socket_link_value(original) is not None:
                        continue
                    else:
                        current["link"] = None
                elif isinstance(candidate, Mapping) and "link" in candidate:
                    current["link"] = deepcopy(candidate["link"])
                elif candidate is None:
                    current["link"] = None
                inputs.append(current)
            else:
                inputs.append(deepcopy(original))
        original_names = {
            _socket_name(item) for item in original_inputs if _socket_name(item)
        }
        for candidate in candidate_inputs:
            name = _socket_name(candidate)
            if name in input_names and name not in original_names:
                if _socket_link_value(candidate) is not None:
                    inputs.append(deepcopy(candidate))
        merged["inputs"] = inputs

    original_outputs = original_node.get("outputs")
    candidate_outputs = candidate_node.get("outputs")
    if isinstance(original_outputs, list) and isinstance(candidate_outputs, list):
        by_ref: dict[str | int, Mapping[str, Any]] = {}
        for index, socket in enumerate(candidate_outputs):
            if not isinstance(socket, Mapping):
                continue
            by_ref.setdefault(socket.get("name"), socket)
            by_ref.setdefault(index, socket)
            by_ref.setdefault(socket.get("slot_index", index), socket)
        outputs: list[Any] = []
        for index, original in enumerate(original_outputs):
            if not isinstance(original, Mapping):
                outputs.append(deepcopy(original))
                continue
            ref = original.get("name")
            slot_index = original.get("slot_index", index)
            current = deepcopy(original)
            if ref in output_refs or slot_index in output_refs or index in output_refs:
                candidate = by_ref.get(ref) or by_ref.get(slot_index) or by_ref.get(index)
                output_link_ids = (
                    [
                        parts[0]
                        for parts in candidate_link_parts
                        if native_id is not None
                        and _canonical_native_int(parts[1]) == native_id
                        and (
                            _canonical_native_int(parts[2]) == slot_index
                            or _canonical_native_int(parts[2]) == index
                        )
                    ]
                    if candidate_links is not None
                    else None
                )
                if candidate_links is not None:
                    current["links"] = output_link_ids or []
                elif isinstance(candidate, Mapping) and "links" in candidate:
                    current["links"] = deepcopy(candidate["links"])
            outputs.append(current)
        merged["outputs"] = outputs
    return merged


def _topology_socket_changes_exact(
    original_node: Mapping[str, Any],
    candidate_node: Mapping[str, Any],
    input_names: set[str],
    output_refs: set[str | int],
) -> bool:
    """Check topology arrays by socket identity, not positional list diffs."""
    original_inputs = original_node.get("inputs")
    candidate_inputs = candidate_node.get("inputs")
    if isinstance(original_inputs, list) and isinstance(candidate_inputs, list):
        candidate_by_name = {
            _socket_name(item): item
            for item in candidate_inputs
            if _socket_name(item) is not None
        }
        original_names = {
            _socket_name(item) for item in original_inputs if _socket_name(item) is not None
        }
        if len(candidate_by_name) != len(
            [item for item in candidate_inputs if _socket_name(item) is not None]
        ):
            return False
        for original in original_inputs:
            name = _socket_name(original)
            candidate = candidate_by_name.get(name)
            if name in input_names:
                if candidate is None:
                    if _socket_link_value(original) is None:
                        return False
                    continue
                left = dict(original) if isinstance(original, Mapping) else {}
                right = dict(candidate) if isinstance(candidate, Mapping) else {}
                left.pop("link", None)
                right.pop("link", None)
                if left != right:
                    return False
            elif candidate != original:
                return False
        for name, candidate in candidate_by_name.items():
            if name not in original_names:
                if name not in input_names or _socket_link_value(candidate) is None:
                    return False
    elif original_inputs != candidate_inputs:
        return False

    original_outputs = original_node.get("outputs")
    candidate_outputs = candidate_node.get("outputs")
    if isinstance(original_outputs, list) and isinstance(candidate_outputs, list):
        if len(original_outputs) != len(candidate_outputs):
            return False
        for index, (original, candidate) in enumerate(zip(original_outputs, candidate_outputs)):
            if not isinstance(original, Mapping) or not isinstance(candidate, Mapping):
                if original != candidate:
                    return False
                continue
            ref = original.get("name")
            slot_index = original.get("slot_index", index)
            owned = ref in output_refs or slot_index in output_refs or index in output_refs
            if not owned:
                if candidate != original:
                    return False
                continue
            left = dict(original)
            right = dict(candidate)
            left.pop("links", None)
            right.pop("links", None)
            if left != right:
                return False
    elif original_outputs != candidate_outputs:
        return False
    return True


def _topology_socket_values_match_links(
    original_node: Mapping[str, Any],
    candidate_node: Mapping[str, Any],
    input_names: set[str],
    output_refs: set[str | int],
    candidate_links: Sequence[Any],
) -> bool:
    """Require owned socket link values to agree with candidate ``links``."""
    candidate_parts = [
        parts
        for link in candidate_links
        for parts in [_raw_link_parts(link)]
        if parts is not None
    ]
    native_id = _native_node_id(original_node)
    if native_id is None:
        return False
    original_inputs = original_node.get("inputs")
    candidate_inputs = candidate_node.get("inputs")
    candidate_by_name = {
        _socket_name(item): item
        for item in candidate_inputs or ()
        if isinstance(item, Mapping) and _socket_name(item) is not None
    }
    if isinstance(original_inputs, list):
        for index, original in enumerate(original_inputs):
            name = _socket_name(original)
            if name not in input_names:
                continue
            expected = [
                parts[0]
                for parts in candidate_parts
                if _canonical_native_int(parts[3]) == native_id
                and _canonical_native_int(parts[4]) == index
            ]
            candidate = candidate_by_name.get(name)
            if not isinstance(candidate, Mapping) or "link" not in candidate:
                # Sparse UI payloads may omit socket link presentation; when
                # present, however, the value must agree with the link table.
                continue
            actual = candidate.get("link")
            if expected:
                if actual != expected[-1]:
                    return False
            elif actual is not None:
                return False

    original_outputs = original_node.get("outputs")
    candidate_outputs = candidate_node.get("outputs")
    if isinstance(original_outputs, list) and isinstance(candidate_outputs, list):
        for index, original in enumerate(original_outputs):
            if not isinstance(original, Mapping):
                continue
            ref = original.get("name")
            slot_index = original.get("slot_index", index)
            if ref not in output_refs and slot_index not in output_refs and index not in output_refs:
                continue
            if index >= len(candidate_outputs) or not isinstance(candidate_outputs[index], Mapping):
                return False
            expected = [
                parts[0]
                for parts in candidate_parts
                if _canonical_native_int(parts[1]) == native_id
                and (
                    _canonical_native_int(parts[2]) == slot_index
                    or _canonical_native_int(parts[2]) == index
                )
            ]
            if "links" not in candidate_outputs[index]:
                # Sparse UI payloads may omit socket link presentation; when
                # present, however, the value must agree with the link table.
                continue
            actual = candidate_outputs[index].get("links")
            if actual != expected:
                return False
    return True


def _merge_set_field_input_sockets(
    original_inputs: Sequence[Any],
    candidate_inputs: Sequence[Any],
    set_fields: set[str],
    *,
    topology_input_fields: set[str] | None = None,
) -> list[Any]:
    """Preserve captured input records while applying owned link changes.

    The UI emitter is allowed to reconstruct input sockets from a hydrated
    schema.  That projection can change harmless presentation bytes (for
    example ``type: "*"`` to ``type: "UNKNOWN"`` or remove ``widget``), so
    those bytes must remain sourced from the captured UI.  A topology op is
    the one exception: its target input's *link* value comes from the current
    candidate and must win over the captured value.  The named literal field
    may also remove a linked input, or turn it into an unlinked value-bearing
    record; no other candidate socket is admitted.
    """
    topology_input_fields = topology_input_fields or set()
    candidates_by_name: dict[str, list[tuple[int, Mapping[str, Any]]]] = defaultdict(list)
    for index, item in enumerate(candidate_inputs):
        name = _socket_name(item)
        if name is not None and isinstance(item, Mapping):
            candidates_by_name[name].append((index, item))
    used_candidate_indices: set[int] = set()
    merged: list[Any] = []

    for original in original_inputs:
        name = _socket_name(original)
        matches = candidates_by_name.get(name or "", [])
        match: tuple[int, Mapping[str, Any]] | None = None
        for candidate in matches:
            if candidate[0] not in used_candidate_indices:
                match = candidate
                break
        if match is not None:
            used_candidate_indices.add(match[0])
        candidate = match[1] if match is not None else None
        original_link = _socket_link_value(original)
        candidate_link = _socket_link_value(candidate)

        if original_link is not None:
            if candidate is None:
                # A literal assignment to a linked input removes that
                # endpoint.  Other missing records remain untouched.
                if name in set_fields or name in topology_input_fields:
                    continue
                merged.append(deepcopy(original))
                continue
            if candidate_link is None and name in set_fields:
                # Some emit paths retain the socket and carry the new literal
                # in a value field instead of omitting the input record. Keep
                # captured metadata but apply only that owned projection.
                replacement = deepcopy(original)
                replacement["link"] = None
                if "value" in candidate:
                    replacement["value"] = deepcopy(candidate["value"])
                merged.append(replacement)
                continue
            if name in topology_input_fields and candidate_link is not None:
                current = deepcopy(original)
                current["link"] = deepcopy(candidate_link)
                merged.append(current)
                continue
            # A SetNodeField alone does not authorize any linked socket
            # rewrite, including a seemingly harmless type/widget change.
            merged.append(deepcopy(original))
            continue

        # Unlinked captured records are socket metadata, not the literal
        # value itself. Preserve them even when hydration omitted the record
        # or reconstructed it without its widget descriptor. A value-bearing
        # projection is the only owned exception.
        current = deepcopy(original)
        if name in set_fields and isinstance(candidate, Mapping) and "value" in candidate:
            current["value"] = deepcopy(candidate["value"])
        merged.append(current)

    # Existing-node field edits cannot invent a new socket. A target-side
    # topology operation may, however, materialize a previously absent linked
    # endpoint; retain only those candidate records and discard all other
    # reconstructed extras.
    if topology_input_fields:
        for index, candidate in enumerate(candidate_inputs):
            if (
                index in used_candidate_indices
                or _socket_link_value(candidate) is None
                or _socket_name(candidate) not in topology_input_fields
            ):
                continue
            merged.append(deepcopy(candidate))
    return merged


def pin_untouched_ui(
    original_ui: Mapping[str, Any],
    candidate_ui: Mapping[str, Any],
    ops: Sequence[EditOp] = (),
) -> dict[str, Any]:
    """Restore original node/link JSON for anything the accepted Δ did not touch.

    Reconstructive emit rewrites every node.  The exit snapshot must keep
    unattributed nodes and links byte-identical to the ingest UI so
    ``guard_exit_ui`` can fail closed on real drift.
    """
    original_ui = _thaw_json_view(original_ui)
    candidate_ui = _thaw_json_view(candidate_ui)
    attribution = _attribution(ops)
    attributed_nodes = set(attribution["node_paths"]) | set(attribution["new_nodes"])
    pinned = deepcopy(dict(candidate_ui))
    # Definitions are Python-owned semantic state.  Preserve the candidate's
    # identity-based subgraph add/change/remove result while pinning only UI
    # furniture for the retained scopes.
    candidate_definitions = (
        deepcopy(pinned.get("definitions"))
        if any(isinstance(op, SubgraphInterfaceOp) for op in ops)
        else None
    )
    original_nodes = _index_nodes(original_ui)
    original_scopes = dict(_iter_scopes(original_ui))
    # RemoveLinkOp names only the target; include its inferred source node in
    # the pin set so the exact source output link can be carried forward.
    for scope_path, scope_ops in attribution["link_ops_by_scope"].items():
        original_scope = original_scopes.get(scope_path)
        if not isinstance(original_scope, Mapping):
            continue
        for node in original_scope.get("nodes") or ():
            if not isinstance(node, Mapping):
                continue
            uid = _node_uid(node)
            if uid is None:
                continue
            input_refs, output_refs = _topology_owned_refs(
                scope_path, uid, tuple(scope_ops), original_scope
            )
            if input_refs or output_refs:
                attributed_nodes.add((scope_path, uid))
    for scope_path, scope in _iter_scopes(pinned):
        if not isinstance(scope, dict):
            continue
        nodes = scope.get("nodes")
        scope_ops = tuple(attribution["link_ops_by_scope"].get(scope_path, ()))
        original_scope_for_topology = original_scopes.get(scope_path)
        if isinstance(original_scope_for_topology, Mapping):
            # LiteGraph counters are retirement ledgers, not live cardinality.
            # Reconstructive emission can derive a smaller value after the
            # highest-numbered link is removed; pinning must retain the larger
            # observed counter just as it retains all other untouched canvas
            # furniture.
            for counter in ("last_node_id", "last_link_id"):
                original_counter = original_scope_for_topology.get(counter)
                candidate_counter = scope.get(counter)
                if (
                    isinstance(original_counter, int)
                    and not isinstance(original_counter, bool)
                    and (
                        not isinstance(candidate_counter, int)
                        or isinstance(candidate_counter, bool)
                        or original_counter > candidate_counter
                    )
                ):
                    scope[counter] = original_counter
        if isinstance(nodes, list):
            for index, node in enumerate(nodes):
                if not isinstance(node, Mapping):
                    continue
                uid = _node_uid(node)
                if uid is None:
                    continue
                key = (scope_path, uid)
                original_node = original_nodes.get(key)
                if original_node is None:
                    continue
                if key in attributed_nodes:
                    allowed = attribution["node_paths"].get(key, set())
                    merged = deepcopy(dict(original_node))
                    set_fields = attribution["set_node_fields"].get(key, set())
                    topology_input_fields = attribution["topology_input_fields"].get(key, set())
                    topology_output_refs = attribution["topology_output_refs"].get(key, set())
                    resolved_inputs: set[str] = set(topology_input_fields)
                    resolved_outputs: set[str | int] = set(topology_output_refs)
                    removed_input_names: set[str] = set()
                    if isinstance(original_scope_for_topology, Mapping) and scope_ops:
                        folded_inputs, folded_outputs = _topology_owned_refs(
                            scope_path,
                            uid,
                            scope_ops,
                            original_scope_for_topology,
                        )
                        resolved_inputs.update(folded_inputs)
                        resolved_outputs.update(folded_outputs)
                        removed_input_names = _topology_removed_inputs(
                            scope_path, uid, scope_ops
                        )
                    for field in allowed:
                        # A SetNodeField owns only the named literal and the
                        # exact linked endpoint it replaces.  Input socket
                        # metadata is merged below so registry hydration
                        # cannot launder captured type/widget bytes.  A
                        # target-side topology op is allowed to carry the
                        # candidate's current link value through that merge.
                        if field == "inputs" and set_fields:
                            continue
                        if field == "widgets_values" and set_fields:
                            continue
                        if field in node:
                            merged[field] = deepcopy(node[field])
                    if (
                        set_fields
                        and isinstance(original_node.get("inputs"), list)
                        and isinstance(node.get("inputs"), list)
                    ):
                        merged["inputs"] = _merge_set_field_input_sockets(
                            original_node["inputs"],
                            node["inputs"],
                            set_fields,
                            topology_input_fields=topology_input_fields,
                        )
                    if resolved_inputs or resolved_outputs:
                        topology_merged = _merge_topology_sockets(
                            original_node,
                            node,
                            resolved_inputs,
                            resolved_outputs,
                            removed_input_names,
                            scope.get("links"),
                        )
                        if resolved_inputs:
                            merged["inputs"] = topology_merged.get("inputs", merged.get("inputs"))
                        if resolved_outputs:
                            merged["outputs"] = topology_merged.get("outputs", merged.get("outputs"))
                    if set_fields and isinstance(node.get("widgets_values"), list):
                        original_widgets = original_node.get("widgets_values")
                        merged_widgets = (
                            list(original_widgets)
                            if isinstance(original_widgets, list)
                            else []
                        )
                        candidate_widgets = node["widgets_values"]
                        allowed_widget_paths = _set_node_field_allowed_ui_paths(
                            original_node,
                            node,
                            set_fields,
                            topology_input_fields=resolved_inputs,
                        )
                        precise_widget_indices: list[int] = []
                        for path in allowed_widget_paths:
                            if not (
                                path.startswith("widgets_values[") and path.endswith("]")
                            ):
                                continue
                            raw_index = path[len("widgets_values["):-1]
                            if not raw_index.isdigit():
                                continue
                            widget_index = int(raw_index)
                            if widget_index >= len(candidate_widgets):
                                continue
                            precise_widget_indices.append(widget_index)
                        if precise_widget_indices:
                            for widget_index in precise_widget_indices:
                                while len(merged_widgets) <= widget_index:
                                    merged_widgets.append(None)
                                merged_widgets[widget_index] = deepcopy(
                                    candidate_widgets[widget_index]
                                )
                            merged["widgets_values"] = merged_widgets
                        else:
                            merged["widgets_values"] = deepcopy(candidate_widgets)
                    elif set_fields and isinstance(node.get("widgets_values"), Mapping):
                        # Dict-shaped widgets carry authoritative field names;
                        # preserve untouched keys and copy only the exact
                        # schema-admitted fields owned by this delta. No
                        # positional inference is involved.
                        original_widgets = original_node.get("widgets_values")
                        merged_widgets = (
                            deepcopy(dict(original_widgets))
                            if isinstance(original_widgets, Mapping)
                            else {}
                        )
                        candidate_widgets = node["widgets_values"]
                        for field in set_fields:
                            if field in candidate_widgets:
                                merged_widgets[field] = deepcopy(
                                    candidate_widgets[field]
                                )
                        merged["widgets_values"] = merged_widgets
                    # A concrete schema witness is emit furniture rather
                    # than an authored property, but a registry-hydrated
                    # candidate must retain it for the authority receipt. Do
                    # not carry the emitter's low-information ``unknown``
                    # marker across the pin boundary; that remains exactly
                    # the captured property state.
                    candidate_properties = node.get("properties")
                    candidate_provider = (
                        candidate_properties.get("_vibecomfy_schema_provider")
                        if isinstance(candidate_properties, Mapping)
                        else None
                    )
                    if (
                        isinstance(candidate_provider, str)
                        and candidate_provider
                        and candidate_provider.casefold() != "unknown"
                    ):
                        properties = deepcopy(dict(merged.get("properties") or {}))
                        properties["_vibecomfy_schema_provider"] = candidate_provider
                        merged["properties"] = properties
                    nodes[index] = merged
                    continue
                nodes[index] = deepcopy(dict(original_node))
            # Reconstructive emission walks the IR in dependency order, while
            # LiteGraph treats the serialized node list order as presentation
            # state.  Keep the relative order of every retained node exactly
            # as authored; newly added nodes may follow the retained list and
            # are still attributed by ``new_nodes`` in the exit guard.
            candidate_by_uid = {
                _node_uid(node): node
                for node in nodes
                if isinstance(node, Mapping) and _node_uid(node) is not None
            }
            retained_order: list[dict[str, Any]] = []
            used_uids: set[str] = set()
            for original_node in original_scope_for_topology.get("nodes", ()) if isinstance(original_scope_for_topology, Mapping) else ():
                if not isinstance(original_node, Mapping):
                    continue
                uid = _node_uid(original_node)
                if uid is None or uid not in candidate_by_uid:
                    continue
                retained_order.append(candidate_by_uid[uid])
                used_uids.add(uid)
            retained_order.extend(
                node
                for node in nodes
                if isinstance(node, dict) and (_node_uid(node) not in used_uids)
            )
            if retained_order:
                scope["nodes"] = retained_order
        original_scope = original_scopes.get(scope_path)
        if original_scope is None:
            continue
        if scope_path not in attribution["link_ops"] and "links" in original_scope:
            changed_target_ids: set[str] = set()
            materialized_input_names: dict[str, set[str]] = {}
            candidate_by_uid = {
                _node_uid(node): node
                for node in scope.get("nodes") or []
                if isinstance(node, Mapping) and _node_uid(node) is not None
            }
            for (node_scope, uid), allowed in attribution["node_paths"].items():
                if node_scope != scope_path or "inputs" not in allowed:
                    continue
                original_node = original_nodes.get((scope_path, uid))
                candidate_node = candidate_by_uid.get(uid)
                if (
                    isinstance(original_node, Mapping)
                    and isinstance(candidate_node, Mapping)
                    and original_node.get("inputs") != candidate_node.get("inputs")
                    and candidate_node.get("id") is not None
                ):
                    native_id = str(candidate_node["id"])
                    changed_target_ids.add(native_id)
                    materialized_input_names[native_id] = set(
                        attribution["set_node_fields"].get((node_scope, uid), set())
                    )
            scope["links"] = _remap_preserved_inbound_links(
                original_scope,
                scope,
                original_scope.get("links") or [],
                changed_target_ids=changed_target_ids,
                materialized_input_names=materialized_input_names,
            )
        allowed_scope = set(attribution["scope_field_paths"].get(scope_path, set()))
        scope_id = _scope_definition_id(scope) or _scope_definition_id(original_scope)
        if scope_id and scope_id in attribution["changed_scope_ids"]:
            allowed_scope.update({"name", "inputs", "outputs", "revision", "state.lastRerouteId"})
        for key in list(scope):
            if key in {"nodes", "links", "definitions", "last_node_id", "last_link_id"}:
                continue
            if key == "state":
                allowed_state_keys = {
                    allowed.split(".", 1)[1].split(".", 1)[0]
                    for allowed in allowed_scope
                    if allowed.startswith("state.")
                }
                if "state" in allowed_scope:
                    continue
                original_state = original_scope.get("state")
                candidate_state = scope.get("state")
                if allowed_state_keys and isinstance(candidate_state, dict):
                    merged = (
                        deepcopy(dict(original_state))
                        if isinstance(original_state, Mapping)
                        else {}
                    )
                    for state_key in allowed_state_keys:
                        if state_key in candidate_state:
                            merged[state_key] = deepcopy(candidate_state[state_key])
                    if merged:
                        scope["state"] = merged
                    elif "state" in original_scope:
                        scope["state"] = deepcopy(original_scope["state"])
                    else:
                        del scope["state"]
                    continue
                if "state" in original_scope:
                    scope["state"] = deepcopy(original_scope["state"])
                else:
                    del scope["state"]
                continue
            if key in allowed_scope:
                continue
            if key == "groups" and "groups" in allowed_scope:
                continue
            if key in original_scope:
                scope[key] = deepcopy(original_scope[key])
            elif key in _EMIT_SCOPE_FURNITURE or key in {"extra", "config", "groups"}:
                del scope[key]
        # An emitter is allowed to omit untouched optional canvas furniture,
        # but omission is not an edit. Restore missing fields from the
        # retained ingest projection so the strict guard compares only the
        # accepted semantic delta (for example, ``revision`` on an add-node
        # operation).
        for key, value in original_scope.items():
            if key in {"nodes", "links", "definitions", "last_node_id", "last_link_id"}:
                continue
            if key not in scope:
                scope[key] = deepcopy(value)
    if candidate_definitions is not None:
        pinned["definitions"] = candidate_definitions
    return pinned


def guard_exit_ui(
    original_ui: Mapping[str, Any],
    candidate_ui: Mapping[str, Any],
    ops: Sequence[EditOp] = (),
) -> ExitGuardResult:
    """Refuse emit candidates that change UI outside the accepted Δ."""
    original_ui = _thaw_json_view(original_ui)
    candidate_ui = _thaw_json_view(candidate_ui)
    diagnostics: list[PortIssue] = []
    original_scopes = dict(_iter_scopes(original_ui))
    candidate_scopes = dict(_iter_scopes(candidate_ui))
    candidate_scopes_by_id = {
        scope_id: scope
        for _path, scope in candidate_scopes.items()
        for scope_id in (_scope_definition_id(scope),)
        if scope_id is not None
    }
    invalid_identity_scopes: set[str] = set()
    for scope_path in set(original_scopes) | set(candidate_scopes):
        for graph in (original_scopes.get(scope_path), candidate_scopes.get(scope_path)):
            if graph is None:
                continue
            issues = _scope_identity_issues(graph, scope_path=scope_path)
            if issues:
                invalid_identity_scopes.add(scope_path)
                diagnostics.extend(issues)
    for op in ops:
        if isinstance(op, RemoveLinkOp) and op.target is None:
            diagnostics.append(
                _issue(
                    "full_ui_identity_malformed",
                    "A targetless RemoveLink operation cannot be attributed safely.",
                    detail={"reason": "targetless_remove_link"},
                )
            )
    attribution = _attribution(ops)

    for scope_path, original_scope in original_scopes.items():
        candidate_scope = candidate_scopes.get(scope_path)
        original_scope_id = _scope_definition_id(original_scope)
        # Subgraph array indices are presentation paths, not identities.  A
        # removal shifts later siblings, so match retained definitions by id
        # before attributing a missing path as a whole-scope deletion.
        if (
            scope_path
            and
            original_scope_id is not None
            and (
                candidate_scope is None
                or _scope_definition_id(candidate_scope) != original_scope_id
            )
        ):
            candidate_scope = candidate_scopes_by_id.get(original_scope_id)
        if candidate_scope is None:
            removed_id = original_scope_id
            if removed_id and removed_id in attribution["removed_scope_ids"]:
                continue
            diagnostics.append(
                _issue(
                    "full_ui_scope_removed",
                    "Candidate removed a UI scope without an attributed operation.",
                    detail={"scope_path": scope_path},
                )
            )
            continue
        ignored = {"nodes", "links", "definitions"}
        keys = (set(original_scope) | set(candidate_scope)) - ignored
        allowed_scope_paths = set(attribution["scope_field_paths"].get(scope_path, set()))
        scope_ops = tuple(attribution["link_ops_by_scope"].get(scope_path, ()))
        scope_has_link_removal_ops = scope_path in attribution["link_removal_ops"]
        expected_links: list[dict[str, Any]] = []
        fold_removed_ids: set[int] = set()
        allowed_changed_link_ids: set[int] = set()
        if scope_path not in invalid_identity_scopes:
            (
                expected_links,
                fold_removed_ids,
                allowed_changed_link_ids,
                fold_diagnostics,
            ) = _expected_ui_links(
                original_scope,
                scope_ops,
                candidate_scope=candidate_scope,
            )
            diagnostics.extend(fold_diagnostics)
        scope_id = _scope_definition_id(candidate_scope) or _scope_definition_id(original_scope)
        if scope_id and scope_id in attribution["changed_scope_ids"]:
            allowed_scope_paths.update({"name", "inputs", "outputs", "revision", "state.lastRerouteId"})
        for key in sorted(keys):
            if key == "last_node_id":
                diagnostics.extend(
                    _guard_counter(
                        scope_path,
                        key,
                        original_scope.get(key),
                        candidate_scope.get(key),
                        original_scope=original_scope,
                        candidate_scope=candidate_scope,
                        allow_link_removal=scope_has_link_removal_ops,
                        authorized_removed_link_ids=fold_removed_ids,
                        allowed_changed_link_ids=allowed_changed_link_ids,
                    )
                )
                continue
            if key == "last_link_id":
                diagnostics.extend(
                    _guard_counter(
                        scope_path,
                        key,
                        original_scope.get(key),
                        candidate_scope.get(key),
                        original_scope=original_scope,
                        candidate_scope=candidate_scope,
                        allow_link_removal=scope_has_link_removal_ops,
                        authorized_removed_link_ids=fold_removed_ids,
                        allowed_changed_link_ids=allowed_changed_link_ids,
                    )
                )
                continue
            if key == "state":
                diagnostics.extend(
                    _guard_subgraph_state(
                        scope_path,
                        original_scope.get(key),
                        candidate_scope.get(key),
                        allowed_paths=allowed_scope_paths,
                        original_scope=original_scope,
                        candidate_scope=candidate_scope,
                        allow_link_removal=scope_has_link_removal_ops,
                        authorized_removed_link_ids=fold_removed_ids,
                        allowed_changed_link_ids=allowed_changed_link_ids,
                    )
                )
                continue
            if key in _EMIT_SCOPE_FURNITURE or (
                key == "groups" and not original_scope.get("groups")
            ):
                continue
            if key == "groups":
                diffs = _value_diff_paths(original_scope.get(key), candidate_scope.get(key), "groups")
                if not diffs or _all_diffs_op_allowed(diffs, allowed_scope_paths):
                    continue
            if key in allowed_scope_paths:
                continue
            if original_scope.get(key) != candidate_scope.get(key):
                diagnostics.append(
                    _issue(
                        "full_ui_scope_field_changed_unattributed",
                        "Candidate changed a scope-level UI field without an attributed operation.",
                        detail={"scope_path": scope_path, "field": key},
                    )
                )

        original_order = [
            uid for uid in _scope_node_uids(original_scope)
            if (scope_path, uid) not in attribution["removed_nodes"]
        ]
        candidate_order = [
            uid for uid in _scope_node_uids(candidate_scope)
            if (scope_path, uid) not in attribution["new_nodes"]
        ]
        if original_order != candidate_order:
            diagnostics.append(
                _issue(
                    "full_ui_node_order_changed_unattributed",
                    "Candidate changed the relative order of existing nodes without an attributed operation.",
                    detail={"scope_path": scope_path, "original": original_order, "candidate": candidate_order},
                )
            )

        if scope_path not in invalid_identity_scopes:
            diagnostics.extend(
                _compare_expected_ui_links(
                    expected_links,
                    candidate_scope.get("links") or [],
                    original_scope,
                    candidate_scope,
                    scope_ops,
                    scope_path=scope_path,
                )
            )

    for scope_path in candidate_scopes:
        if scope_path not in original_scopes:
            added_id = _scope_definition_id(candidate_scopes[scope_path])
            if added_id and added_id in attribution["new_scope_ids"]:
                continue
            diagnostics.append(
                _issue(
                    "full_ui_scope_added",
                    "Candidate added a UI scope without an attributed operation.",
                    detail={"scope_path": scope_path},
                )
            )

    original_nodes = _index_nodes(original_ui)
    candidate_nodes = _index_nodes(candidate_ui)
    for key, original_node in original_nodes.items():
        scope_path, uid = key
        candidate_node = candidate_nodes.get(key)
        candidate_scope_for_node = candidate_scopes.get(scope_path)
        if not isinstance(candidate_scope_for_node, Mapping):
            candidate_scope_for_node = {}
        if candidate_node is None:
            if key in attribution["removed_nodes"]:
                continue
            diagnostics.append(
                _issue(
                    "full_ui_node_removed_unattributed",
                    "Candidate removed an out-of-delta node.",
                    detail={"scope_path": scope_path, "uid": uid},
                )
            )
            continue
        topology_inputs = set(attribution["topology_input_fields"].get(key, set()))
        topology_outputs = set(attribution["topology_output_refs"].get(key, set()))
        scope_ops_for_node = tuple(attribution["link_ops_by_scope"].get(scope_path, ()))
        original_scope_for_node = original_scopes.get(scope_path)
        if isinstance(original_scope_for_node, Mapping) and scope_ops_for_node:
            folded_inputs, folded_outputs = _topology_owned_refs(
                scope_path,
                uid,
                scope_ops_for_node,
                original_scope_for_node,
            )
            topology_inputs.update(folded_inputs)
            topology_outputs.update(folded_outputs)
        if candidate_node == original_node and not (topology_inputs or topology_outputs):
            continue
        diffs = [
            path
            for path in _value_diff_paths(original_node, candidate_node)
            if not _is_emit_furniture_path(path)
            and not _is_stable_uid_materialization(
                path,
                original_node,
                candidate_node,
            )
        ]
        if not diffs and not (topology_inputs or topology_outputs):
            continue
        allowed_paths = set(attribution["node_paths"].get(key, set()))
        set_fields = attribution["set_node_fields"].get(key, set())
        if set_fields:
            # SetNodeField owns one semantic field, not every widget/input on
            # the node. Resolve that semantic name to its exact UI projection.
            allowed_paths.discard("widgets_values")
            allowed_paths.discard("inputs")
            allowed_paths.update(
                _set_node_field_allowed_ui_paths(
                    original_node,
                    candidate_node,
                    set_fields,
                    topology_input_fields=attribution["topology_input_fields"].get(
                        key, set()
                    ),
                )
            )
        if topology_inputs or topology_outputs:
            if not _topology_socket_values_match_links(
                original_node,
                candidate_node,
                topology_inputs,
                topology_outputs,
                candidate_scope_for_node.get("links") or [],
            ):
                diagnostics.append(
                    _issue(
                        "full_ui_node_changed_unattributed",
                        "Candidate socket link values disagree with its top-level topology.",
                        detail={
                            "scope_path": scope_path,
                            "uid": uid,
                            "field_paths": ["inputs/outputs link topology"],
                        },
                    )
                )
                continue
            if _topology_socket_changes_exact(
                original_node,
                candidate_node,
                topology_inputs,
                topology_outputs,
            ):
                diffs = [
                    path
                    for path in diffs
                    if not path == "inputs"
                    and not path.startswith("inputs[")
                    and not path == "outputs"
                    and not path.startswith("outputs[")
                ]
            allowed_paths.update(
                _topology_allowed_ui_paths(
                    original_node,
                    candidate_node,
                    topology_inputs,
                    topology_outputs,
                )
            )
        if _all_diffs_op_allowed(diffs, allowed_paths):
            continue
        diagnostics.append(
            _issue(
                "full_ui_node_changed_unattributed",
                "Candidate changed an out-of-delta node.",
                detail={"scope_path": scope_path, "uid": uid, "field_paths": diffs[:20]},
            )
        )

    for key in candidate_nodes:
        if key in original_nodes:
            continue
        if key in attribution["new_nodes"]:
            continue
        diagnostics.append(
            _issue(
                "full_ui_node_added_unattributed",
                "Candidate added a node without an attributed add_node operation.",
                detail={"scope_path": key[0], "uid": key[1]},
            )
        )

    return ExitGuardResult(
        ok=not any(issue.severity == "error" for issue in diagnostics),
        diagnostics=tuple(diagnostics),
    )
